<?php

class Circle_IndexController extends Core_Controller_Action_Standard {

	public function init() {
		// code here

	}

	public function indexAction() {
		$log = Zend_Registry::get('Zend_Log');
		if (!$this->_helper->requireUser()->isValid()) {return;}
		if (!$this->_helper->requireAuth()->setAuthParams('circle', null, 'view')->isValid()) {
			return;
		}
		$page = $this->_getParam('page', 1);
		$viewer = Engine_Api::_()->user()->getViewer();
		$viewerId = $viewer->getIdentity();
		$coreApi = Engine_Api::_()->getApi('core', 'circle');
		$select = $coreApi->getCirclesSelect($viewerId);
		if (!empty($_GET['name'])) {
			$circlesTable = Engine_Api::_()->getDbTable('circles', 'circle');
			$usersTable = Engine_Api::_()->getDbTable('users', 'user');
			$networkTable = Engine_Api::_()->getDbtable('networks', 'network');
			$select = $circlesTable->select()
				->setIntegrityCheck(false)
				->from(array('cir' => $circlesTable->info('name')))
				->joinLeft(array('net' => $networkTable->info('name')), 'net.network_id = cir.network_id', array("title as titles"))
				->joinLeft(array('usr' => $usersTable->info('name')), 'usr.user_id = cir.user_id', array("displayname"))
				->where('cir.user_id =? ', $viewerId)
				->where('cir.title LIKE ?', '%' . $_GET['name'] . '%');
		}
		$this->view->paginator = $paginator = Zend_Paginator::factory($select);
		$this->view->paginator = $paginator->setCurrentPageNumber($page);

		// Render

		$this->_helper->content
			->setEnabled()
		;
	}

	public function createAction() {
		$log = Zend_Registry::get('Zend_Log');
		$log->log(":::createAction::Step1 :::: ", Zend_Log::DEBUG);

		$viewer = Engine_Api::_()->user()->getViewer();
		if (!$this->_helper->requireAuth()->setAuthParams('circle', null, 'create')->isValid()) {
			return;
		}

		if (!$this->_helper->requireUser()->isValid()) {
			return;
		}

		$viewerId = $viewer->getIdentity();
		$this->view->form = $form = new Circle_Form_Index_Create();
		// Render
		$this->_helper->content
			->setEnabled()
		;
		if (!$this->getRequest()->isPost()) {
			return;
		}

		if (!$form->isValid($this->getRequest()->getPost())) {
			return;
		}

		$log->log(":::createAction::Step2 :::: ", Zend_Log::DEBUG);
		$table = Engine_Api::_()->getDbtable('networks', 'network');
		$circlesTable = Engine_Api::_()->getDbTable('circles', 'circle');
		$db = $table->getAdapter();
		$db->beginTransaction();

		try
		{
			$values = $form->getValues();
			$values['assignment'] = 2;
			$values['hide'] = 1;

			$network = $table->createRow();
			$network->setFromArray($values);
			$lastInsertedId = $network->save();
			$network->recalculateAll();

			$network->membership()->addMember($viewer)
				->setUserApproved($viewer)
				->setResourceApproved($viewer);

			$circles = $circlesTable->createRow();
			$circles->title = $values['title'];
			$circles->description = $values['description'];
			$circles->user_id = $viewerId;
			$circles->network_id = $lastInsertedId;
			$circles->save();
			if (!empty($values['photo'])) {
				$circles->setPhoto($form->photo);
			}

			$db->commit();
		} catch (Exception $e) {
			$db->rollBack();
			$log->log(":::createAction::Exception :::: " . $e->getMessage(), Zend_Log::DEBUG);
			throw $e;
		}

		return $this->_helper->redirector->gotoRoute(array('action' => 'index'));
	}

	public function viewAction() {
		$log = Zend_Registry::get('Zend_Log');
		$this->view->waiting = $waiting = $this->_getParam('waiting', false);
		$this->view->search = $search = $this->_getParam('search');
		if (!$this->_helper->requireUser()->isValid()) {return;}

		$id = $this->_getParam('id');
		if (null !== $id) {
			$subject = Engine_Api::_()->getItem('circle', $id);
			if ($subject && $subject->getIdentity()) {
				Engine_Api::_()->core()->setSubject($subject);
			}
		}
		$this->view->viewer = $viewer = Engine_Api::_()->user()->getViewer();
		$viewerId = $viewer->getIdentity();
		$this->_helper->requireSubject('circle');

		if (!$this->_helper->requireAuth()->setAuthParams($subject, $viewer, 'circleviews')->isValid()) {
			return;
		}
		// get viewer
		if ($viewer->getIdentity() && ($subject->isOwner($viewer))) {
			$this->view->waitingMembers = $waitingMembers = Zend_Paginator::factory($subject->membership()->getMembersSelect(false));
		}

		$log->log(":::viewAction::step1 :::: " . $viewerId, Zend_Log::DEBUG);
		$coreApi = Engine_Api::_()->getApi('core', 'circle');
		// $select = $coreApi->getCirclesSelect($viewerId);

		// if not showing waiting members, get full members
		$select = $subject->membership()->getMembersObjectSelect();
		if ($search) {
			$select->where('displayname LIKE ?', '%' . $search . '%');
		}
		$this->view->fullMembers = $fullMembers = Zend_Paginator::factory($select);

		// if showing waiting members, or no full members
		if (($viewer->getIdentity() && ($subject->isOwner($viewer))) && ($waiting || ($fullMembers->getTotalItemCount() <= 0 && $search == ''))) {

			$log->log(":::viewAction::if :::: " . $select, Zend_Log::DEBUG);
			$this->view->members = $paginator = $waitingMembers;
			$this->view->waiting = $waiting = true;
		} else {

			$log->log(":::viewAction::else :::: " . $select, Zend_Log::DEBUG);
			$this->view->members = $paginator = $fullMembers;
			$this->view->waiting = $waiting = false;
		}

		$this->view->owner = $subject->isOwner($viewer);
		$this->view->circle = $subject;
		$this->view->circle_id = $id;
		// Render
		$this->_helper->content
			->setEnabled()
		;
	}

	public function inviteAction() {
		$log = Zend_Registry::get('Zend_Log');
		$viewer = Engine_Api::_()->user()->getViewer();
		if (0 !== ($circle_id = (int) $this->_getParam('circle_id')) &&
			null !== ($circle = Engine_Api::_()->getItem('circle', $circle_id))) {
			Engine_Api::_()->core()->setSubject($circle);
			$networkId = $circle->network_id;
			$network = Engine_Api::_()->getItem('network', $networkId);
		}
		if (!$network) {
			return $this->_forward('success', 'utility', 'core', array(
				'messages' => array(Zend_Registry::get('Zend_Translate')->_('Network not exist please try again.')),
				'layout' => 'default-simple',
				'parentRefresh' => true,
			));
		}
		$log->log(":::inviteAction::step1 :::: " . $networkId, Zend_Log::DEBUG);
		if (!$this->_helper->requireAuth()->setAuthParams($circle, $viewer, 'invite')->isValid()) {
			return;
		}
		if (!$this->_helper->requireUser()->isValid()) {
			return;
		}

		if (!$this->_helper->requireSubject('circle')->isValid()) {
			return;
		}

		// @todo auth

		// Prepare data
		$this->view->circle = $circle = Engine_Api::_()->core()->getSubject();

		$log->log(":::inviteAction::step3 :::: " . $circle->getTitle(), Zend_Log::DEBUG);
		$this->view->friends = $friends = $viewer->membership()->getMembers();

		// Prepare form
		$this->view->form = $form = new Circle_Form_Index_Invite();

		$count = 0;
		$multiOptions = array();
		foreach ($friends as $friend) {
			if ($circle->membership()->isMember($friend, null)) {
				continue;
			}

			$multiOptions[$friend->getIdentity()] = $friend->getTitle();
			$count++;
		}
		asort($multiOptions);
		$form->users->addMultiOptions($multiOptions);
		$this->view->count = $count;

		// throw notice if count = 0
		if ($count == 0) {
			return $this->_forward('success', 'utility', 'core', array(
				'messages' => array(Zend_Registry::get('Zend_Translate')->_('You have not friends list to add to the circle.')),
				'layout' => 'default-simple',
				'parentRefresh' => true,
			));
		}

		// Not posting
		if (!$this->getRequest()->isPost()) {
			return;
		}

		if (!$form->isValid($this->getRequest()->getPost())) {
			return;
		}

		// Process
		$table = $circle->getTable();
		$db = $table->getAdapter();
		$db->beginTransaction();

		try
		{
			$usersIds = $form->getValue('users');

			$notifyApi = Engine_Api::_()->getDbtable('notifications', 'activity');
			foreach ($friends as $friend) {
				if (!in_array($friend->getIdentity(), $usersIds)) {
					continue;
				}

				$circle->membership()->addMember($friend)
					->setResourceApproved($friend);

				// $notifyApi->addNotification($friend, $viewer, $circle, 'circle_invite');
				$circle->membership()->setUserApproved($friend);

				//
				$network->membership()->addMember($friend)
					->setUserApproved($friend)
					->setResourceApproved($friend);
			}

			$db->commit();
		} catch (Exception $e) {
			$db->rollBack();

			$log->log(":::inviteAction::exception :::: " . $e->getMessage(), Zend_Log::DEBUG);
			throw $e;
		}

		return $this->_forward('success', 'utility', 'core', array(
			'messages' => array(Zend_Registry::get('Zend_Translate')->_('Members added in circle')),
			'layout' => 'default-simple',
			'parentRefresh' => true,
		));
	}

	public function acceptAction() {
		$log = Zend_Registry::get('Zend_Log');
		$log->log(":::acceptAction::step1 :::: ", Zend_Log::DEBUG);
		if (0 !== ($circle_id = (int) $this->_getParam('circle_id')) &&
			null !== ($circle = Engine_Api::_()->getItem('circle', $circle_id))) {
			Engine_Api::_()->core()->setSubject($circle);
		}

		// Check auth
		if (!$this->_helper->requireUser()->isValid()) {
			return;
		}

		if (!$this->_helper->requireSubject('circle')->isValid()) {
			return;
		}

		// Make form
		$this->view->form = $form = new Circle_Form_Index_Accept();

		// Process form
		if (!$this->getRequest()->isPost()) {
			$this->view->status = false;
			$this->view->error = true;
			$this->view->message = Zend_Registry::get('Zend_Translate')->_('Invalid Method');
			return;
		}

		if (!$form->isValid($this->getRequest()->getPost())) {
			$this->view->status = false;
			$this->view->error = true;
			$this->view->message = Zend_Registry::get('Zend_Translate')->_('Invalid Data');
			return;
		}

		// Process
		$viewer = Engine_Api::_()->user()->getViewer();
		$subject = Engine_Api::_()->core()->getSubject();
		$db = $subject->membership()->getReceiver()->getTable()->getAdapter();
		$db->beginTransaction();

		try
		{
			$subject->membership()->setUserApproved($viewer);

			// Set the request as handled
			$notification = Engine_Api::_()->getDbtable('notifications', 'activity')->getNotificationByObjectAndType(
				$viewer, $subject, 'circle_invite');
			if ($notification) {
				$notification->mitigated = true;
				$notification->save();
			}

			// Add activity
			// $activityApi = Engine_Api::_()->getDbtable('actions', 'activity');
			// $action = $activityApi->addActivity($viewer, $subject, 'group_join');

			$db->commit();
		} catch (Exception $e) {
			$db->rollBack();
			throw $e;
		}

		$this->view->status = true;
		$this->view->error = false;

		$message = Zend_Registry::get('Zend_Translate')->_('You have accepted the invite to the circle %s');
		$message = sprintf($message, $subject->__toString());
		$this->view->message = $message;

		if (null === $this->_helper->contextSwitch->getCurrentContext()) {
			return $this->_forward('success', 'utility', 'core', array(
				'messages' => array($message),
				'layout' => 'default-simple',
				'parentRefresh' => true,
			));
		}
	}

	public function rejectAction() {
		$log = Zend_Registry::get('Zend_Log');
		$log->log(":::rejectAction::step1 :::: ", Zend_Log::DEBUG);
		if (0 !== ($circle_id = (int) $this->_getParam('circle_id')) &&
			null !== ($circle = Engine_Api::_()->getItem('circle', $circle_id))) {
			Engine_Api::_()->core()->setSubject($circle);
		}

		// Check auth
		if (!$this->_helper->requireUser()->isValid()) {
			return;
		}

		if (!$this->_helper->requireSubject('circle')->isValid()) {
			return;
		}

		// Get user
		if (0 === ($user_id = (int) $this->_getParam('user_id')) ||
			null === ($user = Engine_Api::_()->getItem('user', $user_id))) {
			$user = Engine_Api::_()->user()->getViewer();
			//return $this->_helper->requireSubject->forward();
		}

		// Make form
		$this->view->form = $form = new Circle_Form_Index_Reject();

		// Process form
		if (!$this->getRequest()->isPost()) {
			$this->view->status = false;
			$this->view->error = true;
			$this->view->message = Zend_Registry::get('Zend_Translate')->_('Invalid Method');
			return;
		}

		if (!$form->isValid($this->getRequest()->getPost())) {
			$this->view->status = false;
			$this->view->error = true;
			$this->view->message = Zend_Registry::get('Zend_Translate')->_('Invalid Data');
			return;
		}

		// Process
		$viewer = Engine_Api::_()->user()->getViewer();
		$subject = Engine_Api::_()->core()->getSubject();
		$db = $subject->membership()->getReceiver()->getTable()->getAdapter();
		$db->beginTransaction();

		try
		{
			$subject->membership()->removeMember($user);

			// Set the request as handled
			$notification = Engine_Api::_()->getDbtable('notifications', 'activity')->getNotificationByObjectAndType(
				$user, $subject, 'circle_invite');
			if ($notification) {
				$notification->mitigated = true;
				$notification->save();
			}

			$db->commit();
		} catch (Exception $e) {
			$db->rollBack();
			throw $e;
		}

		$this->view->status = true;
		$this->view->error = false;
		$message = Zend_Registry::get('Zend_Translate')->_('You have ignored the invite to the circle %s');
		$message = sprintf($message, $subject->__toString());
		$this->view->message = $message;

		if (null === $this->_helper->contextSwitch->getCurrentContext()) {
			return $this->_forward('success', 'utility', 'core', array(
				'messages' => array($message),
				'layout' => 'default-simple',
				'parentRefresh' => true,
			));
		}
	}

	public function removeAction() {
		$log = Zend_Registry::get('Zend_Log');
		$log->log(":::removeAction::step1 :::: ", Zend_Log::DEBUG);
		if (0 !== ($circle_id = (int) $this->_getParam('circle_id')) &&
			null !== ($circle = Engine_Api::_()->getItem('circle', $circle_id))) {
			Engine_Api::_()->core()->setSubject($circle);
		}

		// Check auth
		if (!$this->_helper->requireUser()->isValid()) {
			return;
		}

		if (!$this->_helper->requireSubject()->isValid()) {
			return;
		}

		// Get user
		if (0 === ($user_id = (int) $this->_getParam('user_id')) ||
			null === ($user = Engine_Api::_()->getItem('user', $user_id))) {
			return $this->_helper->requireSubject->forward();
		}
		//get Network Id

		// Make form
		$this->view->form = $form = new Circle_Form_Index_Remove();

		// Process form
		if ($this->getRequest()->isPost() && $form->isValid($this->getRequest()->getPost())) {

			//$db->beginTransaction();

			try
			{
				Engine_Api::_()->getDbtable('membership', 'circle')->delete(array(
					'resource_id = ?' => $circle_id,
					'user_id = ?' => $user_id,
				));
				Engine_Api::_()->getDbtable('membership', 'network')->delete(array(
					'resource_id = ?' => $circle->network_id,
					'user_id = ?' => $user_id,
				));
				//$db->commit();
			} catch (Exception $e) {
				//$db->rollBack();
				//throw $e;
			}

			return $this->_forward('success', 'utility', 'core', array(
				'messages' => array(Zend_Registry::get('Zend_Translate')->_('Member removed from this circle.')),
				'layout' => 'default-simple',
				'parentRefresh' => true,
			));
		}
	}
	public function editAction() {
		if (!$this->_helper->requireUser()->isValid()) {
			return;
		}

		$viewer = Engine_Api::_()->user()->getViewer();
		$circle = Engine_Api::_()->getItem('circle', $this->_getParam('circle_id'));
		if (!Engine_Api::_()->core()->hasSubject('circle')) {
			Engine_Api::_()->core()->setSubject($circle);
		}
		if (!$this->_helper->requireAuth()->setAuthParams($circle, $viewer, 'edit')->isValid()) {
			return;
		}

		if (!$this->_helper->requireSubject()->isValid()) {
			return;
		}

		// if (!$this->_helper->requireAuth()->setAuthParams($circle, $viewer, 'edit')->isValid()) {
		// 	return;
		// }

		// Get navigation
		$this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
			->getNavigation('circle_main');

		// Prepare form
		$this->view->form = $form = new Circle_Form_Index_Create();

		// Populate form
		$form->populate($circle->toArray());

		// Check post/form
		if (!$this->getRequest()->isPost()) {
			return;
		}
		if (!$form->isValid($this->getRequest()->getPost())) {
			return;
		}

		// Process
		$db = Engine_Db_Table::getDefaultAdapter();
		$db->beginTransaction();

		try {
			$values = $form->getValues();

			$circle->setFromArray($values);
			$circle->save();

			// Add photo
			if (!empty($values['photo'])) {
				$circle->setPhoto($form->photo);
			}
			$db->commit();

		} catch (Exception $e) {
			$db->rollBack();
			throw $e;
		}
		$this->_helper->redirector->gotoRoute(array(), 'circle_general', true);

	}
	public function deleteAction() {
		$viewer = Engine_Api::_()->user()->getViewer();
		$circle_id = $this->getRequest()->getParam('circle_id');
		$circle = Engine_Api::_()->getItem('circle', $circle_id);
		$network = Engine_Api::_()->getItem('network', $circle->network_id);

		if (!$this->_helper->requireAuth()->setAuthParams($circle, $viewer, 'delete')->isValid()) {
			return;
		}
		// In smoothbox
		$this->_helper->layout->setLayout('default-simple');

		$this->view->form = $form = new Circle_Form_Index_Delete();

		if (!$circle) {
			$this->view->status = false;
			$this->view->error = Zend_Registry::get('Zend_Translate')->_("Circle entry doesn't exist or not authorized to delete");
			return;
		}
		if (!$network) {
			$this->view->status = false;
			$this->view->error = Zend_Registry::get('Zend_Translate')->_("Network entry doesn't exist or not authorized to delete");
			return;
		}

		if (!$this->getRequest()->isPost()) {
			$this->view->status = false;
			$this->view->error = Zend_Registry::get('Zend_Translate')->_('Invalid request method');
			return;
		}

		$db = $circle->getTable()->getAdapter();
		$db->beginTransaction();

		try {
			$circle->delete();
			Engine_Api::_()->getDbtable('membership', 'circle')->delete(array(
				'resource_id = ?' => $circle_id,
			));
			$network->delete();
			$db->commit();
		} catch (Exception $e) {
			$db->rollBack();
			throw $e;
		}

		$this->view->status = true;
		$this->view->message = Zend_Registry::get('Zend_Translate')->_('Your circle entry has been deleted.');
		return $this->_forward('success', 'utility', 'core', array(
			'parentRedirect' => Zend_Controller_Front::getInstance()->getRouter()->assemble(array('action' => 'index'), 'circle_general', true),
			'messages' => Array($this->view->message),
		));
	}

}
