<?php
/**
 * SocialEngine
 *
 * @category   Application_Core
 * @package    User
 * @copyright  Copyright 2006-2020 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: content.php 9868 2013-02-12 21:50:45Z shaun $
 * @author     John
 */

return array(
	array(
		'title' => 'Circle Browse Search',
		'description' => 'Displays a search form in the circle browse page.',
		'category' => 'Circle',
		'type' => 'widget',
		'name' => 'circle.browse-search',
		'requirements' => array(
			'no-subject',
		),
	),
	array(
		'title' => 'Circle Browse Menu',
		'description' => 'Displays a menu in the circle gutter.',
		'category' => 'Circle',
		'type' => 'widget',
		'name' => 'circle.browse-menu',
	),
	array(
		'title' => 'Circle Gutter Menu',
		'description' => 'Displays a menu in the circle gutter.',
		'category' => 'Circle',
		'type' => 'widget',
		'name' => 'circle.gutter-menu',
	),
	array(
		'title' => 'Circle Gutter Photo',
		'description' => 'Displays owner\'s or/and circle\'s photo in the circle gutter.',
		'category' => 'Circle',
		'type' => 'widget',
		'name' => 'circle.gutter-photo',
	),
	array(
		'title' => 'Circle Gutter info',
		'description' => 'Displays owner\'s or/and circle\'s information in the circle gutter.',
		'category' => 'Circle',
		'type' => 'widget',
		'name' => 'circle.gutter-info',
	),
)?>
