<?php
/**
 * SocialEngine
 *
 * @category   Application_Core
 * @package    User
 * @copyright  Copyright 2006-2010 Pragma Apps
 * @license    https://pragmaapps.com/license/
 * @version    4.10.5
 * @author     Javed Usmani
 */
class Circle_Model_DbTable_ListItems extends Engine_Db_Table
{
  protected $_rowClass = 'Circle_Model_ListItem';
}