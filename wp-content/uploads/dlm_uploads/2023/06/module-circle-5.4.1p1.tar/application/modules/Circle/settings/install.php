<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Messages
 * @copyright  Copyright 2006-2020 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: install.php 9902 2013-02-14 02:35:41Z shaun $
 * @author     John Boehr <john@socialengine.com>
 */

/**
 * @category   Application_Extensions
 * @package    Messages
 * @copyright  Copyright 2006-2020 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
class Circle_Installer extends Engine_Package_Installer_Module {
	public function onPreInstall() {

		parent::onPreInstall();

		$db = $this->getDb();
		$db->query("CREATE TABLE IF NOT EXISTS `engine4_circle_circles` (
  `circle_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `photo_id` INT NOT NULL DEFAULT '0',
  `user_id` int(11) DEFAULT NULL,
  `network_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`circle_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;");

		$db->query("CREATE TABLE IF NOT EXISTS `engine4_circle_membership` (
  `resource_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `active` tinyint(1) NOT NULL default '0',
  `resource_approved` tinyint(1) NOT NULL default '0',
  `user_approved` tinyint(1) NOT NULL default '0',
  `message` text NULL,
  `title` text NULL,
  PRIMARY KEY  (`resource_id`, `user_id`),
  KEY `REVERSE` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_unicode_ci;");

		$db->query("CREATE TABLE IF NOT EXISTS `engine4_circle_lists` (
  `list_id` int(11) unsigned NOT NULL auto_increment,
  `title` varchar(64) NOT NULL default '',
  `owner_id` int(11) unsigned NOT NULL,
  `child_count` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`list_id`),
  KEY `owner_id` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_unicode_ci;");

		$db->query("CREATE TABLE IF NOT EXISTS `engine4_circle_listitems` (
  `listitem_id` int(11) unsigned NOT NULL auto_increment,
  `list_id` int(11) unsigned NOT NULL,
  `child_id` int(11) unsigned NOT NULL,
  PRIMARY KEY  (`listitem_id`),
  KEY `list_id` (`list_id`),
  KEY `child_id` (`child_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_unicode_ci ;");

		$db->query("INSERT IGNORE INTO `engine4_core_menuitems` (`id`, `name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES
(NULL, 'core_main_circle', 'circle', 'Circle', NULL, '{\"route\":\"default\",\"module\":\"circle\",\"controller\":\"index\",\"action\":\"index\"}', 'core_main', NULL, '1', '0', '999');");

		$db->query("INSERT IGNORE INTO `engine4_core_menuitems` (`id`, `name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES
(NULL, 'circle_main_index', 'circle', 'My Circle', NULL, '{\"route\":\"default\",\"module\":\"circle\",\"controller\":\"index\",\"action\":\"index\"}', 'circle_main', NULL, '1', '0', '999'),
(NULL, 'circle_main_create', 'circle', 'Create new circle', NULL, '{\"route\":\"circle_general\",\"action\":\"create\"}', 'circle_main', NULL, '1', '0', '999');");

		$db->query("INSERT IGNORE INTO `engine4_core_menuitems` (`id`, `name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES
(NULL, 'circle_gutter_edit', 'circle', 'Edit Circle Details', 'Circle_Plugin_Menus', '{\"route\":\"circle_specific\",\"action\":\"edit\",\"class\":\"buttonlink icon_edit\"}', 'circle_gutter', NULL, '1', '0', '999'),
(NULL, 'circle_gutter_delete', 'circle', 'Delete Circle', 'Circle_Plugin_Menus', '{\"route\":\"circle_specific\",\"action\":\"delete\",\"class\":\"buttonlink smoothbox icon_circle_delete\"}', 'circle_gutter', NULL, '1', '0', '999'),
(NULL, 'circle_gutter_invite', 'circle', 'Add Members', 'Circle_Plugin_Menus', '{\"route\":\"circle_specific\",\"action\":\"invite\",\"class\":\"buttonlink smoothbox user_home_invite\"}', 'circle_gutter', NULL, '1', '0', '999'),
(NULL, 'circle_gutter_create', 'circle', 'Create New Circle', 'Circle_Plugin_Menus', '{\"route\":\"circle_general\",\"action\":\"create\",\"class\":\"buttonlink user_home_view\"}', 'circle_gutter', NULL, '1', '0', '999'),
(NULL, 'core_admin_main_plugins_circle', 'circle', 'HE - Circle Networks', NULL, '{\"route\":\"admin_default\",\"module\":\"circle\",\"controller\":\"manage\"}', 'core_admin_main_plugins', NULL, '1', '0', '999'),
(NULL, 'circle_admin_main_level', 'circle', 'Member Level Settings', NULL, '{\"route\":\"admin_default\",\"module\":\"circle\",\"controller\":\"level\"}', 'circle_admin_main', NULL, '1', '0', '2'),
(NULL, 'circle_admin_main_manage', 'circle', 'View Circle', NULL, '{\"route\":\"admin_default\",\"module\":\"circle\",\"controller\":\"manage\"}', 'circle_admin_main', NULL, '1', '0', '1'),
(NULL, 'circle_admin_main_synchronize', 'circle', 'Sync User Circle', NULL, '{\"route\":\"admin_default\",\"module\":\"circle\",\"controller\":\"synchronize\"}', 'circle_admin_main', NULL, '1', '0', '999');");
	}
	public function onInstall() {
		$this->_saveSettins();
		$this->_circleMyPage();
		$this->_circleBrowsePage();
		$this->_circlePageCreate();
		$this->_allowPermission();
		parent::onInstall();
	}
	function onEnable() {
		$this->_saveSettins();
		$this->_circleMyPage();
		$this->_circleBrowsePage();
		$this->_allowPermission();
		$this->_circlePageCreate();

		parent::onEnable();
	}
	protected function _saveSettins() {
		$db = $this->getDb();
		$settingName = 'activity.network.privacy';
		$value = 1;
		$setting = $db->select()
			->from('engine4_core_settings', 'name')
			->where('name = ?', $settingName)
			->limit(1)
			->query()
			->fetchColumn();
		if (!$setting) {
			$db->insert('engine4_core_settings', array(
				'name' => 'activity.network.privacy',
				'value' => $value,
			));
		} else {
			$db->update('engine4_core_settings',
				array('value' => $value),
				array('name = ?' => 'activity.network.privacy')
			);
		}
		//Advance activity
		$select = new Zend_Db_Select($db);
		$select
			->from('engine4_core_modules')
			->where('name = ?', 'advancedactivity')
			->where('enabled = ?', 1);
		$check_sitemenu = $select->query()->fetchObject();
		if ($check_sitemenu) {
			$selectsetting
				->from('engine4_core_settings')
				->where('name = ?', 'advancedactivity.networklist.privacy');
			$check_settings = $selectsetting->query()->fetchObject();
			if ($check_settings) {
				$db->update('engine4_core_settings',
					array('value' => $value),
					array('name = ?' => 'advancedactivity.networklist.privacy')
				);
				//Networks Based Filtering
				$db->update('engine4_core_settings',
					array('value' => 0),
					array('name = ?' => 'advancedactivity.networklist.filtering')
				);

			} else {
				$db->insert('engine4_core_settings', array(
					'name' => 'advancedactivity.networklist.privacy',
					'value' => $value,
				));
				//Networks Based Filtering
				$db->insert('engine4_core_settings', array(
					'name' => 'advancedactivity.networklist.filtering',
					'value' => 0,
				));
			}
		}
	}
	protected function _circlePageCreate() {
		$db = $this->getDb();

		// member browse page
		$pageId = $db->select()
			->from('engine4_core_pages', 'page_id')
			->where('name = ?', 'circle_index_create')
			->limit(1)
			->query()
			->fetchColumn();

		// insert if it doesn't exist yet
		if (!$pageId) {
			// Insert page
			$db->insert('engine4_core_pages', array(
				'name' => 'circle_index_create',
				'displayname' => 'Circle Create Page',
				'title' => 'Circle Create Page',
				'description' => 'This page show to create circle listing.',
				'custom' => 0,
			));
			$pageId = $db->lastInsertId();

			// Insert top
			$db->insert('engine4_core_content', array(
				'type' => 'container',
				'name' => 'top',
				'page_id' => $pageId,
				'order' => 1,
			));
			$topId = $db->lastInsertId();

			// Insert main
			$db->insert('engine4_core_content', array(
				'type' => 'container',
				'name' => 'main',
				'page_id' => $pageId,
				'order' => 2,
			));
			$mainId = $db->lastInsertId();

			// Insert top-middle
			$db->insert('engine4_core_content', array(
				'type' => 'container',
				'name' => 'middle',
				'page_id' => $pageId,
				'parent_content_id' => $topId,
			));
			$topMiddleId = $db->lastInsertId();

			// Insert main-middle
			$db->insert('engine4_core_content', array(
				'type' => 'container',
				'name' => 'middle',
				'page_id' => $pageId,
				'parent_content_id' => $mainId,
				'order' => 2,
			));
			$mainMiddleId = $db->lastInsertId();

			// Insert main-right
			$db->insert('engine4_core_content', array(
				'type' => 'container',
				'name' => 'right',
				'page_id' => $pageId,
				'parent_content_id' => $mainId,
				'order' => 1,
			));
			$mainRightId = $db->lastInsertId();

			// Insert menu
			$db->insert('engine4_core_content', array(
				'type' => 'widget',
				'name' => 'circle.browse-menu',
				'page_id' => $pageId,
				'parent_content_id' => $topMiddleId,
				'order' => 2,
			));

			// Insert content
			$db->insert('engine4_core_content', array(
				'type' => 'widget',
				'name' => 'core.content',
				'page_id' => $pageId,
				'parent_content_id' => $mainMiddleId,
				'order' => 1,
			));

			// Insert search
			$db->insert('engine4_core_content', array(
				'type' => 'widget',
				'name' => 'circle.browse-search',
				'page_id' => $pageId,
				'parent_content_id' => $mainRightId,
				'order' => 1,
			));
		}
	}
	protected function _circleBrowsePage() {
		$db = $this->getDb();

		// profile page
		$pageId = $db->select()
			->from('engine4_core_pages', 'page_id')
			->where('name = ?', 'circle_index_view')
			->limit(1)
			->query()
			->fetchColumn();

		// insert if it doesn't exist yet
		if (!$pageId) {
			// Insert page
			$db->insert('engine4_core_pages', array(
				'name' => 'circle_index_view',
				'displayname' => 'Circle View Page',
				'title' => 'Circle View',
				'description' => 'This page displays a Circle entry.',
				'provides' => 'subject=circle',
				'custom' => 0,
			));
			$pageId = $db->lastInsertId();

			// Insert main
			$db->insert('engine4_core_content', array(
				'type' => 'container',
				'name' => 'main',
				'page_id' => $pageId,
			));
			$mainId = $db->lastInsertId();

			// Insert left
			$db->insert('engine4_core_content', array(
				'type' => 'container',
				'name' => 'left',
				'page_id' => $pageId,
				'parent_content_id' => $mainId,
				'order' => 1,
			));
			$leftId = $db->lastInsertId();

			// Insert middle
			$db->insert('engine4_core_content', array(
				'type' => 'container',
				'name' => 'middle',
				'page_id' => $pageId,
				'parent_content_id' => $mainId,
				'order' => 2,
			));
			$middleId = $db->lastInsertId();

			// Insert gutter
			$db->insert('engine4_core_content', array(
				'type' => 'widget',
				'name' => 'circle.gutter-photo',
				'page_id' => $pageId,
				'parent_content_id' => $leftId,
				'order' => 1,
			));
			$db->insert('engine4_core_content', array(
				'type' => 'widget',
				'name' => 'circle.gutter-menu',
				'page_id' => $pageId,
				'parent_content_id' => $leftId,
				'order' => 2,
			));
			$db->insert('engine4_core_content', array(
				'type' => 'widget',
				'name' => 'circle.gutter-info',
				'page_id' => $pageId,
				'parent_content_id' => $leftId,
				'order' => 2,
			));

			// Insert content
			$db->insert('engine4_core_content', array(
				'type' => 'widget',
				'name' => 'core.content',
				'page_id' => $pageId,
				'parent_content_id' => $middleId,
				'order' => 1,
			));
		}
	}
	protected function _circleMyPage() {
		$db = $this->getDb();

		// member browse page
		$pageId = $db->select()
			->from('engine4_core_pages', 'page_id')
			->where('name = ?', 'circle_index_index')
			->limit(1)
			->query()
			->fetchColumn();

		// insert if it doesn't exist yet
		if (!$pageId) {
			// Insert page
			$db->insert('engine4_core_pages', array(
				'name' => 'circle_index_index',
				'displayname' => 'Circle Home Page',
				'title' => 'Circle Home Page',
				'description' => 'This page show to create home page listing.',
				'custom' => 0,
			));
			$pageId = $db->lastInsertId();

			// Insert top
			$db->insert('engine4_core_content', array(
				'type' => 'container',
				'name' => 'top',
				'page_id' => $pageId,
				'order' => 1,
			));
			$topId = $db->lastInsertId();

			// Insert main
			$db->insert('engine4_core_content', array(
				'type' => 'container',
				'name' => 'main',
				'page_id' => $pageId,
				'order' => 2,
			));
			$mainId = $db->lastInsertId();

			// Insert top-middle
			$db->insert('engine4_core_content', array(
				'type' => 'container',
				'name' => 'middle',
				'page_id' => $pageId,
				'parent_content_id' => $topId,
			));
			$topMiddleId = $db->lastInsertId();

			// Insert main-middle
			$db->insert('engine4_core_content', array(
				'type' => 'container',
				'name' => 'middle',
				'page_id' => $pageId,
				'parent_content_id' => $mainId,
				'order' => 2,
			));
			$mainMiddleId = $db->lastInsertId();

			// Insert main-right
			$db->insert('engine4_core_content', array(
				'type' => 'container',
				'name' => 'right',
				'page_id' => $pageId,
				'parent_content_id' => $mainId,
				'order' => 1,
			));
			$mainRightId = $db->lastInsertId();

			// Insert banner
			$db->insert('engine4_core_banners', array(
				'name' => 'circle',
				'module' => 'circle',
				'title' => 'Get Together in Circles',
				'body' => 'Create and join interest based Circle. Bring people together.',
				'photo_id' => 0,
				'params' => '{"label":"Create New Circle","route":"circle_general","routeParams":{"action":"create"}}',
				'custom' => 0,
			));
			$bannerId = $db->lastInsertId();

			if ($bannerId) {
				$db->insert('engine4_core_content', array(
					'type' => 'widget',
					'name' => 'core.banner',
					'page_id' => $pageId,
					'parent_content_id' => $topMiddleId,
					'params' => '{"title":"","name":"core.banner","banner_id":"' . $bannerId . '","nomobile":"0"}',
					'order' => 1,
				));
			}

			// Insert menu
			$db->insert('engine4_core_content', array(
				'type' => 'widget',
				'name' => 'circle.browse-menu',
				'page_id' => $pageId,
				'parent_content_id' => $topMiddleId,
				'order' => 2,
			));

			// Insert content
			$db->insert('engine4_core_content', array(
				'type' => 'widget',
				'name' => 'core.content',
				'page_id' => $pageId,
				'parent_content_id' => $mainMiddleId,
				'order' => 1,
			));

			// Insert search
			$db->insert('engine4_core_content', array(
				'type' => 'widget',
				'name' => 'circle.browse-search',
				'page_id' => $pageId,
				'parent_content_id' => $mainRightId,
				'order' => 1,
			));
		}
	}
	public function _allowPermission() {
		$db = $this->getDb();
		$db->query("INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'circle' as `type`,
    'view' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user', 'admin');");

		$db->query("INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'circle' as `type`,
    'create' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user', 'admin');");

		$db->query("INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'circle' as `type`,
    'edit' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user', 'admin');");

		$db->query("INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'circle' as `type`,
    'delete' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user', 'admin');");

		$db->query("INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'circle' as `type`,
    'invite' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user', 'admin');");

		$db->query("INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'circle' as `type`,
    'circleviews' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user', 'admin');");

	}

}
