<?php
/**
 * SocialEngine
 *
 * @category   Application_Core
 * @package    User
 * @copyright  Copyright 2006-2010 Pragma Apps
 * @license    https://pragmaapps.com/license/
 * @version    4.10.5
 * @author     Javed Usmani
 */
class Circle_Api_Core extends Core_Api_Abstract {
	public function getCirclesSelect($userId) {
		$log = Zend_Registry::get('Zend_Log');

		// userId Validation
		if (!isset($userId) || $userId == '') {
			return false;
		}

		/// creating query
		$circlesTable = Engine_Api::_()->getDbTable('circles', 'circle');
		$usersTable = Engine_Api::_()->getDbTable('users', 'user');
		$networkTable = Engine_Api::_()->getDbtable('networks', 'network');
		$circlesSelect = $circlesTable->select()
			->setIntegrityCheck(false)
			->from(array('cir' => $circlesTable->info('name')))
			->joinLeft(array('net' => $networkTable->info('name')), 'net.network_id = cir.network_id', array("title as titles"))
			->joinLeft(array('usr' => $usersTable->info('name')), 'usr.user_id = cir.user_id', array("displayname"))
			->where('cir.user_id =? ', $userId);
		return $circlesSelect;
	}
	public function getMemberships($circleId) {
		$log = Zend_Registry::get('Zend_Log');
		$db = Zend_Db_Table_Abstract::getDefaultAdapter();
		$select = "SELECT * FROM `engine4_circle_membership` WHERE (engine4_circle_membership .resource_id = $circleId and engine4_circle_membership .active = 1)";
		$log->log("Step 1 :::" . $select, Zend_Log::DEBUG);
		$results = $db->query($select)->fetchAll();
		return $results;
	}

	public function updateItemCircle(User_Model_User $user, $object) {

		if (!$user->getIdentity()) {
			return;
		}
		$circleArray = array("Colleague", "Family", "Close Friends");
		$table = Engine_Api::_()->getDbtable('networks', 'network');
		$circlesTable = Engine_Api::_()->getDbTable('circles', 'circle');
		//$user = Engine_Api::_()->getItem('user', $user->getIdentity());
		$db = $table->getAdapter();
		$db->beginTransaction();
		foreach ($circleArray as $row) {
			try {
				$values = array();
				$values['title'] = $row;
				$values['description'] = 'This is default circles for user';
				$values['assignment'] = 2;
				$values['hide'] = 1;

				$network = $table->createRow();
				$network->setFromArray($values);
				$lastInsertedId = $network->save();
				$network->recalculateAll();

				$network->membership()->addMember($user)
					->setUserApproved($user)
					->setResourceApproved($user);

				// save details into the circles table
				$circlesTable->insert(array(
					'title' => $values['title'],
					'description' => $values['description'],
					'user_id' => $user->getIdentity(),
					'network_id' => $lastInsertedId,
				));

				$db->commit();
			} catch (Exception $e) {
				$db->rollBack();
				// throw $e;
			}
		}
	}
}
