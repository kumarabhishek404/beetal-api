<?php
/**
 * SocialEngine
 *
 * @category   Application_Core
 * @package    User
 * @copyright  Copyright 2006-2010 Pragma Apps
 * @license    https://pragmaapps.com/license/
 * @version    4.10.5
 * @author     Javed Usmani
 */
class Circle_Form_Index_Create extends Engine_Form {
	public function init() {
		$this
			->setAttrib('id', 'create_circle')
			->setAction($_SERVER['REQUEST_URI']);

		// add title element
		$this->addElement('Text', 'title', array(
			'label' => 'Title',
			'required' => true,
			'filters' => array(
				'StringTrim',
			),
		));

		$this->addElement('TinyMce', 'description', array(
			'disableLoadDefaultDecorators' => true,
			'required' => true,
			'allowEmpty' => false,
			'decorators' => array(
				'ViewHelper',
			),
			'editorOptions' => $editorOptions,
			'filters' => array(
				new Engine_Filter_Censor(),
				new Engine_Filter_Html(array('AllowedTags' => $allowedHtml))),
		));

		$this->addElement('File', 'photo', array(
			'label' => 'Choose Circle Profile Photo',
		));
		$this->photo->addValidator('Extension', false, 'jpg,png,gif,jpeg');

		// Add submit button
		$this->addElement('Button', 'submit', array(
			'label' => 'Save',
			'type' => 'submit',
		));

	}
}