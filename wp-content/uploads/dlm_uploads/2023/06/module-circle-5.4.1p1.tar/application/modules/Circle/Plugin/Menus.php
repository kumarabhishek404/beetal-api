<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Blog
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: Menus.php 9747 2012-07-26 02:08:08Z john $
 * @author     John Boehr <j@webligo.com>
 */

/**
 * @category   Application_Extensions
 * @package    Blog
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
class Circle_Plugin_Menus {

	public function onMenuInitialize_CircleGutterCreate($row) {
		$viewer = Engine_Api::_()->user()->getViewer();
		$request = Zend_Controller_Front::getInstance()->getRequest();

		$circle = Engine_Api::_()->core()->getSubject('circle');

		if (!$circle->authorization()->isAllowed($viewer, 'create')) {
			return false;
		}
		return true;
	}

	public function onMenuInitialize_CircleGutterEdit($row) {
		if (!Engine_Api::_()->core()->hasSubject()) {
			return false;
		}

		$viewer = Engine_Api::_()->user()->getViewer();
		$circle = Engine_Api::_()->core()->getSubject('circle');

		if (!$circle->authorization()->isAllowed($viewer, 'edit')) {
			return false;
		}

		// Modify params
		$params = $row->params;
		$params['params']['circle_id'] = $circle->getIdentity();
		return $params;
	}

	public function onMenuInitialize_CircleGutterDelete($row) {
		if (!Engine_Api::_()->core()->hasSubject()) {
			return false;
		}

		$viewer = Engine_Api::_()->user()->getViewer();
		$circle = Engine_Api::_()->core()->getSubject('circle');

		if (!$circle->authorization()->isAllowed($viewer, 'delete')) {
			return false;
		}
		// Modify params
		$params = $row->params;
		$params['params']['circle_id'] = $circle->getIdentity();
		return $params;
	}
	public function onMenuInitialize_CircleGutterInvite($row) {
		if (!Engine_Api::_()->core()->hasSubject()) {
			return false;
		}

		$viewer = Engine_Api::_()->user()->getViewer();
		$circle = Engine_Api::_()->core()->getSubject('circle');

		if (!$circle->authorization()->isAllowed($viewer, 'invite')) {
			return false;
		}
		// Modify params
		$params = $row->params;
		$params['params']['circle_id'] = $circle->getIdentity();
		return $params;
	}

}