<?php
/**
 * SocialEngine
 *
 * @category   Application_Core
 * @package    User
 * @copyright  Copyright 2006-2010 Pragma Apps
 * @license    https://pragmaapps.com/license/
 * @version    4.10.5
 * @author     Javed Usmani
 */
class Circle_Model_DbTable_Membership extends Core_Model_DbTable_Membership {
	protected $_type = 'circle';

	// Configuration

	/**
	 * Does membership require approval of the resource?
	 *
	 * @param Core_Model_Item_Abstract $resource
	 * @return bool
	 */
	public function isResourceApprovalRequired(Core_Model_Item_Abstract $resource) {
		return 0;
	}
}