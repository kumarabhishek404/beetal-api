scriptJquery(document).ready(function() {
      var url = en4.core.baseUrl + 'circle/usernetwork/get-network';
        var req = new Request.JSON({
          url : url,
          data : {
            format : 'json',
          },
          onComplete : function(responseJSON) {
			scriptJquery.each (responseJSON, function (bb) {
			  var network_id = responseJSON[bb].resource_id;
			  scriptJquery("#privacy_list_network_"+network_id).addClass('circle_hide');
			});
			scriptJquery("#privacylist li").each(function(){
				if(scriptJquery(this).attr('class') != undefined ) {
				      } else {
				           scriptJquery(this).addClass('circle_hide');
				      }
				})
			//Advance activity
			scriptJquery("#user_profile_network_list_custom").addClass('circle_hide');
			
          }
        });
        req.send();
});