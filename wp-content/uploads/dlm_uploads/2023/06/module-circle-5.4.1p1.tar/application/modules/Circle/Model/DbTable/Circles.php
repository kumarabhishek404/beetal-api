<?php
/**
 * SocialEngine
 *
 * @category   Application_Core
 * @package    User
 * @copyright  Copyright 2006-2010 Pragma Apps
 * @license    https://pragmaapps.com/license/
 * @version    4.10.5
 * @author     Javed Usmani
 */
class Circle_Model_DbTable_Circles extends Engine_Db_Table {
	protected $_rowClass = 'Circle_Model_Circle';

	public function getCirclesSelect($params = array()) {
		$circlesTable = Engine_Api::_()->getDbTable('circles', 'circle');
		$usersTable = Engine_Api::_()->getDbTable('users', 'user');
		$networkTable = Engine_Api::_()->getDbtable('networks', 'network');
		$select = $circlesTable->select()
			->setIntegrityCheck(false)
			->from(array('cir' => $circlesTable->info('name')))
			->joinLeft(array('net' => $networkTable->info('name')), 'net.network_id = cir.network_id', array("title as titles"))
			->joinLeft(array('usr' => $usersTable->info('name')), 'usr.user_id = cir.user_id', array("displayname"));

		if (!empty($params['displayname'])) {
			$select->where("net.title LIKE ?", '%' . $params['displayname'] . '%');
		}
		if (!empty($params['owner'])) {
			$select->where("usr.displayname LIKE ?", '%' . $params['owner'] . '%');
		}
		$select->order("cir.circle_id DESC");
		return $select;
	}

	/**
	 * Gets a paginator for blogs
	 *
	 * @param Core_Model_Item_Abstract $user The user to get the messages for
	 * @return Zend_Paginator
	 */
	public function getCirclesPaginator($params = array()) {
		$paginator = Zend_Paginator::factory($this->getCirclesSelect($params));
		return $paginator;
	}
	public function synchButton($user_id) {
		$db = Zend_Db_Table_Abstract::getDefaultAdapter();
		$select = "SELECT * FROM `engine4_circle_circles` WHERE (engine4_circle_circles .user_id = $user_id and engine4_circle_circles .status = 1)";
		$results = $db->query($select)->fetchAll();
		return $results;
	}
	public function getMembershipsOfIds(User_Model_User $user, $active = true) {
		$ids = array();
		$rows = $this->getMembershipsOfInfo($user, $active);
		foreach ($rows as $row) {
			$ids[] = $row->network_id;
		}
		return $ids;
	}

	/**
	 * Gets resource membership info that $user is a member of in the current type.
	 *
	 * @param User_Model_User $user
	 * @param bool|null $active
	 * @return Engine_Db_Table_Rowset
	 */
	public function getMembershipsOfInfo(User_Model_User $user, $active = true) {
		$circlesTable = Engine_Api::_()->getDbTable('circles', 'circle');
		$usersTable = Engine_Api::_()->getDbTable('users', 'user');
		$networkTable = Engine_Api::_()->getDbtable('networks', 'network');
		$circlesSelect = $circlesTable->select()
			->setIntegrityCheck(false)
			->from(array('cir' => $circlesTable->info('name')))
			->joinLeft(array('net' => $networkTable->info('name')), 'net.network_id = cir.network_id', array("title as titles"))
			->joinLeft(array('usr' => $usersTable->info('name')), 'usr.user_id = cir.user_id', array("displayname"))
			->where('cir.user_id =? ', $user->getIdentity());
		return $circlesTable->fetchAll($circlesSelect);
	}
}