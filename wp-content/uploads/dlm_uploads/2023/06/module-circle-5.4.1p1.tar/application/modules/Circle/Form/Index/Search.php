<?php
/**
 * SocialEngine
 *
 * @category   Application_Core
 * @package    User
 * @copyright  Copyright 2006-2020 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: Search.php 9747 2012-07-26 02:08:08Z john $
 * @author     John
 */

/**
 * @category   Application_Core
 * @package    User
 * @copyright  Copyright 2006-2020 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
class Circle_Form_Index_Search extends Fields_Form_Search {
	public function init() {
		$this->setMethod('get');
		$this->addElement('Text', 'name', array(
			'label' => 'Name',
			'required' => false,
			'allowEmpty' => false,
		));

		// Init submit
		$this->addElement('Button', 'submit', array(
			'label' => 'Search',
			'type' => 'submit',
			'ignore' => true,
		));
	}

}
