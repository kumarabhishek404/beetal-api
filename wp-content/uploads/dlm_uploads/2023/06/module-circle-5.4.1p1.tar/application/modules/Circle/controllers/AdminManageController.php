<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Blog
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: AdminManageController.php 9747 2012-07-26 02:08:08Z john $
 * @author     Jung
 */

/**
 * @category   Application_Extensions
 * @package    Blog
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
class Circle_AdminManageController extends Core_Controller_Action_Admin {
	public function indexAction() {
		$log = Zend_Registry::get('Zend_Log');
		$this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
			->getNavigation('circle_admin_main', array(), 'circle_admin_main_manage');

		$page = $this->_getParam('page', 1);
		$this->view->formFilter = $formFilter = new Circle_Form_Admin_Filter();

		$page = $this->_getParam('page', 1);

		// Process form
		$values = array();
		if ($formFilter->isValid($this->_getAllParams())) {
			$values = $formFilter->getValues();
		}

		foreach ($values as $key => $value) {
			if (null === $value) {
				unset($values[$key]);
			}
		}
		$values = array_merge(array(
			'orderby' => 'circle_id',
		), $values);

		$log->log("Step :::" . print_r($values, true), Zend_Log::DEBUG);
		/**
		 * @var $logsTbl Credit_Model_DbTable_Logs
		 */

		$this->view->assign($values);
		$this->view->paginator = Engine_Api::_()->getItemTable('circle')->getCirclesPaginator($values);
		$this->view->paginator->setItemCountPerPage(15);
		$this->view->paginator->setCurrentPageNumber($page);
		if (Engine_Api::_()->hasModuleBootstrap('advancedactivity')) {
			$this->view->advancedactivity = true;
		}

		if ($this->getRequest()->isPost()) {
			$values = $this->getRequest()->getPost();
			foreach ($values as $key => $value) {
				if ($key == 'delete_' . $value) {
					$circle = Engine_Api::_()->getItem('circle', $value);
					$network = Engine_Api::_()->getItem('network', $circle->network_id);

					$circle->delete();
					Engine_Api::_()->getDbtable('membership', 'circle')->delete(array(
						'resource_id = ?' => $value,
					));

					$network->delete();
				}
			}
		}
	}

	public function deleteAction() {
		// In smoothbox
		$this->_helper->layout->setLayout('admin-simple');
		$circle_id = $this->_getParam('id');
		$circle = Engine_Api::_()->getItem('circle', $circle_id);
		$network = Engine_Api::_()->getItem('network', $circle->network_id);
		$this->view->circle_id = $circle_id;
		// Check post
		if ($this->getRequest()->isPost()) {
			$db = Engine_Db_Table::getDefaultAdapter();
			$db->beginTransaction();

			try
			{
				$circle->delete();
				Engine_Api::_()->getDbtable('membership', 'circle')->delete(array(
					'resource_id = ?' => $circle_id,
				));

				$network->delete();
				$db->commit();
			} catch (Exception $e) {
				$db->rollBack();
				throw $e;
			}

			$this->_forward('success', 'utility', 'core', array(
				'smoothboxClose' => 10,
				'parentRefresh' => 10,
				'messages' => array(''),
			));
		}

		// Output
		$this->renderScript('admin-manage/delete.tpl');
	}
}