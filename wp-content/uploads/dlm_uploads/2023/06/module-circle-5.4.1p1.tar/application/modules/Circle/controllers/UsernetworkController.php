<?php

class Circle_UsernetworkController extends Core_Controller_Action_Standard {
	public function getNetworkAction() {
		if (!$this->_helper->requireUser()->isValid()) {return;}
		$viewer = Engine_Api::_()->user()->getViewer();
		$viewerId = $viewer->getIdentity();
		$networkTable = Engine_Api::_()->getDbtable('circles', 'circle');
		$select = $networkTable->select()
			->where('user_id <> ?', $viewerId);
		$result = $networkTable->fetchAll($select);
		if (count($result) < 1) {
			$data[] = array(
				'status' => false,
			);
		} else {
			foreach ($result as $rows) {
				$data[] = array(
					'user_id' => $rows->user_id,
					'resource_id' => $rows->network_id,
					'status' => true,
				);
			}
		}
		return $this->_helper->json($data);
	}

}
