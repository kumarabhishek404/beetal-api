<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Credit
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: Filter.php 10.01.12 15:06 TeaJay $
 * @author     Taalay
 */

/**
 * @category   Application_Extensions
 * @package    Credit
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Circle_Form_Admin_Syncfilter extends Engine_Form {

	public function init() {
		$this
			->clearDecorators()
			->addDecorator('FormElements')
			->addDecorator('Form')
			->addDecorator('HtmlTag', array('tag' => 'div', 'class' => 'search'))
			->addDecorator('HtmlTag2', array('tag' => 'div', 'class' => 'clear'))
		;

		$this
			->setAttribs(array(
				'id' => 'filter_form',
				'class' => 'global_form_box',
			));

		$this->addElement('Text', 'displayname', array(
			'label' => 'Name',
			'decorators' => array(
				'ViewHelper',
				array('Label', array('tag' => null, 'placement' => 'PREPEND')),
				array('HtmlTag', array('tag' => 'div')),
			),
		));

		$this->addElement('Button', 'search', array(
			'label' => 'Filter',
			'ignore' => true,
			'type' => 'submit',
			'decorators' => array(
				'ViewHelper',
				array('HtmlTag', array('tag' => 'div', 'class' => 'buttons')),
				array('HtmlTag2', array('tag' => 'div')),
			),
		));

		// Set default action without URL-specified params
		$params = array();
		foreach (array_keys($this->getValues()) as $key) {
			$params[$key] = null;
		}
		$this->setAction(Zend_Controller_Front::getInstance()->getRouter()->assemble($params));
	}
}
