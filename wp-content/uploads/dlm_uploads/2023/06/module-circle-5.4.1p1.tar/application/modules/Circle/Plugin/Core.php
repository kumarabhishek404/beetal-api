<?php
/**
 * SocialEngine
 *
 * @category   Application_Core
 * @package    User
 * @copyright  Copyright 2006-2010 Pragma Apps
 * @license    https://pragmaapps.com/license/
 * @version    4.10.5
 * @author     Javed Usmani
 */
class Circle_Plugin_Core extends Zend_Controller_Plugin_Abstract {
	public function onUserDeleteBefore($event) {
		// code here
	}

	public function onUserEnable($event) {

	}

	public function onUserCreateAfter($event) {
		$payload = $event->getPayload();
		$user = Engine_Api::_()->getItem('user', $payload->user_id);
		$api = Engine_Api::_()->circle();
		$api->updateItemCircle($user, $user);
	}
	public function onUserLoginAfter($event) {
		$user = $event->getPayload();
		$api = Engine_Api::_()->circle();
		$circleTable = Engine_Api::_()->getDbtable('circles', 'circle');
		$circleCount = $circleTable->synchButton($user->getIdentity());
		if (count($circleCount) == 0) {
			$api->updateItemCircle($user, $user);
		}
	}
}
?>