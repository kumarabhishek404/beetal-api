<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Blog
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: Level.php 10100 2013-10-24 23:09:16Z guido $
 * @author     Jung
 */

/**
 * @category   Application_Extensions
 * @package    Blog
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
class Circle_Form_Admin_Settings_Level extends Authorization_Form_Admin_Level_Abstract {
	public function init() {
		parent::init();

		// My stuff
		$this
			->setTitle('Member Level Settings')
			->setDescription("CIRCLE_FORM_ADMIN_LEVEL_DESCRIPTION");

		// Element: view
		$this->addElement('Radio', 'view', array(
			'label' => 'Allow Listing of Circle?',
			'description' => 'Do you want to let members view circle listing? If set to no, some other settings on this page may not apply.',
			'multiOptions' => array(
				1 => 'Yes, allow viewing of circle list.',
				0 => 'No, do not allow circle list to be viewed.',
			),
			'value' => 1,
		));

		if (!$this->isPublic()) {

			// Element: create
			$this->addElement('Radio', 'create', array(
				'label' => 'Allow Creation of Circle?',
				'description' => 'Do you want to let members create circle? If set to no, some other settings on this page may not apply. This is useful if you want members to be able to view circle, but only want certain levels to be able to create circles.',
				'multiOptions' => array(
					1 => 'Yes, allow creation of circle.',
					0 => 'No, do not allow circle to be created.',
				),
				'value' => 1,
			));

			// Element: edit
			$this->addElement('Radio', 'edit', array(
				'label' => 'Allow Editing of Circle?',
				'description' => 'Do you want to let members edit circle? If set to no, some other settings on this page may not apply.',
				'multiOptions' => array(
					1 => 'Yes, allow members to edit their own circle.',
					0 => 'No, do not allow members to edit their circle.',
				),
				'value' => 1,
			));

			// Element: delete
			$this->addElement('Radio', 'delete', array(
				'label' => 'Allow Deletion of Circle?',
				'description' => 'Do you want to let members delete circle? If set to no, some other settings on this page may not apply.',
				'multiOptions' => array(
					1 => 'Yes, allow members to delete their own circle.',
					0 => 'No, do not allow members to delete their circle.',
				),
				'value' => 1,
			));
			// Element: search
			$this->addElement('Radio', 'invite', array(
				'label' => 'Allow Add members of Circle?',
				'description' => 'Do you want to let members add in circle? If set to no, some other settings on this page may not apply.',
				'multiOptions' => array(
					1 => 'Yes, allow members to add their own circle.',
					0 => 'No, do not allow members to add their circle.',
				),
				'value' => 1,
			));
			// Element: search
			$this->addElement('Radio', 'circleviews', array(
				'label' => 'Allow view of circle detail page?',
				'description' => 'Do you want to let members circle detail page? If set to no, some other settings on this page may not apply.',
				'multiOptions' => array(
					1 => 'Yes, allow members to see their own circle.',
					0 => 'No, do not allow members to see their circle.',
				),
				'value' => 1,
			));

		}
	}
}