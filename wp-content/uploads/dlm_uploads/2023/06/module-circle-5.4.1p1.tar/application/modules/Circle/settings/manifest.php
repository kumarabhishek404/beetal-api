<?php return array(
	'package' => array(
		'type' => 'module',
		'name' => 'circle',
		'version' => '5.4.1p1',
		'sku' => 'circle',
		'path' => 'application/modules/Circle',
		'title' => 'Circle',
		'description' => 'This plugin allows you to create custom circle. This comes in handy at times when you have an update you\'d like to share with only certain circle',
		'author' => '<a href="http://www.hire-experts.com" title="Hire-Experts LLC" target="_blank">Hire-Experts LLC</a>',
		'callback' => array(
			'class' => 'Engine_Package_Installer_Module',
		),
		'actions' => array(
			0 => 'install',
			1 => 'upgrade',
			2 => 'refresh',
			3 => 'enable',
			4 => 'disable',
		),
		'callback' => array(
			'path' => 'application/modules/Circle/settings/install.php',
			'class' => 'Circle_Installer',
		),
		'directories' => array(
			0 => 'application/modules/Circle',
		),
		'files' => array(
			0 => 'application/languages/en/circle.csv',
		),
	),
	// Hooks ---------------------------------------------------------------------
	'hooks' => array(
		array(
			'event' => 'onUserEnable',
			'resource' => 'Circle_Plugin_Core',
		),
		array(
			'event' => 'onUserDeleteBefore',
			'resource' => 'Circle_Plugin_Core',
		),
		array(
			'event' => 'onUserCreateAfter',
			'resource' => 'Circle_Plugin_Core',
		),
		array(
			'event' => 'onUserLoginAfter',
			'resource' => 'Circle_Plugin_Core',
		),
	),
	// Items ---------------------------------------------------------------------
	'items' => array(
		'circle',
		'circle_list',
		'circle_list_item',
	),
	// Routes --------------------------------------------------------------------
	'routes' => array(
		'circle_general' => array(
			'route' => 'circle/:action/*',
			'defaults' => array(
				'module' => 'circle',
				'controller' => 'index',
				'action' => 'index',
			),
			'reqs' => array(
				'action' => '(index|create|user-network)',
			),
		),
		'circle_profile' => array(
			'route' => 'circle/:id/:slug/*',
			'defaults' => array(
				'module' => 'circle',
				'controller' => 'index',
				'action' => 'view',
				'slug' => '',
			),
			'reqs' => array(
				'id' => '\d+',
			),
		),
		'circle_specific' => array(
			'route' => 'circle/:action/:circle_id/*',
			'defaults' => array(
				'module' => 'circle',
				'controller' => 'index',
				'action' => 'index',
			),
			'reqs' => array(
				'circle_id' => '\d+',
				'action' => '(edit|remove|delete|join|leave|cancel|accept|invite|style|reject)',
			),
		),
	),
);?>