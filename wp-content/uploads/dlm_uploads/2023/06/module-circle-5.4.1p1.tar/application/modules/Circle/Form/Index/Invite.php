<?php
/**
 * SocialEngine
 *
 * @category   Application_Core
 * @package    User
 * @copyright  Copyright 2006-2010 Pragma Apps
 * @license    https://pragmaapps.com/license/
 * @version    4.10.5
 * @author     Javed Usmani
 */
class Circle_Form_Index_Invite extends Engine_Form {
	public function init() {
		$this
			->setTitle('Add Members in the Circle')
			->setDescription('Choose the people you want to add to this circle.')
			->setAttrib('id', 'circle_form_invite')
		;

		$this->addElement('Checkbox', 'all', array(
			'id' => 'selectall',
			'label' => 'Choose All Friends',
			'ignore' => true,
		));

		$this->addElement('MultiCheckbox', 'users', array(
			'label' => 'Members',
			'required' => true,
			'allowEmpty' => 'false',
		));

		$this->addElement('Button', 'submit', array(
			'label' => 'Add To Circle',
			'type' => 'submit',
			'ignore' => true,
			'decorators' => array(
				'ViewHelper',
			),
		));

		$this->addElement('Cancel', 'cancel', array(
			'label' => 'cancel',
			'link' => true,
			'prependText' => ' or ',
			'onclick' => 'parent.Smoothbox.close();',
			'decorators' => array(
				'ViewHelper',
			),
		));

		$this->addDisplayGroup(array('submit', 'cancel'), 'buttons');
	}
}