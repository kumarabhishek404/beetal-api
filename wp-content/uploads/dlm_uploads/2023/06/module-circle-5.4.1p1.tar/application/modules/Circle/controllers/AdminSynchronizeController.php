<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Blog
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: AdminManageController.php 9747 2012-07-26 02:08:08Z john $
 * @author     Jung
 */

/**
 * @category   Application_Extensions
 * @package    Blog
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
class Circle_AdminSynchronizeController extends Core_Controller_Action_Admin {
	public function indexAction() {
		$log = Zend_Registry::get('Zend_Log');
		$page = $this->_getParam('page', 1);
		$table = Engine_Api::_()->getDbtable('users', 'user');
		$this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
			->getNavigation('circle_admin_main', array(), 'circle_admin_main_synchronize');
		$select = $table->select();
		$settings = Engine_Api::_()->getApi('settings', 'core');
		$resendEmailSetting = $settings->getSetting('user.signup.verifyemail', 0);
		$isResendEmailEnable = (2 === (int) $resendEmailSetting || 3 === (int) $resendEmailSetting) ? true : false;
		$this->view->formFilter = $formFilter = new Circle_Form_Admin_Syncfilter();
		// Process form
		$values = array();
		if ($formFilter->isValid($this->_getAllParams())) {
			$values = $formFilter->getValues();
		}

		foreach ($values as $key => $value) {
			if (null === $value) {
				unset($values[$key]);
			}
		}

		$values = array_merge(array(
			'order' => 'user_id',
			'order_direction' => 'DESC',
		), $values);

		$this->view->assign($values);

		// Set up select info
		$select->order((!empty($values['order']) ? $values['order'] : 'user_id') . ' ' . (!empty($values['order_direction']) ? $values['order_direction'] : 'DESC'));

		if (!empty($values['displayname'])) {
			$select->where('displayname LIKE ?', '%' . $values['displayname'] . '%');
		}

		// Filter out junk
		$valuesCopy = array_filter($values);

		// Make paginator
		$this->view->paginator = $paginator = Zend_Paginator::factory($select);
		$this->view->paginator = $paginator->setCurrentPageNumber($page);
		$this->view->formValues = $valuesCopy;

		$this->view->hideEmails = _ENGINE_ADMIN_NEUTER;

		if ($this->getRequest()->isPost()) {
			$values = $this->getRequest()->getPost();
			foreach ($values as $key => $value) {
				if ($key == 'modify_' . $value) {
					$log->log("multiModifyAction 1:::" . $value, Zend_Log::DEBUG);
					$this->multiModify($value);
				}
			}
		}

	}
	public function synchCircleAction() {
		$this->_helper->layout->setLayout('admin-simple');
		$user_id = $this->_getParam('id');

		$circleArray = array("Colleague", "Family", "Close Friends");
		$table = Engine_Api::_()->getDbtable('networks', 'network');
		$circlesTable = Engine_Api::_()->getDbTable('circles', 'circle');

		$user = Engine_Api::_()->getItem('user', $user_id);
		if ($this->getRequest()->isPost()) {
			$db = Engine_Db_Table::getDefaultAdapter();
			$db->beginTransaction();
			foreach ($circleArray as $row) {
				try {
					$values = array();
					$values['title'] = $row;
					$values['description'] = 'This is default circles for user';
					$values['assignment'] = 2;
					$values['hide'] = 1;

					$network = $table->createRow();
					$network->setFromArray($values);
					$lastInsertedId = $network->save();
					$network->recalculateAll();

					$network->membership()->addMember($user)
						->setUserApproved($user)
						->setResourceApproved($user);

					// save details into the circles table
					$circlesTable->insert(array(
						'title' => $values['title'],
						'description' => $values['description'],
						'user_id' => $user->user_id,
						'network_id' => $lastInsertedId,
					));

					$db->commit();
				} catch (Exception $e) {
					$db->rollBack();
					// throw $e;
				}
				$this->_forward('success', 'utility', 'core', array(
					'smoothboxClose' => 10,
					'parentRefresh' => 10,
					'messages' => array(''),
				));
			}
		}
	}
	public function multiModify($userId) {
		$circleArray = array("Colleague", "Family", "Close Friends");
		$table = Engine_Api::_()->getDbtable('networks', 'network');
		$circlesTable = Engine_Api::_()->getDbTable('circles', 'circle');

		$user = Engine_Api::_()->getItem('user', $userId);
		$db = Engine_Db_Table::getDefaultAdapter();
		$db->beginTransaction();
		foreach ($circleArray as $row) {
			try {
				$values = array();
				$values['title'] = $row;
				$values['description'] = 'This is default circles for user';
				$values['assignment'] = 2;
				$values['hide'] = 1;

				$network = $table->createRow();
				$network->setFromArray($values);
				$lastInsertedId = $network->save();
				$network->recalculateAll();

				$network->membership()->addMember($user)
					->setUserApproved($user)
					->setResourceApproved($user);

				// save details into the circles table
				$circlesTable->insert(array(
					'title' => $values['title'],
					'description' => $values['description'],
					'user_id' => $user->user_id,
					'network_id' => $lastInsertedId,
				));

				$db->commit();
			} catch (Exception $e) {
				$db->rollBack();
				// throw $e;
			}
		}
	}
}