<?php

class Circle_Bootstrap extends Engine_Application_Bootstrap_Abstract {
	protected function _initFrontController() {

		$front = Zend_Controller_Front::getInstance();
		$headScript = new Zend_View_Helper_HeadScript();
		$StaticBaseUrl = '';
		if (Zend_Registry::isRegistered('StaticBaseUrl')) {
			$StaticBaseUrl = Zend_Registry::get('StaticBaseUrl');
		}
		$headLink = new Zend_View_Helper_HeadLink();
		$headLink->appendStylesheet($StaticBaseUrl
			. 'application/modules/Circle/externals/styles/main.css');

		$headScript
			->appendFile($StaticBaseUrl
				. 'application/modules/Circle/externals/scripts/core.js');
		$headLink = new Zend_View_Helper_HeadLink();
	}
}