
INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES
('pageblog', 'Page Blogs', 'Page Blogs', '5.4.1', 1, 'extra');