<?php

/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Pageevent
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: install.php 2010-07-02 19:54 michael $
 * @author     Michael
 */

/**
 * @category   Application_Extensions
 * @package    Pageevent
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Pageevent_Installer extends Engine_Package_Installer_Module
{
  public function onPreInstall()
  {
    parent::onPreInstall();

    $db = $this->getDb();
    $translate = Zend_Registry::get('Zend_Translate');
    
    $db->query("CREATE TABLE IF NOT EXISTS `engine4_page_events` (
  `pageevent_id` INT( 11 ) NOT NULL AUTO_INCREMENT ,
  `page_id` INT( 11 ) NOT NULL ,
  `title` VARCHAR( 128 ) NOT NULL ,
  `description` text NOT NULL ,
  `user_id` INT( 11 ) NOT NULL ,
  `creation_date` DATETIME NOT NULL ,
  `modified_date` DATETIME NOT NULL ,
  `starttime` DATETIME NOT NULL ,
  `endtime` DATETIME NOT NULL ,
  `location` VARCHAR( 115 ) NOT NULL ,
  `view_count` INT( 11 ) DEFAULT '0' NOT NULL ,
  `member_count` INT( 11 ) DEFAULT '0' NOT NULL ,
  `approval` TINYINT( 1 ) DEFAULT '0' NOT NULL ,
  `invite` TINYINT( 1 ) DEFAULT '0' NOT NULL ,
  `photo_id` INT( 11 ) NOT NULL ,
  PRIMARY KEY ( `pageevent_id` )
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;");
    
    $db->query("CREATE TABLE IF NOT EXISTS `engine4_page_eventmembership` (
  `resource_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `active` tinyint(1) NOT NULL default '0',
  `resource_approved` tinyint(1) NOT NULL default '0',
  `user_approved` tinyint(1) NOT NULL default '0',
  `message` text NULL,
  `rsvp` tinyint(3) NOT NULL default '3',
  `title` text NULL,
  PRIMARY KEY  (`resource_id`, `user_id`),
  KEY `REVERSE` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_unicode_ci;");
    
    $db->query("INSERT IGNORE INTO `engine4_page_modules` (`name`, `widget`, `order`, `params`) VALUES
('pageevent', 'pageevent.profile-event', 20, '{\"title\":\"PAGEEVENT_TABITEM\", \"titleCount\":true}');");
    
    $db->query("INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `order`) VALUES
('pageevent_upcoming', 'pageevent', 'PAGEEVENT_UPCOMING', 'Pageevent_Plugin_Menus', '', 'pageevent', '', 1),
('pageevent_past', 'pageevent', 'PAGEEVENT_PAST', 'Pageevent_Plugin_Menus', '', 'pageevent', '', 2),
('pageevent_user', 'pageevent', 'PAGEEVENT_USER', 'Pageevent_Plugin_Menus', '', 'pageevent', '', 3),
('pageevent_create', 'pageevent', 'PAGEEVENT_CREATE', 'Pageevent_Plugin_Menus', '', 'pageevent', '', 4);");
    
    $db->query("INSERT IGNORE INTO `engine4_activity_actiontypes` (`type`, `module`, `body`, `enabled`, `displayable`, `attachable`, `commentable`, `shareable`, `is_generated`) VALUES
('pagevent_create', 'pageevent', 'PAGEEVENT_ACTION_CREATE', 1, 7, 2, 1, 1, 1),
('pagevent_join', 'pageevent', 'PAGEEVENT_ACTION_JOIN', 1, 7, 2, 1, 1, 1),
('comment_pageevent', 'pageevent', '{actors:\\\$subject:\\\$object} commented on {item:\\\$owner}\\'s event {var:\\\$link}: {body:\\\$body}', 1, 7, 2, 1, 1, 1);");
    
    $db->query("INSERT IGNORE INTO `engine4_activity_notificationtypes` (`type`, `module`, `body`, `is_request`, `handler`) VALUES
('pageevent_accepted', 'pageevent', 'PAGEEVENT_NOTIFY_ACCEPTED', 0, ''),
('pageevent_approved', 'pageevent', 'PAGEEVENT_NOTIFY_APPROVED', 0, ''),
('pageevent_invite', 'pageevent', 'PAGEEVENT_NOTIFY_INVITE', 1, 'pageevent.widget.request');");
    
    $db->query("INSERT IGNORE INTO `engine4_activity_notificationtypes` (`type`, `module`, `body`, `is_request`, `handler`, `default`) VALUES
('post_pageevent', 'pageevent', '{item:\\\$subject} created new {item:\\\$object:\\\$label}.', 0, '', 1);");
    
    $db->query("INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'pageevent' as `type`,
    'comment' as `name`,
    1 as `value`,
    null as `params`
  FROM `engine4_authorization_levels` WHERE `type` NOT IN('public');");
    
    $db->query("INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'pageevent' as `type`,
    'view' as `name`,
    1 as `value`,
    null as `params`
  FROM `engine4_authorization_levels` WHERE `type`;");
    
    $db->query("INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'pageevent' as `type`,
    'posting' as `name`,
    1 as `value`,
    null as `params`
  FROM `engine4_authorization_levels` WHERE `type` NOT IN('public');");
    
    
    
    
    $db->query("INSERT IGNORE INTO `engine4_core_menus` (`name`, `type`, `title`, `order`)
VALUES ('pageevent_main', 'standard', 'Pageevent Main Navigation Menu', 999);");
    
    $db->query("INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES
('pageevent_main_upcoming', 'pageevent', 'Upcoming Events', '', '{\"route\":\"pageevent_upcoming\"}', 'pageevent_main', '', 1, 0, 996),
('pageevent_main_past', 'pageevent', 'Past Events', '', '{\"route\":\"pageevent_past\"}', 'pageevent_main', '', 1, 0, 997),
('pageevent_main_manage', 'pageevent', 'My Events', 'Pageevent_Plugin_Menus', '{\"route\":\"pageevent_manage\"}', 'pageevent_main', '', 1, 0, 998),
('pageevent_main_create', 'pageevent', 'Create New Event', 'Event_Plugin_Menus::canCreateEvents', '{\"route\":\"event_general\",\"action\":\"create\"}', 'pageevent_main', '', 1, 0, 999),
('page_admin_main_event', 'pageevent', 'Event', 'Event_Plugin_Menus::canCreateEvents', '{\"route\":\"admin_default\",\"module\":\"pageevent\",\"controller\":\"settings\"}', 'page_admin_settings', '', 1, 0, 999);");
    
    $sql = <<<CONTENT
INSERT IGNORE INTO  `engine4_core_pages` (`name`, `displayname`, `title`, `description`, `provides`, `view_count`) VALUES
('pageevent_events_browse', 'All Events Browse Page', 'Events Browse', 'This page displays all events', '', 0)
CONTENT;
    $db->query($sql);
    $page_id = $db->lastInsertId();
    
    $sql = <<<CONTENT
INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'container', 'main', NULL, 2)
CONTENT;
    $db->query($sql);
    $main_content_id = $db->lastInsertId();
    
    $sql = <<<CONTENT
INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'container', 'middle', $main_content_id, 6)
CONTENT;
    $db->query($sql);
    $middle_content_id = $db->lastInsertId();
    
    $sql = <<<CONTENT
INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'container', 'right', $main_content_id, 5)
CONTENT;
    $db->query($sql);
    $right_content_id = $db->lastInsertId();
    
    $sql = <<<CONTENT
INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'widget', 'core.content', $middle_content_id, 6)
CONTENT;
    $db->query($sql);
    
    $sql = <<<CONTENT
INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'widget', 'pageevent.browse-search', $right_content_id, 8)
CONTENT;
    $db->query($sql);
    
    $sql = <<<CONTENT
INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'container', 'top', NULL, 1)
CONTENT;
    $db->query($sql);
    $top_content_id = $db->lastInsertId();
    
    $sql = <<<CONTENT
INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'container', 'middle', $top_content_id, 6)
CONTENT;
    $db->query($sql);
    $top_middle_content_id = $db->lastInsertId();
    
    
    $sql = <<<CONTENT
INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'widget', 'pageevent.browse-menu', $top_middle_content_id, 3)
CONTENT;
    $db->query($sql);
    $top_middle_content_id = $db->lastInsertId();
    
    
    $sql = <<<CONTENT
INSERT IGNORE INTO  `engine4_core_pages` (`name`, `displayname`, `title`, `description`, `provides`, `view_count`) VALUES
('pageevent_events_manage', 'All Events Manage Page', 'Events Manage', 'This page displays viewers events', '', 0)
CONTENT;
    $db->query($sql);
    $page_id = $db->lastInsertId();
    
    $sql = <<<CONTENT
INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'container', 'main', NULL, 2)
CONTENT;
    $db->query($sql);
    $main_content_id = $db->lastInsertId();
    
    $sql = <<<CONTENT
INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'container', 'middle', $main_content_id, 6)
CONTENT;
    $db->query($sql);
    $middle_content_id = $db->lastInsertId();
    
    $sql = <<<CONTENT
INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'widget', 'core.content', $middle_content_id, 6)
CONTENT;
    $db->query($sql);
    
    $sql = <<<CONTENT
INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'container', 'top', NULL, 1)
CONTENT;
    $db->query($sql);
    $top_content_id = $db->lastInsertId();
    
    $sql = <<<CONTENT
INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'container', 'middle', $top_content_id, 6)
CONTENT;
    $db->query($sql);
    $top_middle_content_id = $db->lastInsertId();
    
    $sql = <<<CONTENT
INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'widget', 'pageevent.browse-menu', $top_middle_content_id, 3)
CONTENT;
    $db->query($sql);
    
    }
}