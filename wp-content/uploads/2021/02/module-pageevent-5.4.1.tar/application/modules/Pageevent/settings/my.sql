
INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES
('pageevent', 'Page Event', 'Displays the Page Event.', '5.4.1', 1, 'extra');
