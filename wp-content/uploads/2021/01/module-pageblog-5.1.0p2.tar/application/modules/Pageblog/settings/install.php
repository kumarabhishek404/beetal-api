<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Pageblog
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: install.php 2010-08-31 16:05 idris $
 * @author     Idris
 */

/**
 * @category   Application_Extensions
 * @package    Pageblog
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Pageblog_Installer extends Engine_Package_Installer_Module
{

  public function onInstall()
  {
        parent::onInstall();
        $db = $this->getDb();
        $db = Engine_Db_Table::getDefaultAdapter();

        $db->query("CREATE TABLE IF NOT EXISTS `engine4_page_blogs` (
          `pageblog_id` int(11) unsigned NOT NULL auto_increment,
          `page_id` int(11) unsigned NOT NULL default '0',
          `title` varchar(128) collate utf8_unicode_ci NOT NULL,
          `body` longtext collate utf8_unicode_ci NOT NULL,
          `user_id` int(11) unsigned NOT NULL,
          `creation_date` datetime NOT NULL,
          `modified_date` datetime NOT NULL,
          `view_count` int(11) unsigned NOT NULL default '0',
          `comment_count` int(11) unsigned NOT NULL default '0',
          `photo_id` int(11) NOT NULL DEFAULT '0',
          PRIMARY KEY  (`pageblog_id`),
          KEY `owner_type` (`user_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;");

        $db->query("INSERT IGNORE INTO `engine4_activity_actiontypes` (`type`, `module`, `body`, `enabled`, `displayable`, `attachable`, `commentable`, `shareable`, `is_generated`) VALUES
        ('pageblog_new', 'pageblog', '{actors:\\\$subject:\\\$object} posted new blog entry {var:\\\$link}: {body:\\\$body}', 1, 7, 2, 1, 1, 1),
        ('comment_pageblog', 'pageblog', '{actors:\\\$subject:\\\$object} commented on {item:\\\$owner}\\'s blog entry {var:\\\$link}: {body:\\\$body}', 1, 7, 2, 1, 1, 1);");

        $db->query("INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `order`) VALUES
        ('pageblog_all', 'pageblog', 'All', 'Pageblog_Plugin_Menus', '', 'pageblog', '', 1),
        ('pageblog_mine', 'pageblog', 'Mine', 'Pageblog_Plugin_Menus', '', 'pageblog', '', 2),
        ('pageblog_create', 'pageblog', 'Create', 'Pageblog_Plugin_Menus', '', 'pageblog', '', 3);");

        $db->query("INSERT IGNORE INTO `engine4_page_modules` (`name`, `widget`, `order`, `params`) VALUES
        ('pageblog', 'pageblog.profile-blog', 15, '{\"title\":\"Blogs\", \"titleCount\":true}');");

        $db->query("INSERT IGNORE INTO `engine4_activity_notificationtypes` (`type`, `module`, `body`, `is_request`, `handler`, `default`) VALUES
        ('post_pageblog', 'pageblog', '{item:\\\$subject} created new {item:\\\$object:\\\$label}.', 0, '', 1);");

        $db->query("INSERT IGNORE INTO `engine4_core_menus` (`name`, `type`, `title`, `order`)
        VALUES ('pageblog_main', 'standard', 'Pageblog Main Navigation Menu', 999);");

        $db->query("INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES
        ('pageblog_main_browse', 'pageblog', 'Browse Entries', '', '{\"route\":\"page_blogs\",\"action\":\"browse\"}', 'pageblog_main', '', 1, 0, 997),
        ('pageblog_main_manage', 'pageblog', 'My Entries', 'Pageblog_Plugin_Menus', '{\"route\":\"page_blogs\",\"action\":\"manage\"}', 'pageblog_main', '', 1, 0, 998),
        ('pageblog_main_create', 'pageblog', 'Write New Entry', 'Blog_Plugin_Menus::canCreateBlogs', '{\"route\":\"blog_general\",\"action\":\"create\"}', 'pageblog_main', '', 1, 0, 999),
        ('page_admin_main_blog', 'pageblog', 'Blog', NULL, '{\"route\":\"admin_default\",\"module\":\"pageblog\",\"controller\":\"settings\"}', 'page_admin_settings', '', 1, 0, 999);");


        $sql = "INSERT IGNORE INTO  `engine4_core_pages` (`name`, `displayname`, `title`, `description`, `provides`, `view_count`) VALUES
        ('pageblog_blogs_browse', 'All Blogs Browse Page', 'Blog Browse', 'This page displays a page blogs', '', 0)";
        $db->query($sql);
        $page_id = $db->lastInsertId();

        $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
        ($page_id, 'container', 'main', NULL, 2)";
        $db->query($sql);
        $main_content_id = $db->lastInsertId();

        $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
        ($page_id, 'container', 'middle', $main_content_id, 6)";
        $db->query($sql);
        $middle_content_id = $db->lastInsertId();

        $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
        ($page_id, 'container', 'right', $main_content_id, 5)";
        $db->query($sql);
        $right_content_id = $db->lastInsertId();

        $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
        ($page_id, 'widget', 'core.content', $middle_content_id, 6)";
        $db->query($sql);

        $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
        ($page_id, 'widget', 'pageblog.browse-search', $right_content_id, 8)";
        $db->query($sql);

        $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
        ($page_id, 'container', 'top', NULL, 1)";
        $db->query($sql);
        $top_content_id = $db->lastInsertId();

        $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
        ($page_id, 'container', 'middle', $top_content_id, 6)";
        $db->query($sql);
        $top_middle_content_id = $db->lastInsertId();


        $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
        ($page_id, 'widget', 'pageblog.browse-menu', $top_middle_content_id, 3)";
        $db->query($sql);
        $top_middle_content_id = $db->lastInsertId();


        $sql = "INSERT IGNORE INTO  `engine4_core_pages` (`name`, `displayname`, `title`, `description`, `provides`, `view_count`) VALUES
        ('pageblog_blogs_manage', 'All Blogs Manage Page', 'Blogs Manage', 'This page displays viewers blogs', '', 0)";
        $db->query($sql);
        $page_id = $db->lastInsertId();

        $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
        ($page_id, 'container', 'main', NULL, 2)";
        $db->query($sql);
        $main_content_id = $db->lastInsertId();

        $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
        ($page_id, 'container', 'middle', $main_content_id, 6)";
        $db->query($sql);
        $middle_content_id = $db->lastInsertId();

        $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
        ($page_id, 'widget', 'core.content', $middle_content_id, 6)";
        $db->query($sql);

        $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
        ($page_id, 'container', 'top', NULL, 1)";
        $db->query($sql);
        $top_content_id = $db->lastInsertId();

        $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
        ($page_id, 'container', 'middle', $top_content_id, 6)";
        $db->query($sql);
        $top_middle_content_id = $db->lastInsertId();

        $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
        ($page_id, 'widget', 'pageblog.browse-menu', $top_middle_content_id, 3)";
        $db->query($sql);
  }
}
