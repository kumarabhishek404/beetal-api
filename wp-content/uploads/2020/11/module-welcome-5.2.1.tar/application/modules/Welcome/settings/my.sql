INSERT INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES
('welcome', 'Welcome Slideshow', 'Welcome Slideshow Plugin.', '5.2.1', 1, 'extra');
