<?php

class Welcome_Model_DbTable_SlideshowSettings extends Engine_Db_Table
{
  protected $_rowClass = 'Welcome_Model_SlideshowSetting';
}

?>