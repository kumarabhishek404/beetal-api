/*
 ---

 name: Hestrap

 description: The BootStrap namespace.

 authors: [Aaron Newton]

 license: MIT-style license.

 provides: [Hestrap]

 ...
 */

/*if (!Hestrap) {
 var Hestrap = {
 version: 3,
 components: {
 dropdown: null,
 tab: null
 },
 init: function () {
 this.components.dropdown = new Hestrap.Dropdown(document.body);
 this.components.tab = new Hestrap.Tab(document.body);
 }
 };
 document.addEvent('domready', function () {
 Hestrap.init();
 });
 }*/
(function(){
  if(!window.Hestrap){
    window.Hestrap = {
      version: 3,
      components: {
        dropdown: null,
        tab: null
      },
      init: function(){
        window.hestrapInited = 1;
        this.components.dropdown = new window.Hestrap.Dropdown(document.body);
        this.components.tab = new window.Hestrap.Tab(document.body);
      }
    };
  }})();
document.addEvent('domready', function () {
  if(typeof window.hestrapInited == 'undefined'){
    window.Hestrap.init();
  }
  else{
    console.log('hestrap inited');
  }
});