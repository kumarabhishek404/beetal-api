<?php

class Like_Model_Unfollow extends Core_Model_Item_Abstract
{

}
