<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Like
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: Controller.php 2015-09-07 16:05 BOLOT $
 * @author     bOLOT
 */

/**
 * @category   Application_Extensions
 * @package    Like
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Like_Widget_StatusController extends Engine_Content_Widget_Abstract
{	
  public function indexAction()
  {
    if( !Engine_Api::_()->core()->hasSubject() ) {
      $this->setNoRender();
    }
    
    $this->view->subject = $subject = Engine_Api::_()->core()->getSubject();
    $this->view->viewer = $viewer = Engine_Api::_()->user()->getViewer();

    $this->view->is_enabled = (bool)( $viewer->getIdentity());
    $this->view->is_allowed = (bool)(Engine_Api::_()->like()->isAllowed($subject));
    $this->view->verified = 0;
    $this->view->auth = ( $subject->authorization()->isAllowed(null, 'view') );
    $this->view->is_owner = ($subject->getType() == 'page') ? $subject->isTeamMember($viewer) : $viewer->isOwner($subject);

    if (Engine_Api::_()->core()->hasSubject('page')) {
      $pageObject = Engine_Api::_()->core()->getSubject('page');

    $page_id = $pageObject->page_id;
    $this->view->page_id = $page_id;
    $table = Engine_Api::_()->getDbTable('status', 'page');
    $select = $table->select();
    $select->where('page_id = ?',$page_id);
    $stat = $table->fetchRow($select);
    $followTable = Engine_Api::_()->getDbTable('follows', 'like');
    $viewer = Engine_Api::_()->user()->getViewer();
    $page_follows = $followTable->getFollow($viewer->getIdentity(), $page_id);
    if ($page_follows && Engine_Api::_()->getDbTable('modules','core')->isModuleEnabled('page')) {
        $preferences = json_decode($page_follows->value, true);
    } else {
        $settings = Engine_Api::_()->getDbTable('settings', 'core')->getSetting('page.follows', array());
        $preferences = json_decode($settings, true);
    }
    if(!Engine_Api::_()->getDbTable('modules','core')->isModuleEnabled('pageblog')){
        unset($preferences['pageblog_new']);
    }
    if(!Engine_Api::_()->getDbTable('modules','core')->isModuleEnabled('pagealbum')){
        unset($preferences['pagealbum_photo_new']);
    }
    if(!Engine_Api::_()->getDbTable('modules','core')->isModuleEnabled('donation')){
        unset($preferences['page_charity_new']);
        unset($preferences['page_project_new']);
    }
    if(!Engine_Api::_()->getDbTable('modules','core')->isModuleEnabled('offers')){
        unset($preferences['page_offer_new']);
        unset($preferences['page_offers_purchase']);
        unset($preferences['page_offers_accept']);
    }
    if(!Engine_Api::_()->getDbTable('modules','core')->isModuleEnabled('pagediscussion')){
        unset($preferences['page_topic_create']);
        unset($preferences['page_topic_reply']);
    }
    if(!Engine_Api::_()->getDbTable('modules','core')->isModuleEnabled('pagedocument')){
        unset($preferences['pagedocument_new']);
    }
    if(!Engine_Api::_()->getDbTable('modules','core')->isModuleEnabled('rate')){
        unset($preferences['pagereview_new']);
    }
    if(!Engine_Api::_()->getDbTable('modules','core')->isModuleEnabled('pageevent')){
        unset($preferences['pagevent_create']);
    }
    if(!Engine_Api::_()->getDbTable('modules','core')->isModuleEnabled('pageevent')){
        unset($preferences['pagevent_create']);
        unset($preferences['pagevent_join']);
    }
    if(!Engine_Api::_()->getDbTable('modules','core')->isModuleEnabled('pagemusic')){
        unset($preferences['pagemusic_playlist_new']);
    }
    if(!Engine_Api::_()->getDbTable('modules','core')->isModuleEnabled('pagevideo')){
        unset($preferences['pagevideo_new']);
    }
    if(!Engine_Api::_()->getDbTable('modules','core')->isModuleEnabled('store')){
        unset($preferences['page_product_new']);
    }
    $this->view->preferences = $preferences;

    if ($stat !== null) {
      $this->view->verified = $verified = $stat->status;
    }
    }
  }
}