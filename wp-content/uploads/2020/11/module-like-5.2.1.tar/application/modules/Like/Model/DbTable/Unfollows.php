<?php

class Like_Model_DbTable_Unfollows extends Engine_Db_Table
{
    protected $_rowClass = 'Like_Model_Unfollow';

    public function getUnFollowTable()
    {
        return $this;
    }

    public function getUnFollow($user_id, $page_id, $type){
        $table = $this->getUnFollowTable();
        $select = $table->select()
            ->where('user_id = ?', $user_id)
            ->where('page_id = ?', $page_id)
            ->where('type = ?', $type)
            ->limit(1);

        return $table->fetchRow($select);
    }


    public function createUnfollow($user_id, $page_id, $type) {

        $table = $this->getUnFollowTable();
        try {
            $row = $table->createRow();
            $row->user_id = $user_id;
            $row->page_id = $page_id;
            $row->type = $type;
            $row->save();

            return $row;
        } catch (Exception $e) {
            throw $e;
        }
    }

    public function removeUnfollow($user_id, $page_id, $type) {
        $unfollow = $this->getUnFollow($user_id, $page_id, $type);

        if ($unfollow) {
            $unfollow->delete();
            return true;
        }

        return false;
    }


    public function getUnfollowType($user_id, $data) {
        $table = $this->getUnFollowTable();
        $select = $table->select()
            ->where('user_id = ?', $user_id);
        if (is_array($data)) {
            $select->where('page_id IN (?)', $data);
        } else {
            $select->where('page_id = ?', $data);
        }
        return $table->fetchAll($select);
    }
}