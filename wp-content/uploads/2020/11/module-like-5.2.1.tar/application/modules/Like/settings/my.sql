INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES
('like', 'Likes', 'Likes', '5.2.1', 1, 'extra');
