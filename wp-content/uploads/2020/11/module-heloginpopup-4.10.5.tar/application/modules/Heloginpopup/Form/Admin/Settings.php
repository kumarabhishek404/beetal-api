<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Heloginpopup
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    Id: Settings.php 24.09.13 14:26 Ulan T $
 * @author     Ulan T
 */

/**
 * @category   Application_Extensions
 * @package    Heloginpopup
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Heloginpopup_Form_Admin_Settings extends Engine_Form
{
  public function init()
  {
    $this->setTitle('')
      ->setDescription('');

      $description = $this->getTranslator()->translate('USER_ADMIN_SETTINGS_TWITTER_DESCRIPTION');
    $moreinfo = $this->getTranslator()->translate('');
      $description = vsprintf($description.$moreinfo, array(
        'https://apps.twitter.com',
        'http://' . $_SERVER['HTTP_HOST'] . Zend_Controller_Front::getInstance()->getRouter()->assemble(array(
            'module' => 'heloginpopup',
            'controller' => 'index',
            'action' => 'twitter'
          ), 'default', true),
      ));
      $this->setDescription($description);

      $this->loadDefaultDecorators();
      $this->getDecorator('Description')->setOption('escape', false);

    $settings = Engine_Api::_()->getDbTable('settings', 'core');

    $this->addElement('Text', 'maxday', array(
      'Label' => 'Max Days',
      'description' => 'How often Login Popup appears in the site.',
      'value' => $settings->getSetting('heloginpopup.max.day', 30),
      'filters'  => array(
        array('name' => 'Int'),
      ),
    ));

    $this->addElement('Button', 'submit', array(
      'label' => 'Save',
      'type' => 'submit'
    ));
  }
}
