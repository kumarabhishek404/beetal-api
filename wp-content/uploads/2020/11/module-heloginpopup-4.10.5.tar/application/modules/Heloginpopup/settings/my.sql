INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES  ('heloginpopup', 'Loginpopup', '', '4.10.5', 1, 'extra') ;

INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES
('core_admin_main_plugins_heloginpopup', 'heloginpopup', 'He - Login Popup', NULL, '{\"route\":\"admin_default\",\"module\":\"heloginpopup\",\"controller\":\"index\",\"action\":\"index\"}', 'core_admin_main_plugins', NULL, 1, 0, 888);
