UPDATE `engine4_core_modules` SET `version` = '4.5.1p5' WHERE `name` = 'hecontest';
