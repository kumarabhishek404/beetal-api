INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`)
VALUES  ('hecontest', 'HE Contest', 'Hire-Experts Contest plugin', '4.10.5', '1', 'extra');

INSERT IGNORE INTO `engine4_activity_actiontypes` (`type`, `module`, `body`, `enabled`, `displayable`, `attachable`, `commentable`, `shareable`, `is_generated`) VALUES
('hecontest_begins', 'hecontest', '{item:\\\$object} just started! Take part!', 1, 7, 1, 1, 1, 1),
('hecontest_participate', 'hecontest', '{item:\\\$subject} has joined to contest {item:\\\$object}', 1, 7, 1, 1, 1, 1),
('hecontest_win', 'hecontest', '{item:\\\$subject} won the {item:\\\$object} contest.', 1, 7, 1, 1, 1, 1);

INSERT IGNORE INTO `engine4_authorization_permissions` (`level_id`, `type`, `name`, `value`, `params`) VALUES
(1, 'hecontest_photo', 'auth_comment', 5, '[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),
(1, 'hecontest_photo', 'auth_tag', 5, '[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),
(1, 'hecontest_photo', 'auth_view', 5, '[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),
(1, 'hecontest_photo', 'comment', 2, NULL),
(1, 'hecontest_photo', 'create', 1, NULL),
(1, 'hecontest_photo', 'delete', 2, NULL),
(1, 'hecontest_photo', 'edit', 2, NULL),
(1, 'hecontest_photo', 'tag', 2, NULL),
(1, 'hecontest_photo', 'view', 1, NULL),
(1, 'hecontest_photo', 'view', 2, NULL),
(1, 'hecontest', 'view', 1, NULL),
(1, 'hecontest', 'vote', 1, NULL),
(1, 'hecontest', 'participate', 1, NULL),
(2, 'hecontest_photo', 'auth_comment', 5, '[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),
(2, 'hecontest_photo', 'auth_tag', 5, '[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),
(2, 'hecontest_photo', 'auth_view', 5, '[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),
(2, 'hecontest_photo', 'comment', 2, NULL),
(2, 'hecontest_photo', 'create', 1, NULL),
(2, 'hecontest_photo', 'delete', 2, NULL),
(2, 'hecontest_photo', 'edit', 2, NULL),
(2, 'hecontest_photo', 'tag', 2, NULL),
(2, 'hecontest_photo', 'view', 1, NULL),
(2, 'hecontest_photo', 'view', 2, NULL),
(2, 'hecontest', 'view', 1, NULL),
(2, 'hecontest', 'vote', 1, NULL),
(2, 'hecontest', 'participate', 1, NULL),
(3, 'hecontest_photo', 'auth_comment', 5, '[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),
(3, 'hecontest_photo', 'auth_tag', 5, '[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),
(3, 'hecontest_photo', 'auth_view', 5, '[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),
(3, 'hecontest_photo', 'comment', 2, NULL),
(3, 'hecontest_photo', 'create', 1, NULL),
(3, 'hecontest_photo', 'delete', 2, NULL),
(3, 'hecontest_photo', 'edit', 2, NULL),
(3, 'hecontest_photo', 'tag', 2, NULL),
(3, 'hecontest_photo', 'view', 1, NULL),
(3, 'hecontest_photo', 'view', 2, NULL),
(3, 'hecontest', 'view', 1, NULL),
(3, 'hecontest', 'vote', 1, NULL),
(3, 'hecontest', 'participate', 1, NULL),
(4, 'hecontest_photo', 'auth_comment', 5, '[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),
(4, 'hecontest_photo', 'auth_tag', 5, '[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),
(4, 'hecontest_photo', 'auth_view', 5, '[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),
(4, 'hecontest_photo', 'comment', 2, NULL),
(4, 'hecontest_photo', 'create', 1, NULL),
(4, 'hecontest_photo', 'delete', 2, NULL),
(4, 'hecontest_photo', 'edit', 2, NULL),
(4, 'hecontest_photo', 'tag', 2, NULL),
(4, 'hecontest_photo', 'view', 1, NULL),
(4, 'hecontest', 'view', 1, NULL),
(4, 'hecontest', 'vote', 1, NULL),
(4, 'hecontest', 'participate', 1, NULL);

INSERT IGNORE INTO `engine4_core_menus` (`name`, `type`, `title`, `order`) VALUES ('hecontest_main', 'standard', 'Hecontest Main Navigation Menu', 999);
INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES
('core_admin_main_plugins_hecontest', 'hecontest', 'HECONTEST_He Contest', NULL, '{\"route\":\"admin_default\",\"module\":\"hecontest\",\"controller\":\"index\",\"action\":\"index\"}', 'core_admin_main_plugins', NULL, 1, 0, 888),
('hecontest_admin_main_level_settings', 'hecontest', 'Level Settings', NULL , '{\"route\":\"admin_default\",\"module\":\"hecontest\",\"controller\":\"index\",\"action\":\"level-settings\"}', 'hecontest_admin_main', NULL , 1, 0, 3),
('hecontest_admin_main_settings', 'hecontest', 'Settings', NULL, '{\"route\":\"admin_default\",\"module\":\"hecontest\",\"controller\":\"index\",\"action\":\"settings\"}', 'hecontest_admin_main', NULL, 1, 0, 2),
('hecontest_admin_main_create', 'hecontest', 'Create', NULL, '{\"route\":\"admin_default\",\"module\":\"hecontest\",\"controller\":\"index\",\"action\":\"create\"}', 'hecontest_admin_main', NULL, 1, 0, 3),
('hecontest_admin_main_contests', 'hecontest', 'Contests', '', '{\"route\":\"admin_default\",\"module\":\"hecontest\",\"controller\":\"index\",\"action\":\"index\"}', 'hecontest_admin_main', NULL, 1, 0, 1),
('hecontest_main_active', 'hecontest', 'Active Contest', NULL, '{\"route\":\"hecontest_general\"}', 'hecontest_main', NULL, 1, 0, 888),
('hecontest_main_recent', 'hecontest', 'Recent Contest', NULL, '{\"route\":\"hecontest_general\",\"action\":\"recent\"}', 'hecontest_main', NULL, 1, 0, 999),
('core_main_hecontest', 'hecontest', 'Contests', NULL, '{\"route\":\"hecontest_general\"}', 'core_main', NULL, 1, 0, 999);

INSERT IGNORE INTO `engine4_core_mailtemplates` (`type`, `module`, `vars`) VALUES
('hecontest_approve', 'hecontest', '[user],[contest_name],[contest_link]'),
('hecontest_reject', 'hecontest', '[user],[contest_name],[contest_link]');
