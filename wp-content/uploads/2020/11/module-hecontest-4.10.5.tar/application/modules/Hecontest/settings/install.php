<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Hecontest
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: install.php 19.10.13 08:20 jungar $
 * @author     Jungar
 */

/**
 * @category   Application_Extensions
 * @package    Hecontest
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */


class Hecontest_Installer extends Engine_Package_Installer_Module
{
    public function onPreInstall()
    {
        parent::onPreInstall();
        
        $db = $this->getDb();
        
        ///Create table
        $sql = $db->query("CREATE TABLE IF NOT EXISTS `engine4_hecontest_hecontests` (
  `hecontest_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `terms` text COLLATE utf8_unicode_ci NOT NULL,
  `prize_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `prize_photo` int(11) NOT NULL,
  `sponsor` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sponsor_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sponsor_href` text COLLATE utf8_unicode_ci NOT NULL,
  `sponsor_type` tinyint(4) NOT NULL DEFAULT '1',
  `date_begin` datetime NOT NULL,
  `checkin` text COLLATE utf8_unicode_ci NULL,
  `date_end` datetime NOT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT '0',
  `is_recent` tinyint(4) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL,
  `price_credit` int(11) NULL,
  `photo_id` int(11) NULL,
            
  PRIMARY KEY (`hecontest_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;");
        
        $sql = $db->query("CREATE TABLE IF NOT EXISTS `engine4_hecontest_photos` (
  `photo_id` int(11) NOT NULL AUTO_INCREMENT,
  `file_id` int(11) NOT NULL,
  `contest_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `votes` int(11) NOT NULL,
  `date_posted` datetime NOT NULL,
  `status` enum('approved','pending','decline') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'pending',
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `comment_count` int(11) NOT NULL,
  PRIMARY KEY (`photo_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;");
        
        $sql = $db->query("CREATE TABLE IF NOT EXISTS `engine4_hecontest_voters` (
  `voter_id` int(11) NOT NULL AUTO_INCREMENT,
  `photo_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`voter_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;");
        
        $sql = $db->query("CREATE TABLE IF NOT EXISTS `engine4_hecontest_purchaseds` (
`purchaseds_id` INT(10) NOT NULL AUTO_INCREMENT,
`contest_id` INT(10) NULL DEFAULT '0',
`status` INT(1) NULL DEFAULT '0',
`user_id` INT(10) NULL DEFAULT '0',
PRIMARY KEY (`purchaseds_id`)
) COLLATE='latin1_swedish_ci'
ENGINE=InnoDB;");
        //End
        $sql1 = $db->query("INSERT IGNORE INTO `engine4_core_pages` (`name`, `displayname`, `url`, `title`, `description`, `keywords`, `custom`, `fragment`, `layout`, `levels`, `provides`, `view_count`, `search`) VALUES
('hecontest_index_index', 'Contest Main Page', NULL, 'Contest Main Page', 'Contest Main Page', '', 0, 0, '', NULL, 'subject=hecontest', 0, 0)");
        $page_id = $db->lastInsertId();
       
        
        
        $sql2 = $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
('$page_id', 'container', 'main', NULL, 1)");
        $main_content_id = $db->lastInsertId();
        
        $sql3 = $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`,`order`, `params`, `attribs`) VALUES ('$page_id', 'container', 'right', '$main_content_id', 1, NULL, NULL )");
        $right_container_id = $db->lastInsertId();
        
        $sql4 = $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`,`order`, `params`, `attribs`) VALUES ('$page_id', 'container', 'middle', '$main_content_id', 1, NULL, NULL )");
        $middle_container_id = $db->lastInsertId();
        
        $sql5 = $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
('$page_id', 'widget', 'hecontest.browse-menu', '$middle_container_id', 3),
('$page_id', 'widget', 'core.content', '$middle_container_id', 4)");
        //new pages
        $sql6 = $db->query("INSERT IGNORE INTO `engine4_core_pages` (`name`, `displayname`, `url`, `title`, `description`, `keywords`, `custom`, `fragment`, `layout`, `levels`, `provides`, `view_count`, `search`) VALUES
('hecontest_index_recent', 'Contest Recent Page', NULL, 'Contest RecentPage', 'Contest RecentPage', '', 0, 0, '', NULL, 'subject=hecontest', '0', '0')");
        $page_id2 = $db->lastInsertId();
        
        $sql7 = $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id2', 'container', 'main', NULL, 1, NULL, NULL)");
        $main_content_id2 = $db->lastInsertId();
        
        $sql8 = $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`,`order`, `params`, `attribs`) VALUES ('$page_id2', 'container', 'middle', '$main_content_id', 1, NULL, NULL )");
        $right_container_id2 = $db->lastInsertId();
        
        $sql9 = $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
('$page_id2', 'widget', 'hecontest.contest-info', '$right_container_id2', 6),
('$page_id2', 'widget', 'hecontest.contest-participants', '$right_container_id2', 7),
('$page_id2', 'widget', 'hecontest.contest-winner', '$right_container_id2', 8),
('$page_id2', 'widget', 'hecontest.contest-partners', '$right_container_id2', 9)");
        
        $sql10 = $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`,`order`, `params`, `attribs`) VALUES ('$page_id2', 'container', 'middle', '$main_content_id2', 1, NULL, NULL )");
        $middle_container_id2 = $db->lastInsertId();
        
        $sql11 = $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
('$page_id2', 'widget', 'hecontest.browse-menu', '$middle_container_id2', 3),
('$page_id2', 'widget', 'core.content', '$middle_container_id2', 4)");
        
        $sql12 = $db->query("INSERT IGNORE INTO `engine4_core_tasks` (`task_id` ,`title` ,`module` ,`plugin` ,`timeout` ,`processes` ,`semaphore` ,`started_last` ,`started_count` ,`completed_last` ,`completed_count` ,`failure_last` ,`failure_count` ,`success_last` ,`success_count`)VALUES
(NULL , 'Hecontest Auto Update', 'hecontest', 'Hecontest_Plugin_Job_Maintenance_Update', 60, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0)");
        
        $sql13 = $db->query("INSERT IGNORE INTO `engine4_activity_notificationtypes` (`type`, `module`, `body`, `is_request`, `handler`, `default`) VALUES ('suggest_hecontest_photo', 'hecontest', '{item:\\$subject} has suggested to you a {item:\\$object:\\hecontest photo}.', '1', 'suggest.handler.request', '1')");
        
        $sql14 = $db->query("INSERT IGNORE INTO  `engine4_core_pages` (`name`, `displayname`, `title`, `description`, `custom`, `levels`, `provides`) VALUES ('hecontest_index_contestview', 'Contest view Page', 'Contest view Page', 'Contest viewPage', 0, NULL, 'subject=hecontest')");
        $main_content_id3 = $db->lastInsertId();
        
        $sql15 = $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `type`, `name`, `order`, `params`, `attribs`) VALUES ('$main_content_id3', 'container', 'main', 2, '[]', NULL)");
        $contest_id3 = $db->lastInsertId();
        
        $sql16 = $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$main_content_id3', 'container', 'middle', '$contest_id3', 6, '[]', NULL)");
        $contest_id_main3 = $db->lastInsertId();
        
        $sql17 = $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$main_content_id3', 'container', 'right', '$contest_id3', 5, '[]', NULL)");
        $contest_id_right3 = $db->lastInsertId();
        
        $sql18 = $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$main_content_id3', 'hecontest.contest-info', '$contest_id_right3', 7, '[]', NULL)");
        $sql19 = $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$main_content_id3', 'hecontest.contest-participants', '$contest_id_right3', 8, '[]', NULL)");
        $sql20 = $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$main_content_id3', 'hecontest.contest-partners', '$contest_id_right3', 9, '[]', NULL)");
        $sql21 = $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$main_content_id3', 'hecontest.contest-countdown', '$contest_id_main3', 3, '[\"[]\"]', NULL)");
        $sql22 = $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$main_content_id3', 'core.content', '$contest_id_main3', 5, '[]', NULL)");
    }
}
