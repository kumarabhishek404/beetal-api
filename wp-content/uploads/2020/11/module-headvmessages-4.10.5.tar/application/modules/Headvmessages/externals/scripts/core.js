var composeInstance;

function removeFromToValue(id) {
    var toValues = headvmessagesCore.wrapper.getElement('input#toValues').value;
    var toValueArray = toValues.split(",");
    var toValueIndex = "";

    var checkMulti = id.search(/,/);

    if (checkMulti != -1) {
        var recipientsArray = id.split(",");
        for (var i = 0; i < recipientsArray.length; i++) {
            headvmessagesCore.removeToValue(recipientsArray[i], toValueArray);
        }
    }
    else {
        headvmessagesCore.removeToValue(id, toValueArray);
    }

    headvmessagesCore.wrapper.getElement('input#send_to').disabled = false;
}

function he_show_message(message, type, delay) {
    var text = '';
    var duration = 400;
    var delay = (delay == undefined) ? 3000 : delay;

    text = message;

    if (window.$message_container == undefined) {
        window.$message_container = new Element('div', {'class': 'he_message_container'});
        $(document.body).adopt(window.$message_container);
    }

    var className = 'he_msg_text';
    if (type == 'error') {
        className = 'he_msg_error';
    } else if (type == 'notice') {
        className = 'he_msg_notice';
    } else {
        className = 'he_msg_text';
    }

    var $message = new Element('div', {
        'class': className,
        'styles': {
            'opacity': 0
        }
    });
    var $close_btn = new Element('a', {
        'class': 'he_close',
        'href': 'javascript://',
        'events': {
            'click': function () {
                $message.fade('out');
                $message.removeClass('visible');

                window.setTimeout(function () {
                    $message.dispose();
                    if (window.$message_container.getElements('.visible').length == 0) {
                        window.$message_container.empty();
                    }
                    ;
                }, duration);
            }
        }
    });

    $message.addClass('visible');
    $message.adopt($close_btn);
    $message.adopt('html', new Element('span', {'html': message}));
    window.$message_container.adopt($message);

    $message.set('tween', {duration: duration});
    $message.fade('in');

    window.setTimeout(function () {
        $message.fade('out');
        $message.removeClass('visible');
        window.setTimeout(function () {
            if (window.$message_container.getElements('.visible').length == 0) {
                window.$message_container.empty();
            }
        }, duration);
    }, delay);
}

var headvmessagesCore = {
    allowSmiles: false,
    allowEnter: false,
    maxRecipients: 10,
    composeNew: null,
    screen: null,
    loader: null,
    delay_check_new: 8000,
    unread_count: 0,
    message_label: "Messages",
    send_state: true,
    smile_load: false,
    smile_visible: false,
    up_interval_id: 0,
    blackLayer: null,

    conversationsWrapper: null,
    messagesWrapper: null,
    backColorTextArea: '#fcf9f9',

    message_send_area: null,
    message_count: 0,
    con_id: 0,
    scripts: '',
    conversation_ids: null,

    wrapper: null,
    linkWrapper: null,
    link: null,

    friendsSuggestUrl: '',

    init: function () {
        var self = this;
    },

    prepare: function () {
        var self = this;
        var tmp = $('core_menu_mini_menu');
        if (tmp) {
            self.link = tmp.getElement('a.core_mini_messages');

            if (self.link) {
                self.link.set('href', 'javascript://');
                self.link.set('id', 'headvmessages-link');
                self.initCheckNewMessage();


                if (!$('headvmessages_wrapper_global')) {
                    $$('body')[0].grab(new Element('div', {"id": "headvmessages_wrapper_global"}));
                }

                $('headvmessages_wrapper_global').grab(new Element('div', {
                    'class': "headvmessages_black_layaer",
                    'id': "headvmessages_black_layaer"
                }));
                $('headvmessages_black_layaer').setStyle('display', 'none');
                self.blackLayer = $('headvmessages_black_layaer');

                $('headvmessages_black_layaer').addEvent('click', function () {
                    self.toggle();
                });

                self.linkWrapper = $('headvmessages_wrapper_global');

                self.wrapper = new Element('div', {'id': 'headvmessages-wrapper'});

                var window_resize = function () {
                    var windowSize = window.getSize(),
                        width = self.wrapper.getSize().x || 920,
                        height = self.wrapper.getSize().y || 520;

                    var left = ( windowSize.x / 2 ) - (width / 2),
                        top = 100; // ( windowSize.y / 2 ) - (height / 2);

                    self.wrapper.setStyle('top', top).setStyle('left', left);
                };

                window.addEvent('resize', function () {
                    window_resize();
                }.bind(this));
                window_resize();

                self.link.addEvent('click', function (e) {
                    self.toggle();
                    window_resize();
                });

                self.messagesWrapper = new Element('div', {'class': 'messages-list'});
                self.conversationsWrapper = new Element('div', {'class': 'conversations-list'});

                self.message_send_area = new Element('div', {'id': 'message_send_area', 'class': 'message_send_area'});  // KAlYSKIN Custom

                self.screen = new Element('div', {'class': 'headvmessages-screen'});
                self.loader = new Element('div', {'class': 'headvmessages-loader headvmessages-loader-circle'});

                self.wrapper.grab(self.conversationsWrapper);
                self.wrapper.grab(self.messagesWrapper);

                self.wrapper.grab(self.message_send_area);

                self.wrapper.grab(self.screen);
                self.wrapper.grab(self.loader);

                self.wrapper.set('style', 'display:none;');

                self.linkWrapper.grab(self.wrapper);

                var close = new Element('a', {
                    'class': 'hei hei-times headvmessages-close-popup'
                });
                close.addEvent('click', function () {
                    self.toggle();
                });
                self.wrapper.grab(close);

                var list = $$('.conversations-list')[0];
                var messages_list = $$('.messages-list')[0];
                var messages_send_area = $$('.message_send_area')[0];
                var switcher = new Element('a', {
                    'id': 'headvmessages-toggle-popup',
                    'class': 'fa fa-reorder',
                    'style': 'z-index:100010'
                });
                self.wrapper.grab(switcher);
                switcher.addEvent('click', function () {
                    var status = list.getStyle('display');
                    if (status == "block") {
                        console.log('100%');
                        messages_list.addClass('headvmessages-full-width');
                        messages_send_area.addClass('headvmessages-full-width');
                        switcher.addClass('headvmessages-menu-closed');
                        list.toggle();
                    }
                    else {
                        console.log('56%');
                        messages_list.removeClass('headvmessages-full-width');
                        messages_send_area.removeClass('headvmessages-full-width');
                        switcher.removeClass('headvmessages-menu-closed');
                        list.toggle();
                    }

                    //     list.toggle();
                    //
                });


            }
        }

    },

    initCheckNewMessage: function () {
        var self = this;
        var checker = function () {
            self.myrequest('headvmessages/index/get-unread-count', {count: self.unread_count}, function (response) {
                if (response.status) {
                    self.unread_count = response.message_count;
                    self.message_label = response.message_label;
                    self.showUnreadMessage();
                }
            }, 'post');
        };
        setInterval(checker, self.delay_check_new);
    },

    showUnreadMessage: function () {
        var self = this;

        if ($$(".menu_core_mini.core_mini_messages")) {
            if ($("message_count")) {
                if (self.unread_count > 0) {
                    $("message_count").set("html", self.unread_count);
                } else {
                    $("message_count").remove();
                }
                $$(".menu_core_mini.core_mini_messages").set("text", self.message_label);
            } else if (self.unread_count > 0) {
                var badge = new Element("span", {
                    class: "minimenu_message_count_bubble",
                    id: "message_count",
                    html: self.unread_count
                });
                $$(".menu_core_mini.core_mini_messages").getParent("li").grab(badge);
                $$(".menu_core_mini.core_mini_messages").set("text", self.message_label);
            }
        } else {
            if (self.unread_count > 0)
                he_show_message(self.message_label, 0, 45000);
        }


    },

    onAir: false,

    toggle: function () {
        var self = this;
        if (!self.wrapper) {
            return;
        }

        if (self.onAir) {
            self.close();
            self.blackLayer.setStyle('opacity', 0);
            setTimeout(function () {
                self.blackLayer.setStyle('display', 'none');
            }, 300);
            self.onAir = false;
        } else {
            self.wrapper.set('style', 'display: block;');
            self.open();
            self.blackLayer.setStyle('display', 'block');
            self.blackLayer.setStyle('opacity', 1);
            self.onAir = true;
        }
    },

    openConversation: function (id) {
        var self = this;
        clearInterval(self.up_interval_id);
        self.con_id = id;
        self.toggleLoader(true);
        new Request.HTML({
            method: 'get',
            data: {conversation_id: id},
            url: en4.core.baseUrl + 'headvmessages/index/conversation',
            evalScripts: false,
            onComplete: function (responseTree, responseElements, responseHTML, responseJavaScript) {

                /*if (self.conversation_ids) {
                 id = JSON.parse(id);
                 id = id[0];
                 self.con_id = id;
                 }*/

                if ($('conversation-' + id) && !$('conversation-' + id).hasClass('headvmessage-active-conversation')) {
                    $('conversation-' + id).addClass('headvmessage-active-conversation');
                }
                $('conversation-' + id).getElement('span.headvmessages-new-conversation').setStyle('display', 'none');

                self.messagesWrapper.set('html', responseHTML);

                if (self.messagesWrapper.getElement('div#message_count_user')) {
                    self.message_count = self.messagesWrapper.getElement('div#message_count_user').get('data-value');
                }
                self.message_send_area.setStyle('display', 'inline-block');
                self.up_interval_id = setInterval(function () {
                    self.update_mess();
                }, 6000);

                eval(responseJavaScript);
                self.prepareComposerLinks();

                self.toggleLoader(false);

                self.initSendEvent(id);
                $$('.messages-list').scrollTo(0, parseInt($('message_list_w').getStyle('height')));

            }
        }).send();

    },

    initConversationsEvents: function () {
        var self = this;

        self.conversationsWrapper.getElements('a.headvmessages-remove').removeEvents().addEvent('click', function (e) {
            var parent = $(this).getParent();
            parent.getElements('a.hei').setStyle('display', 'inline-block');
            $(this).setStyle('display', 'none');
        });

        self.conversationsWrapper.getElements('a.headvmessages-remove-cancel').removeEvents().addEvent('click', function (e) {
            var parent = $(this).getParent();
            parent.getElements('a.hei').setStyle('display', 'none');
            parent.getElements('a.headvmessages-remove').setStyle('display', 'inline-block');
        });

        self.conversationsWrapper.getElements('a.headvmessages-remove-confirm').removeEvents().addEvent('click', function (e) {
                var id = $(this).get('data-id');
                var parent = $(this).getParent('li');

                self.request('headvmessages/index/delete', {id: id}, function (response) {
                    if (response.status) {
                        if (parent.hasClass('headvmessage-active-conversation')) {
                            self.messagesWrapper.set('html', '');
                            console.log('wtf 1');
                            if (!response.cCount) {
                                console.log('wtf 2');
                                self.showNoDialogsSpan();
                            }
                        }
                        parent.remove();
                    } else {
                        parent.getElements('a.hei').setStyle('display', 'inline-block');
                        $(this).setStyle('display', 'none');
                    }
                }, 'post');
            }
        )
        ;

        var items = self.conversationsWrapper.getElements('li.list-group-item');
        items.each(function (el, i) {
            el.removeEvents().addEvent('click', function (e) {

                if (e.target.hasClass('hei')) {
                    return;
                }

                var id = $(this).get('data-id');

                self.openConversation(id);

                items.removeClass('headvmessage-active-conversation');
                $(this).addClass('headvmessage-active-conversation');

                var toggle_popup = $('headvmessages-toggle-popup');
                var list = $$('.conversations-list')[0];
                var messages_list = $$('.messages-list')[0];
                var messages_send_area = $$('.message_send_area')[0];

                if (toggle_popup.getStyle('display') == "block") {
                    messages_list.addClass('headvmessages-full-width');
                    messages_send_area.addClass('headvmessages-full-width');
                    list.toggle();
                }
            });
        });
        self.wrapper.getElement('a#headvmessages-compose-new').addEvent('click', function () {
            self.wrapper.getElement('#message_send_area').setStyle('display', 'none');
            self.showComposeForm();
            var toggle_popup = $('headvmessages-toggle-popup');
            var list = $$('.conversations-list')[0];
            var messages_list = $$('.messages-list')[0];
            var messages_send_area = $$('.message_send_area')[0];

            if (toggle_popup.getStyle('display') == "block") {
                messages_list.addClass('headvmessages-full-width');
                messages_send_area.addClass('headvmessages-full-width');
                list.toggle();
            }
        });
    },

    prepareComposerLinks: function () {
        var self = this;
        window.id_time_ComposerLinks = setInterval(function () {
            try {
                var ok = 0;
                if (self.wrapper.getElement('a#compose-photo-activator')) {
                    self.wrapper.getElement('a#compose-photo-activator')
                        .addClass('hei hei-camera')
                        .set('text', '')
                        .setStyle('background', 'none')
                    ;
                    ok++;
                }
                if (self.wrapper.getElement('a#compose-link-activator')) {
                    self.wrapper.getElement('a#compose-link-activator')
                        .addClass('hei hei-link')
                        .set('text', '')
                        .setStyle('background', 'none')
                    ;
                    ok++;
                }
                if (self.wrapper.getElement('a#compose-music-activator')) {
                    self.wrapper.getElement('a#compose-music-activator')
                        .addClass('hei hei-music')
                        .set('text', '')
                        .setStyle('background', 'none')
                    ;
                    ok++;
                }
                if (self.wrapper.getElement('a#compose-video-activator')) {
                    self.wrapper.getElement('a#compose-video-activator')
                        .addClass('hei hei-film')
                        .set('text', '')
                        .setStyle('background', 'none')
                    ;
                    ok++;
                }
            } catch (e) {
                console.log("failed to change classes!!!" + ' Success:  ' + ok);
            }

        }, 1000);
        setTimeout(function () {
            clearInterval(window.id_time_ComposerLinks);
        }, 6000)

    },

    showComposeForm: function () {
        var self = this;
        self.message_send_area.setStyle('display', 'none');
        self.toggleLoader(true);
        new Request.HTML({
            method: 'get',
            data: {},
            url: en4.core.baseUrl + 'headvmessages/index/compose',
            evalScripts: false,
            onComplete: function (responseTree, responseElements, responseHTML, responseJavaScript) {

                self.messagesWrapper.set('html', responseHTML);
                eval(responseJavaScript);

                self.initCoreComposer();
                self.initSmiles();
                self.prepareComposerLinks();
                self.initComposerEvents();
                self.toggleLoader(false);
            }
        }).send();
    },

    initSmiles: function () {
        var self = this;
        if (self.allowSmiles) {
            var t = self.wrapper.getElement('#messages-list-controls');
            var smile = new Element('a', {
                'id': 'compose-smile-activator',
                'class': 'compose-activator buttonlink hei hei-smile-o',
                'onclick': 'javascript:void(0);',
                'style': 'background: none;'
            });
            smile.addEvent('click', function () {
                if (!self.smile_load) {
                    self.showSmiles();
                    self.smile_visible = true;

                } else {
                    if (self.smile_visible) {
                        $('headvmessages-smiles').setStyle('display', 'none');
                        self.smile_visible = false;
                    } else {
                        $('headvmessages-smiles').setStyle('display', 'inline-block');
                        self.smile_visible = true;
                    }

                }

            });
            t.grab(smile);
        }
    },

    showSmiles: function () {
        var self = this;

        new Request.HTML({
            url: en4.core.baseUrl + 'heemoticon/index/index?format=html',
            method: 'get',
            evalScripts: false,
            onRequest: function () {
                self.toggleLoader(true);
            },
            onComplete: function (responseTree, responseElements, responseHTML, responseJavaScript) {
                self.wrapper.getElement('#headvmessages-smiles').set('html', responseHTML).setStyle('display', 'inline-block');
                self.smile_load = true;
                var cont = self.wrapper.getElements('.wall_data_comment');
                var opt = {
                    autoHide: 1,
                    fade: 1,
                    className: 'scrollbar',
                    proportional: true,
                    proportionalMinHeight: 15,
                    left: 295,
                    top: 50
                };
                var myScrollable = new Scrollable(cont, opt);

                self.wrapper.getElements('.smiles_standart').addEvent('click', function () {
                    console.log('smile click');
                    $('headvmessages-body').set('value', $('headvmessages-body').get('value') + $(this).get('rev'));
                });

                self.wrapper.getElements('.smiles_NEW').addEvent('click', function () {
                    $('headvmessages-body').set('value', $('headvmessages-body').get('value') + ' (H)' + $(this).get('data-id') + '(/H)  ');

                    console.log('animated smile click');
                });
                $('headvmessages-smiles').getElement('.add-icon-smiles').addEvent('click', function () {
                    self.smile_load = false;
                });
                self.toggleLoader(false);
            },
            onFailure: function () {
                self.toggleLoader(false);
            },
            onCancel: function () {
                self.toggleLoader(false);
            },
            onException: function () {
                self.toggleLoader(false);
            }
        }).send();
    },

    initCoreComposer: function () {
        var mel = $('messages-list-controls');
        var tel = $('messages-list-controls-tray');

        if (!Browser.Engine.trident && !DetectMobileQuick() && !DetectIpad()) {
            composeInstance = new Composer('hidden-body', {
                overText: false,
                menuElement: mel,
                trayElement: tel,
                baseHref: en4.core.baseUrl,
                hideSubmitOnBlur: false,
                allowEmptyWithAttachment: false,
                submitElement: 'messages-list-send',
                type: 'message'
            });
        }
        en4.core.runonce.trigger();
    },

    initEnterSendEvent: function () {
        var self = this;
        var text = self.wrapper.getElement('textarea#headvmessages-body');
        var send = self.wrapper.getElement('a#messages-list-send');

        var t = text.removeEvents();
        if (text && send) {
            text.removeEvents();
            text.addEvent('keypress', function (e) {
                if (e.key == 'enter') {
                    if (self.allowEnter) {
                        send.click();
                        return false;
                    }
                }
            });
            text.addEvent('click', function (e) {
                if ($('headvmessages-smiles')) {
                    $('headvmessages-smiles').setStyle('display', 'none');
                    self.smile_visible = false;
                }
            });
        }
    },

    initSendEvent: function (id) {
        var self = this;

        self.wrapper.getElement('a#messages-list-send').addEvent('click', function () {
            var form = $(this).getParent('form');
            var data = self.collectForm(form);
            data.id = self.con_id;

            if (!$('headvmessages-body').value.trim().length) {
                self.markField($('headvmessages-body'));
                return;
            }

            if (self.send_state) {
                self.send_state = false;
                self.request('headvmessages/index/reply', data, function (response) {
                    var type = '';
                    if (response.status) {

                        $('headvmessages-body').set('value', '');
                        $('headvmessages-smiles').setStyle('display', 'none');
                        self.smile_visible = false;
                        if (response.lastMessage != '') {
                            var lastmess = new Element('div', {'html': response.lastMessage});
                            var item = lastmess.getElement('div.headvmessage-item');
                            $('message_list_w').grab(item);
                            var titledate = item.getElement('small span').get('title');
                            var textdate = item.getElement('small span').get('text');
                            var con_date = self.wrapper.getElement('li.headvmessage-active-conversation').getElement('span.date span');
                            con_date.set('title', titledate);
                            con_date.set('text', textdate);
                            con_date.set('class', 'timestamp timestamp-update');
                            self.message_count += 1;
                            $$('.messages-list').scrollTo(0, parseInt($('message_list_w').getStyle('height')));
                        } else {
                            self.openConversation(self.con_id);
                        }

                        if ($('compose-link-menu')) {
                            $('compose-link-menu').getElement('a').click();
                        }
                        if ($('compose-video-menu')) {
                            $('compose-video-menu').getElement('a').click();
                        }
                        self.send_state = false;
                        setTimeout(function () {
                            $$('.messages-list').scrollTo(0, parseInt($('message_list_w').getStyle('height')));
                            $$('.messages-list').scrollTo(0, parseInt($('message_list_w').getStyle('height')));
                            self.send_state = true;
                        }, 1000);


                    } else {
                        type = 'error';
                    }
                    if (response.message) {
                        he_show_message(response.message, type, 5000);
                    }
                }, 'post');
            }

            if ($$("#compose-photo-menu a")[0]) $$("#compose-photo-menu a")[0].click();

            setTimeout(function () {
                $$('.messages-list').scrollTo(0, parseInt($('message_list_w').getStyle('height')));
                $$('.messages-list').scrollTo(0, parseInt($('message_list_w').getStyle('height')));
                self.send_state = true;
            }, 4000);
        });
    },

    initComposerEvents: function () {
        var self = this;
        if (self.wrapper.getElement('textarea#headvmessages-body'))
            self.backColorTextArea = self.wrapper.getElement('textarea#headvmessages-body').getStyle('background-color');

        self.wrapper.getElement('a#messages-list-send').addEvent('click', function () {
            var form = $(this).getParent('form');

            var data = self.collectForm(form);

            if (!self.checkForm()) {
                return;
            }

            self.request('headvmessages/index/compose', data, function (response) {
                var type = '';
                if (response.status) {
                    self.conversationsWrapper.set('html', response.conversationsHtml);
                    self.initConversationsEvents();
                    self.openConversation(response.id);
                } else {
                    type = 'error';
                }
                if (response.message) {
                    he_show_message(response.message, type, 5000);
                }
            }, 'post');

        });

        new Autocompleter.Request.JSON('send_to', self.friendsSuggestUrl, {
            'minLength': 1,
            'delay': 250,
            'selectMode': 'pick',
            'autocompleteType': 'message',
            'multiple': false,
            'className': 'message-autosuggest',
            'filterSubset': true,
            'tokenFormat': 'object',
            'tokenValueKey': 'label',
            'injectChoice': function (token) {
                if (token.type == 'user') {
                    var choice = new Element('li', {
                        'class': 'autocompleter-choices',
                        'html': token.photo,
                        'id': token.label
                    });
                    if (typeof(window.scrollTo) !== "function") {

                        choice.addEvent("click", function (e) {
                            var id = token.id;
                            var label = token.label;
                            self.wrapper.getElement('input#toValues').set("value", id);
                            var userSpan = new Element("span", {id: "tospan_" + label + "_" + id, class: "tag"});
                            new Element("span", {text: label}).inject(userSpan);
                            var aInSpan = new Element("a", {href: "javascript:void(0);", text: "x"});
                            aInSpan.addEvent("click", function () {
                                userSpan.remove();
                                self.wrapper.getElement('input#toValues').set("value", "");
                            });
                            aInSpan.inject(userSpan);
                            self.wrapper.getElement('#toValues-element').set("html", "");
                            self.wrapper.getElement('#toValues-element').grab(userSpan);

                        });
                    }
                    new Element('div', {
                        'html': this.markQueryValue(token.label),
                        'class': 'autocompleter-choice'
                    }).inject(choice);
                    this.addChoiceEvents(choice).inject(this.choices);
                    choice.store('autocompleteChoice', token);
                }
                else {
                    var choice = new Element('li', {
                        'class': 'autocompleter-choices friendlist',
                        'id': token.label
                    });
                    new Element('div', {
                        'html': this.markQueryValue(token.label),
                        'class': 'autocompleter-choice'
                    }).inject(choice);
                    this.addChoiceEvents(choice).inject(this.choices);
                    choice.store('autocompleteChoice', token);
                }

            },
            onPush: function () {
                if (self.wrapper.getElement('input#toValues').value.split(',').length >= self.maxRecipients) {
                    self.wrapper.getElement('input#send_to').disabled = true;
                }
            }
        });
    },

    collectForm: function (form) {
        var formObjects = form.toQueryString().parseQueryString();
        return formObjects;
    },

    checkForm: function () {
        var self = this;

        var toValues = self.wrapper.getElement('input#toValues').value.trim();
        var subj = self.wrapper.getElement('input#headvmessages-subject').value;
        var body = self.wrapper.getElement('textarea#headvmessages-body').value;

        var result = true;

        if (!toValues.length) {
            self.markField(self.wrapper.getElement('input#send_to'));
            result = false;
        }
        if (!subj.length) {
            self.markField(self.wrapper.getElement('input#headvmessages-subject'));
            result = false;
        }
        if (!body.length) {
            self.markField(self.wrapper.getElement('textarea#headvmessages-body'));
            result = false;
        }

        return result;
    },

    markField: function (el) {
        var back = el.getStyle('background-color');
        el.setStyle('background-color', 'salmon');
        setTimeout(function () {
            el.setStyle('background-color', back);
        }, 2000);
    },

    removeFromToValue: function (id) {
        var self = this;
        var toValues = self.wrapper.getElement('input#toValues').value;
        var toValueArray = toValues.split(",");
        var toValueIndex = "";

        var checkMulti = id.search(/,/);

        if (checkMulti != -1) {
            var recipientsArray = id.split(",");
            for (var i = 0; i < recipientsArray.length; i++) {
                self.removeToValue(recipientsArray[i], toValueArray);
            }
        }
        else {
            self.removeToValue(id, toValueArray);
        }

        self.wrapper.getElement('input#send_to').disabled = false;
    },

    removeToValue: function (id, toValueArray) {
        var self = this;
        for (var i = 0; i < toValueArray.length; i++) {
            if (toValueArray[i] == id) toValueIndex = i;
        }

        toValueArray.splice(toValueIndex, 1);
        self.wrapper.getElement('input#toValues').value = toValueArray.join();
    },

    toggleLoader: function (mode) {
        var self = this;
        if (mode) {
            self.screen.setStyle('display', 'block');
            self.loader.setStyle('display', 'block');
        } else {
            self.screen.setStyle('display', 'none');
            self.loader.setStyle('display', 'none');
        }
    },

    showNoDialogsSpan: function () {
        var self = this;
        var span = new Element('span',
            {
                'class': 'headvmessages-no-active-dialogs',
                'text': en4.core.language.translate('HEADVMESSAGES_No active dialogs')
            }
        );
        span.addEvent('click', function (e) {
            self.showComposeForm();
        });
        self.messagesWrapper.grab(span);
    },

    openConversationFromNotification: function (id) {
        var self = this;

        self.request('headvmessages/index', {}, function (response) {
            if (response.status) {
                self.conversationsWrapper.set('html', response.html);
                self.initConversationsEvents();
                if (!response.cCount) {
                    self.showNoDialogsSpan();
                }

                self.openConversation(id);
            }
        }, 'post');

        $$('html')[0].setStyle('overflow-y', 'hidden');
        if ($('store-cart-box')) {
            $('store-cart-box').setStyle('z-index', '99');
        }
    },

    open: function () {
        var self = this;

        self.request('headvmessages/index', {}, function (response) {
            if (response.status) {
                self.conversationsWrapper.set('html', response.html);
                self.message_send_area.set('html', response.SenderForm);

                var scr = new Element('div', {'html': response.SenderForm});
                self.scripts = scr.getElements('script');
                var el = headvmessagesCore.scripts;
                var srcipt = '';
                for (var i = 0; i < el.length; i++) {
                    srcipt += '  ' + el[i].get('html');
                }
                eval(srcipt);
                self.prepareComposerLinks();
                self.initConversationsEvents();
                self.initCoreComposer();
                self.initEnterSendEvent();
                self.initSmiles();
                self.message_send_area.setStyle('display', 'none');
                if (!response.cCount) {
                    self.showNoDialogsSpan();
                }
            }
        }, 'post');


        $$('html')[0].setStyle('overflow-y', 'hidden');
        if ($('store-cart-box')) {
            $('store-cart-box').setStyle('z-index', '99');
        }
    },

    update_mess: function () {
        var self = this;

        var data = {
            con_id: self.con_id
        };
        self.myrequest('headvmessages/index/messupdate', data, function (response) {
            if (response.status) {
                if (response.count > self.message_count) {
                    self.openConversation(self.con_id);
                    setTimeout(function () {
                        $$('.messages-list').scrollTo(0, parseInt($('message_list_w').getStyle('height')));
                    }, 3000);
                }
                self.message_count = response.count;
            }
        }, 'post');

    },

    close: function () {
        var self = this;
        self.smile_load = false;
        if (!self.wrapper) {
            return;
        }
        $$('html')[0].setStyle('overflow-y', 'scroll');
        if ($('store-cart-box')) {
            $('store-cart-box').setStyle('z-index', '100');
        }
        self.wrapper.set('style', 'display: none;');
        self.conversationsWrapper.set('html', '');
        self.messagesWrapper.set('html', '');
        self.message_send_area.set('html', '');
        clearInterval(self.up_interval_id);

        self.toggleLoader(false);

        self.onAir = false;
    },

    request: function (url, data, callback, method) {
        var self = this;
        data.format = 'json';
        new Request.JSON({
            url: en4.core.baseUrl + url,
            data: data,
            onRequest: function () {
                self.toggleLoader(true);
            },
            onSuccess: function (response) {
                callback(response);
                self.toggleLoader(false);
            },
            onFailure: function () {
                self.toggleLoader(false);
            },
            onCancel: function () {
                self.toggleLoader(false);
            },
            onException: function () {
                self.toggleLoader(false);
            },
            onComplete: function () {
                self.toggleLoader(false);
            }
        }).send();
    },

    myrequest: function (url, data, callback, method) {
        var self = this;
        data.format = 'json';
        new Request.JSON({
            url: en4.core.baseUrl + url,
            data: data,
            onRequest: function () {

            },
            onSuccess: function (response) {
                callback(response);

            },
            onFailure: function () {
                self.toggleLoader(false);
            },
            onCancel: function () {
                self.toggleLoader(false);
            },
            onException: function () {
                self.toggleLoader(false);
            },
            onComplete: function () {
                self.toggleLoader(false);
            }
        }).send();
    }
};

function heMsgClearUrl() {
    var heMsg = document.querySelector(".core_mini_messages");

    if (heMsg) {
        heMsg.href = "javascript://";
    } else
        setTimeout(heMsgClearUrl, 100);

}
heMsgClearUrl();
