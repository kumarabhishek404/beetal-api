<?php
/**
 * Mass Email
 *
 * @author Eldar
 * @copyright Hire-Experts LLC
 * @version Mass Email 2.01
 */
class he_mass_mail
{
	function create_campaign($subject, $message, $restriction_type, $levels = array(), $subnets = array(), $cat_selected = 0, $include_subscribers = false)
	{
		global $setting;
		
		set_time_limit(600);
		
		if( !$subject || !$message ) return false;
		
		$conditions = array();
		$joins = array();
		$conditions_glue = ' AND ';
		if( $restriction_type==1 )
		{
			$levels = (array)$levels;
			$subnets = (array)$subnets;
			if( !$levels && !$subnets ) return false;
		
			if( $levels )
				$conditions[] = "user_level_id IN('".implode("', '", $levels)."')";
			
			if( $subnets )
				$conditions[] = "user_subnet_id IN('".implode("', '", $subnets)."')";
			
			$conditions_glue = ' OR ';
		}
		else
		{
			$field = new se_field("profile");
			$field->cat_list(0, 0, 1, "profilecat_id='{$cat_selected}'", "", "profilefield_search<>'0'");
		  
			$joins[] = "LEFT JOIN se_profilevalues ON se_profilevalues.profilevalue_user_id=se_users.user_id";
			
			$conditions[] = "se_users.user_profilecat_id='$cat_selected'";
			
			if($field->field_query != "")
				$conditions[] = $field->field_query;
			
			if( $_REQUEST['user_withphoto'] ) 
				$conditions[] = "user_photo<>''";
		}
	
		#generate fetch users query
		$email_query = "SELECT user_username FROM se_users";
		
		if( $joins ) $email_query .= ' '.implode(' ', $joins);
		if( $conditions ) $email_query .= ' WHERE '.implode($conditions_glue, $conditions);
		
		#create campaign
		$res = he_database::query($email_query);
		$recipients_count = he_database::num_rows($res);
        if( $include_subscribers ) $recipients_count += he_mass_mail::get_subscribers_count();

		$campaign_id = he_mass_mail::insert_campaign($subject, $message, $recipients_count);
		if( !$campaign_id ) return false;
		
		while( $user = he_database::fetch_row_from_resource($res) )
		{
			he_mass_mail::insert_into_queue($campaign_id, $user['user_username']);
		}
        if( $include_subscribers )
        {
            $subscribers = he_mass_mail::get_subscribers(0, 100000);
            foreach($subscribers as $subscriber)
                he_mass_mail::insert_into_queue($campaign_id, $subscriber['id'], true);
        }

		return true;
	}
	
	function insert_campaign($subject, $message, $recipient_count)
	{
		he_database::query("INSERT INTO se_mass_mail_campaign SET subject='".he_database::real_escape($subject)."', message='".he_database::real_escape(htmlspecialchars_decode($message))."', recipient_count=$recipient_count, sent_time=UNIX_TIMESTAMP()");
		return he_database::insert_id();
	}
	
	function get_campaigns($from, $count)
	{
		$from = intval($from);
		$count = intval($count);
		return he_database::fetch_array("SELECT * FROM se_mass_mail_campaign ORDER BY sent_time DESC LIMIT $from, $count");
	}
	
	function get_campaign($id)
	{
		return he_database::fetch_row("SELECT * FROM se_mass_mail_campaign WHERE id=".intval($id));
	}
	
	function insert_into_queue($campaign_id, $recipient, $subscriber = false)
	{
		he_database::query("INSERT INTO se_mass_mail_queue SET campaign_id=$campaign_id, recipient='".he_database::real_escape($recipient)."', is_subscriber=".intval($subscriber));
	}
	
	function send_message_from_queue($count)
	{
		global $setting;
		$count = intval($count) ? intval($count) : 10;
		$campaigns = array();
		$alt_body = SE_Language::_get(690690035);
		
		$messages = he_database::fetch_array("SELECT * FROM se_mass_mail_queue ORDER BY id LIMIT $count");
		foreach ($messages as $message)
		{
			he_database::query("DELETE FROM se_mass_mail_queue WHERE id={$message['id']}");
			if( !he_database::affected_rows() ) continue;
			
			if( !$campaigns[$message['campaign_id']] )
				$campaigns[$message['campaign_id']] = he_mass_mail::get_campaign($message['campaign_id']);
			$campaign = $campaigns[$message['campaign_id']];

            if( $message['is_subscriber'] )
            {
                $subscriber = he_mass_mail::get_subscriber($message['recipient']);
                if( !$subscriber ) continue;

                $name = $subscriber['name'];
                $email = $subscriber['email'];
            }
            else
            {
                $user = new se_user(array(0, $message['recipient']));
                if( !$user->user_exists ) continue;

                $name = $user->user_info['user_displayname'];
                $email = $user->user_info['user_email'];
            }

			$mail = new PHPMailer();
			
			$mail->From = $setting['setting_email_fromemail'];
			$mail->FromName = $setting['setting_email_fromname'];
			$mail->Subject = str_replace(array('[displayname]', '[email]'), array($name, $email), $campaign['subject']);
			$mail->AltBody = $alt_body;
			$mail->MsgHTML(str_replace(array('[displayname]', '[email]'), array($name, $email), $campaign['message']));
			$mail->AddAddress($email, $name);
			$mail->CharSet = 'UTF-8';
			
			$mail->Send();
		}
	}
	
	function cron()
	{
		global $setting;
		
		if( $setting['setting_mass_email_last_execute'] > time()-60 ) return;
		$setting['setting_mass_email_last_execute'] = time();
		he_database::query("UPDATE se_settings SET setting_mass_email_last_execute={$setting['setting_mass_email_last_execute']}");
		
		he_mass_mail::send_message_from_queue($setting['setting_mass_email_per_minute']);
	}

    function subscribe($name, $email)
    {
        $name = trim($name);
        $email = trim($email);
        if( !is_email_address($email) || !strlen($name) ) return false;

        if( !he_database::fetch_row(he_database::placeholder("SELECT * FROM se_mass_message_subscriber WHERE `email`='?'", $email)) )
            he_database::query(he_database::placeholder("INSERT INTO se_mass_message_subscriber SET `name`='?',`email`='?'", $name, $email));
        return true;
    }

    function unsubscribe($email)
    {
        $email = trim($email);
        if( !is_email_address($email) ) return false;

        he_database::query(he_database::placeholder("DELETE FROM se_mass_message_subscriber WHERE `email`='?'", $email));
        return true;
    }

    function get_subscriber($id)
    {
        return he_database::fetch_row(he_database::placeholder("SELECT * FROM se_mass_message_subscriber WHERE id=?", intval($id)));
    }

    function get_subscribers($from, $count)
    {
        return he_database::fetch_array(he_database::placeholder("SELECT * FROM se_mass_message_subscriber LIMIT ?, ?", intval($from), intval($count)));
    }

    function get_subscribers_count()
    {
        return he_database::fetch_field("SELECT COUNT(*) FROM se_mass_message_subscriber");
    }

}

?>