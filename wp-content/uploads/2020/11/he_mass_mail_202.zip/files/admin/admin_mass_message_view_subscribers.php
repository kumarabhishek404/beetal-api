<?php
/**
 * @author Eldar
 * @copyright Hire-Experts LLC
 * @version Mass Email/Message Pro 2.01
 */

$page = "admin_mass_message_view_subscribers";
include("admin_header.php");

include_once "./admin_header_he_core.php";
include_once "../include/class_he_mass_message.php";
include_once "../include/class_he_mass_mail.php";

if( is_array($_POST['subscribers']) )
{
    foreach($_POST['subscribers'] as $email)
        he_mass_mail::unsubscribe($email);
}


$on_page = 20;
$current_page = intval($_REQUEST['page']) ? intval($_REQUEST['page']) : 1;
$total = he_mass_mail::get_subscribers_count();

$subscribers = he_mass_mail::get_subscribers((($current_page*$on_page)-$on_page), $on_page);
$smarty->assign_by_ref('subscribers', $subscribers);

$smarty->assign('paging', array( 'total' => $total, 'on_page' => $on_page, 'pages' => 5 ));

include "admin_footer.php";
?>