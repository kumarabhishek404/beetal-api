<?php
/**
 * @author Eldar
 * @copyright Hire-Experts LLC
 * @version Mass Email/Message Pro 2.01
 */

$page = "admin_mass_message_view_campaign";
include("admin_header.php");

include_once "./admin_header_he_core.php";
include_once "../include/class_he_mass_message.php";
include_once "../include/class_he_mass_mail.php";

if( $_GET['message_campaign_id'] ) {
    $campaign = he_mass_message::get_campaign(intval($_GET['message_campaign_id']));
    $type = 'message';
}
elseif( $_GET['mail_campaign_id'] ) {
    $campaign = he_mass_mail::get_campaign(intval($_GET['mail_campaign_id']));
    $type = 'mail';
}
else
    exit;


$smarty->assign('campaign', $campaign);

include "admin_footer.php";
?>