<?php

$plugin_name = "Mass Mailing Premium";
$plugin_version = "2.02";
$req_core_version = "3.01";
$plugin_type = "he_mass_mail";
$plugin_desc = "This plugin allows admin to easily send messages and email announcements to selected users and subscribers. Also group and event owners/officers can send mass message. It is a paid plugin from Hire-Experts LLC. Please go to <a href=\"http://www.hire-experts.com/\">Hire-Experts.com</a> to get this plugin latest version.";
$plugin_icon = "he_mass_message16.gif";
$plugin_menu_title = "";
$plugin_pages_main = "690690029<!>he_mass_message16.gif<!>admin_mass_message_tool.php<~!~>";
$plugin_pages_level = "";
$plugin_url_htaccess = "";
$plugin_db_charset = 'utf8';
$plugin_db_collation = 'utf8_unicode_ci';


if($install == "he_mass_mail") {
	
	//check core library
	$sql = "SELECT `plugin_version` FROM `se_plugins` WHERE plugin_type='he_core' AND `plugin_disabled`=0 LIMIT 1";
	$resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
	$core_version = $database->database_fetch_array($resource);
	if ( floatval($core_version[0]) < floatval($req_core_version) ) {
		die ('This plugin requires Hire-Experts Core Library. Please install latest version of Hire-Experts Core Library plugin. You can download it from My Plugins section in Hire-Experts.com for FREE.');
	}
	
	//check if plugin was already installed
	$sql = "SELECT * FROM se_plugins WHERE plugin_type='$plugin_type' LIMIT 1";
	$resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
	
	$plugin_info = array();
	if( $database->database_num_rows($resource) )
		$plugin_info = $database->database_fetch_assoc($resource);
	
	
	//install plugin
	if( !$plugin_info ) {
		$database->database_query("INSERT INTO se_plugins (plugin_name,
			plugin_version,
			plugin_type,
			plugin_desc,
			plugin_icon,
			plugin_menu_title,
			plugin_pages_main,
			plugin_pages_level,
			plugin_url_htaccess
			) VALUES (
			'$plugin_name',
			'$plugin_version',
			'$plugin_type',
			'".str_replace("'", "\'", $plugin_desc)."',
			'$plugin_icon',
			'',
			'$plugin_pages_main',
			'',
			'$plugin_url_htaccess')");
	
	
	//update plugin
	} else {
		$database->database_query("UPDATE se_plugins SET plugin_name='$plugin_name',
			plugin_version='$plugin_version',
			plugin_desc='".str_replace("'", "\'", $plugin_desc)."',
			plugin_icon='$plugin_icon',
			plugin_menu_title='',
			plugin_pages_main='$plugin_pages_main',
			plugin_pages_level='',
			plugin_url_htaccess='$plugin_url_htaccess' WHERE plugin_type='$plugin_type'");
	}


	if( !$database->database_num_rows(($database->database_query("SHOW COLUMNS FROM se_settings LIKE 'setting_mass_message_from_user'"))) )
	{
		$database->database_query("ALTER TABLE `se_settings` ADD `setting_mass_message_from_user` varchar(255) NOT NULL;");
		$database->database_query("ALTER TABLE `se_settings` ADD `setting_mass_message_per_minute` int(10) NOT NULL;");
		$database->database_query("ALTER TABLE `se_settings` ADD `setting_mass_email_per_minute` int(10) NOT NULL;");
		$database->database_query("ALTER TABLE `se_settings` ADD `setting_mass_message_last_execute` int(10) unsigned NOT NULL;");
		$database->database_query("ALTER TABLE `se_settings` ADD `setting_mass_email_last_execute` int(10) unsigned NOT NULL;");
		$database->database_query("CREATE TABLE `se_mass_message_campaign` (`id` int(11) NOT NULL AUTO_INCREMENT,`subject` varchar(255) NOT NULL,`message` text NOT NULL,`sender` varchar(255) NOT NULL,`recipient_count` int(10) NOT NULL,`sent_time` int(10) unsigned NOT NULL,PRIMARY KEY (`id`)	) ENGINE=MyISAM;");
		$database->database_query("CREATE TABLE `se_mass_message_queue` (`id` int(10) unsigned NOT NULL AUTO_INCREMENT,`campaign_id` int(11) NOT NULL,`recipient` varchar(255) NOT NULL,PRIMARY KEY (`id`)) ENGINE=MyISAM;");
	}
	
	$database->database_query("CREATE TABLE IF NOT EXISTS `se_mass_mail_campaign` (`id` int(11) NOT NULL AUTO_INCREMENT,`subject` varchar(255) NOT NULL,`message` text NOT NULL,`recipient_count` int(10) NOT NULL,`sent_time` int(10) unsigned NOT NULL,PRIMARY KEY (`id`)) ENGINE=MyISAM;");
	$database->database_query("CREATE TABLE IF NOT EXISTS `se_mass_mail_queue` (`id` int(10) unsigned NOT NULL AUTO_INCREMENT,`campaign_id` int(11) NOT NULL,`recipient` varchar(255) NOT NULL,PRIMARY KEY (`id`)) ENGINE=MyISAM;");
	$database->database_query("CREATE TABLE `se_mass_message_subscriber` (`id` INT NOT NULL AUTO_INCREMENT,`name` VARCHAR(255) NOT NULL ,`email` VARCHAR(255) NOT NULL,PRIMARY KEY (`id`),UNIQUE (`email`));");


    if( !$database->database_num_rows(($database->database_query("SHOW COLUMNS FROM se_mass_mail_queue LIKE 'is_subscriber'"))) )
    {
        $database->database_query("ALTER TABLE `se_mass_mail_queue` ADD `is_subscriber` TINYINT( 1 ) DEFAULT '0' NOT NULL;");
    }


	if( !$setting['setting_mass_message_per_minute'] )
		$database->database_query("UPDATE `se_settings` SET `setting_mass_message_per_minute`='30' WHERE `setting_id`=1");
	if( !$setting['setting_mass_email_per_minute'] )
		$database->database_query("UPDATE `se_settings` SET `setting_mass_email_per_minute`='20' WHERE `setting_id`=1");
	

	//insert langs
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690001 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690001', '1', 'Mass Mailing Premium Tools', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Mass Mailing Premium Paid Tools', languagevar_default='mass_message' WHERE languagevar_id='690690001' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690002 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690002', '1', 'This plugin allows you to easily send message and email announcements to selected users. You can restrict recipients by user level, subnetwork or profile fields. Also you can use placeholders(like recipient display name and email) in an announcement\'s subject and message body. The plugin allows queueing mass messages, emails and sending them in a much more controlled way in order to prevent server overload and marking host as spammer. It is very useful feature if you have a large user base.', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='This plugin allows you to easily send message and email announcements to selected users. You can restrict recipients by user level, subnetwork or profile fields. Also you can use placeholders(like recipient display name and email) in an announcement\'s subject and message body. The plugin allows queueing mass messages, emails and sending them in a much more controlled way in order to prevent server overload and marking host as spammer. It is very useful feature if you have a large user base.', languagevar_default='mass_message' WHERE languagevar_id='690690002' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690003 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690003', '1', 'Settings', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Settings', languagevar_default='mass_message' WHERE languagevar_id='690690003' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690004 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690004', '1', 'Send Mass Message', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Send Mass Message', languagevar_default='mass_message' WHERE languagevar_id='690690004' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690005 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690005', '1', 'Send Mass Email', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Send Mass Email', languagevar_default='mass_message' WHERE languagevar_id='690690005' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690006 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690006', '1', 'From User(Mass Message)', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='From User(Mass Message)', languagevar_default='mass_message' WHERE languagevar_id='690690006' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690007 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690007', '1', 'Local messages count sending per minute', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Local messages count sending per minute', languagevar_default='mass_message' WHERE languagevar_id='690690007' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690008 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690008', '1', 'Emails count sending per minute', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Emails count sending per minute', languagevar_default='mass_message' WHERE languagevar_id='690690008' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690009 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690009', '1', 'Save changes', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Save changes', languagevar_default='mass_message' WHERE languagevar_id='690690009' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690010 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690010', '1', 'Changes have been saved.', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Changes have been saved.', languagevar_default='mass_message' WHERE languagevar_id='690690010' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690011 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690011', '1', 'Failed. Please check carefully and try again', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Failed. Please check carefully and try again', languagevar_default='mass_message' WHERE languagevar_id='690690011' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690012 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690012', '1', 'Subject', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Subject', languagevar_default='mass_message' WHERE languagevar_id='690690012' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690013 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690013', '1', 'Message', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Message', languagevar_default='mass_message' WHERE languagevar_id='690690013' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690014 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690014', '1', 'Recipients', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Recipients', languagevar_default='mass_message' WHERE languagevar_id='690690014' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690015 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690015', '1', 'Select which users will receive this message announcement. By default, all user levels and subnetworks are selected - this means that every user on your social network will receive this announcement. Use CTRL-click to select or deselect multiple user levels or subnetworks. If a user matches any user level OR subnetwork you have selected here, they will receive this announcement.', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Select which users will receive this message announcement. By default, all user levels and subnetworks are selected - this means that every user on your social network will receive this announcement. Use CTRL-click to select or deselect multiple user levels or subnetworks. If a user matches any user level OR subnetwork you have selected here, they will receive this announcement.', languagevar_default='mass_message' WHERE languagevar_id='690690015' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690016 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690016', '1', 'Available Variables: [displayname],[email]', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Available Variables: [displayname],[email]', languagevar_default='mass_message' WHERE languagevar_id='690690016' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690017 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690017', '1', 'Send Message', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Send Message', languagevar_default='mass_message' WHERE languagevar_id='690690017' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690018 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690018', '1', 'User Levels', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='User Levels', languagevar_default='mass_message' WHERE languagevar_id='690690018' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690019 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690019', '1', 'Subnetworks', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Subnetworks', languagevar_default='mass_message' WHERE languagevar_id='690690019' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690020 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690020', '1', 'Profile Categories', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Profile Categories', languagevar_default='mass_message' WHERE languagevar_id='690690020' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690021 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690021', '1', '(signup default)', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='(signup default)', languagevar_default='mass_message' WHERE languagevar_id='690690021' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690022 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690022', '1', 'Default Subnetwork', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Default Subnetwork', languagevar_default='mass_message' WHERE languagevar_id='690690022' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690023 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690023', '1', 'Sent.', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Sent.', languagevar_default='mass_message' WHERE languagevar_id='690690023' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690024 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690024', '1', 'This feature is available in Mass Message Pro Paid version. The paid version has many enhancements of existing features(it supports fields restrictions - only for female recipients, etc) and also it allows you to send email announcements. You can purchase this plugin from <a href=\"http://www.hire-experts.com/plugin.php?plugin_name=he_mass_message\">Hire-Experts.com</a>. ', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='This feature is available in Mass Message Pro Paid version. The paid version has many enhancements of existing features(it supports fields restrictions - only for female recipients, etc) and also it allows you to send email announcements. You can purchase this plugin from <a href=\"http://www.hire-experts.com/plugin.php?plugin_name=he_mass_message\">Hire-Experts.com</a>. ', languagevar_default='mass_message' WHERE languagevar_id='690690024' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690025 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690025', '1', 'Mass Message Campaigns', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Mass Message Campaigns', languagevar_default='mass_message' WHERE languagevar_id='690690025' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690026 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690026', '1', 'From User', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='From User', languagevar_default='mass_message' WHERE languagevar_id='690690026' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690027 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690027', '1', 'Recipients', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Recipients', languagevar_default='mass_message' WHERE languagevar_id='690690027' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690028 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690028', '1', 'Sent Date', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Sent Date', languagevar_default='mass_message' WHERE languagevar_id='690690028' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690029 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690029', '1', 'Mass Mailing Premium', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Mass Mailing Premium', languagevar_default='mass_message' WHERE languagevar_id='690690029' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690030 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690030', '1', 'Here you can change the plugin settings. Please <b>choose From User - the plugin use this user as sender in mass message</b>.', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Here you can change the plugin settings. Please <b>choose From User - the plugin use this user as sender in mass message</b>.', languagevar_default='mass_message' WHERE languagevar_id='690690030' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690031 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690031', '1', 'Please <b>choose From User - the plugin use this user as sender in mass message</b>.', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Please <b>choose From User - the plugin use this user as sender in mass message</b>.', languagevar_default='mass_message' WHERE languagevar_id='690690031' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690032 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690032', '1', 'Restrict recipients using user levels and subnetworks', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Restrict recipients using user levels and subnetworks', languagevar_default='mass_message' WHERE languagevar_id='690690032' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690033 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690033', '1', 'Restrict recipients using profile categories and fields', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Restrict recipients using profile categories and fields', languagevar_default='mass_message' WHERE languagevar_id='690690033' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690034 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690034', '1', 'Users with Photos Only', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Users with Photos Only', languagevar_default='mass_message' WHERE languagevar_id='690690034' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690035 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690035', '1', 'To view the message, please use an HTML compatible email viewer.', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='To view the message, please use an HTML compatible email viewer.', languagevar_default='mass_message' WHERE languagevar_id='690690035' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690036 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690036', '1', 'Mass Email Campaigns', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Mass Email Campaigns', languagevar_default='mass_message' WHERE languagevar_id='690690036' AND languagevar_language_id='1'");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690037 LIMIT 1")) == 0)
	$database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690690037', '1', 'Send Mass Email', 'mass_message')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Send Mass Email', languagevar_default='mass_message' WHERE languagevar_id='690690037' AND languagevar_language_id='1'");

    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693001 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693001', '1', 'Preview', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Preview', languagevar_default='mass_message' WHERE languagevar_id='690693001' AND languagevar_language_id='1'");

    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693002 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693002', '1', 'Resend', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Resend', languagevar_default='mass_message' WHERE languagevar_id='690693002' AND languagevar_language_id='1'");

    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693003 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693003', '1', 'Allows you to copy the campaign template for further reworking and sending mass message', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Allows you to copy the campaign template for further reworking and sending mass message', languagevar_default='mass_message' WHERE languagevar_id='690693003' AND languagevar_language_id='1'");

    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693004 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693004', '1', 'Newsletter', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Newsletter', languagevar_default='mass_message' WHERE languagevar_id='690693004' AND languagevar_language_id='1'");

    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693005 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693005', '1', 'Subscribe', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Subscribe', languagevar_default='mass_message' WHERE languagevar_id='690693005' AND languagevar_language_id='1'");

    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693006 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693006', '1', 'Unsubscribe', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Unsubscribe', languagevar_default='mass_message' WHERE languagevar_id='690693006' AND languagevar_language_id='1'");

    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693007 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693007', '1', 'Name', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Name', languagevar_default='mass_message' WHERE languagevar_id='690693007' AND languagevar_language_id='1'");

    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693008 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693008', '1', 'Email', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Email', languagevar_default='mass_message' WHERE languagevar_id='690693008' AND languagevar_language_id='1'");
    
    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693009 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693009', '1', '<span style=\"color: red;\">*</span> name is required', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='<span style=\"color: red;\">*</span> name is required', languagevar_default='mass_message' WHERE languagevar_id='690693009' AND languagevar_language_id='1'");

    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693010 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693010', '1', '<span style=\"color: red;\">*</span> correct email is required', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='<span style=\"color: red;\">*</span> correct email is required', languagevar_default='mass_message' WHERE languagevar_id='690693010' AND languagevar_language_id='1'");

    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693011 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693011', '1', 'Thanks for contacting us. To stop delivery of this newsletter, please type your email address and click the button below.', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Thanks for contacting us. To stop delivery of this newsletter, please type your email address and click the button below.', languagevar_default='mass_message' WHERE languagevar_id='690693011' AND languagevar_language_id='1'");

    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693012 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693012', '1', 'Unsubscribe from newsletters', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Unsubscribe from newsletters', languagevar_default='mass_message' WHERE languagevar_id='690693012' AND languagevar_language_id='1'");

    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693013 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693013', '1', 'Cancel', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Cancel', languagevar_default='mass_message' WHERE languagevar_id='690693013' AND languagevar_language_id='1'");

    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693014 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693014', '1', 'Thank you, you have been successfully unsubscribed from this newsletter.', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Thank you, you have been successfully unsubscribed from this newsletter.', languagevar_default='mass_message' WHERE languagevar_id='690693014' AND languagevar_language_id='1'");

    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693015 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693015', '1', 'Failed. Please check if your email address is correct.', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Failed. Please check if your email address is correct.', languagevar_default='mass_message' WHERE languagevar_id='690693015' AND languagevar_language_id='1'");

    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693016 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693016', '1', 'Include newsletter subscribers', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Include newsletter subscribers', languagevar_default='mass_message' WHERE languagevar_id='690693016' AND languagevar_language_id='1'");

    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693017 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693017', '1', 'View subscribers', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='View subscribers', languagevar_default='mass_message' WHERE languagevar_id='690693017' AND languagevar_language_id='1'");

    if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=680680001 LIMIT 1")) == 0)
        $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('680680001', '1', 'next &raquo;', 'paging')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='next &raquo;', languagevar_default='paging' WHERE languagevar_id='680680001' AND languagevar_language_id='1'");

    if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=680680002 LIMIT 1")) == 0)
        $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('680680002', '1', 'last', 'paging')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='last', languagevar_default='paging' WHERE languagevar_id='680680002' AND languagevar_language_id='1'");

    if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=680680003 LIMIT 1")) == 0)
        $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('680680003', '1', '&laquo; previous', 'paging')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='&laquo; previous', languagevar_default='paging' WHERE languagevar_id='680680003' AND languagevar_language_id='1'");

    if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=680680004 LIMIT 1")) == 0)
        $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('680680004', '1', 'first', 'paging')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='first', languagevar_default='paging' WHERE languagevar_id='680680004' AND languagevar_language_id='1'");

    if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=680680005 LIMIT 1")) == 0)
        $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('680680005', '1', 'Pages:', 'paging')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Pages:', languagevar_default='paging' WHERE languagevar_id='680680005' AND languagevar_language_id='1'");

    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693018 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693018', '1', 'Delete Selected', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Delete Selected', languagevar_default='mass_message' WHERE languagevar_id='690693018' AND languagevar_language_id='1'");

    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693019 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693019', '1', 'Send Mass Message', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Send Mass Message', languagevar_default='mass_message' WHERE languagevar_id='690693019' AND languagevar_language_id='1'");
    
    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693020 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693020', '1', 'Your announcement will be sent as an message to the group users.', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Your announcement will be sent as an message to the group users.', languagevar_default='mass_message' WHERE languagevar_id='690693020' AND languagevar_language_id='1'");

    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693021 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693021', '1', 'Your announcement will be sent as an message to the event guests.', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Your announcement will be sent as an message to the event guests.', languagevar_default='mass_message' WHERE languagevar_id='690693021' AND languagevar_language_id='1'");

    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693022 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693022', '1', 'Subject', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Subject', languagevar_default='mass_message' WHERE languagevar_id='690693022' AND languagevar_language_id='1'");

    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693023 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693023', '1', 'Message', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Message', languagevar_default='mass_message' WHERE languagevar_id='690693023' AND languagevar_language_id='1'");

    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693024 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693024', '1', 'Send', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Send', languagevar_default='mass_message' WHERE languagevar_id='690693024' AND languagevar_language_id='1'");
    
    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693025 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693025', '1', 'Cancel', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Cancel', languagevar_default='mass_message' WHERE languagevar_id='690693025' AND languagevar_language_id='1'");

    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693026 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693026', '1', 'The announcement has been successfully sent.', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='The announcement has been successfully sent.', languagevar_default='mass_message' WHERE languagevar_id='690693026' AND languagevar_language_id='1'");

    if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690693027 LIMIT 1")) == 0)
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('690693027', '1', 'Failed. Please check carefully fields and try again.', 'mass_message')");
    else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Failed. Please check carefully fields and try again.', languagevar_default='mass_message' WHERE languagevar_id='690693027' AND languagevar_language_id='1'");
}
?>