<?php
/**
 * @author Eldar
 * @copyright Hire-Experts LLC
 * @version Mass Email/Message Pro 2.01
 */

$page = "admin_mass_message_tool";
include("admin_header.php");

include_once "./admin_header_he_core.php";
include_once "../include/class_he_mass_message.php";
include_once "../include/class_he_mass_mail.php";

$task = $_POST['task'] ? $_POST['task'] : $_GET['task'];
$tab = $_POST['tab'] ? $_POST['tab'] : ( $_GET['tab'] ? $_GET['tab'] : 'settings');
$restriction_type = $_REQUEST['restriction_type'] ? $_REQUEST['restriction_type'] : 1;

$field = new se_field("profile");
$field->cat_list(0, 0, 1, "", "", "profilefield_search<>'0'");

if(isset($_POST['cat_selected'])) { $cat_selected = $_POST['cat_selected']; } elseif(isset($_GET['cat_selected'])) { $cat_selected = $_GET['cat_selected']; } else { $cat_selected = $field->cats[0]['cat_id']; }

$message = array();

if( get_magic_quotes_gpc() )
{
    $_REQUEST["subject"] = str_replace("\\", "\\\\", stripslashes($_REQUEST["subject"]));
    $_REQUEST["message"] = str_replace("\\", "\\\\", stripslashes($_REQUEST["message"]));
}

//handle requests
if($task == "mass_message")
{
	if( he_mass_message::create_campaign($_REQUEST["subject"], $_REQUEST["message"], $_POST['restriction_type'], $_POST["levels"], $_POST["subnets"], $_POST['cat_selected']) )
		$message['info'] = SE_Language::get(690690023);
	else
		$message["error"] = SE_Language::get(690690011);
}

elseif($task == "mass_mail")
{
	if( he_mass_mail::create_campaign($_REQUEST["subject"], $_REQUEST["message"], $_POST['restriction_type'], $_POST["levels"], $_POST["subnets"], $_POST['cat_selected'], $_REQUEST['include_subscribers']) )
		$message['info'] = SE_Language::get(690690023);
	else
		$message["error"] = SE_Language::get(690690011);
}

elseif ($task=='save_settings')
{
	if( he_mass_message::update_settings(array('setting_mass_message_from_user'=>$_POST['setting_mass_message_from_user'], 'setting_mass_message_per_minute'=>$_POST['setting_mass_message_per_minute'], 'setting_mass_email_per_minute'=>$_POST['setting_mass_email_per_minute'])) )
		$message['info'] = SE_Language::get(690690010);
	else
		$message["error"] = SE_Language::get(690690011);
}

elseif ($task=='get_users')
{
	header("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); // Date in the past
	header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); // always modified
	header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
	header("Pragma: no-cache"); // HTTP/1.0
	header("Content-Type: application/json");
	$result = array( 'results' => he_mass_message::get_users($_GET["username"]) );
	echo json_encode($result);
	exit();
}


$subject = $_REQUEST['subject'];
$body = $_REQUEST['message'];
if( $_GET['campaign_id'] ) {
    $campaign = $tab=='mass_email' ? he_mass_mail::get_campaign(intval($_GET['campaign_id'])) : he_mass_message::get_campaign(intval($_GET['campaign_id']));
    $subject = $campaign['subject'];
    $body = $campaign['message'];
}

switch ( $tab )
{
	case 'mass_message':
		if( !$setting['setting_mass_message_from_user'] )
			$message['error'] = SE_Language::get(690690031);
		
		$campaigns = he_mass_message::get_campaigns(0, 10);
		break;
	
	case 'mass_email':
		$campaigns = he_mass_mail::get_campaigns(0, 10);
		foreach ($campaigns as $key => $value)
			$campaigns[$key]['message'] = str_replace("\\", "\\\\",htmlspecialchars(stripslashes($value['message']), ENT_QUOTES, 'UTF-8'));

        if( $body )
            $body = he_secure_js($body);
		break;
}

$smarty->assign('tab', $tab);
$smarty->assign("message", $message);
$smarty->assign("subject", $subject);
$smarty->assign("body", $body);
$smarty->assign("levels", he_mass_message::get_user_levels());
$smarty->assign("subnets", he_mass_message::get_subnets());
$smarty->assign("cat_selected", $cat_selected);
$smarty->assign("restriction_type", $restriction_type);
$smarty->assign("cats", $field->cats);
$smarty->assign_by_ref("campaigns", $campaigns);
$smarty->assign('se_version', intval(str_replace('.', '', $version)));

include "admin_footer.php";
?>