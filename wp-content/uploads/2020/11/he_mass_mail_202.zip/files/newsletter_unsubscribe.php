<?php
/**
 * @author Eldar
 * @copyright Hire-Experts LLC
 * @version Mass Email/Message Pro 2.01
 */
$page = "newsletter_unsubscribe";
include "header.php";

$task = ( isset($_POST['task']) ? $_POST['task'] : ( isset($_GET['task']) ? $_GET['task'] : NULL ) );

if( $task=='unsubscribe' && $_REQUEST['subscribe_email'] ) {
    if( he_mass_mail::unsubscribe($_REQUEST['subscribe_email']) )
    {
        $message = array('type'=>'success', 'title'=>SELanguage::_get(690693014));
    }
    else
    {
        $message = array('type'=>'error', 'title'=>SELanguage::_get(690693015));
    }
}


$smarty->assign('message', $message);
include "footer.php";
?>