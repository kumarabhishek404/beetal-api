<?php
/**
 * @author Eldar
 * @copyright Hire-Experts LLC
 * @version Mass Email/Message Pro 2.01
 */
$page = 'send_mass_message';
include('header.php');

if( !$user->user_exists ) exit;

$subject = $_REQUEST['subject'];
$body = $_REQUEST['body'];
if( $_REQUEST['group_id'] )
{
    $group = new se_group($user->user_info['user_id'], $_REQUEST['group_id']);
    if( !$group->group_exists || $group->user_rank<1 )
    {
      $page = "error";
      $smarty->assign('error_header', 639);
      $smarty->assign('error_message', 2000219);
      $smarty->assign('error_submit', 641);
      include "footer.php";
    }

    if( $_REQUEST['task']=='send' )
    {
        $mass_mailing = new he_mass_mailing();
        $campaign_id = $mass_mailing->create_campaign($subject, $body, $user->user_info['user_id'], false);
        if( $campaign_id ) {
            $members = $group->group_member_list(0, 100000, "groupmember_id DESC", "se_groupmembers.groupmember_status='1' AND se_users.user_id!={$user->user_info['user_id']}");
            foreach( $members as $member ) {
                if( is_object($member['member']) )
                    $mass_mailing->add_message_into_queue_for_user($campaign_id, $member['member']->user_info['user_id']);
            }
            $message = array( 'type'=>'success', 'title' => SE_Language::_get(690693026) );
            $subject = $body = '';
        }
        else {
            $message = array( 'type'=>'error', 'title' => SE_Language::_get(690693027) );
        }
    }
}
elseif( $_REQUEST['event_id'] )
{
    $event = new se_event($user->user_info['user_id'], $_REQUEST['event_id']);

    if( !$event->event_exists || $event->user_rank < 3 )
    {
      $page = "error";
      $smarty->assign('error_header', 639);
      $smarty->assign('error_message', 828);
      $smarty->assign('error_submit', 641);
      include "footer.php";
    }

    if( $_REQUEST['task']=='send' )
    {
        $mass_mailing = new he_mass_mailing();
        $campaign_id = $mass_mailing->create_campaign($subject, $body, $user->user_info['user_id'], false);
        if( $campaign_id ) {
            $members = $event->event_member_list(0, 100000, "se_users.user_username", "(se_eventmembers.eventmember_status=1 AND se_eventmembers.eventmember_approved=1 AND se_eventmembers.eventmember_rsvp!='3' AND se_users.user_id!={$user->user_info['user_id']})");
            foreach( $members as $member ) {
                if( is_object($member['member']) )
                    $mass_mailing->add_message_into_queue_for_user($campaign_id, $member['member']->user_info['user_id']);
            }
            $message = array( 'type'=>'success', 'title' => SE_Language::_get(690693026) );
            $subject = $body = '';
        }
        else {
            $message = array( 'type'=>'error', 'title' => SE_Language::_get(690693027) );
        }
    }
}
else
{
    exit;
}

$smarty->assign('message', $message);
$smarty->assign('subject', $subject);
$smarty->assign('body', $body);
$smarty->assign_by_ref('profiles', $profiles);
include "footer.php";
?>