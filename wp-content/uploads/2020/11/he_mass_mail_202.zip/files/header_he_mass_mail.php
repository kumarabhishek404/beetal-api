<?php
/**
 * @author Eldar
 * @copyright Hire-Experts LLC
 * @version Mass Email/Message Pro 2.01
 */
defined('SE_PAGE') or exit();

include_once "./header_he_core.php";
include_once "./include/class_he_mass_message.php";
include_once "./include/class_he_mass_mail.php";

//CRON JOBS:
he_mass_message::cron();
he_mass_mail::cron();

//send messages from mass mailing queue
$mass_mailing = new he_mass_mailing();
$mass_mailing->cron();

if( $_REQUEST['subscribe_email'] ) {
    he_mass_mail::subscribe($_REQUEST['subscribe_name'], $_REQUEST['subscribe_email']);
}

// Use new template hooks
if ( is_a($smarty, 'SESmarty') )
{
	$plugin_vars['uses_tpl_hooks'] = TRUE;
}

?>