INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`)
VALUES  ('social-boost', 'Social Boost', 'Social Boost plugin', '4.10.3', 1, 'extra') ;