<?php return array (
  'package' =>

  array (
    'type' => 'module',
    'name' => 'userimporter',
    'version' => '4.10.3p2',
    'path' => 'application/modules/Userimporter',
    'title' => 'User Importer',
    'description' => 'This plugin import the users from the csv.',
    'author' => 'iPragmatech',
    'sku' => 'IPSEEMUI',
    'callback' =>

    array (
      'class' => 'Engine_Package_Installer_Module',
    ),
    'actions' =>
    array (
      0 => 'install',
      1 => 'upgrade',
      2 => 'refresh',
      3 => 'enable',
      4 => 'disable',
    ),
    'directories' =>
    array (
      0 => 'application/modules/Userimporter',
    ),
    'files' =>
    array (
      0 => 'application/languages/en/userimporter.csv',
    ),
  ),

	//routes--------------------------------------------------------
		'routes' => array(

		),
); ?>
