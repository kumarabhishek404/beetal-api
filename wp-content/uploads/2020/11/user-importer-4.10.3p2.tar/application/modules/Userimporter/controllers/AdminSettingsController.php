<?php

class Userimporter_AdminSettingsController extends Core_Controller_Action_Admin
{
  public function indexAction()
  {
  	$log = Zend_Registry::get('Zend_Log');
  	$this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
  	->getNavigation('userimporter_admin_main', array(), 'userimporter_admin_main_settings');

  	$this->view->form = $form = new Userimporter_Form_Admin_Import();

  	//fetch profile type options
  	$userfieldoptiontable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'options' );
  	$options = $userfieldoptiontable->select()->where('field_id=1');
  	$optiondata = $userfieldoptiontable->fetchAll($options);
  	$profileOptions = array();
  	foreach( $optiondata as $item ) {
  		$profileOptions[$item->option_id] = $item->label;
  	}
  	//$form->profile->setMultiOptions($profileOptions);


  	if( !$this->getRequest()->isPost() ) {
  		return;
  	}

  	if( !$form->isValid($this->getRequest()->getPost()) ) {
  		return;
  	}

  	// Process
  	$values = $form->getValues();
  	$jvd = $form->csv_file->getValue();
  	$log->log("Values:-".print_r($jvd,true),Zend_Log::DEBUG);

  	// temporarily enable queueing if requested
  	$temporary_queueing = Engine_Api::_()->getApi('settings', 'core')->core_mail_queueing;
  	if (isset($values['queueing']) && $values['queueing']) {
  		Engine_Api::_()->getApi('settings', 'core')->core_mail_queueing = 1;
  	}

  	// Uploading a new csv file''
  	if ($form->csv_file->getValue() !== null)
  	{
  	    //$profile_type = $values['profile'];
  		$verified = $values['verify'];
  		$approved = $values['approve'];
  	    $level_id = $values['level_id'];
  	    $notify_email = $values['notify_email'];
  		$usercsv = $form->csv_file;
  		$creation_date = new Zend_Db_Expr ( 'NOW()' );
  		$viewer = Engine_Api::_()->user()->getViewer();
  		$logData = array(
  				'creation_date' => $creation_date,
  				'import_type' => 'CSV',
  				'user_id' => $viewer->getIdentity()
  		);
  		$logTable = Engine_Api::_()->getDbTable('logs','userimporter');
  		$log_id = $logTable->insert($logData);

  		try{
  			$csvPath = Engine_Api::_()->userimporter()->getCsv($usercsv);
	  		$csv_data = array();
	  		$filepath = APPLICATION_PATH . '/' . $csvPath;
	  		$csv_data = Engine_Api::_()->userimporter()->readCsv($filepath);
	  		$logData['params'] = json_encode($csv_data);
	  		$logData['status'] = 1;
	  		$logData['message'] = "Import successfully";
	  		$status = Engine_Api::_()->userimporter()->uploadCsv($csv_data,$level_id,$verified,$approved,$notify_email,$log_id);
	  		$form->addNotice('Successfully imported the  users from your file');
	  		$logTable->update($logData,'log_id = '.$log_id);
  		}catch(Exception $e){
  			$logData['status'] = 0;
  			$logData['message'] = "Import failed due to exception thrown";
  			$logTable->update($logData,'log_id = '.$log_id);
  		}
  	}
  	// emails have been queued (or sent); re-set queueing value to original if changed
  	if (isset($values['queueing']) && $values['queueing']) {
  		Engine_Api::_()->getApi('settings', 'core')->core_mail_queueing = $temporary_queueing;
  	}
  }

  public function webserviceAction()
  {
  	$log = Zend_Registry::get('Zend_Log');
  	$this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
  	->getNavigation('userimporter_admin_main', array(), 'userimporter_admin_main_webservice');

  	$this->view->form = $form = new Userimporter_Form_Admin_Importservice();

  	//fetch profile type options
  	$userfieldoptiontable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'options' );
  	$options = $userfieldoptiontable->select()->where('field_id=1');
  	$optiondata = $userfieldoptiontable->fetchAll($options);
  	$profileOptions = array();
  	foreach( $optiondata as $item ) {
  		$profileOptions[$item->option_id] = $item->label;
  	}
  	//$form->profile->setMultiOptions($profileOptions);


  	if( !$this->getRequest()->isPost() ) {
  		return;
  	}

  	if( !$form->isValid($this->getRequest()->getPost()) ) {
  		return;
  	}

  	// Process
  	$values = $form->getValues();

  	// temporarily enable queueing if requested
  	$temporary_queueing = Engine_Api::_()->getApi('settings', 'core')->core_mail_queueing;
  	if (isset($values['queueing']) && $values['queueing']) {
  		Engine_Api::_()->getApi('settings', 'core')->core_mail_queueing = 1;
  	}

  	// Uploading a new csv file''
  	if ($form->service_url->getValue() !== null)
  	{
  		//$profile_type = $values['profile'];
  		$verified = $values['verify'];
  		$approved = $values['approve'];
  		$level_id = $values['level_id'];
  		$notify_email = $values['notify_email'];
  		$serverUrl = $values['service_url'];
  		$creation_date = new Zend_Db_Expr ( 'NOW()' );
  		$viewer = Engine_Api::_()->user()->getViewer();

  		$logTable = Engine_Api::_()->getDbTable('logs','userimporter');
  		if($values['service_type'] == 1){
  			$importType = "JSON";
  		}else{
  			$importType = "XML";
  		}
  		$logData = array(
  				'import_url' => $serverUrl,
  				'creation_date' => $creation_date,
  				'import_type' => 'JSON',
  				'user_id' => $viewer->getIdentity()
  		);
  		$log_id = $logTable->insert($logData);

  		try{
	  		$importApi = Engine_Api::_()->getApi('webservice','userimporter');
	  		if($values['service_type'] == 1){
	  			$data = $importApi->readJson($serverUrl);
	  		}elseif($values['service_type'] == 2){
	  			$data = $importApi->readXml($serverUrl);
	  		}
	  		if($data['status'] == true && is_array($data['content'])){
	  			$logData['params'] = json_encode($data['content']);
	  			$status = $importApi->uploadJson($data['content'],$level_id,$verified,$approved,$notify_email,$log_id);
	  			$form->addNotice('Successfully imported the  users from your file');
	  			$logData['status'] = 1;
	  			$logData['message'] = "Import Successfully";
	  			$logTable->update($logData,'log_id = '.$log_id);
	  		}else{
	  			$logData['status'] = 0;
	  			if($values['service_type'] == 1){
	  				$form->addError('Not able to read JSON.');
	  			}else{
	  				$form->addError('Not able to read XML.');
	  			}
	  			if($values['service_type'] == 1){
	  				$logData['message'] = "Import failed. Not able to read JSON";
	  			}else{
	  				$logData['message'] = "Import failed. Not able to read XML";
	  			}

	  			$logTable->update($logData,'log_id = '.$log_id);
	  		}

  		}catch(Exception $e){
  			$logData['status'] = 0;
  			if($values['service_type'] == 1){
  				$logData['message'] = "Import failed due to exception thrown";
  			}else{
  				$logData['message'] = "Import failed due to exception thrown";
  			}
  			$logTable->update($logData,'log_id = '.$log_id);
  		}
  	}
  	// emails have been queued (or sent); re-set queueing value to original if changed
  	if (isset($values['queueing']) && $values['queueing']) {
  		Engine_Api::_()->getApi('settings', 'core')->core_mail_queueing = $temporary_queueing;
  	}
  }

  public function logsAction(){
  	$log = Zend_Registry::get('Zend_Log');

  	$this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
  	->getNavigation('userimporter_admin_main', array(), 'userimporter_admin_main_logs');


  	$userDataTable = Engine_Api::_()->getDbtable('logs', 'userimporter');
  	$userTable = Engine_Api::_()->getDbtable('users', 'user');
  	$select = $userDataTable->select()
		  	->setIntegrityCheck(false)
		  	->from(array('data' => $userDataTable->info('name')))
		 	->order('data.log_id desc');

  	$paginator = Zend_Paginator::factory($select);
  	$paginator->setItemCountPerPage($this->_getParam('itemCountPerPage', 10));
  	$page = $this->_getParam('page', 1);
  	$this->view->paginator = $paginator->setCurrentPageNumber( $page );
  	$this->view->paginator = $paginator;
  }

  public function datasAction()
  {
  	$log = Zend_Registry::get('Zend_Log');

  	$this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
  	->getNavigation('userimporter_admin_main', array(), 'userimporter_admin_main_logs');


  	$this->view->log_id = $log_id = $this->_getParam('log_id',null);
  	if(!$log_id){
  		return false;
  	}

  	$userDataTable = Engine_Api::_()->getDbtable('datas', 'userimporter');
  	$userTable = Engine_Api::_()->getDbtable('users', 'user');
  	$dataSelect = $userDataTable->select()
			  	->setIntegrityCheck(false)
			  	->from(array('data' => $userDataTable->info('name')))
			  	->joinLeft(array('user' => $userTable->info('name')),'data.email = user.email',array('user_id'))
			  	->where('data.log_id = ?',$log_id)
			  	;

  	$log->log("Log details:- ".$dataSelect,Zend_Log::DEBUG);
  	$paginator = Zend_Paginator::factory($dataSelect);
  	$paginator->setItemCountPerPage($this->_getParam('itemCountPerPage', 10));
  	$page = $this->_getParam('page', 1);
  	$this->view->paginator = $paginator->setCurrentPageNumber( $page );
  	$this->view->paginator = $paginator;

  }

}
