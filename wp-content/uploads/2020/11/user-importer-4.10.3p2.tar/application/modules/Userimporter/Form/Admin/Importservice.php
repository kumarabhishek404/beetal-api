<?php
/**
 * iPragmatech Solution Pvt. Ltd.
 *
 * @category   Application_User Importer
 * @package    User Importer
 * @copyright  Copyright 2008-2013 iPragmatech Solution Pvt. Ltd.
 * @license   � 2013 iPragmatech. All Rights Reserved.
 * @version    $Id: Global.php 9747 2013-07-06 02:08:08Z iPrgamtech $
 * @author     iPragmatech
 */

class Userimporter_Form_Admin_Importservice extends Engine_Form
{
  public function init()
  {
     /* $this
      ->setDescription('This plugin import the users in socialengine from the webservice.');

   //select profile Type
    $this->addElement('Select', 'profile', array(
    		'label'=>'Profile Type',
    		'required' => true,
    		'multiOptions' => array(
                    '0' => ''
    
            )
    )); */

	// Init level
    $levelMultiOptions = array(); //0 => ' ');
    $levels = Engine_Api::_()->getDbtable('levels', 'authorization')->fetchAll();
    foreach( $levels as $row ) {
    	$levelMultiOptions[$row->level_id] = $row->getTitle();
    }
    $this->addElement('Select', 'level_id', array(
    		'label' => 'Member Level',
    		'required' => true,
    		'multiOptions' => $levelMultiOptions
    ));
    
    //select verified or not
    $this->addElement('Select', 'verify', array(
    		'label'=>'Verified / Not Verified',
    		'required' => true,
    		'multiOptions' => array(
    				'1' => 'Verified',
    				'0' => 'Not Verified',
    
    		)
    ));
    //select approved or not
    $this->addElement('Select', 'approve', array(
    		'label'=>'Approved / Not Approved',
    		'required' => true,
    		'multiOptions' => array(
    				'1' => 'Approved',
    				'0' => 'Not Approved',
    		)
    ));
    
    //upload File
    $this->addElement('Text', 'service_url', array(
    		'label' => 'Web Service Url',
    		'required' => true,
    		
    ));
    
    //select webservice type or not
    $this->addElement('Select', 'service_type', array(
    		'label'=>'Webservice Type',
    		'required' => true,
    		'onchange' => 'changeimage(this)',
    		'multiOptions' => array(
    				'1' => 'JSON',
    				'2' => 'XML',
    
    		)
    ));
    
    $this->addElement('Radio', 'notify_email', array(
    		'label' => 'Send Welcome Email',
    		'multiOptions' => array(
    				1 => 'Yes',
    				0 => 'No',
    		),
    		'value' => 1,
    ));
    // Add submit button
    $this->addElement('Button', 'submit', array(
      'label' => 'Import',
      'type' => 'submit',
      'ignore' => true,
    ));
    
    //email queue setting
    $settings = Engine_Api::_()->getApi('settings', 'core')->core_mail;
    
    if( !@$settings['queueing'] ) {
    	$this->addElement('Radio', 'queueing', array(
    			'label' => 'Utilize Mail Queue',
    			'description' => 'Mail queueing permits the emails to be sent out over time, preventing your mail server
           from being overloaded by outgoing emails.  It is recommended you utilize mail queueing for large email
           blasts to help prevent negative performance impacts on your site.',
    			'multiOptions' => array(
    					1 => 'Utilize Mail Queue (recommended)',
    					0 => 'Send all emails immediately (only recommended for less than 100 recipients).',
    			),
    			'value' => 1,
    	));
    }
  }
}