<?php

class Hecontest_Widget_RecentContentMemberhomeController extends Engine_Content_Widget_Abstract
{
  public function indexAction()
  {

      $hecontestsTable = Engine_Api::_()->getDbtable('hecontests', 'hecontest');
	    $hecontestsTableName = $hecontestsTable->info( 'name' ) ;
	    $select = $hecontestsTable->select()
	            ->from( $hecontestsTableName)
	            ->where( 'is_active = ?' , '1' )
	            ->order('date_begin DESC')
	            ->limit( 1 ) ;
	    $results = $hecontestsTable->fetchRow($select) ;
      if(empty($results->hecontest_id))
        return $this->setNoRender();
        
      $this->view->hecontest = Engine_Api::_()->getItem('hecontest', $results->hecontest_id);
        
      $photosTable = Engine_Api::_()->getDbtable('photos', 'hecontest');
	    $photosTableName = $photosTable->info( 'name' ) ;
	    $selectphotos = $photosTable->select()
	            ->from( $photosTableName)
	            ->where('contest_id = ?' , $results->hecontest_id)
	            ->order('date_posted DESC')
	            ->limit(1) ; 
      $this->view->result_onephoto = $photosTable->fetchRow($selectphotos) ;  

	    $selectphotos = $photosTable->select()
	            ->from( $photosTableName)
	            ->where( 'contest_id = ?' , $results->hecontest_id)
	            ->order('votes DESC')
	            ->limit(4) ;
      $this->view->results = $results = $selectphotos->query()->fetchAll() ;
      if(count($results) == 0)
        return $this->setNoRender();

  }
}
