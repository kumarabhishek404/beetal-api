INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES  ('socialads', 'Social ads plugin', 'Social ads plugin', '5.1.0p3', 1, 'extra') ;


