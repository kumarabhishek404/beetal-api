/**
 * Created by Kalys on 16.11.2016.
 */
window.widget_ads = {
    type: "",
    url: en4.core.baseUrl + "socialads/widget/index",
    wrapper: null,
    delay: 15000,
    timerID: 0,
    ID_ad: 0,
    init: function (id_wrapper, delay, type) {
        var self = this;
        if ($(id_wrapper)) {
            self.wrapper = $(id_wrapper);
            self.delay = delay;
            self.type = type;
            self.start();
        } else {
            console.log("id: <" + id_wrapper + "> Not found! Ads Widget not initialize!");
        }
    },
    start: function () {
        var self = this;
      //  var w = self.wrapper.getParent().getStyle('width');
        //self.wrapper.setStyle('width',w);
       // console.log(w);
        self.get_ads();
        self.timerID = setInterval(function () {
            self.get_ads();
        }, self.delay);
    },
    stop:function(){
        var self = this;
        clearInterval(self.timerID);
    },
    get_ads: function () {
        var self = this;
        new Request.JSON({
            url: self.url,
            data: {
                type: self.type,
                format: 'json',
                id_ad:self.ID_ad
            },
            onSuccess: function (res) {
                if (res.status) {
                    self.ID_ad = res.ID_AD;
                    self.hide_ad();
                    setTimeout(function(){
                        self.wrapper.set('html',res.html);
                        self.show_ad();
                    },1000);

                } else {
                   // alert("Error");
                }
            },
            onFailure: function () {
                //alert("An error occurred!");
                self.show_ad();
            }
        }).send();
    },
    show_ad: function () {
        var self = this;
        self.wrapper.setStyle('opacity', 1);
    },
    hide_ad: function () {
        var self = this;
        self.wrapper.setStyle('opacity', 0);
    }
};