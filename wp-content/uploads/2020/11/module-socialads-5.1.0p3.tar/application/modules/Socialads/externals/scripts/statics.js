/**
 * Created by Kalys on 08.11.2016.
 */
window.static_map = {
    static_data:[],
    canvas:null,
    w:0,
    h:0,
    init:function()
    {
        var self = this;
        if($('static_map')){
            console.log($('static_map'));
            self.canvas = $('static_map');
            self.w = $('static_map').getParent().getStyle('width');
            self.h =  Math.floor(parseInt(self.w) /3);
            self.canvas.setStyle('width',(parseInt(self.w)-40)+'px');
            self.canvas.setStyle('height',self.h);
            self.canvas.setStyle('margin',20);
            self.render();
        }
    },
    render:function()
    {
        var self = this;
        self.drawBg();
    },
    drawBg:function()
    {
        var self = this;
        var canvas = document.getElementById("static_map");
        canvas.width  = parseInt(self.w);
        canvas.height = parseInt(self.h);
        var ctx = canvas.getContext("2d");
        ctx.setLineDash([5, 15]);
        ctx.beginPath();
        ctx.lineWidth = 2;
        ctx.strokeStyle = '#ссс';
        ctx.moveTo(0,100);
        ctx.lineTo(400, 100);
        ctx.stroke();
    }

};

