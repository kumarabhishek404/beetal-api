<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Socialads
 * @author     KALYSKIN
 */
class Socialads_Model_Viewmode extends Core_Model_Item_Abstract
{
  protected $_searchTriggers = false;
  
  public function getLabel()
  {
    return $this->label;
  }
  public function getParam($param_name,$default = 0)
  {
    $JSON_PARAM = json_decode($this->params,true);
    if(count($JSON_PARAM)){
      return isset($JSON_PARAM[$param_name])?$JSON_PARAM[$param_name]:$default;
    }else
      return $default;
  }
  public function setParam($param_name,$value)
  {
    if($value) {
      $JSON_PARAM = json_decode($this->params, true);
      if ($JSON_PARAM == null) {
        $JSON_PARAM = array();
      }
      $JSON_PARAM[$param_name] = $value;
      $this->params = json_encode($JSON_PARAM);
    }
  }
  public function removeParam($param_name)
  {

    $JSON_PARAM = json_decode($this->params, true);
    if ($JSON_PARAM == null) {
      return $this;
    }
    unset($JSON_PARAM[$param_name]);
    $this->params = json_encode($JSON_PARAM);
    return $this;

  }
  public function getRequiredFields()
  {
    return $this->getParam('required_fields',0);
  }
  public function setRequiredFields($f)
  {
    $this->setParam('required_fields',$f);
    $this->save();
    return $this;
  }


}





























