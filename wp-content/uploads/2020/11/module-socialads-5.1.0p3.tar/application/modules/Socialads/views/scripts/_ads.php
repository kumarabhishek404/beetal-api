<?php
/**
 * Created by PhpStorm.
 * User: Kalys
 * Date: 25.10.2016
 * Time: 16:23
 */
if (isset($this->view_mode)) {

    if (isset($this->model_ad) && ($this->model_ad)) {

        $title = $this->model_ad->title;
        $description = $this->model_ad->description;
        $font_color_style = ' style="color:#' . $this->font_color . ';" ';
        $bg_color_style = ' style="background-color:#' . $this->bg_color . ';" ';
        $Ad_url = $this->model_ad->getRedUrl();
        $Image_url =$this->model_ad->getPhotoUrl();
        $Ad_url_real = $this->model_ad->ad_url;

    } else {
        $title = "Example of the Title";
        $description = "Example description. Lorem Ipsum is simply dummy text of the printing and type..";
        $font_color_style = " ";
        $bg_color_style = " ";
        $Ad_url = "javascript:void(0);";
        $Ad_url_real = "http://example.com";
        if (strtolower($this->view_mode) == strtolower('Wall-feed-large') || strtolower($this->view_mode) ==  strtolower('Responsive-Image'))
            $Image_url = $this->BaseUrl() . '/application/modules/Socialads/externals/images/example-hor.png';
        else
            $Image_url = $this->BaseUrl() . '/application/modules/Socialads/externals/images/example.jpg';
    }
    ?>

    <?php if (strtolower($this->view_mode) == strtolower('default')) { ?>

        <div class="social-ad-default-block" <?php echo $bg_color_style; ?>>
            <a target="_blank" href="<?php echo $Ad_url; ?>">
                <div class="img-left-block">
                    <div id="ad_img_div" style="background-image: url(<?php echo $Image_url ?>);"></div>
                    <div class="ad-img-overlayar"></div>
                </div>
                <div class="social-ad-content">
                    <h3 class="social-ad-content__title" <?php echo $font_color_style; ?> > <?php echo $title; ?></h3>
                    <p class="social-ad-content__desc" <?php echo $font_color_style; ?>><?php echo $description; ?></p>
                    <span class="social-ad-content__url"><?php echo $Ad_url_real; ?></span>
                </div>
            </a>
        </div>

    <?php } ?>

    <?php if (strtolower($this->view_mode) == strtolower('default-extra')) { ?>

        <div class="social-ad-default-extra-block"<?php echo $bg_color_style; ?>>
            <a target="_blank" href="<?php echo $Ad_url; ?>">
                <div class="img-left-block">
                    <div id="ad_img_div" style="background-image: url(<?php echo $Image_url ?>);"></div>
                    <div class="ad-img-overlayar"></div>
                </div>
                <div class="social-ad-content">
                    <h3 class="social-ad-content__title" <?php echo $font_color_style; ?>> <?php echo $title; ?></h3>
                    <p class="social-ad-content__desc" <?php echo $font_color_style; ?>><?php echo $description; ?></p>
                    <span class="social-ad-content__url"><?php echo ($Ad_url_real); ?></span>
                </div>
            </a>
        </div>

    <?php } ?>

    <?php if (strtolower($this->view_mode) == strtolower('side-links')) { ?>

        <div class="social-ad-default-side-links" <?php echo $bg_color_style; ?>>
            <a target="_blank" href="<?php echo $Ad_url; ?>">
                <div class="social-ad-content">
                    <h3 class="social-ad-content__title" <?php echo $font_color_style; ?>> <?php echo $title ?></h3>
                    <p class="social-ad-content__desc" <?php echo $font_color_style; ?>><?php echo $description ?></p>
                </div>
            </a>
        </div>

    <?php } ?>

    <?php if (strtolower($this->view_mode) == strtolower('sticker-style')) { ?>

        <div class="social-ad-default-sticker-style" <?php echo $bg_color_style; ?>>
            <div class="right_angle" <?php echo $bg_color_style; ?>></div>
            <a target="_blank" href="<?php echo $Ad_url; ?>">
                <div class="social-ad-content">
                    <h3 class="social-ad-content__title" <?php echo $font_color_style ?>> <?php echo $title ?></h3>
                    <p class="social-ad-content__desc" <?php echo $font_color_style ?>><?php echo $description ?></p>
                </div>
            </a>
        </div>

    <?php } ?>

    <?php if (strtolower($this->view_mode) == strtolower('FB-style')) { ?>

        <div class="social-ad-default-fb-style" <?php echo $bg_color_style ?>>
            <a target="_blank" href="<?php echo $Ad_url ?>">
                <div class="social-ad-content">
                    <h3 class="social-ad-content__title" <?php echo $font_color_style; ?>> <?php echo $title ?></h3>
                    <p class="social-ad-content__desc" <?php echo $font_color_style; ?>><?php echo $description; ?></p>
                    <div class="image_ad"
                         id="ad_img_div" <?php echo $this->model_ad ? 'style="background-image: url(' . $this->model_ad->getPhotoUrl() . ');"' : ' '; ?> ></div>
                </div>
            </a>
        </div>

    <?php } ?>

    <?php if (strtolower($this->view_mode) == strtolower('Full-Image')) { ?>

        <div class="social-ad-default-full-image" <?php echo $bg_color_style ?>>
            <a target="_blank" href="<?php echo $Ad_url ?>">
                <div class="social-ad-content">
                    <div class="image_ad" id="ad_img_div"
                         style="background-image: url(<?php echo $Image_url ?>);"></div>
                </div>
            </a>
        </div>

    <?php } ?>

    <?php if (strtolower($this->view_mode) == strtolower('Responsive-Image')) { ?>
        <div class="social-ad-default-responsive-image" <?php echo $bg_color_style; ?>>
            <a target="_blank" href="<?php echo $Ad_url; ?>">
                <div class="social-ad-content">
                    <img title="<?php echo $title; ?>" id="ad_img_div" ref="image" class="image_ad_responsive" src="<?php echo $Image_url; ?>"/>
                </div>
            </a>
        </div>

    <?php } ?>

    <?php if (strtolower($this->view_mode) == strtolower('Standart-block')) { ?>
        <div class="social-ad-default-standart-block" <?php echo $bg_color_style; ?>>
            <a target="_blank" href="<?php echo $Ad_url; ?>">
                <div class="social-ad-content">
                    <img title="<?php echo $title; ?>" class="image_ad_standart" id="ad_img_div" ref="image" src="<?php echo $Image_url; ?>"/>
                </div>
            </a>
        </div>

    <?php } ?>

    <?php if (strtolower($this->view_mode) == strtolower('Wall-feed-mini')) { ?>
        <div class="social-ad-default-wall-feed-mini" <?php echo $bg_color_style; ?>>
            <a target="_blank" href="<?php echo $Ad_url ?>">
                <div class="img-left-block">
                    <img title="<?php echo $title; ?>" class="Wall-feed-mini-img" id="ad_img_div" ref="image"
                         src="<?php echo $Image_url; ?>"/>
                </div>
                <div class="social-ad-content">
                    <h3 class="social-ad-content__title" <?php echo $font_color_style; ?>> <?php echo $title; ?></h3>
                    <p class="social-ad-content__desc" <?php echo $font_color_style; ?>><?php echo $description; ?></p>
                    <span class="social-ad-content__url"><?php echo $Ad_url_real; ?></span>
                </div>
            </a>
        </div>

    <?php } ?>

    <?php if (strtolower($this->view_mode) == strtolower('Wall-feed-large')) { ?>
        <a target="_blank" href="<?php echo $Ad_url ?>">
            <div class="social-ad-default-wall-feed-large" <?php echo $bg_color_style ?>>
                <div class="img-left-block">
                    <img title="<?php echo $title ?>" class="Wall-feed-mini-img" id="ad_img_div" ref="image"
                         src="<?php echo $Image_url; ?>"/>
                </div>
                <div class="social-ad-content">
                    <h3 class="social-ad-content__title" <?php echo $font_color_style ?>> <?php echo $title; ?></h3>
                    <p class="social-ad-content__desc" <?php echo $font_color_style ?>>   <?php echo $description; ?></p>
                    <span class="social-ad-content__url"><?php echo $Ad_url_real; ?></span>
                </div>
            </div>
        </a>

    <?php } ?>

    <?php if (strtolower($this->view_mode) == strtolower('Sidebar-ads')) { ?>

            <div class="socialads_ad_block_sidebar">
                <div class="subject_top_box">
                    <a target="_blank" href="<?php echo $Ad_url ?>" class="subject_text">
                        <b class="social-ad-content__title"><?php echo $title ?></b>
                        <span class="carret_content">
                            <svg width="12" height="7" viewBox="1259 685 12 7" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1259.62 685l-.62.656 6 6.344 6-6.344-.62-.656-5.38 5.688z"></path>
                            </svg>
                        </span>
                    </a>
                    <br>
                    <a target="_blank" class="url_green social-ad-content__url" href="<?php echo $Ad_url ?>"><?php echo ($Ad_url_real) ?></a>
                </div>
                <a target="_blank" href="<?php echo $Ad_url ?>">
                    <div class="image_content">
                        <div class="desc_content_slide_down">
                            <p class="social-ad-content__desc"> <?php echo $description; ?> </p>
                        </div>
                        <img ref="image" id="ad_img_div" src="<?php echo $Image_url; ?>" alt="<?php echo $title ?>">
                    </div>
                </a>
            </div>

    <?php } ?>

<?php } ?>

