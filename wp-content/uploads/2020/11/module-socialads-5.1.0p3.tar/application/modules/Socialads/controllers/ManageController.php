<?php

class Socialads_ManageController extends Core_Controller_Action_Standard
{
    public function indexAction()
    {
        // print_die(Engine_Api::_()->getApi('core','socialads')->getThisWeek());
    }

    public function editAction()
    {
        $user_id = $this->getParam('user_id', 0);
        $viewer = Engine_Api::_()->user()->getViewer();
        if (!$this->isSuperAdmin()) {
            if (!$this->_helper->requireUser()->isValid()) return;
            if (!$this->_helper->requireAuth()->setAuthParams('socialads', null, 'allow_edit')->isValid()) return;
            if ($user_id != $viewer->getIdentity()) {
                return;
            }
        }

        $viewer = Engine_Api::_()->user()->getViewer();

        $this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
            ->getNavigation('socialads_main', array(), '');

        $ads_id = $this->_getParam('ad_id');
        $this->view->ads_id = $ads_id;
        $adsTable = Engine_Api::_()->getDbtable('ads', 'socialads');

        if (!$this->isSuperAdmin())
            $select = $adsTable
                ->select()
                ->where('ad_id=?', $ads_id)
                ->where('user_id=?', $viewer->getIdentity());
        else
            $select = $adsTable
                ->select()
                ->where('ad_id=?', $ads_id);

        $item = $adsTable->fetchRow($select);

        $this->view->form = $form = new Socialads_Form_adsedit($item->getPhotoUrl());
        $form->populateFromModel($item);

        if (!$this->getRequest()->isPost()) {
            return;
        }
        //save
        if (!empty($_FILES['image']) && !empty($_FILES['image']['name']) && $_FILES['image']['error'][0] == 0) {
            $image = $_FILES['image'];
        } else {
            $image = false;
        }
        $values = $_POST;
        $table = Engine_Api::_()->getDbtable('ads', 'socialads');
        $db = $table->getAdapter();
        $db->beginTransaction();

        try {
            $val = array(
                'email' => $values['email'],
                'title' => htmlspecialchars($values['title']),
                'description' => htmlspecialchars($values['description']),
                'ad_url' => $values['ad_url'],
                'modified_date' => date('Y-m-d H:i:s'),
            );

            $ads = $item;
            $ads->setFromArray($val);
            $ads->save();
            if ($image) {
                $ads->setPhoto($image);
            }
            $db->commit();
            return $this->_helper->redirector->gotoRoute(array('action' => 'manage'), 'socialads_general', true);
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
        }
    }

    public function deleteAction()
    {
        // In smoothbox
        if (!$this->_helper->requireUser()->isValid()) return;
        if (!$this->_helper->requireAuth()->setAuthParams('socialads', null, 'allow_delete')->isValid()) return;

        $viewer = Engine_Api::_()->user()->getViewer();
        $this->_helper->layout->setLayout('default-simple');
        $ads_id = $this->_getParam('ad_id');
        $user_id = $this->_getParam('user_id');
        if ($user_id != $viewer->getIdentity()) {
            return;
        }
        $this->view->ads_id = $ads_id;
        $this->view->user_id = $user_id;
        $adsTable = Engine_Api::_()->getDbtable('ads', 'socialads');
        $select = $adsTable
            ->select()
            ->where('ad_id=?', $ads_id)
            ->where('user_id=?', $viewer->getIdentity());

        $item = $adsTable->fetchRow($select);

        if (!$adsTable) {
            return $this->_forward('success', 'utility', 'core', array(
                'smoothboxClose' => 10,
                'parentRefresh' => 10,
                'messages' => array('')
            ));
        }

        if (!$this->getRequest()->isPost()) {
            // Output
            $this->renderScript('manage/delete.tpl');
            return;
        }

        // Process
        $db = $adsTable->getAdapter();
        $db->beginTransaction();

        try {

            $item->delete();
            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
        }

        return $this->_forward('success', 'utility', 'core', array(
            'smoothboxClose' => 10,
            'parentRefresh' => 10,
            'messages' => array('')
        ));
    }

    public function statisticsAction()
    {
        if (!$this->_helper->requireUser()->isValid()) return;
        //if (!$this->_helper->requireAuth()->setAuthParams('socialads', null, 'allow_edit')->isValid()) return;

        $viewer = Engine_Api::_()->user()->getViewer();
        $this->_helper->layout->setLayout('default-simple');
        $ads_id = $this->_getParam('ad_id', 0);

        // Engine_Api::_()->getApi('core', 'socialads')->sinhronizeClicks($ads_id);
        // Engine_Api::_()->getApi('core', 'socialads')->sinhronizeViews($ads_id);

        $this->view->item_ad = $item_ad = Engine_Api::_()->getItem('ad', $ads_id);
        $db = Engine_Db_Table::getDefaultAdapter();
        $res = $db->query("SELECT SUM(day1)+ SUM(day2)+SUM(day3)+SUM(day4)+SUM(day5)+SUM(day6)+SUM(day7) as 'all_sum' FROM engine4_socialads_views where ad_id =" . intval($ads_id))->fetchAll();
        $res2 = $db->query("SELECT SUM(day1)+ SUM(day2)+SUM(day3)+SUM(day4)+SUM(day5)+SUM(day6)+SUM(day7) as 'all_sum' FROM engine4_socialads_clicks where ad_id =" . intval($ads_id))->fetchAll();
        $this->view_all_count = count($res) ? $res[0]['all_sum'] : 0;
        $this->click__all_count = count($res2) ? $res2[0]['all_sum'] : 0;
        if ($ads_id == 0) {
            return;
        }
        $user_id = $this->_getParam('user_id');
        if ($user_id != $viewer->getIdentity()) {
            return;
        }
        if ($i = $this->getParam('prev', 0)) {
            $week = Engine_Api::_()->getApi('core', 'socialads')->getPrevWeek('d/m/Y', $i);
            $this->view->prev_url = $this->view->url(array('action' => 'statistics', 'user_id' => $user_id, 'ad_id' => $ads_id), 'socialads_manage', true) . '?prev=' . ($i + 1);
            $this->view->week_range = Engine_Api::_()->getApi('core', 'socialads')->getPrevWeek('d.m.Y', $i);
            $this->view->week = Engine_Api::_()->getApi('core', 'socialads')->getPrevWeek('d.m', $i);
            $this->view->next_url = $this->view->url(array('action' => 'statistics', 'user_id' => $user_id, 'ad_id' => $ads_id), 'socialads_manage', true) . '?prev=' . ($i - 1);

        } else {
            $week = Engine_Api::_()->getApi('core', 'socialads')->getThisWeek('d/m/Y');
            $this->view->prev_url = $this->view->url(array('action' => 'statistics', 'user_id' => $user_id, 'ad_id' => $ads_id), 'socialads_manage', true) . '?prev=1';
            $this->view->week_range = Engine_Api::_()->getApi('core', 'socialads')->getThisWeek('d.m.Y');
            $this->view->week = Engine_Api::_()->getApi('core', 'socialads')->getThisWeek();
        }
        $W = Engine_Api::_()->getApi('core', 'socialads')->getThisWeek('Y/m/d');

        if (strtotime($W['Monday']) <= strtotime($item_ad->start_date) || strtotime($W['Sunday']) < strtotime($item_ad->start_date)) {
            $this->view->prev_url = null;
        }

        $clicks = Engine_Api::_()->getDbtable('clicks', 'socialads');
        $views = Engine_Api::_()->getDbtable('views', 'socialads');
        $select_click = $clicks
            ->select()
            ->where('ad_id=?', $ads_id)
            ->where('week_date=?', $week['Monday'] . '-' . $week['Sunday'])
            ->limit(1);
        $select_view = $views
            ->select()
            ->where('ad_id=?', $ads_id)
            ->where('week_date=?', $week['Monday'] . '-' . $week['Sunday'])
            ->limit(1);

        $item_click = $clicks->fetchRow($select_click);
        $item_view = $views->fetchRow($select_view);

        if ($item_click == null) {
            $row = $clicks->createRow();
            $row->week_date = $week['Monday'] . '-' . $week['Sunday'];
            $row->ad_id = $ads_id;
            $row->save();
            $item_click = $row;
        }

        $this->view->click_data = array(
            1 => $item_click->day1,
            2 => $item_click->day2,
            3 => $item_click->day3,
            4 => $item_click->day4,
            5 => $item_click->day5,
            6 => $item_click->day6,
            7 => $item_click->day7,
        );

        if ($item_view == null) {
            $row = $views->createRow();
            $row->week_date = $week['Monday'] . '-' . $week['Sunday'];
            $row->ad_id = $ads_id;
            $row->save();
            $item_view = $row;
        }

        $this->view->view_data = array(
            1 => $item_view->day1,
            2 => $item_view->day2,
            3 => $item_view->day3,
            4 => $item_view->day4,
            5 => $item_view->day5,
            6 => $item_view->day6,
            7 => $item_view->day7,
        );


        if (!$this->getRequest()->isPost()) {
            // Output
            $this->renderScript('_chart_week.php');
            return;
        }
    }

    public function startstopAction()
    {
        // In smoothbox
        if (!$this->_helper->requireUser()->isValid()) return;
        if (!$this->_helper->requireAuth()->setAuthParams('socialads', null, 'allow_stop_start')->isValid()) return;

        $viewer = Engine_Api::_()->user()->getViewer();
        $this->_helper->layout->setLayout('default-simple');
        $ads_id = $this->_getParam('ad_id');
        $user_id = $this->_getParam('user_id');
        if ($user_id != $viewer->getIdentity()) {
            return;
        }
        $this->view->ads_id = $ads_id;
        $this->view->user_id = $user_id;
        $adsTable = Engine_Api::_()->getDbtable('ads', 'socialads');
        $select = $adsTable
            ->select()
            ->where('ad_id=?', $ads_id)
            ->where('user_id=?', $viewer->getIdentity());

        $item = $adsTable->fetchRow($select);

        if (!$adsTable) {
            return $this->_forward('success', 'utility', 'core', array(
                'smoothboxClose' => 10,
                'parentRefresh' => 10,
                'messages' => array('')
            ));
        }

        if (!$this->getRequest()->isPost()) {
            // Output
            if ($item->active)
                $this->renderScript('manage/stop.tpl');
            else
                $this->renderScript('manage/start.tpl');
            return;
        }
        // print_die($this->getParam('start_stop',99));

        // Process
        $db = $adsTable->getAdapter();
        $db->beginTransaction();

        try {

            $item->active = $this->getParam('start_stop', 0);
            $item->save();
            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
        }

        return $this->_forward('success', 'utility', 'core', array(
            'smoothboxClose' => 10,
            'parentRefresh' => 10,
            'messages' => array('')
        ));

    }

    public function extendAction()
    {
        $user_id = $this->getParam('user_id', 0);
        $ad_id = $this->getParam('ad_id', 0);
        $viewer = Engine_Api::_()->user()->getViewer();
        if ($viewer->getIdentity() != $user_id) return;
        $item = Engine_Api::_()->getItem('ad', $ad_id);
        if (!$item && $item->user_id != $viewer->getIdentity()) return;
        $item->extendOrPay('extend');
        $clicks = Engine_Api::_()->getDbtable('clicks', 'socialads');
        $views = Engine_Api::_()->getDbtable('views', 'socialads');
        $clicks->clearByAdId($ad_id);
        $views->clearByAdId($ad_id);

        return $this->_helper->redirector->gotoRoute(array(), 'socialads_general', true);
    }

    public function isSuperAdmin()
    {
        $viewer = Engine_Api::_()->user()->getViewer();

        if (!$viewer || !$viewer->getIdentity()) {
            return false;
        }
        $viewerLevel = Engine_Api::_()->getDbtable('levels', 'authorization')->find($viewer->level_id)->current();

        if (null === $viewerLevel || $viewerLevel->flag != 'superadmin') {
            return false;
        }
        return true;
    }

}
