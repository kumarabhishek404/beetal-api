<?php

/**
 * Created by JetBrains PhpStorm.
 * User: Ravshanbek
 * Date: 31.07.12
 * Time: 14:30
 * To change this template use File | Settings | File Templates.
 */
class Socialads_PayadsController extends Core_Controller_Action_Standard
{
    protected $_subject;

    protected $_settings;

    protected $_viewer;

    protected $_data;

    protected $_status;

    protected $_session;

    public function init()
    {
        $this->_session = new Zend_Session_Namespace('Socialads_Transaction');
        $this->_viewer =  Engine_Api::_()->user()->getViewer();
        $this->_settings = Engine_Api::_()->getDbTable('settings', 'core');
        $this->_subject = null;
        if (!Engine_Api::_()->core()->hasSubject('ad')) {
            $id = $this->_getParam('ad_id');
            if (null != $id) {
                $this->_subject = Engine_Api::_()->getItem('ad', $id);
                Engine_Api::_()->core()->setSubject($this->_subject);
            }
        }

    }

    public function payadAction()
    {
        if (!$this->_subject ) {
            return $this->_helper->redirector->gotoRoute(array(), 'socialads_general', true);
        }
        //If members can not to make donation anonymously and viewer is quest
        if (!$this->_helper->requireUser()->isValid()) {
            return;
        }
        $this->view->viewer = $viewer = $this->_viewer;
        $this->view->subject = $this->_subject;

        $values['name'] = $this->view->translate('Anonym');
        $values['email'] = $viewer->email;
        $values['amount'] = $this->_subject->price;
        $values['min_amount'] = $this->_subject->price;
        $values['object_id'] = $adid = $this->_subject->getIdentity();
        $values['object'] = 'ad';
        $values['ad_text'] = 'ad text';

        $this->_session->__set('ads_info', $values);

        $moduleTable = Engine_Api::_()->getDbTable('modules', 'core');
        $this->view->CREDIT_active = $moduleTable->isModuleEnabled('credit');
        $this->view->stripe_active = $moduleTable->isModuleEnabled('advbilling');
        $this->view->paypal_active = true;
        // If there are no enabled gateways, disable
        if (Engine_Api::_()->getDbtable('gateways', 'payment')->getEnabledGatewayCount() <= 0 && !$this->view->CREDIT_active ) {
            return $this->_helper->redirector->gotoRoute(array('action' => 'finish', 'state' => 'no_payment'));
        }
        $gatewayTable = Engine_Api::_()->getDbtable('gateways', 'payment');
        $gatewaySelect = $gatewayTable->select()
            ->where('enabled = ?', 1);
        $gateways = $gatewayTable->fetchAll($gatewaySelect);
        $gateway_ids = array();
        foreach ($gateways as $gateway){
            $gateway_ids[] = $gateway->gateway_id;
        }
        if(!in_array(555,$gateway_ids,true)){
            $this->view->stripe_active = false;
        }
        if(!in_array(2,$gateway_ids,true)){
            $this->view->paypal_active = false;
        }

        if($this->view->CREDIT_active){
            $balances = Engine_Api::_()->getItem('credit_balance', $viewer->getIdentity());
            $currency = $this->_settings->getSetting('credit.default.price',100);
            $this->view->credits = $credits = (int)((double)$currency * (double)$this->_subject->price );
            $this->view->credits = empty($credits)?0:$credits;
            $this->view->credit_balance_have = true;
            if( $credits > $balances->current_credit){
                $this->view->credit_balance_have = false;
            }
            $this->view->credit_balance = $balances->current_credit;
            $this->view->link_credit = $this->view->url(array('ad_id' => $adid,  "gateway_id" => 0, 'action' => 'buy-with-credit'), 'socialads_pay', true);
        }

        if($this->view->stripe_active){
            $this->view->link_stripe = $this->view->url(array('ad_id' => $adid,  "gateway_id" => 555, 'action' => 'process'), 'socialads_pay', true);
        }

        $this->view->link_pay_pal = $this->view->url(array('ad_id' => $adid, "gateway_id" => 2, 'action' => 'process'), 'socialads_pay', true);

        if(!$this->view->paypal_active && !$this->view->stripe_active && !$this->view->CREDIT_active ){
            return $this->_helper->redirector->gotoRoute(array('action' => 'finish', 'state' => 'no_payment'));
        }

    }

    public function processAction()
    {
        $values = $this->_session->__get('ads_info');
        if (!((bool)$values)) return;
        $currency = $this->_settings->getSetting('payment.currency', 'USD');

        //Get Gateway
        $gatewayId = $this->getParam('gateway_id',0);
        if(!$gatewayId) return;
        /**
         * @var $plugin Payment_Model_Gateway
         */

        $this->view->gateway =  $plugin = Engine_Api::_()->socialads()->getPlugin($gatewayId);
        /**
         * @var $ad Socialads_Model_Ad
         */
        $ad = Engine_Api::_()->getItem($values['object'], $values['object_id']);
        // Process
        // Create order
        $ordersTable = Engine_Api::_()->getDbtable('orders', 'payment');
        if (!empty($this->_session->order_id)) {
            $previousOrder = $ordersTable->find($this->_session->order_id)->current();
            if ($previousOrder && $previousOrder->state == 'pending') {
                $previousOrder->state = 'incomplete';
                $previousOrder->save();
            }
        }

        $ordersTable->insert(array(
            'user_id' => $this->_viewer->getIdentity(),
            'gateway_id' => $gatewayId,
            'state' => 'pending',
            'creation_date' => new Zend_Db_Expr('NOW()'),
            'source_type' => 'ad',
            'source_id' => $ad->getIdentity(),
        ));
        $this->_session->order_id = $order_id = $ordersTable->getAdapter()->lastInsertId();

        // Get gateway plugin
        $this->view->gatewayPlugin = $gatewayPlugin = $plugin->getGateway();

        $schema = 'http://';
        if (!empty($_ENV["HTTPS"]) && 'on' == strtolower($_ENV["HTTPS"])) {
            $schema = 'https://';
        }
        $host = $_SERVER['HTTP_HOST'];


        /*$params = array(
            'cmd' => '_xclick',
            'item_name' => $ad->getPaypalTitle(),
            'business' => Engine_Api::_()->getApi('core', 'socialads')->getPayPalEmail(),   //PayPal email address
            'notify_url' => $schema . $host
                . $this->view->url(array(), 'socialads_ipn')
                . '?order_id=' . $order_id
                . '&state=' . 'ipn',
            'return' => $schema . $host
                . $this->view->url(array('action' => 'return'))
                . '?order_id=' . $order_id
                . '&state=' . 'return',
            'cancel_return' => $schema . $host
                . $this->view->url(array('action' => 'return'))
                . '?order_id=' . $order_id
                . '&state=' . 'cancel',
            'rm' => 2,
            'currency_code' => $currency,
            'no_note' => 1,
            'cbt' => $this->view->translate('Go Back to The Site'),
            'no_shipping' => 1,
            'bn' => 'PP-DonationsBF:btn_donate_LG.gif:NonHostedGuest',
            'amount' => $values['amount'],
        );*/
        // Prepare transaction
        $params = array();
        $params['language'] = $this->_user->language;
        $localeParts = explode('_', $this->_user->language);
        if( count($localeParts) > 1 ) {
            $params['region'] = $localeParts[1];
        }
        $params['vendor_order_id'] = $order_id;
        $params['return_url'] = $schema . $host
            . $this->view->url(array('action' => 'return'))
            . '?order_id=' . $order_id
            . '&state=' . 'return';
        $params['cancel_url'] = $schema . $host
            . $this->view->url(array('action' => 'return'))
            . '?order_id=' . $order_id
            . '&state=' . 'cancel';
        $params['ipn_url'] = $schema . $host
            . $this->view->url(array('action' => 'index', 'controller' => 'ipn', 'module' => 'socialads'))
            . '?order_id=' . $order_id;

        // Process transaction
        //$plugin = Engine_Api::_()->socialads()->getPlugin($gatewayId);

        $transaction = $plugin->createAdsTransaction($ad, $params);

        // Pull transaction params
        $this->view->transactionUrl = $transactionUrl = $gatewayPlugin->getGatewayUrl();
        $this->view->transactionMethod = $transactionMethod = $gatewayPlugin->getGatewayMethod();
        $this->view->transactionData = $transactionData = $transaction->getData();;

        // Handle redirection
        if ($transactionMethod == 'GET') {
            $transactionUrl .= '?' . http_build_query($transactionData);
            return $this->_helper->redirector->gotoUrl($transactionUrl, array('prependBase' => false));
        }

        // Post will be handled by the view script
    }

    public function returnAction()
    {
        $all_params = array_merge($_POST, $this->_getAllParams());
        $ordersTable = Engine_Api::_()->getDbtable('orders', 'payment');

        // Get order
        if (!$this->_viewer ||
            !($orderId = $this->_getParam('order_id', $this->_session->order_id)) ||
            !($order = $ordersTable->find($orderId)->current()) ||
            $order->source_type != 'ad' ||
            !($ad = $order->getSource())
        ){
            $this->_goBack();
        }

        $api = $plugin = Engine_Api::_()->socialads();
        $plugin = $api->getPlugin($all_params['gateway_id']);
        $gatewayPlugin = $plugin->getGateway();

        // Get gateway plugin
        $this->view->gatewayPlugin = $gatewayPlugin;

        // Process return
        unset($this->_session->errorMessage);
        try {

            $status = $plugin->onAdsTransactionReturn($order, $this->_getAllParams());
            $amount = $this->_session->amount;
            if ($status == 'active') {
                $settings = Engine_Api::_()->getDbTable('settings', 'core');
                $ad->raised_sum = $ad->raised_sum + $amount;
                if ($settings->getSetting('socialads.auto.approve', 0)) {
                    $ad->approved = 1;
                }
                if ($ad->extend) {
                    $ad->extendOrPay('extend');
                } else {
                    $ad->extendOrPay('pay');
                }

            }
        } catch( Payment_Model_Exception $e ) {
            $status = 'failure';
            $this->_session->errorMessage = $e->getMessage();
        }

        return $this->_finishPayment($status);
    }

    public function _finishPayment($state = 'completed')
    {
        // Clear session
        $errorMessage = $this->_session->errorMessage;
        $this->_session->unsetAll();
        $this->_session->errorMessage = $errorMessage;

        // Redirect
        return $this->_helper->redirector->gotoRoute(array('action' => 'finish', 'state' => $state));
    }

    public function finishAction()
    {
        $this->view->status = $status = $this->_getParam('state');
        $this->view->error = $this->_session->errorMessage;
        $this->_session->unsetAll();
    }

    public function buyWithCreditAction()
    {
        $user = $this->_viewer;
        $values = $this->_session->__get('ads_info');
        $amount = $values['amount'];

        if (!$user->getIdentity() || !count($values) ) {
            return;
        }
        $table = Engine_Api::_()->getDbTable('logs', 'credit');
        $balances = Engine_Api::_()->getItem('credit_balance', $user->getIdentity());
        if (!$balances) {
            $visitorBalance = Engine_Api::_()->getItemTable('credit_balance')->createRow();
            $visitorBalance->balance_id = $user->getIdentity();
            $visitorBalance->save();
        }
        $currency = $this->_settings->getSetting('credit.default.price',100);
        $credits = (int)((double)$currency * (double)$amount );
        if ($credits > $balances->current_credit) {
            return $this->_helper->redirector->gotoRoute(array('act ion' => 'finish', 'state' => 'nomoney'));
        }
        $credits *=(-1);
        $actionTypes = Engine_Api::_()->getDbTable('actionTypes', 'credit');
        $buySocialads = $actionTypes->getActionType('buy_socialads');
        if(!$buySocialads){
            try{
                $db = Engine_Db_Table::getDefaultAdapter();
                $db->query("INSERT IGNORE INTO `engine4_credit_actiontypes` (`action_type`, `group_type`, `action_module`, `action_name`, `credit`, `max_credit`, `rollover_period`) VALUES ('buy_socialads', 'spent', NULL, 'Socialads', 0, 0, 0);");
                $buySocialads = $actionTypes->getActionType('buy_socialads');
            }catch (Exception $exception){
                print_die($exception->getMessage());
            }

        }
        $row = $table->createRow();
        $row->user_id = $user->getIdentity();
        $row->action_id = $buySocialads->action_id;
        $row->credit = $credits;
        $row->object_type = '';
        $row->object_id = 0;
        $row->body = $credits;
        $row->creation_date = new Zend_Db_Expr('NOW()');

        $balances->setCredits($credits);
        $row->save();
        $ad_item = Engine_Api::_()->getItem($values['object'], $values['object_id']);

        $ad_item->raised_sum = $ad_item->raised_sum + $amount;

        if ($this->_settings->getSetting('socialads.auto.approve', 0)) {
            $ad_item->approved = 1;
        }
        if ($ad_item->extend) {
            $ad_item->extendOrPay('extend');
        } else {
            $ad_item->extendOrPay('pay');
        }

        $ordersTable = Engine_Api::_()->getDbtable('orders', 'payment');
        $ordersTable->insert(array(
            'user_id' => $user->getIdentity(),
            'gateway_id' => 0,
            'state' => 'completed',
            'creation_date' => new Zend_Db_Expr('NOW()'),
            'source_type' => 'ad',
            'source_id' => $values['object_id'],
        ));
        //$order_id = $ordersTable->getAdapter()->lastInsertId();

        // Clear session
        $this->_session->unsetAll();
        // Redirect
        return $this->_helper->redirector->gotoRoute(array('action' => 'finish', 'state' => 'complete'));



    }

    protected function _goBack($back = true)
    {
        $ad_id = $this->_session->ad_id;
        unset($this->_session->ad_id);
        unset($this->_session->gateway_id);
        unset($this->_session->order_id);
        unset($this->_session->errorMessage);

        if ($back) {
            return $this->_helper->redirector->gotoRoute(array('action' => 'payad', 'ad_id' => $ad_id), 'socialads_pay', true);
        }
        return $this->_helper->redirector->gotoRoute(array(), 'socialads_pay', true);
    }

}
