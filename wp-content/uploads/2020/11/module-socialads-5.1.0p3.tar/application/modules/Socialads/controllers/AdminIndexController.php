<?php

/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Socialads
 * @author     KALYSKIN
 */
class Socialads_AdminIndexController extends Core_Controller_Action_Admin
{
    public function createpackageAction()
    {
        $return = false;
        $Billing_type = $this->getParam('plan','CPC');
        $Viewmode_id = $this->getParam('ads',0);

        $this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
            ->getNavigation('socialads_admin_main', array(), 'socialads_admin_main_packages');

        $this->view->form = $form = new Socialads_Form_Admin_Package();

        $view_model = Engine_Api::_()->getDbtable('viewmodes', 'socialads');

        $view_modes = $view_model->getModesAssoc(false,'id');
        if (!empty($view_modes) && is_array($view_modes) && $form->getElement('space')) {
            $form->getElement('space')->addMultiOptions($view_modes);
            if($Viewmode_id)
                $form->getElement('space')->setValue($Viewmode_id);

            $form->getElement('billing_model')->setValue($Billing_type);
            $form->setCountLabel();
        }
        $this->view->model = $view_model->fetchAll();
        if (!$this->getRequest()->isPost()) {
            return;
        }
        if (!$form->isValid($this->getRequest()->getPost())) {
            return;
        }
        $values = $form->getValues();
        if (!intval($values['count'])) {
            $form->addError($this->view->translate('Please enter valid count no.'));
            $return = true;
        }
        if ($return) return;
        // Process
        $table = Engine_Api::_()->getDbTable('prices', 'socialads');
        $db = $table->getAdapter();
        $db->beginTransaction();
        try {
            $val = array(
                'type_pay' => $values['billing_model'],
                'viewmode_id' => $values['space'],
                'price' => $values['price'],
                'discount_percent' => $values['discount'],
                'count' => $values['count'],
            );

            $price = $table->createRow();
            $price->setFromArray($val);
            $price->save();
            $db->commit();

            $this->view->form = $form = new Engine_Form();
            $form->addNotice("Package have been successfully saved!");
            $this->view->close = true;
            return $this->_forward('success', 'utility', 'core', array(
                    'smoothboxClose' => 10,
                    'parentRefresh' => 10,
                    'messages' => array('')
                ));
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
            $form->addError("An error occurred while saving data");
        }
    }

    public function indexAction()
    {
        Engine_Api::_()->getApi('core', 'socialads')->addDefaultPrices();
        $this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
            ->getNavigation('socialads_admin_main', array(), 'socialads_admin_main_packages');
        $view_model = Engine_Api::_()->getDbtable('viewmodes', 'socialads');
        $this->view->model = $view_model->fetchAll();

    }

    public function autoSwitchAction()
    {
        $this->_helper->layout->disableLayout();
        $view_model = Engine_Api::_()->getDbtable('viewmodes', 'socialads');
        $view_model->auto_switch_all();

        return $this->_helper->redirector->gotoRoute(array('module' => 'socialads', "controller" => "index", "action" => "index"), 'admin_default', true);
    }

    public function activeAdsAction()
    {
        $id_ad = $this->getParam('ad_id', 0);
        $item = Engine_Api::_()->getItem('ad', $id_ad);
        if ($item != null) {
            $item->active = $item->active ? 0 : 1;
            $item->save();
        }

        return $this->_helper->redirector->gotoRoute(array('module' => 'socialads', "controller" => "index", "action" => "ad-listing"), 'admin_default', true);

    }

    public function approveAdsAction()
    {
        $id_ad = $this->getParam('ad_id', 0);
        $item = Engine_Api::_()->getItem('ad', $id_ad);
        if ($item != null) {
            $item->approved = $item->approved ? 0 : 1;
            $item->save();
        }

        return $this->_helper->redirector->gotoRoute(array('module' => 'socialads', "controller" => "index", "action" => "ad-listing"), 'admin_default', true);

    }

    public function settingsAction()
    {
        if (!$this->getRequest()->isPost()) {
            $this->view->status = false;
            return;
        }
        $typepay = $this->getParam('typepay');
        $id = $this->getParam('id');
        $state = $this->getParam('state');

        $table = Engine_Api::_()->getDbTable('viewmodes', 'socialads');
        $select = $table->select()
            ->where('id = ?', $id)
            ->limit(1);

        $item = $table->fetchRow($select);

        if (!$item) {
            $this->view->status = false;
            return;
        }
        try {
            switch ($typepay) {
                case 'CPC':
                    $item->cpc = $state;
                    break;
                case 'CPM':
                    $item->cpm = $state;
                    break;
                case 'CPD':
                    $item->cpd = $state;
                    break;
                case 'ACTIVE':
                    $item->active = $state;
                    break;
            }
            $item->save();
            $this->view->status = true;
        } catch (Exception $e) {
            $this->view->status = false;
        }


    }

    public function getpackagesAction()
    {
        if (!$this->getRequest()->isPost()) {
            $this->view->status = false;
            return;
        }
        $id = $this->getParam('id');

        $table = Engine_Api::_()->getDbTable('prices', 'socialads');
        $select = $table->select()
            ->where('viewmode_id = ?', $id);

        $item = $table->fetchAll($select);

        if (!$item) {
            $this->view->status = false;
            return;
        }
        try {
            $this->view->content = $this->view->partial('_prices_admin.php', 'socialads', array(
                'prices' => $item,
                'viewmode_id' => $id,
            ));
            $this->view->status = true;
        } catch (Exception $e) {
            $this->view->status = false;
        }

    }

    public function adListingAction()
    {
        $this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
            ->getNavigation('socialads_admin_main', array(), 'socialads_admin_main_adlisting');

        $table = Engine_Api::_()->getDbTable('ads', 'socialads');
        $select = $table->select();
        $this->view->is_super_admin = $this->isSuperAdmin();
        $this->view->model = $paginator = Zend_Paginator::factory($select);
        $paginator->setCurrentPageNumber($this->getParam('page', 1));
        $paginator->setItemCountPerPage(20);
        $this->view->model = $paginator;

    }

    public function deleteAdsAction()
    {
        // In smoothbox
        $this->_helper->layout->setLayout('admin-simple');
        $ads_id = $this->_getParam('id');
        $this->view->ads_id = $ads_id;
        $adsTable = Engine_Api::_()->getDbtable('ads', 'socialads');
        $select = $adsTable
            ->select()
            ->where('ad_id=?', $ads_id);

        $item = $adsTable->fetchRow($select);

        if (!$adsTable) {
            return $this->_forward('success', 'utility', 'core', array(
                'smoothboxClose' => 10,
                'parentRefresh' => 10,
                'messages' => array('')
            ));
        }

        if (!$this->getRequest()->isPost()) {
            // Output
            $this->renderScript('admin-index/delete-ads.tpl');
            return;
        }

        // Process
        $db = $adsTable->getAdapter();
        $db->beginTransaction();

        try {

            $item->delete();
            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
        }

        return $this->_forward('success', 'utility', 'core', array(
            'smoothboxClose' => 10,
            'parentRefresh' => 10,
            'messages' => array('')
        ));
    }

    public function getpriceAction()
    {
        if (!$this->getRequest()->isPost()) {
            $this->view->status = false;
            return;
        }
        $id_viewmode = $this->getParam('id_vm', 0);
        $type_pay = $this->getParam('type_pay', 0);
        if ($id_viewmode && $type_pay) {
            $prices = Engine_Api::_()->getDbtable('prices', 'socialads')->getPricesArray($id_viewmode);
            $options = '';

            foreach ($prices[$type_pay] as $key => $option) {
                $options .= '<option value="' . $key . '">' . $option . '</option>';
            }
            if ($options == "")
                $options = '<option value="0">---no-package---</option>';
            $this->view->status = true;
            $this->view->options = $options;
        } else {
            $this->view->status = false;
        }
    }

    public function globalSettingsAction()
    {
        $this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
            ->getNavigation('socialads_admin_main', array(), 'socialads_admin_main_global_settings');
        $this->view->form = $form = new Socialads_Form_Admin_Global();

        $settings = Engine_Api::_()->getDbTable('settings', 'core');

        if (!$this->getRequest()->isPost()) {
            return;
        }

        if (!$form->isValid($this->getRequest()->getPost())) {
            return;
        }
        //Auto_Approve
        $value = $form->getValue('auto_approve');
        $settings->setSetting('socialads.auto.approve', $value);
        $form->auto_approve->setValue($value);

        $value = $form->getValue('user_manage_perpage');
        $settings->setSetting('socialads.manage.perpage', $value);
        $form->user_manage_perpage->setValue($value);

        $value = $form->getValue('order_on_wall');
        $settings->setSetting('socialads.orderonwall', $value);
        $form->order_on_wall->setValue($value);

        /*$value = $form->getValue('paypalemail');
        $settings->setSetting('socialads.paypalemail', $value);
        $form->paypalemail->setValue($value);*/

        $form->addNotice('Your changes have been saved.');

    }

    public function isSuperAdmin()
    {
        $viewer = Engine_Api::_()->user()->getViewer();

        if (!$viewer || !$viewer->getIdentity()) {
            return false;
        }
        $viewerLevel = Engine_Api::_()->getDbtable('levels', 'authorization')->find($viewer->level_id)->current();

        if (null === $viewerLevel || $viewerLevel->flag != 'superadmin') {
            return false;
        }
        return true;
    }
}