<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Socialads
 * @author     KALYSKIN
 */
class Socialads_Model_DbTable_Clicks extends Engine_Db_Table
{
    protected $_rowClass = 'Socialads_Model_Click';

    public function getAdById($id= 0)
    {
        $stmt = $this->select()
            ->where('ads_id=?',$id)
            ->query()
            ->limit(1);

        return $stmt->fetchRow();
    }
    public function clearByAdId($id)
    {
        $db = Engine_Db_Table::getDefaultAdapter();
        $res = $db->query("DELETE FROM engine4_socialads_clicks where ad_id =".intval($id));
        return $res;
    }

}
