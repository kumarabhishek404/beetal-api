<?php
/**
 * Created by PhpStorm.
 * User: Kalys
 * Date: 25.10.2016
 * Time: 16:23
 */
if (isset($this->prices)) {
    $NEW_PLAN = '<i class="hei hei-plus" aria-hidden="true"></i> '.$this->translate("Add plan");
    $BASE_URL_NEW_PLAN = $this->baseUrl()."/admin/socialads/index/createpackage";
    $DAYS_T = $this->translate('days');
    $CLICKS_T = $this->translate('clicks');
    $VIEWS_T = $this->translate('views');
    $viewmode_id = $this->viewmode_id;
    ?>
    <div class="prices_block_parent">
        <div class="prices_block">
            <div class="title_type_pay"><h4><?php echo $this->translate('Cost per Click (CPC)'); ?></h4></div>
            <?php
            $count_cpc = 0;
            foreach ($this->prices as $price) : ?>
                <?php
                if ($price['type_pay'] == 'CPC') {
                    $count_cpc++;
                    $dis = $price['discount_percent'] ? '<span class="discount">(' . $price['discount_percent'] . '%)</span>' : '';
                    ?>
                    <div class="price_element">
                        <a class="delete_package_icon smoothbox"
                           href="<?php echo Delete_link($price['price_id'], $this); ?>">x</a>
                        <span class="count_label"><?php echo $price['count'] . ' ' . $CLICKS_T ?></span>
                        <span class="price">$<?php echo number_format($price['price'], 2, '.', ''); ?></span>
                        <?php echo $dis ?>
                        <a class="edit_package_icon smoothbox"
                           href="<?php echo Edit_link($price['price_id'], $this); ?>">Edit</a>
                    </div>
                <?php }
            endforeach;
            if ($count_cpc < 3): ?>
                <div class="price_element">
                    <a class="smoothbox add_plan_admin" href="<?php echo $BASE_URL_NEW_PLAN."?plan=CPC&ads=".$viewmode_id;?>"><?php echo $NEW_PLAN ?> </a>
                </div>
            <?php endif; ?>
        </div>
        <div class="prices_block">
            <div class="title_type_pay"><h4><?php echo $this->translate('Cost per Views (CPV)'); ?></h4></div>
            <?php
            $count_cpm = 0;
            foreach ($this->prices as $price): ?>
                <?php
                if ($price['type_pay'] == 'CPM') {
                    $count_cpm++;
                    $dis = $price['discount_percent'] ? '<span class="discount">(' . $price['discount_percent'] . '%)</span>' : '';
                    ?>
                    <div class="price_element">
                        <a class="delete_package_icon smoothbox"
                           href="<?php echo Delete_link($price['price_id'], $this); ?>">x</a>
                        <span class="count_label"><?php echo $price['count'] . ' ' . $VIEWS_T ?></span>
                        <span class="price">$<?php echo number_format($price['price'], 2, '.', ''); ?></span>
                        <?php echo $dis; ?>
                        <a class="edit_package_icon smoothbox"
                           href="<?php echo Edit_link($price['price_id'], $this); ?>">Edit</a>
                    </div>
                <?php }
            endforeach;
            if ($count_cpm < 3): ?>
            <div class="price_element">
                <a class="smoothbox add_plan_admin" href="<?php echo $BASE_URL_NEW_PLAN."?plan=CPM&ads=".$viewmode_id;?>"><?php echo $NEW_PLAN ?> </a>
            </div>
            <?php endif; ?>
        </div>
        <div class="prices_block">
            <div class="title_type_pay"><h4><?php echo $this->translate('Cost per Day (CPD)'); ?></h4></div>

            <?php
            $count_cpd = 0;
            foreach ($this->prices as $price): ?>
                <?php
                if ($price['type_pay'] == 'CPD') {
                    $count_cpd++;
                    $dis = $price['discount_percent'] ? '<span class="discount">(' . $price['discount_percent'] . '%)</span>' : '';
                    ?>
                    <div class="price_element">
                        <a class="delete_package_icon smoothbox"
                           href="<?php echo Delete_link($price['price_id'], $this); ?>">x</a>
                        <span class="count_label"><?php echo $price['count'] . ' ' . $DAYS_T; ?></span>
                        <span class="price">$<?php echo number_format($price['price'], 2, '.', ''); ?></span>
                        <?php echo $dis; ?>
                        <a class="edit_package_icon smoothbox"
                           href="<?php echo Edit_link($price['price_id'], $this); ?>">Edit</a>
                    </div>
                <?php }
            endforeach;
            if ($count_cpd < 3): ?>
                <div class="price_element">
                    <a class="smoothbox add_plan_admin" href="<?php echo $BASE_URL_NEW_PLAN."?plan=CPD&ads=".$viewmode_id;?>"><?php echo $NEW_PLAN ?> </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php }
function Edit_link($id, $t)
{
    return $t->url(array('module' => 'socialads', 'controller' => 'package', 'action' => 'edit-package', 'package_id' => $id), 'admin_default', true);
}

function Delete_link($id, $t)
{
    return $t->url(array('module' => 'socialads', 'controller' => 'package', 'action' => 'delete-packages', 'package_id' => $id), 'admin_default', true);
}

?>


