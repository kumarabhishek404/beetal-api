<?php return array(
    'package' =>
        array(
            'type' => 'module',
            'name' => 'socialads',
            'version' => '5.1.0p3',
            'path' => 'application/modules/Socialads',
            'sku' => 'HEsocialads',
            'title' => 'HE - Social ads plugin',
            'description' => 'Hire-Experts Social ads Plugin',
            'author' => '<a href="http://www.hire-experts.com" title="Hire-Experts LLC" target="_blank">Hire-Experts LLC</a>',
            'meta' =>
                array(
                    'title' => 'HE - Socialads',
                    'description' => 'Hire-Experts Socialadsc Plugin',
                    'author' => '<a href="http://www.hire-experts.com" title="Hire-Experts LLC" target="_blank">Hire-Experts LLC</a>',
                ),
            'dependencies' => array(
                array(
                    'type' => 'module',
                    'name' => 'core',
                    'minVersion' => '4.1.8',
                ),
            ),
            'callback' =>
                array(
                    'path' => 'application/modules/Socialads/settings/install.php',
                    'class' => 'Socialads_Installer',
                ),
            'actions' =>
                array(
                    0 => 'install',
                    1 => 'upgrade',
                    2 => 'refresh',
                    3 => 'enable',
                    4 => 'disable',
                ),
            'directories' =>
                array(
                    0 => 'application/modules/Socialads',
                ),
            'files' =>
                array(
                    0 => 'application/languages/en/socialads.csv',
                ),
        ),
    // Items ---------------------------------------------------------------------
    'items' => array(
        'viewmode',
        'price',
        'ad',
    ),
    // Routes --------------------------------------------------------------------
    'routes' => array(
        // Public
        'socialads_general' => array(
            'route' => 'socialads/:action/*',
            'defaults' => array(
                'module' => 'socialads',
                'controller' => 'index',
                'action' => 'manage',
            ),
            'reqs' => array(
                'action' => '(index|create|manage|getpaymantblock|getspace)',
            ),
        ),

        'socialads_manage' => array(
            'route' => 'socialads/:action/:user_id/:ad_id/:slug',
            'defaults' => array(
                'module' => 'socialads',
                'controller' => 'manage',
                'action' => 'index',
                'slug' => '',
            ),
            'reqs' => array(
                'user_id' => '\d+',
                'ad_id' => '\d+',
                'action' => '(edit|delete|statistics|startstop|extend)',
            ),
        ),
        'socialads_redirect' => array(
            'route' => 'socialads/redirect-to/:ad_id/',
            'defaults' => array(
                'module' => 'socialads',
                'controller' => 'redirecturl',
                'action' => 'index',
                'slug' => '',
            ),
            'reqs' => array(
                'ad_id' => '\d+',
                'action' => '(index)',
            ),
        ),
        'socialads_pay' => array(
            'route' => 'socialads/pay-ad/:ad_id/:gateway_id/:action/:state',
            'defaults' => array(
                'module' => 'socialads',
                'controller' => 'payads',
                'action' => 'payad',
                'state' => '',
                'gateway_id' => '0'
            ),
            'reqs' => array(
                'ad_id' => '\d+',
                'gateway_id' => '\d+',
                'action' => '(payad|checkout|process|return|finish|buy-with-credit)',
            ),
        ),
        'socialads_extend_free' => array(
            'route' => 'socialads/extend/:ad_id/:user_id/',
            'defaults' => array(
                'module' => 'socialads',
                'controller' => 'manage',
                'action' => 'extend',
            ),
            'reqs' => array(
                'ad_id' => '\d+',
                'user_id' => '\d+',
            ),
        ),
        'socialads_ipn' => array(
            'route' => 'socialads-ipn/:action/*',
            'defaults' => array(
                'module' => 'socialads',
                'controller' => 'ipn',
                'action' => 'index',
            ),
        ),

    ),
);





?>