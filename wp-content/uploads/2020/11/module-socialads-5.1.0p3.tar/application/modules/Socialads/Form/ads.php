<?php

/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Socialads
 * @author     KALYSKIN
 */
class Socialads_Form_ads extends Engine_Form
{
    protected $_mode;

    public function init()
    {
        $tabindex = 10;

        $this->setAttrib('class', 'socialads_ads_form global_form');
        $this->setAttrib('enctype', 'multipart/form-data');
        $this->setMethod('post');
        $view = Zend_Registry::get('Zend_View');

        $this->addElement('Select', 'space', array(
            'label' => $view->translate('Where do you want to show your ad?'),
            'id' => 'space_id',
            'required' => true,
            'multiOptions' => [],
        ));



        $this->addElement('Text', 'title', array(
            'label' => 'Ad title (<span id="title_length">80</span>)',
            'id' => 'ad_title',
            'onkeyup' => '$("title_length").set("html",80 - $(this).get(\'value\').length)',
            'placeholder' => $view->translate('Example title'),
            'required' => true,
            'allowEmpty' => false,
            'filters' => array(
                'StringTrim',
            ),
            'tabindex' => $tabindex++,
            'autofocus' => 'autofocus',
            'inputType' => 'text',
            'maxlength' => 80,
            'class' => 'text',

        ));
        $this->getElement('title')->getDecorator('label')->setOption('escape', false);

        $this->addElement('Text', 'description', array(
            'label' => $view->translate('Ad description').' (<span id="description_length">255</span>)',
            'id' => 'ad_description',
            'onkeyup' => '$("description_length").set("html",255 - $(this).get(\'value\').length)',
            'placeholder' => $view->translate('Example description'),
            'allowEmpty' => true,
            'filters' => array(
                'StringTrim',
            ),
            'tabindex' => $tabindex++,
            'autofocus' => 'autofocus',
            'inputType' => 'text',
            'maxlength' => 255,
            'class' => 'text',

        ));
        $this->getElement('description')->getDecorator('label')->setOption('escape', false);

        $this->addElement('Text', 'ad_url', array(
            'label' => $view->translate('Ad URL').'(<span id="ad_url_length">255</span>)',
            'id' => 'ad_url',
            'onkeyup' => '$("ad_url_length").set("html",255 - $(this).get(\'value\').length)',
            'placeholder' => 'http://example.com',
            'required' => true,
            'allowEmpty' => false,
            'filters' => array(
                'StringTrim',
            ),
            'validators' => array(
                new Zend_Validate_Regex('|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i')
            ),
            'tabindex' => $tabindex++,
            'autofocus' => 'autofocus',
            'inputType' => 'text',
            'maxlength' => 255,
            'class' => 'text',

        ));
        $this->getElement('ad_url')->getDecorator('label')->setOption('escape', false);

        $audio = <<<COVER

<input id="image_file_ad" type="file" name="image[]"  multiple>

COVER;

        $this->addElement('Dummy', 'image1', array(
            'label' => 'Thumbnail: png, jpg, gif',
            'content' => $audio
        ));
        $this->addElement('Dummy', 'date_ad', array(
            'content' => '<div class="form-element datepicker_con">
                            <div class="form-label">
                              <label for="date_ad" class="required">' . $view->translate('When you want to start displaying ad?') . '</label>
                            </div>
                            <div class="datepicker_container ">
                                <div class="form-element">
                                     <input  type="text"  name="date_ad"  id="date_ad"/>
                                </div>
                            </div>
                        </div>',
            'decorators' => array(
                'ViewHelper',
            )
        ));

        $this->addElement('Dummy', 'left_title', array(
            'content' => '<h2>' . $view->translate('Create new ad') . '</h2>',
            'decorators' => array(
                'ViewHelper',
            )
        ));
        $this->addElement('Dummy', 'preview_title', array(
            'content' => '<h2>' . $view->translate('Your ad will look like below') . '<span id="preview_loader"></span></h2>',
            'decorators' => array(
                'ViewHelper',
            )
        ));

        $this->addElement('Dummy', 'right_title', array(
            'content' => '<h2>' . $view->translate('Choose Billing model and Limit display') . '<span id="model_limit_loader"></span></h2>',
            'decorators' => array(
                'ViewHelper',
            )
        ));

        $this->addDisplayGroup(array('left_title', 'space', 'title', 'description', 'ad_url', 'image1', 'date_ad'), 'left');
        $inputs = $this->getDisplayGroup('left');

        $inputs->setDecorators(array(
            'FormElements',
            array('HtmlTag', array('tag' => 'div', 'class' => 'left'))
        ));


        /*==============RIGHT=====================*/
        $this->addElement('Dummy', 'paymant_block', array(
            'content' => '<div class="paymant_block_row" >
                        </div>',
            'decorators' => array(
                'ViewHelper',
            )
        ));

        $this->addDisplayGroup(array('right_title', 'paymant_block'), 'right');
        $social_group = $this->getDisplayGroup('right');

        $social_group->setDecorators(array(
            'FormElements',
            array('HtmlTag', array('tag' => 'div', 'class' => 'right'))
        ));

        /*====================PREVIEW==========================*/
        $this->addElement('Dummy', 'preview_box', array(
            'content' => '<div class="preview_box" id="preview_box">
                            <div class="preview_content"></div>
                        </div>',
            'decorators' => array(
                'ViewHelper',
            )
        ));

        $this->addElement('Button', 'submit', array(
            'label' => 'Pay now!',
            'id' => 'pay_now',
            'type' => 'submit',
            'ignore' => true
        ));


        $this->addDisplayGroup(array('preview_title', 'preview_box', 'submit'), 'preview_block');
        $social_group = $this->getDisplayGroup('preview_block');

        $social_group->setDecorators(array(
            'FormElements',
            array('HtmlTag', array('tag' => 'div', 'class' => 'preview_block'))
        ));


    }

    public function getMode()
    {
        if (null === $this->_mode) {
            $this->_mode = 'page';
        }
        return $this->_mode;
    }
}