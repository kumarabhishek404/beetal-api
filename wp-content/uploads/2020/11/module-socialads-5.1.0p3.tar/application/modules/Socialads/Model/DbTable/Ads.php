<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Socialads
 * @author     KALYSKIN
 */
class Socialads_Model_DbTable_Ads extends Engine_Db_Table
{
    protected $_rowClass = 'Socialads_Model_Ad';

    public function getAdById($id= 0)
    {
        $stmt = $this->select()
            ->where('ads_id=?',$id)
            ->query()
            ->limit(1);

        return $stmt->fetchRow();
    }
    public function getLastOrder($type)
    {
        $select = $this->select()
            ->where('approved = ?', 1)
            ->where('payd = ?', 1)
            ->where('viewmode_id = ?', $type)
            ->where('start_date <= ?', date('Y-m-d'))
            ->where('active = ?', 1)
            ->order('order DESC')
            ->limit(1);

        $item = $this->fetchRow($select);
        return $item->order?$item->order:0;
    }

}
