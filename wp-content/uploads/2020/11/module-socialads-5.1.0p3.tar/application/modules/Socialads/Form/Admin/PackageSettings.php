<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Socialads
 * @author     KALYSKIN
 */

class Socialads_Form_Admin_PackageSettings extends Engine_Form
{
  private $data = array();
  private $bg_color = false;
  private $font_color = false;
  private $wall_count = false;
  private $_count = false;
  public function init()
  {
    $this
      ->setTitle('Edit Model');
      //->setDescription('Register API keys at <a target="_blank" href ="https://www.google.com/recaptcha/admin">https://www.google.com/recaptcha/admin</a>');

    // Decorators
    $this->loadDefaultDecorators();
    $this->getDecorator('Description')->setOption('escape', false);

    $settings = Engine_Api::_()->getDbTable('settings', 'core');
    $view = Zend_Registry::get('Zend_View');

    $this->addElement('text', 'label_model', array(
      'label' => 'Label',
     // 'description' => '',
      'value' => 0
    ));
    /*$this->_count?$this->addElement('text', 'count_ads', array(
      'label' => 'Count',
     // 'description' => '',
      'value' => 0
    )):null;*/
     // $this->getElement('count_ads')->getDecorator('label')->setOption('escape', false);

      $this->bg_color?$this->addElement('text', 'background_color', array(
          'label' => 'Background Color',
          'class' => 'jscolor',
          'onChange' => 'window.social_ad_plugin.setBgColor(this)',
          // 'description' => '',

      )):null;

      $this->font_color?$this->addElement('text', 'font_color', array(
          'label' => 'Font Color',
          'class' => 'jscolor',
          'onChange' => 'window.social_ad_plugin.setTextColor(this)',
          // 'description' => '',

      )):null;

      $this->wall_count?$this->addElement('text', 'wall_count', array(
          'label' => 'Order in wall (1-99)',
          'onChange' => 'var val = parseInt($(this).get("value")); if( val && val < 100 && val > 0){ $(this).set("value",val) }else{$(this).set("value","5")}',
          // 'description' => '',

      )):null;

      $this->addElement('Dummy', 'preview_box', array(
          'content' => $this->data?$view->partial(
              '_ads.php',
              'socialads',
              $this->data
          ):'',
          'decorators' => array(
              'ViewHelper',
          )
      ));

      $this->addElement('Button', 'submit', array(
          'label' => 'Save',
          'style' => 'margin: 0 100px;',
          'type' => 'submit',
         // 'ignore' => true,
          'decorators' => array(
              'ViewHelper',
          )
      ));

      $this->addDisplayGroup(array('label_model','count_ads','background_color','font_color','wall_count','submit' ), 'left');
      $social_group = $this->getDisplayGroup('left');
      $social_group->addDecorator(new Socialads_Form_Decorator_EditForm());


      $this->addDisplayGroup(array('preview_box' ), 'right');
      $social_group2 = $this->getDisplayGroup('right');
      $social_group2->addDecorator(new Socialads_Form_Decorator_EditForm());



  }

 public function setPreview($data)
 {
     $this->data = array(
         'view_mode' => $data->name,
         'bg_color' => $bg_color = $data->getParam('background_color'),
         'font_color' => $font_color = $data->getParam('font_color'),
     );
     $wall_count = $data->getParam('wall_count');
     $this->bg_color = $bg_color?true:false;
     $this->font_color = $font_color?true:false;
     $this->wall_count = $wall_count?true:false;
     $this->init();

     $bg = $this->getElement('background_color');
     $bg?$bg->setValue($bg_color):null;

     $fc = $this->getElement('font_color');
     $fc?$fc->setValue($font_color):null;

     $wc = $this->getElement('wall_count');
     $wc?$wc->setValue($wall_count):null;

     //if($data->getParam('count_in_widget',0))
         //$this->getElement('count_ads')->setValue($data->getParam('count_in_widget',0));
     $this->getElement('label_model')->setValue($data->label);

 }

}

