<?php

class Socialads_WidgetController extends Core_Controller_Action_Standard
{
    public function indexAction()
    {
        $viewer = Engine_Api::_()->user()->getViewer();

        $type = $this->getParam('type', 0);
        $this->view->type = $type;
        $id_ad = $this->getParam('id_ad', 0);
        $table = Engine_Api::_()->getDbtable('ads', 'socialads');
        $select = $table->select()
            ->where('approved = ?', 1)
            ->where('payd = ?', 1)
            ->where('viewmode_id = ?', $type)
            ->where('ad_id <> ?', $id_ad)
            ->where('start_date <= ?', date('Y-m-d'))
            ->where('active = ?', 1)
            ->order('order ASC')
            ->limit(1);

        $item = $table->fetchRow($select);
        if($item != null && $item->getRestPercent() >= 100){
            try{
                $item->active = 0;
                $item->extend = 1;
                $item->save();
                $this->view->status = false;
                return;
            }catch (Exception $e)
            {
                print_die($e);
            }

        }

        if ($item == null){
            $this->view->status = false;
            return;
        }
        try {
            $item->incViewCount();
            $item->incOrderCount();
            $item->save();
            $this->view->status = true;
        } catch (Exception $e) {
            $this->view->status = false;
        }

        $this->view->ID_AD = $item->getIdentity();
        $viewmodeAd = $item->getBlockType();

        if($viewmodeAd->getParam('background_color',false) && $viewmodeAd->getParam('font_color',false)){
            $this->view->html = $this->view->partial('_ads.php', 'socialads', array(
                'view_mode' => $viewmodeAd->name,
                'model_ad' => $item,
                'bg_color' => $viewmodeAd->getParam('background_color',''),
                'font_color' => $viewmodeAd->getParam('font_color',''),
            ));

        }else{
            $this->view->html = $this->view->partial('_ads.php', 'socialads', array(
                'view_mode' => $viewmodeAd->name,
                'model_ad' => $item,
            ));
        }


    }

}
