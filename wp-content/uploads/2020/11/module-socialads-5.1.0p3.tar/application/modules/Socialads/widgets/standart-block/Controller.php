<?php

/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Socialads
 * @author     KALYSKIN
 */
class Socialads_Widget_StandartBlockController extends Engine_Content_Widget_Abstract
{
    public function indexAction()
    {
        $this->view->adstype = $this->_getParam('adsType', false);

        if( !$this->view->adstype ){
            return $this->setNoRender();
        }
        $this->view->delay  = intval($this->_getParam('delay',120))*1000;
    }
}
