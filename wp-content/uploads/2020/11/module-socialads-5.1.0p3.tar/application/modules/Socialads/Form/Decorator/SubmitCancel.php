<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Wall
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: WallElemDesc.php 18.06.12 10:52 michael $
 * @author     Michael
 */

/**
 * @category   Application_Extensions
 * @package    Wall
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */
class Socialads_Form_Decorator_SubmitCancel extends Zend_Form_Decorator_Abstract
{

    public function render($content)
    {
        $label = $this->getOption('label');
        $c_label = $this->getOption('cancel_label');
        $type = $this->getOption('type');
        $content = <<<COVER
<p><button type='{$type}'>{$this->translate($label) }</button>
            or <a href='javascript:void(0);' onclick='javascript:parent.Smoothbox.close()'>{$this->translate($c_label) }</a></p>
COVER;
        return  $content;

    }


}