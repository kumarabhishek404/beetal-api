<?php

/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Socialads
 * @author     KALYSKIN
 */
class Socialads_Form_adsedit extends Engine_Form
{
    protected $_mode;
    protected $_img_url = '';

    public function __construct($_img_url)
    {
        $this->_img_url = $_img_url;
        parent::__construct();
    }

    public function init()
    {
        $tabindex = 10;

        $this->setAttrib('class', 'socialads_ads_form global_form');
        $this->setAttrib('enctype', 'multipart/form-data');
        $this->setMethod('post');

        //$this->setAction(Zend_Controller_Front::getInstance()->getRouter()->assemble(array('module' => 'heloginpopup', 'controller' => 'index', 'action' => 'index'), 'default'));

        //$settings = Engine_Api::_()->getApi('settings', 'core');
        $view = Zend_Registry::get('Zend_View');

        $this->addElement('Dummy', 'left_title', array(
            'content' => '<h2>' . $view->translate('Edit ads') . '</h2>',
            'decorators' => array(
                'ViewHelper',
            )
        ));

        $this->addElement('Text', 'title', array(
            'label' => 'Ad title (<span id="title_length">80</span>)',
            'id' => 'ad_title',
            'onkeyup' => '$("title_length").set("html",80 - $(this).get(\'value\').length)',
            'placeholder' => 'Example title',
            'required' => true,
            'allowEmpty' => false,
            'filters' => array(
                'StringTrim',
            ),
            'tabindex' => $tabindex++,
            'autofocus' => 'autofocus',
            'inputType' => 'text',
            'maxlength' => 80,
            'class' => 'text',

        ));
        $this->getElement('title')->getDecorator('label')->setOption('escape', false);

        $this->addElement('Textarea', 'description', array(
            'label' => 'Ad description (<span id="description_length">255</span>)',
            'id' => 'ad_description',
            'onkeyup' => '$("description_length").set("html",255 - $(this).get(\'value\').length)',
            'placeholder' => 'Example description',
            'required' => true,
            'row' => 255,
            'allowEmpty' => false,
            'filters' => array(
                'StringTrim',
            ),
            'tabindex' => $tabindex++,
            'autofocus' => 'autofocus',
            'inputType' => 'text',
            'maxlength' => 255,
            'class' => 'text',

        ));
        $this->getElement('description')->getDecorator('label')->setOption('escape', false);

        $this->addElement('Text', 'ad_url', array(
            'label' => 'Ad URL (<span id="ad_url_length">255</span>)',
            'id' => 'ad_url',
            'onkeyup' => '$("ad_url_length").set("html",255 - $(this).get(\'value\').length)',
            'placeholder' => 'http://example.com',
            'required' => true,
            'allowEmpty' => false,
            'filters' => array(
                'StringTrim',
            ),
            'tabindex' => $tabindex++,
            'autofocus' => 'autofocus',
            'inputType' => 'text',
            'maxlength' => 255,
            'class' => 'text',

        ));
        $this->getElement('ad_url')->getDecorator('label')->setOption('escape', false);

        $file = <<<COVER
     <div class="form-wrapper">
        <div id="image1-label" class="form-label">{$view->translate('Thumbnail: png, jpg, gif')}</div>
        <div id="image1-element" class="form-element">
            <input id="image_file_ad" type="file" name="image[]" multiple="">
        </div>
      </div>

COVER;

        $this->addElement('Dummy', 'image_icon', array(
            'content' => '<img style="max-height:150px;" src="' . $this->_img_url . '"/>',
        ));

        $this->addElement('Dummy', 'image1', array(
            'content' => $file,
            'decorators' => array(
                'ViewHelper',
            )
        ));


        /*
              $this->addDisplayGroup(array('left_title', 'email','title','description','ad_url','image_icon','image1'), 'content');
              $inputs = $this->getDisplayGroup('content');

              $inputs->setDecorators(array(
                  'FormElements',
                  array('HtmlTag', array('tag' => 'div',
                  ))));*/

        $this->addElement('Button', 'submit', array(
            'label' => 'Save!',
            'id' => 'pay_now',
            'type' => 'submit',
            'ignore' => true
        ));

        $this->addElement('hidden', 'user_id', array());

    }

    public function populateFromModel($model)
    {
        $this->getElement('title')->setValue($model->title);
        $this->getElement('description')->setValue($model->description);
        $this->getElement('ad_url')->setValue($model->ad_url);
        $this->getElement('user_id')->setValue($model->user_id);
    }
}