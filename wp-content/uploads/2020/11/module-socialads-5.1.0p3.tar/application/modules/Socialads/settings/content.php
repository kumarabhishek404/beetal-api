<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Socialads
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: content.php 9747 2012-07-26 02:08:08Z john $
 * @author     KAlYSKIN
 */
return array(
    array(
        'title' => 'Social ads widget',
        'description' => 'Social ads widget',
        'category' => 'Socialads',
        'type' => 'widget',
        'name' => 'socialads.standart-block',
        'isPaginated' => false,
        'requirements' => array(
            'no-subject',
        ),
        'defaultParams' => array(
            'title' => 'Ads',
        ),
        'autoEdit' => true,
        'adminForm' => array(
            'elements' => array(
                array(
                    'Select',
                    'adsType',
                    array(
                        'label' => 'Ads Block Type',
                        'multiOptions' => Engine_Api::_()->getDbtable('viewmodes', 'socialads')->getModesAssoc(),
                        'value' => '1',
                    )
                ),
                array(
                    'Text',
                    'delay',
                    array(
                        'label' => 'Delay (sec)',
                        'value' => 60,
                    )
                ),
            )
        ),
    ),
        array(
    'title' => 'Browse Menu',
    'description' => 'Displays menu.',
    'category' => 'Socialads',
    'type' => 'widget',
    'name' => 'socialads.browse-menu',
  ),


) ?>