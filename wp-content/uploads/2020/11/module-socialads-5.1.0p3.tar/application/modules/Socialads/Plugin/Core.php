<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Socialads
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @author     KAlYSKIN
 */
class Socialads_Plugin_Core extends Zend_Controller_Plugin_Abstract
{

}
