<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Socialads
 * @author     KALYSKIN
 */
class Socialads_Model_DbTable_Prices extends Engine_Db_Table
{
    protected $_rowClass = 'Socialads_Model_Price';

    public function getPricesAssoc($id= 0)
    {
        $stmt = $this->select()
            ->where('viewmode_id=?',$id)
            ->order('price_id ASC')
            ->query();

        return $stmt->fetchAll();
    }

    public function getPricesArray($id= 0)
    {
        $stmt = $this->select()
            ->where('viewmode_id=?',$id)
            ->order('price_id ASC')
            ->query();
        $res = array();
        $view = Zend_Registry::get('Zend_View');
        $m = $stmt->fetchAll();
           // print_die($m);
        foreach($m as $item)
        {
            $_px = '';
            switch($item['type_pay']){
                case 'CPC': $_px = $view->translate('Clicks'); break;
                case 'CPM': $_px = $view->translate('Views'); break;
                case 'CPD': $_px = $view->translate('Days'); break;
            }
            $res[ $item['type_pay'] ][ $item['price_id'] ] = '$'. number_format($item['price'] , 2, '.', '') . ' ('.$item['count'].' '.$_px.')';
        }
        return $res;
    }

    public function sinhronizePricesWithPercent()
    {
        $sql = "UPDATE engine4_socialads_ads
INNER JOIN engine4_socialads_prices ON engine4_socialads_ads.price_id = engine4_socialads_prices.price_id
SET engine4_socialads_ads.price = (engine4_socialads_prices.price - (engine4_socialads_prices.price * engine4_socialads_prices.discount_percent / 100))";
        $db = Engine_Db_Table::getDefaultAdapter();
        $db->query($sql);
    }

}
