<?php
/**
 * Created by PhpStorm.
 * User: Kalys
 * Date: 25.10.2016
 * Time: 16:23
 */
if(isset($this->model)){
    function number_f($a,$b,$c,$d)
    {
        if(intval($a) <= 0)
            return "FREE";
        return '$ '.number_format($a,$b,$c,$d);
    }
    ?>
<div class="type_paymant">
    <?php if($this->model->cpc){ ?>
        <div class="right_input_radios opacity05 fw700" >
            <input class="method_pay_inputs" id="right_input_radios_cpc" type="radio" value="cpc" name="method_pay">
            <label for="right_input_radios_cpc" ><?php echo $this->translate('Cost per Click (CPC)');  ?></label>
        </div>
    <?php } ?>

    <?php if($this->model->cpm){ ?>
        <div class="right_input_radios opacity05 fw700" >
            <input class="method_pay_inputs"  id="right_input_radios_cpm" type="radio" value="cpm" name="method_pay">
            <label for="right_input_radios_cpm" ><?php echo $this->translate('Cost per Views (CPV)'); ?></label>
        </div>
    <?php } ?>

    <?php if($this->model->cpd){ ?>
        <div class="right_input_radios opacity05 fw700" >
            <input class="method_pay_inputs"  id="right_input_radios_cpd" type="radio" value="cpd" name="method_pay">
            <label for="right_input_radios_cpd" ><?php echo $this->translate('Cost per Day (CPD)'); ?></label>
        </div>
    <?php } ?>
</div>
    <div class="prices_block">
        <div class="cpc_prices">
           <?php $i = 0; foreach($this->prices as $price){?>
               <?php
               if($price['type_pay'] == 'CPC' && $i < 3){
               $dis = $price['discount_percent']?'<span class="discount">('.$price['discount_percent'].'%)</span>':'';
               ?>
               <div class="right_input_radios">
                   <input  id="right_input_radios_400" type="radio"  value="<?php echo $price['price_id']; ?>"  name="price"/>
                   <label for="right_input_radios_400" ><?php echo $price['count'].' '.$this->translate('clicks')?></label>
                   <span class="price" ><?php echo number_f($price['price'], 2, '.', ''); ?></span>
                   <?php echo $dis?>
               </div>
           <?php $i++; } }?>
        </div>
        <div class="cpm_prices">
           <?php $i = 0; foreach($this->prices as $price){?>
               <?php
               if($price['type_pay'] == 'CPM' && $i < 3){
               $dis = $price['discount_percent']?'<span class="discount">('.$price['discount_percent'].'%)</span>':'';
               ?>
               <div class="right_input_radios">
                   <input  id="right_input_radios_400" value="<?php echo $price['price_id']; ?>" type="radio" name="price"/>
                   <label for="right_input_radios_400" ><?php echo $price['count'].' '.$this->translate('views')?></label>
                   <span class="price" ><?php echo number_f($price['price'], 2, '.', ''); ?></span>
                   <?php echo $dis; ?>
               </div>
           <?php $i++; } }?>
        </div>
        <div class="cpd_prices">
           <?php $i = 0; foreach($this->prices as $price){?>
               <?php
               if($price['type_pay'] == 'CPD' && $i < 3){
               $dis = $price['discount_percent']?'<span class="discount">('.$price['discount_percent'].'%)</span>':'';
               ?>
               <div class="right_input_radios">
                   <input  id="right_input_radios_400" value="<?php echo $price['price_id']; ?>" type="radio" name="price"/>
                   <label for="right_input_radios_400" ><?php echo $price['count'].' '.$this->translate('days'); ?></label>
                   <span class="price" ><?php echo number_f($price['price'], 2, '.', ''); ?></span>
                   <?php echo $dis; ?>
               </div>
           <?php $i++; } }?>
        </div>
    </div>
<?php } ?>
