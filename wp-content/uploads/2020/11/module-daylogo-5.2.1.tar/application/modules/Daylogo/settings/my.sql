--
-- Dumping data for table `engine4_core_modules`
--

INSERT INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES
('daylogo', 'Daylogo', 'Site Daylogo', '5.2.1', 1, 'extra');
