<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Credit
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: ActionTypes.php 03.01.12 16:09 TeaJay $
 * @author     Taalay
 */

/**
 * @category   Application_Extensions
 * @package    Credit
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Credit_Model_DbTable_Signups extends Engine_Db_Table
{


  public function getSignup($params = array())
  {
/*    $select = $this->select()->where('user_id = ?',$params);
    $action_types = $this->fetchAll($select);


    if (count($action_types->toArray()) == 0){*/
      $table = Engine_Api::_()->getDbTable('logs', 'credit');
      $balance = Engine_Api::_()->getItem('credit_balance', $params);

      if (!$balance) {
        $balance = Engine_Api::_()->getItemTable('credit_balance')->createRow();
        $balance->balance_id = $params;
        $balance->save();
      }


/*      $db = $this->getAdapter();
      $db->beginTransaction();
      $cred = $this->createRow();
      $cred->user_id = $params;
      $cred->save();*/


      $object_id = $params;

      $actiontypes = Engine_Api::_()->getDbTable('actiontypes', 'credit');

      $actiontypes_select = $actiontypes->select()->where('action_type = ?','signup');

      $actiontypes_action_id = $actiontypes->fetchAll($actiontypes_select);

      $action_id = $actiontypes_action_id->toArray();

      
      $row = $table->createRow();
      $row->user_id = $params;
      $row->action_id = $action_id[0]['action_id'];
      $row->credit = $action_id[0]['credit'];
      $row->object_type = 'signup';
      $row->object_id = $object_id;
      $row->creation_date = new Zend_Db_Expr('NOW()');

      $balance->setCredits($action_id[0]['credit']);

      $row->save();


/*      return;

    }else{
      return;
    }

    return;*/



  }

}
