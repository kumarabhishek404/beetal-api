<?php
/**
 * SocialEngine
 * @category   Application_Extensions
 * @package    Credit
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: GiveCredits.php 11.01.12 18:02 TeaJay $
 * @author     Taalay
 */

/**
 * @category   Application_Extensions
 * @package    Credit
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Credit_Form_Admin_Faqs extends Engine_Form
{
  public function init()
  {
    $this->setAttribs(
      array(
        'class' => 'global_form_box credit_settings_form'
      )
    );

    //$this->setTitle('Give Mass Credits')
     // ->setDescription('CREDIT_GIVE_MASS_CREDITS_DESC');

    $this->addElement('Text', 'subject', array(
      'label' => 'Question',
      'allowEmpty' => false,
      'required' => true
    ));

    $this->addElement('Textarea', 'message', array(
      'label' => 'Answer',
      'value' => '',
      'allowEmpty' => false,
      'required' => true
    ));


    $this->addElement('Button', 'submit', array(
      'label' => 'Submit',
      'type' => 'submit',
      'ignore' => true
    ));
  }
}
