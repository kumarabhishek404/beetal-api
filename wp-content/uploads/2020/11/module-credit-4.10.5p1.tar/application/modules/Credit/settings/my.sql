INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES
('credit', 'Credit', 'Credit', '4.10.5p1', 1, 'extra');


INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES
('core_main_hegift', 'hegift', 'HEGIFT_Gifts', NULL, '{\"route\":\"hegift_general\"}', 'core_main', NULL, 1, 0, 11),
('core_admin_main_plugins_hegift', 'hegift', 'vGift', NULL, '{\"route\":\"admin_default\",\"module\":\"hegift\",\"controller\":\"index\",\"action\":\"index\"}', 'core_admin_main_plugins', NULL, 1, 0, 888),
('hegift_admin_main_index', 'hegift', 'View Gifts', NULL, '{\"route\":\"admin_default\",\"module\":\"hegift\",\"controller\":\"index\",\"action\":\"index\"}', 'hegift_admin_main', NULL, 1, 0, 1),
('hegift_admin_main_category', 'hegift', 'Categories', NULL, '{\"route\":\"admin_default\",\"module\":\"hegift\",\"controller\":\"category\",\"action\":\"index\"}', 'hegift_admin_main', NULL, 1, 0, 2),
('hegift_admin_main_levels', 'hegift', 'Levels Settings', NULL, '{\"route\":\"admin_default\",\"module\":\"hegift\",\"controller\":\"settings\",\"action\":\"levels\"}', 'hegift_admin_main', NULL, 1, 0, 2),
('hegift_admin_main_listing', 'hegift', 'Listings', NULL, '{\"route\":\"admin_default\",\"module\":\"hegift\",\"controller\":\"settings\",\"action\":\"listing\"}', 'hegift_admin_main', NULL, 1, 0, 4),
('hegift_main_index', 'hegift', 'Browse Gifts', NULL, '{\"route\":\"hegift_general\"}', 'hegift_main', NULL, 1, 0, 1),
('hegift_main_manage', 'hegift', 'Inbox/Sent', 'Hegift_Plugin_Menus', '{\"route\":\"hegift_general\",\"action\":\"manage\"}', 'hegift_main', NULL, 1, 0, 2),
('hegift_main_own', 'hegift', 'Send Own Gift', 'Hegift_Plugin_Menus', '{\"route\":\"hegift_own\"}', 'hegift_main', NULL, 1, 0, 3),
('hegift_admin_main_settings', 'hegift', 'Global Settings', NULL, '{\"route\":\"admin_default\",\"module\":\"hegift\",\"controller\":\"settings\",\"action\":\"index\"}', 'hegift_admin_main', NULL, 1, 0, 3),
('hegift_main_temp', 'hegift', 'Temporary', 'Hegift_Plugin_Menus', '{\"route\":\"hegift_temp\"}', 'hegift_main', NULL, 1, 0, 4),
('hegift_profile_gift', 'hegift', 'HEGIFT_Send Gift', 'Hegift_Plugin_Menus', '', 'user_profile', '', 1, 0, 6);
