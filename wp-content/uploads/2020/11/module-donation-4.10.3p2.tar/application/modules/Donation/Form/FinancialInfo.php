<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Donation
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @author     adik
 * @date       16.08.12
 * @time       17:43
 */
class Donation_Form_FinancialInfo extends Engine_Form
{
  public function init()
  {
    $this->setTitle('Financial Information For Donation')
      ->setDescription('DONATION_FinInfo');



    $this->addElement('Text', 'pemail', array(
      'label' => 'PayPal Email Address',
      'validators' => array(
        array('EmailAddress', true),
      ),
      'filters' => array(
        'StringTrim'
      ),
      // fancy stuff
      'inputType' => 'email',
      'autofocus' => 'autofocus',
        'order' => 8,
    ));



    // Buttons
    $this->addElement('Button', 'submit', array(
      'label' => 'Save Changes',
      'type' => 'submit',
      'ignore' => true,
        'order' => 997,
      'decorators' => array(
        'ViewHelper',
      ),
       c
    ));

    $this->addElement('Cancel', 'cancel', array(
      'label' => 'cancel',
      'link' => true,
      'prependText' => ' or ',
        'order' => 998,
      'decorators' => array(
        'ViewHelper',
      ),
    ));

    $this->addDisplayGroup(array('submit', 'cancel'), 'buttons', array(
      'decorators' => array(
        'FormElements',
        'DivDivDivWrapper',
      ),
        'order' => '999'
    ));
  }
    public function addStripDetails($values){
        $this->addElement('Checkbox', 'paypal', array(
            'label' => 'I Have a PayPal account',
            'value' => false,
            'order' => 1,
             "onClick" => "PayPalChecked()",
        ));

        $this->addElement('Checkbox', 'stripe', array(
            'label' => 'I Have a Stripe account',
            'value' => $values['status'],
            'order' => 15,
            "onClick" => "StripeChecked()",
        ));
        $this->addElement('dummy', 'description_stripe',array(
            'label' => 'DONATION_FinInfoStripe',
            'order' => 16,
        ));
        $this->getElement('description_stripe')->getDecorator('label')->setOption('escape', false);

        $this->addElement('Text', 'stripe_secret_key', array(
            'label' => 'Stripe secret key',
            'value' => $values['secret_key'],
            'order' => 17,
        ));
        $this->addElement('Text', 'stripe_publish_key', array(
            'label' => 'Publishable Key ',
            'value' => $values['publish_key'],
            'order' => 18,
        ));
    }
  public function addPapalCheck(){
        $this->addElement('hidden', 'paypal', array(
            'value' => 1,
          'order' => '15465'

        ));


    }
}
