<?php
class Headvancedalbum_Model_Featurephoto extends Core_Model_Item_Abstract
{
  
}