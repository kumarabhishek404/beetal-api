<?php

class Headvancedalbum_Widget_OrderBoxFeaturedController extends Engine_Content_Widget_Abstract
{
  public function indexAction()
  {

  }
}