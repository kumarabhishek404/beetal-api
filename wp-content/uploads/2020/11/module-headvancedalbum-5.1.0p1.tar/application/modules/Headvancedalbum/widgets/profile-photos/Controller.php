<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Headvancedalbum
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: Controller.php 2013-01-21 16:48:00 ratbek $
 * @author     Ratbek
 */

/**
 * @category   Application_Extensions
 * @package    Headvancedalbum
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Headvancedalbum_Widget_ProfilePhotosController extends Engine_Content_Widget_Abstract
{
    public function indexAction()
    {

      $viewer = Engine_Api::_()->user()->getViewer();
      $this->view->subject = $subject = Engine_Api::_()->core()->getSubject('user');
      if( !$subject->authorization()->isAllowed($viewer, 'view') ) {
        return $this->setNoRender();
      }
      $params = array(
        'owner' => $subject,
        'random' => 1
      );
      /**
       * @var $paginator Zend_Paginator
       */
      $paginator = Engine_Api::_()->getDbTable('photos', 'headvancedalbum')->getPhotosPaginator($params);
      $paginator->setItemCountPerPage(6);
      $paginator->setCurrentPageNumber(1);
      $this->view->paginator = $paginator;
      $this->view->count=$paginator->getTotalItemCount();
      $this->view->photos = $photos = Engine_Api::_()->getDbTable('photos', 'headvancedalbum')->getPhotosByPaginator($paginator);
      $this->view->categories = $categories = Engine_Api::_()->getDbTable('categories', 'album')->getCategoriesAssoc($params);
    }
}
