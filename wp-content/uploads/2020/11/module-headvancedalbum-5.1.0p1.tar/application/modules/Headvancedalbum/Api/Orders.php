<?php

class Headvancedalbum_Api_Orders extends Core_Api_Abstract
{

    public function getBirthday($user, $viewer = null)
    {

        $profileTypeId = $this->getProfileType($user);
        if (!$profileTypeId)
            return false;
        $fieldsMapsTable = new Fields_Model_DbTable_Meta("user", "maps");
        $fieldsMetaTable = new Fields_Model_DbTable_Meta("user", "meta");

        $select = $fieldsMetaTable->select()
            ->setIntegrityCheck(false)
            ->from(array("meta" => $fieldsMetaTable->info('name')), array("meta.field_id"))
            ->where("type = ?", "birthdate")
            ->joinLeft(array("maps" => $fieldsMapsTable->info('name')), "meta.field_id = maps.child_id", array())
            ->where("option_id = ?", $profileTypeId);

        $result = $fieldsMetaTable->fetchAll($select)->toArray();

        if (!empty($result)) {
            $birthdayFieldId=  $result[0]['field_id'];
        }
        $fieldsValuesTable = new Fields_Model_DbTable_Values("user", "values");
        $myBirthdaySql = $fieldsValuesTable->select()->where("field_id = ?", $birthdayFieldId)->where("item_id = ?", $user->getIdentity());
        $myBirthdayRow = $fieldsValuesTable->fetchAll($myBirthdaySql)->toArray();
        if($myBirthdayRow) {
            return $this->get_age($myBirthdayRow[0]['value']);
        }
        return false;
    }
    public function getProfileType($user)
    {
        $fieldsSearchTable = new Fields_Model_DbTable_Search("user", "search");
        $profileTypeSql = $fieldsSearchTable->select()->where("item_id = ?", $user->getIdentity());
        $profileTypeRow = $fieldsSearchTable->fetchRow($profileTypeSql);

        if(!$profileTypeRow || !is_object($profileTypeRow))
            return "";
        $profileType = $profileTypeRow->toArray();
        return $profileType['profile_type'];
    }
    public function get_age($birthday)
    {   
        if (!preg_match("^[0-9]{4}-[0-1][0-9]-[0-3][0-9]$",$birthday))
        {
            $birthday = 1972-01-01;
        }
        list($by, $bm, $bd) = explode('-', $birthday);
        list($cd, $cm, $cy) = explode('-', date('d-m-Y'));
        $cd -= $bd;
        $cm -= $bm;
        $cy -= $by;
        if ($cd < 0) $cm--;
        if ($cm < 0) $cy--;
        return $cy;
    }


    public function user_inf($viewer){
         $user_t = Engine_Api::_()->getDbtable("user", "search");
         $res =  $user_t->select()->where('item_id = ?',$viewer->user_id );
         return $res;
         //$user_t->fetchAll($res);
     }

    public function featured(){

        $table = Engine_Api::_()->getDbtable('albums', 'album');
        $table_like = Engine_Api::_()->getDbtable('likes', 'core');
        $pageSelect = $table->select()
            ->setIntegrityCheck(false)
            ->from(array('albums' => $table->info('name')), new Zend_Db_Expr('*'))
            ->joinLeft(array('likes' => $table_like->info('name')), 'albums.album_id = likes.resource_id', array())
            ->where("likes.resource_type = 'album'")
            ->where('albums.view_count > 0')
            ->where('albums.comment_count > 0');
        $option = $table->fetchAll($pageSelect)->toArray();


        $option['sort_by'] = 'featured';
        return $this->getAlbumPaginator($option);
    }

    public function liked(){
        $table = Engine_Api::_()->getDbtable('albums', 'album');
        $table_like = Engine_Api::_()->getDbtable('likes', 'core');
        $pageSelect = $table->select()
            ->setIntegrityCheck(false)
            ->from(array('albums' => $table->info('name')), new Zend_Db_Expr('*'))
            ->joinLeft(array('likes' => $table_like->info('name')), 'albums.album_id = likes.resource_id', array())
            ->where("likes.resource_type = 'album'");
        $option = $table->fetchAll($pageSelect)->toArray();
        $option['sort_by'] = 'liked';
        return $this->getAlbumPaginator($option);
    }

    public function viewed(){
        $table = Engine_Api::_()->getDbtable('albums', 'album');
        $select = $table->select()
            ->where('view_count > 0')
            ->order('view_count DESC');
        $option = $table->fetchAll($select)->toArray();
        $option['sort_by'] = 'view_count';
        return $this->getAlbumPaginator($option);
    }

    public function commented(){
        $table = Engine_Api::_()->getDbtable('albums', 'album');
        $select = $table->select()
                        ->where('comment_count > 0')
                        ->order('comment_count DESC');
        $option = $table->fetchAll($select)->toArray();
        $option['sort_by'] = 'comment_count';
        return $this->getAlbumPaginator($option);
    }

    public function recent(){
        $table = Engine_Api::_()->getDbtable('albums', 'album');
        $select = $table->select();
        $option = $table->fetchAll($select)->toArray();
        $option['sort_by'] = 'recent';
        return $this->getAlbumPaginator($option);
    }

    public function random(){
        $table = Engine_Api::_()->getDbtable('albums', 'album');
        $select = $table->select();
        $option = $table->fetchAll($select)->toArray();
        $option['sort_by'] = 'random';
        return $this->getAlbumPaginator($option);
    }

    public function getAlbumPaginator($options = array())
    {
      return Zend_Paginator::factory($this->selectAlbums($options));
    }

    public function selectAlbums($options=null){




        $viewer = Engine_Api::_()->user()->getViewer();
        $db = Engine_Db_Table::getDefaultAdapter();

        $authallowTbl = Engine_Api::_()->getDbTable('allow', 'authorization');
        $albumsTbl = Engine_Api::_()->getDbTable('albums', 'album');

        $user_id = $viewer->getIdentity();
        $friend_ids = array();

        // if a user is logged
        if ($viewer->getIdentity()) {
            $friend_ids = $viewer->membership()->getMembershipsOfIds();
        }

        // add 0 in order to don't break the query
        if (empty($friend_ids)) {
            $friend_ids = array(0);
        }

        $settings = Engine_Api::_()->getApi('settings', 'core');
        $pageAlbumSettings = $settings->getSetting('page.browse.pagealbum');


            // The albums select
            $select = $albumsTbl->select()
                ->setIntegrityCheck(false)
                ->from(array('albums' => $albumsTbl->info('name')),
                    new Zend_Db_Expr('albums.album_id AS id, "album" AS type, albums.view_count AS view_count, albums.creation_date AS creation_date'));

        if($options['sort_by']=='featured') {
            $select->order('view_count DESC');
            $select->order('albums.comment_count DESC');
            $select->order('albums.creation_date DESC');
        }

        //print_arr($select."");

        if(!empty($allowed_albums)){
            $select->where("albums.album_id IN (?)", $allowed_albums);
        }

        // Page albums select
        $pageSelect = new Zend_Db_Select($db);

        if (Engine_Api::_()->getDbTable('modules', 'core')->isModuleEnabled('pagealbum') && $pageAlbumSettings) {

            $pageTable = Engine_Api::_()->getDbTable('pages', 'page');
            $pageAlbumTable = Engine_Api::_()->getDbTable('pagealbums', 'pagealbum');
            $listitemTbl = Engine_Api::_()->getItemTable('page_list_item');

            $pageSelect = $pageAlbumTable->select()
                ->setIntegrityCheck(false)
                ->from(array('albums' => $pageAlbumTable->info('name')), new Zend_Db_Expr('albums.pagealbum_id AS id, "pagealbum" AS type, albums.view_count AS view_count, albums.creation_date AS creation_date'))
                ->join(array('pages' => $pageTable->info('name')), 'pages.page_id = albums.page_id', array())
                ->joinLeft(array('auth' => $authallowTbl->info('name')), "auth.resource_type = 'page' AND auth.resource_id = albums.page_id AND auth.action = 'view'", array())
                ->joinLeft(array('li' => $listitemTbl->info('name')), 'auth.role_id = li.list_id', array())
                ->where("auth.role = 'everyone' OR (auth.role = 'registered' AND $user_id > 0) OR (li.child_id = $user_id)");
        }

        if (Engine_Api::_()->getDbTable('modules', 'core')->isModuleEnabled('pagealbum') && $pageAlbumSettings) {
            // Build two question in the query
            $union = new Zend_Db_Select($db);
            $union->union(array('(' . $select->__toString() . ')'));
            $union->union(array('(' . $pageSelect->__toString() . ')'));
            $union->group('id');

        } else {
            if($options['sort_by']!='featured'){
                // The one query
                $union = $select;
                $union->group('albums.album_id');
            }else{
                $union = $select;
            }
        }

        // Order
        if (isset($options['sort_by']) && ($options['sort_by'] == 'view_count' || $options['sort_by'] == 'comment_count')) {
            $union->order($options['sort_by'].' DESC');
        }

        if (isset($options['sort_by']) && $options['sort_by'] == 'random') {
            $union->order('RAND()');
        }

        if (isset($options['sort_by']) && $options['sort_by'] == 'recent') {
            $union->order('creation_date DESC');
        }

        if (isset($options['sort_by']) && $options['sort_by'] == 'liked') {
            $union->order('creation_date DESC');
        }

        return $union;
    }
}
