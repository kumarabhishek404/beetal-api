<?php

class Headvancedalbum_Widget_OrderBoxRecentController extends Engine_Content_Widget_Abstract
{
  public function indexAction()
  {

  }
}