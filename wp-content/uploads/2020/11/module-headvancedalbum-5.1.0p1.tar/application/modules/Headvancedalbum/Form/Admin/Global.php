<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Album
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: Global.php 9747 2012-07-26 02:08:08Z john $
 * @author     Jung
 */

/**
 * @category   Application_Extensions
 * @package    Album
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
class Headvancedalbum_Form_Admin_Global extends Engine_Form
{
    public function init()
    {

        $settings = Engine_Api::_()->getApi('settings', 'core');

        $this
            ->setTitle('Global Settings')
            ->setDescription('These settings affect all members in your community.');

        $this->addElement('Text', 'popular_albums_count', array(
            'label' => 'Popular Albums Count',
            'description' => 'How many popular albums will be shown on the widget',
            'value' => $settings->getSetting('headvancedalbum.popular.albums.count', 10)
        ));

        $this->addElement('Text', 'map_api_key', array(
            'label' => 'Enter Google Map Api Key',
            'description' => '',
            'value' => $settings->getSetting('headvancedalbum.map.api.key')
        ));

        $this->addElement('Radio', 'album_position', array(
            'label' => 'Photo view settings',
            'multiOptions' => array(
                0 => 'Pinview',
                1 => 'Grid view'
            ),
            'value' => $settings->getSetting('headvancedalbum.album.position', 1)
        ));






        // Add submit button
        $this->addElement('Button', 'submit', array(
            'label' => 'Save Changes',
            'type' => 'submit',
            'ignore' => true,
        ));
    }
}