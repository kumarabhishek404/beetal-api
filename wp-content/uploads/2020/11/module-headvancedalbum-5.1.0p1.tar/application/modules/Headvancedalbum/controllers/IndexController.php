<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Headvancedalbum
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: IndexController.php 2013-01-17 15:23:00 stanislav $
 * @author     Drujinin S
 */

/**
 * @category   Application_Extensions
 * @package    Headvancedalbum
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */
class Headvancedalbum_IndexController extends Core_Controller_Action_Standard
{
    public function indexAction()
    {
        if (!$this->_helper->requireAuth()->setAuthParams('album', null, 'view')->isValid()) return;

        $owner = null;
        if ($this->_getParam('owner')) {
            $owner = Engine_Api::_()->getItemByGuid($this->_getParam('owner'));
        }


        $this->view->paginator = $paginator = Engine_Api::_()->getDbTable('photos', 'headvancedalbum')->getPhotosPaginator(array(
            'category' => $this->_getParam('category_id', 'recent'),
            'search_photos' => $this->_getParam('search'),
            'tagged' => $this->_getParam('tagged'),
            'owner' => $owner,
            'search' => 1,
            'type' => $this->_getParam('type')
        ));

        $paginator->setItemCountPerPage(24);

        $paginator->setCurrentPageNumber($this->_getParam('page'));

        $this->view->photos = $photos = Engine_Api::_()->getDbTable('photos', 'headvancedalbum')->getPhotosByPaginator($paginator);

        $this->view->categories = Engine_Api::_()->getDbTable('albums', 'headvancedalbum')->getNonEmptyCategories();

        $this->view->photos_browse = true;

        $settings = Engine_Api::_()->getApi('settings', 'core');
        $option = $settings->getSetting('headvancedalbum.album.position');

        $this->view->settings = $option;

        $this->view->is_next = (int)(isset($paginator->getPages()->next));

        if ($this->_getParam('page') > $paginator->count()) { // the page is not exists
            $this->view->body = '';
            $this->view->is_next = 0;
            return;
        }

        if ($this->_getParam('format') == 'json') {

            $this->view->body = $this->view->render('application/modules/Headvancedalbum/views/scripts/_photoItems.tpl');

            $this->view->item_count = $paginator->getCurrentItemCount();

        } else {
            $this->_helper->content
                ->setEnabled();
        }
    }

    public function locationAction()
    {
        if (!$this->_helper->requireAuth()->setAuthParams('album', null, 'view')->isValid()) return;

        $owner = null;
        if ($this->_getParam('owner')) {
            $owner = Engine_Api::_()->getItemByGuid($this->_getParam('owner'));
        }

        $paginator = Engine_Api::_()->getDbTable('albums', 'headvancedalbum')->getAlbumPaginator(array(
            'category' => $this->_getParam('category_id', 'recent'),
            'search_albums' => $this->_getParam('location'),
            'tagged' => $this->_getParam('tagged'),
            'owner' => $owner,
            'location' => "location",
            'search' => 1,
            'type' => $this->_getParam('type'),
            'filter_search' => "album"
        ));


        $this->view->paginator = $paginator;

        $paginator->setItemCountPerPage(15);
        $paginator->setCurrentPageNumber($this->_getParam('page'));

        $this->view->albums = $photos = Engine_Api::_()->getDbTable('albums', 'headvancedalbum')->getAlbumsByPaginator($paginator);

        $this->view->categories = Engine_Api::_()->getDbTable('albums', 'headvancedalbum')->getNonEmptyCategories();

        $this->view->is_next = (int)(isset($paginator->getPages()->next));

        if ($this->_getParam('page') > $paginator->count()) { // the page is not exists
            $this->view->body = '';
            $this->view->is_next = 0;
            return;
        }

    }

    public function optionForSearch($filter_search, $owner)
    {
        $module = "headvancedalbum";
        $table = "albums";

        if ($filter_search != "") {
            if ($filter_search == "photo") {
                $table = 'photos';
            }
        }

        $method = 'getAlbumPaginator';
        $search_metod = '';
        if ($filter_search != "") {
            if ($filter_search == "all") {
                $method = 'getAlbumPaginator';
                $search_metod = 'search_albums';
            }
            if ($filter_search == "album") {
                $method = 'getAlbumPaginator';
                $search_metod = 'search_albums';
            }
            if ($filter_search == "photo") {
                $method = 'getPhotosPaginator';
                $search_metod = 'search_photos';

            }
        } else {
            $method = 'getAlbumPaginator';

        }

        $result = Engine_Api::_()->getDbTable($table, $module)->$method(array(
            'category' => $this->_getParam('category_id', 'recent'),
            $search_metod => $this->_getParam('search'),
            'tagged' => $this->_getParam('tagged'),
            'owner' => $owner,
            'search' => 1,
            'type' => $this->_getParam('type'),
            'filter_search' => $filter_search
        ));

        return $result;
    }

    public function browseAction()
    {

        
        if (!$this->_helper->requireAuth()->setAuthParams('album', null, 'view')->isValid()) return;

        $owner = null;

        if ($this->_getParam('owner')) {
            $owner = Engine_Api::_()->getItemByGuid($this->_getParam('owner'));
        }
   
        $filter_search = '';
        if ($this->_getParam('filter_search')) {
            $filter_search = $this->_getParam('filter_search');
            if ($filter_search == "album") {
                $result = $this->optionForSearch($filter_search, $owner);
                $tab = "albums";
            }

            if ($filter_search == "photo") {
                $result = $this->optionForSearch($filter_search, $owner);
                $tab = "photos";

            }

            if ($filter_search == "all") {
                $result = $this->optionForSearch($filter_search, $owner);
                $tab = "albums";
            }

        } else {
            $result = $this->optionForSearch("", $owner);
            $tab = "albums";
        }


        $paginator = $this->view->paginator = $result;

        $paginator->setItemCountPerPage(20);
        $paginator->setCurrentPageNumber($this->_getParam('page'));

        if ($filter_search) {
            if ($filter_search == "photo") {
                $this->view->photos_browse = true;
                $photos = Engine_Api::_()->getDbTable($tab, 'headvancedalbum')->getPhotosByPaginator($paginator);
                $this->view->photos = $photos;
                $this->view->categories = Engine_Api::_()->getDbTable('albums', 'headvancedalbum')->getNonEmptyCategories();
            }
            if ($filter_search == "album") {
                $this->view->albums = Engine_Api::_()->getDbTable($tab, 'headvancedalbum')->getAlbumsByPaginator($paginator);
                $this->view->categories = Engine_Api::_()->getDbTable('albums', 'headvancedalbum')->getNonEmptyCategories();
            }
            if ($filter_search == "all") {
                $this->view->albums = Engine_Api::_()->getDbTable($tab, 'headvancedalbum')->getAlbumsByPaginator($paginator);
                $this->view->categories = Engine_Api::_()->getDbTable('albums', 'headvancedalbum')->getNonEmptyCategories();
            }
        } else {
            $this->view->albums = Engine_Api::_()->getDbTable($tab, 'headvancedalbum')->getAlbumsByPaginator($paginator);
            $this->view->categories = Engine_Api::_()->getDbTable('albums', 'headvancedalbum')->getNonEmptyCategories();
        }


        $this->view->is_next = (int)(isset($paginator->getPages()->next));
        if ($this->_getParam('page') > $paginator->count()) {
            $this->view->body = '';
            $this->view->is_next = 0;
            return;
        }


        if ($this->_getParam('format') == 'json') {

            // print_arr($this->_getAllParams());

            if (!$this->_getParam('filter_search')) {
                $this->view->body = $this->view->render('application/modules/Headvancedalbum/views/scripts/_albumItems.tpl');
            } else {

                if ($filter_search == "all") {
                    $this->view->body = $this->view->render('application/modules/Headvancedalbum/views/scripts/_AllItemsForSearch.tpl');
                }

                if ($filter_search == "album") {
                    $this->view->body = $this->view->render('application/modules/Headvancedalbum/views/scripts/_albumItems.tpl');
                }

                if ($filter_search == "photo") {
                    $this->view->body = $this->view->render('application/modules/Headvancedalbum/views/scripts/_photoItemsForSearch.tpl');
                }
            }

            $this->view->item_count = $paginator->getCurrentItemCount();

        } else {
            $this->_helper->content
                ->setEnabled();
        }

    }

    public function manageAction()
    {
        $this->view->navigation = $navigation = Engine_Api::_()
            ->getApi('menus', 'core')
            ->getNavigation('headvancedalbum_main');
    }

    public function uploadAction()
    {

        $this->view->navigation = $navigation = Engine_Api::_()
            ->getApi('menus', 'core')
            ->getNavigation('headvancedalbum_main');


        if (isset($_GET['ul']) || isset($_FILES['Filedata']))
            return $this->_forward('upload-photo', null, null, array('format' => 'json'));

        if (!$this->_helper->requireAuth()->setAuthParams('album', null, 'create')->isValid()) return;
        $this->view->mapKey = Engine_Api::_()->getDbTable('settings', 'core')->getSetting('headvancedalbum.map.api.key');

        // Get form
        $this->view->form = $form = new Headvancedalbum_Form_Album();

        if (!$this->getRequest()->isPost()) {
            if (null !== ($album_id = $this->_getParam('album_id'))) {
                $form->populate(array(
                    'album' => $album_id
                ));
            }
            return;
        }
        if (!$form->isValid($this->getRequest()->getPost())) {
            return;
        }

        $db = Engine_Api::_()->getItemTable('album')->getAdapter();
        $db->beginTransaction();


        try {
            $album = $form->saveValues();

            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
        }

        $this->_helper->redirector->gotoRoute(array('album_id' => $album->album_id), 'headvancedalbum_album_photos_edit', true);

    }

    public function viewMapAction()
    {

        $location = $this->_getParam('location');


        if (isset($location)) {
            $location = $location;
        } else {
            $location = "";
        }

        $this->view->location = $location;
        $this->view->mapKey = Engine_Api::_()->getDbTable('settings', 'core')->getSetting('headvancedalbum.map.api.key');
    }

    public function editLocationAction()
    {

        if (!$this->_getParam('id_img') && !$this->_getParam('location')) {
            return;
        }
        if ($this->_getParam('location') == "") {
            return;
        }

        $id_img = $this->_getParam('id_img');

        $location = $this->_getParam('location');

        $db = Engine_Api::_()->getDbtable('photos', 'headvancedalbum')->getAdapter();
        $db->beginTransaction();

        try {
            $row = Engine_Api::_()->getDbtable('photos', 'headvancedalbum')->find($id_img)->current();
            $row->photo_id = $id_img;
            $row->location = $location;
            $row->save();
            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
        }

    }

    public function uploadPhotoAction()
    {

        if (!$this->_helper->requireAuth()->setAuthParams('album', null, 'create')->isValid()) return;

        if (!$this->_helper->requireUser()->checkRequire()) {
            $this->view->status = false;
            $this->view->error = Zend_Registry::get('Zend_Translate')->_('Max file size limit exceeded (probably).');
            return;
        }

        if (!$this->getRequest()->isPost()) {
            $this->view->status = false;
            $this->view->error = Zend_Registry::get('Zend_Translate')->_('Invalid request method');
            return;
        }

        $values = $this->getRequest()->getPost();
        if (empty($_FILES['file']['name'])) {
            $this->view->status = false;
            $this->view->error = Zend_Registry::get('Zend_Translate')->_('No file');
            return;
        }

        if (!isset($_FILES['file']) || !is_uploaded_file($_FILES['file']['tmp_name'])) {
            $this->view->status = false;
            $this->view->error = Zend_Registry::get('Zend_Translate')->_('Invalid Upload');
            return;
        }

        $db = Engine_Api::_()->getDbtable('photos', 'headvancedalbum')->getAdapter();
        $db->beginTransaction();

        try {
            $viewer = Engine_Api::_()->user()->getViewer();

            $photoTable = Engine_Api::_()->getDbtable('photos', 'headvancedalbum');
            $photo = $photoTable->createRow();
            $photo->setFromArray(array(
                'owner_type' => 'user',
                'owner_id' => $viewer->getIdentity()
            ));
            $photo->save();

            $photo->order = $photo->photo_id;
            $photo->setPhoto($_FILES['file']);
            $photo->save();

            $this->view->status = true;
            $this->view->name = $_FILES['file']['name'];
            $this->view->photo_id = $photo->photo_id;
//             $this->sendJson([
//                 'id' => $photo->photo_id,
//                 'fileName' => $_FILES['file']['name']
//             ]);
            $db->commit();
            $this->sendJson([
                'id' => $photo->photo_id,
                'fileName' => $_FILES['file']['name']
            ]);

        } catch (Album_Model_Exception $e) {
            $db->rollBack();
            $this->view->status = false;
            $this->view->error = $this->view->translate($e->getMessage());
            throw $e;
            return;

        } catch (Exception $e) {
            $db->rollBack();
            $this->view->status = false;
            $this->view->error = Zend_Registry::get('Zend_Translate')->_($e->__toString());
            throw $e;
            return;
        }
    }

    public function resizeAction()
    {
        if ($this->getRequest()->isPost()) {
            $width = $this->_getParam('width', 0);
            $sample = $this->_getParam('sample', 0);

            if (!$width || !$sample)
                return false;
        }
    }

    public function viewAction()
    {

        if (!$this->_helper->requireAuth()->setAuthParams('album', null, 'view')->isValid()) return;

        if (0 !== ($photo_id = (int)$this->_getParam('photo_id')) &&
            null !== ($photo = Engine_Api::_()->getItem('album_photo', $photo_id))
        ) {
            Engine_Api::_()->core()->setSubject($photo);
        } else if (0 !== ($album_id = (int)$this->_getParam('album_id')) &&
            null !== ($album = Engine_Api::_()->getItem('album', $album_id))
        ) {
            Engine_Api::_()->core()->setSubject($album);
        }

        $settings = Engine_Api::_()->getApi('settings', 'core');
        if (!$this->_helper->requireSubject('album')->isValid()) return;

        $this->view->album = $album = Engine_Api::_()->core()->getSubject();
        if (!$this->_helper->requireAuth()->setAuthParams($album, null, 'view')->isValid()) return;

        // Prepare params
        $this->view->page = $page = $this->_getParam('page');

        // Prepare data
        $photoTable = Engine_Api::_()->getItemTable('album_photo');
        $this->view->paginator = $paginator = $photoTable->getPhotoPaginator(array(
            'album' => $album,
        ));
        $paginator->setItemCountPerPage(6);
        $paginator->setCurrentPageNumber($page);

        $this->view->isWallAlbum = $album->getTitle() == 'Wall Photos' ? true : false;

        // Do other stuff
        $this->view->mine = true;
        $this->view->canEdit = $this->_helper->requireAuth()->setAuthParams($album, null, 'edit')->checkRequire();
        if (!$album->getOwner()->isSelf(Engine_Api::_()->user()->getViewer())) {
            $album->getTable()->update(array(
                'view_count' => new Zend_Db_Expr('view_count + 1'),
            ), array(
                'album_id = ?' => $album->getIdentity(),
            ));
            $this->view->mine = false;
        }

        $this->view->is_next = (int)(isset($paginator->getPages()->next));
        if ($this->_getParam('page') > $paginator->count()) { // the page is not exists
            $this->view->body = '';
            $this->view->is_next = 0;
            return;
        }

        $option = $settings->getSetting('headvancedalbum.album.position');

        $this->view->settings = $option;

        if ($this->_getParam('format') == 'json') {

            // render only part
            $this->view->body = $this->view->render('application/modules/Headvancedalbum/views/scripts/_photoItems.tpl');

        } else {
            // Render
            $this->_helper->content
                //->setNoRender()
                ->setEnabled();
        }


    }

    public function editphotosAction()
    {
        if (0 !== ($photo_id = (int)$this->_getParam('photo_id')) && null !== ($photo = Engine_Api::_()->getItem('album_photo', $photo_id))) {
            Engine_Api::_()->core()->setSubject($photo);
        } else if (0 !== ($album_id = (int)$this->_getParam('album_id')) && null !== ($album = Engine_Api::_()->getItem('album', $album_id))) {
            Engine_Api::_()->core()->setSubject($album);
        }

        if (!$this->_helper->requireUser()->isValid()) return;
        if (!$this->_helper->requireSubject('album')->isValid()) return;
        if (!$this->_helper->requireAuth()->setAuthParams(null, null, 'edit')->isValid()) return;

        // Get navigation
        $this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
            ->getNavigation('album_main');

        // Hack navigation
        foreach ($navigation->getPages() as $page) {
            if ($page->route != 'album_general' || $page->action != 'manage') continue;
            $page->active = true;
        }

        // Prepare data
        $this->view->album = $album = Engine_Api::_()->core()->getSubject();
        $photoTable = Engine_Api::_()->getItemTable('album_photo');
        $this->view->paginator = $paginator = $photoTable->getPhotoPaginator(array(
            'album' => $album,
        ));
        $paginator->setCurrentPageNumber($this->_getParam('page'));
        $paginator->setItemCountPerPage(12);

        // Make form
        $this->view->form = $form = new Headvancedalbum_Form_Photos_Photos();

        foreach ($paginator as $photo) {
            $subform = new Headvancedalbum_Form_Photos_EditPhoto(array('elementsBelongTo' => $photo->getGuid()));
            $subform->populate($photo->toArray());
            $form->addSubForm($subform, $photo->getGuid());
            $form->cover->addMultiOption($photo->getIdentity(), $photo->getIdentity());
        }

        if (!$this->getRequest()->isPost()) {
            return;
        }
        if (!$form->isValid($this->getRequest()->getPost())) {
            return;
        }

        $table = $album->getTable();
        $db = $table->getAdapter();
        $db->beginTransaction();

        try {
            $values = $form->getValues();
            if (!empty($values['cover'])) {
                $album->photo_id = $values['cover'];
                $album->save();
            }

            // Process
            foreach ($paginator as $photo) {
                $subform = $form->getSubForm($photo->getGuid());
                $values = $subform->getValues();

                $values = $values[$photo->getGuid()];
                unset($values['photo_id']);
                if (isset($values['delete']) && $values['delete'] == '1') {
                    $photo->delete();
                } else {
                    $photo->setFromArray($values);
                    $photo->save();
                }
            }

            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
        }

        return $this->_helper->redirector->gotoRoute(array('album_id' => $album->album_id), 'headvancedalbum_album_view', true);
    }

    public function composeUploadAction()
    {
        if (!Engine_Api::_()->user()->getViewer()->getIdentity()) {
            $this->_redirect('login');
            return;
        }

        if (!$this->getRequest()->isPost()) {
            $this->view->status = false;
            $this->view->error = Zend_Registry::get('Zend_Translate')->_('Invalid method');
            return;
        }

        if (empty($_FILES['Filedata'])) {
            $this->view->status = false;
            $this->view->error = Zend_Registry::get('Zend_Translate')->_('Invalid data');
            return;
        }

        // Get album
        $viewer = Engine_Api::_()->user()->getViewer();
        $table = Engine_Api::_()->getDbtable('albums', 'headvancedalbum');
        $db = $table->getAdapter();
        $db->beginTransaction();

        try {
            $type = $this->_getParam('type', 'wall');

            if (empty($type)) $type = 'wall';

            $album = $table->getSpecialAlbum($viewer, $type);

            $photoTable = Engine_Api::_()->getDbtable('photos', 'headvancedalbum');
            $photo = $photoTable->createRow();
            $photo->setFromArray(array(
                'owner_type' => 'user',
                'owner_id' => Engine_Api::_()->user()->getViewer()->getIdentity()
            ));
            $photo->save();
            $photo->setPhoto($_FILES['Filedata']);

            if ($type == 'message') {
                $photo->title = Zend_Registry::get('Zend_Translate')->_('Attached Image');
            }

            $photo->order = $photo->photo_id;
            $photo->album_id = $album->album_id;
            $photo->save();

            if (!$album->photo_id) {
                $album->photo_id = $photo->getIdentity();
                $album->save();
            }

            if ($type != 'message') {
                // Authorizations
                $auth = Engine_Api::_()->authorization()->context;
                $auth->setAllowed($photo, 'everyone', 'view', true);
                $auth->setAllowed($photo, 'everyone', 'comment', true);
            }

            $db->commit();

            $this->view->status = true;
            $this->view->photo_id = $photo->photo_id;
            $this->view->album_id = $album->album_id;
            $this->view->src = $photo->getPhotoUrl();
            $this->view->message = Zend_Registry::get('Zend_Translate')->_('Photo saved successfully');
        } catch (Exception $e) {
            $db->rollBack();
            //throw $e;
            print_die($e->__toString());
            $this->view->status = false;
        }
    }
}