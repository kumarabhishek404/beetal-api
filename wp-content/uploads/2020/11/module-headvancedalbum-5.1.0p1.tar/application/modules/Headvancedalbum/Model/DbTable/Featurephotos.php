<?php
class Headvancedalbum_Model_DbTable_Featurephotos extends Core_Model_Item_DbTable_Abstract
{
    protected $_rowClass = 'Headvancedalbum_Model_Featurephoto';
}