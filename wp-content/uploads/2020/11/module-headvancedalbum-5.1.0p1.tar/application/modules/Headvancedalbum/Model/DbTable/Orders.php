<?php

class Headvancedalbum_Model_DbTable_Orders extends Album_Model_DbTable_Albums
{
    protected $_rowClass = 'Headvancedalbum_Model_Album';
    protected $_name = 'album_albums';
}
