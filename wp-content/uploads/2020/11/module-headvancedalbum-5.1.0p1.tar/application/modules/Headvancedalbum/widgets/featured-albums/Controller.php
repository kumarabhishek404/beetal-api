<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Headvancedalbum
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: Controller.php 2013-01-21 16:48:00 ratbek $
 * @author     Ratbek
 */

/**
 * @category   Application_Extensions
 * @package    Headvancedalbum
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */
class Headvancedalbum_Widget_FeaturedAlbumsController extends Engine_Content_Widget_Abstract
{
    public function indexAction()
    {
        $request = Zend_Controller_Front::getInstance()->getRequest();
        $params = $request->getParams();

        $viewer = Engine_Api::_()->user()->getViewer();

        $params['featured'] = 1;
        $params['search'] = 1;

        $this->view->currentDate = $currentDate = date('Y-m-d h:i:s');
        $this->view->filter = $params['filter'];

        $settings = Engine_Api::_()->getApi('settings', 'core');
        $albums_count = $this->_getParam('itemCountPerPage') ? $this->_getParam('itemCountPerPage') : '3';
        $albums_order = $this->_getParam('recentType') ? $this->_getParam('recentType') : '';
        /////
        $he_featured = 1;
    $albumsTable = Engine_Api::_()->getDbtable('albums', 'album');
    $aName = $albumsTable->info('name');

    $featurealbumsTable = Engine_Api::_()->getDbTable('featurealbums', 'headvancedalbum');
    $fName = $featurealbumsTable->info('name');

    $query = $albumsTable->select()
            ->setIntegrityCheck(false)
            ->from($aName)
            ->join($fName, $fName . '.album_id = ' . $aName . '.album_id'
        )
    ->where($fName . " .he_featured = ?", $he_featured)
        ->order($aName.".album_id ".$albums_order)
        ;
        $this->view->paginator = $paginator = Zend_Paginator::factory($query);
        
        // Set item count per page and current page number
        $paginator->setItemCountPerPage($albums_count);
    }
}
