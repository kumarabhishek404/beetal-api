INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`)
VALUES  ('headvancedalbum', 'Advanced Photo Albums', '', '5.1.0p1', 1, 'extra');

INSERT IGNORE INTO  `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES
('album_main_photos', 'headvancedalbum', 'HEADVANCEDALBUM_Browse Photos', 'Album_Plugin_Menus::canViewAlbums', '{"route":"headvancedalbum_photos_browse", "action": "index"}', 'album_main', NULL, 1, 0, 2),
('headvancedalbum_browse', 'headvancedalbum', 'HEADVANCEDALBUM_Albums', 'Album_Plugin_Menus::canViewAlbums', '{"route":"headvancedalbum_albums_browse", "action": "browse"}', 'headvancedalbum_main', NULL, 1, 0, 1),
('headvancedalbum_photos', 'headvancedalbum', 'HEADVANCEDALBUM_Photos', 'Album_Plugin_Menus::canViewAlbums', '{"route":"headvancedalbum_photos_browse", "action": "index"}', 'headvancedalbum_main', NULL, 1, 0, 2),
('headvancedalbum_manage', 'headvancedalbum', 'HEADVANCEDALBUM_My Albums', 'Album_Plugin_Menus::canCreateAlbums', '{"route":"headvancedalbum_mine_albums", "action": "manage"}', 'headvancedalbum_main', NULL, 1, 0, 3),
('headvancedalbum_add', 'headvancedalbum', 'HEADVANCEDALBUM_Add New Photos', 'Album_Plugin_Menus::canCreateAlbums', '{"route":"headvancedalbum_add_photos", "action": "upload"}', 'headvancedalbum_main', NULL, 1, 0, 4),
('core_admin_main_plugins_headvancedalbum', 'headvancedalbum', 'HE - Advanced Photo Albums', NULL, '{"route": "admin_default", "module": "headvancedalbum", "controller": "manage"}', 'core_admin_main_plugins', NULL, 1, 0, 889),
('headvancedalbum_admin_main_manage', 'headvancedalbum', 'HEADVANCEDALBUM_Manage Albums', NULL, '{"route":"admin_default","module":"headvancedalbum","controller":"manage"}', 'headvancedalbum_admin_main', NULL, 1, 0, 1),
('headvancedalbum_admin_main_settings', 'headvancedalbum', 'HEADVANCEDALBUM_Global Settings', NULL, '{"route":"admin_default","module":"headvancedalbum","controller":"settings"}', 'headvancedalbum_admin_main', NULL, 1, 0, 2);

INSERT IGNORE INTO  `engine4_core_menus` (`name`, `type`, `title`, `order`) VALUES
('headvancedalbum_main', 'standard', 'HE Advanced Photo Albums Main Navigation Menu', 999);
