<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Album
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: EditPhoto.php 9747 2012-07-26 02:08:08Z john $
 * @author     John Boehr <j@webligo.com>
 */

/**
 * @category   Application_Extensions
 * @package    Album
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
class Headvancedalbum_Form_Photos_EditPhoto extends Engine_Form
{
    protected $_isArray = true;

    public function init()
    {
        $view = Zend_Registry::get('Zend_View');
        $this->clearDecorators()
            ->addDecorator('FormElements');

        $this->addElement('Text', 'title', array(
            'attribs' => array(
                'placeholder' => $view->translate('Title')
            ),
            'filters' => array(
                new Engine_Filter_Censor(),
                new Engine_Filter_HtmlSpecialChars(),
            ),
            'decorators' => array(
                'ViewHelper',
                array('HtmlTag', array('tag' => 'div', 'class' => 'albums_editphotos_title_input')),
            ),
        ));

        $this->addElement('Textarea', 'description', array(
            'cols' => 120,
            'attribs' => array(
                'placeholder' => $view->translate('Caption')
            ),
            'filters' => array(
                new Engine_Filter_Censor(),
            ),
            'decorators' => array(
                'ViewHelper',
                array('HtmlTag', array('tag' => 'div', 'class' => 'album_editphotos_caption_input')),
            ),
        ));

        $this->addElement('Checkbox', 'delete', array(
            'label' => "Delete photo",
            'decorators' => array(
                'ViewHelper',
                array('Label', array('placement' => 'APPEND')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'photo-delete-wrapper')),
            ),
        ));


        $this->addElement('Hidden', 'photo_id', array(
            'validators' => array(
                'Int',
            )
        ));
    }
}