<?php

class Headvancedalbum_Widget_OrderBoxViewedController extends Engine_Content_Widget_Abstract
{
  public function indexAction()
  {

  }
}