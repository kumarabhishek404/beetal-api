<?php

class Like_Model_Follow extends Core_Model_Item_Abstract
{

}
