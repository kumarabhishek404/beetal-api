<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Ravshanbek
 * Date: 03.07.12
 * Time: 10:40
 * To change this template use File | Settings | File Templates.
 */
class Like_Model_Exception extends Engine_Exception
{

}
