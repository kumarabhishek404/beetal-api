<?php

class Like_Model_DbTable_Follows extends Engine_Db_Table
{
    protected $_rowClass = 'Like_Model_Follow';

    public function getFollowTable()
    {
        return $this;
    }

    public function getFollow($user_id, $page_id){
        $table = $this->getFollowTable();
        $select = $table->select()
            ->where('user_id = ?', $user_id)
            ->where('page_id = ?', $page_id)
            ->limit(1);

        return $table->fetchRow($select);
    }

    public function removeNotActivePageIds($type, $user_id, $response = array()){

        $page_follows = $this->getFollowCore($user_id);
        foreach ($page_follows as $page_follow){
            $follows_type = json_decode($page_follow->value, true);
            $page_id = $page_follow->page_id;
            foreach ($follows_type as $key => $value){
                if($type == $key){
                    if(!$value){
                        unset($response[$page_id]);
                    }
                }
            }
        }
        return $response;
    }

    public function getFollowCore($user_id){
        $list = Engine_Api::_()->getDbTable('lists', 'page');
        $select = $this->select()
            ->setIntegrityCheck(false)
            ->from(array('item'=>$this->info('name')))
            ->join(array('list'=>$list->info('name')), 'list.title = "PAGE_LIKES"', array())
            ->where('list.owner_id = item.page_id')
            ->where('item.user_id = ?', $user_id);

        return $this->fetchAll($select);
    }

    public function createFollow($user_id, $page_id){
        $table = $this->getFollowTable();
        $settings = Engine_Api::_()->getDbTable('settings', 'core');
        $page_follows = $settings->getSetting('page.follows', array());
        if($page_follows){
            $row = $table->createRow();
            $row->user_id = $user_id;
            $row->page_id = $page_id;
            $row->value = $page_follows;
            $row->save();

            return $row;
        }
        return false;

    }

    public function setFollow($user_id, $page_follow, $page_id) {
        $follows = $this->getFollow($user_id, $page_id);
        if($follows){
            $this->update(array(
                'value' => $page_follow,
            ), array(
                'user_id = ?' => $user_id,
                'page_id = ?' => $page_id
            ));
            return true;
        }

        return false;

    }
}