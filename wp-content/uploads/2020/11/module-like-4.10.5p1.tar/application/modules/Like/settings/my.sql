INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES
('like', 'Likes', 'Likes', '4.10.5p1', 1, 'extra');
