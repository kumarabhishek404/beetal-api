<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: Donatesettings.php 16.12.16 05:40 bolot $
 * @author     Bolot
 */

/**
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Advbilling_Model_DbTable_Donatesettings extends Engine_Db_Table
{

}
