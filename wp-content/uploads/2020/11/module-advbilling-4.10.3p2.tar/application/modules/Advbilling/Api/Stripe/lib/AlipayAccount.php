<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: AlipayAccount.php 16.12.16 05:40 bolot $
 * @author     Bolot
 */

/**
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */


namespace Stripe;

/**
 * Class AlipayAccount
 *
 * @package Stripe
 */
class AlipayAccount extends ExternalAccount
{

}
