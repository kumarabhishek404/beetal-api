<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: Stripe.php 16.12.16 05:40 bolot $
 * @author     Bolot
 */

/**
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */
class Advbilling_Plugin_Gateway_Stripemain extends Engine_Payment_Plugin_Abstract
{
  protected $_gatewayInfo;
  protected $_gateway;
  // General
  /**
   * Constructor
   */
  public function __construct(Zend_Db_Table_Row_Abstract $gatewayInfo)
  {
    $this->_gatewayInfo = $gatewayInfo;
    // @todo
  }

  /**
   * Get the service API
   *
   * @return Engine_Service_PayPal
   */
  public function createRequestTransaction(Store_Model_Order $order, array $params = array())
  {

  }

  public function getService()
  {
    return $this->getGateway()->getService();
  }

  /**
   * Get the gateway object
   *
   * @return Engine_Payment_Gateway
   */
  public function getGateway()
  {

    if (null === $this->_gateway) {
      $class = 'Engine_Payment_Gateway_PayPal';
      Engine_Loader::loadClass($class);

      try {
        $gateway = new $class(array('config' => (array)$this->_gatewayInfo->config, 'testMode' => $this->_gatewayInfo->test_mode, 'currency' => Engine_Api::_()->getApi('settings', 'core')->getSetting('payment.currency', 'USD'),));
      } catch (Exception $e) {
        throw new Engine_Exception('Plugin class not instance of Engine_Payment_Gateway');
      }

      if (!($gateway instanceof Engine_Payment_Gateway)) {
        throw new Engine_Exception('Plugin class not instance of Engine_Payment_Gateway');
      }
      $this->_gateway = $gateway;
    }

    return $this->_gateway;
  }

  public function cancelOrder($transactionId)
  {
    // TODO: Implement cancelOrder() method.
  }

  public function onRequestTransactionIpn(
    Store_Model_Order $order,
    Experts_Payment_Ipn $ipn)
  {

  }

  /**
   * Generate href to a page detailing the order
   *
   * @param $orderId
   *
   * @return string
   */
  public function getOrderDetailLink($orderId)
  {
    // TODO: Implement getOrderDetailLink() method.
  }

  public function onCartTransactionReturn(Store_Model_Order $order, array $params = array())
  {

    // Check that gateways match
    if ($order->gateway_id != $this->_gatewayInfo->gateway_id) {
      throw new Experts_Payment_Plugin_Exception('Gateways do not match');
    }

    // Check that item_type match
    if ($order->item_type != 'store_cart') {
      throw new Experts_Payment_Plugin_Exception("Wrong item_type has been provided. Method requires 'store_cart'");
    }

    // Check if the cart has any items
    if (!$order->hasItems()) {
      throw new Experts_Payment_Plugin_Exception("Provided store_cart doesn't have any order items");
    }


    // Check for cancel state - the user cancelled the transaction
    if ($params['state'] == 'cancel') {
      $order->onPaymentFailure();
      // Error
      throw new Store_Model_Exception('Your payment has been cancelled and ' .
        'not been purchased. If this is not correct, please try again later.');
    }

    if ($order->ukey != $params['ukey']) {
      $order->onPaymentFailure();
      // This is a sanity error and cannot produce information a user could use
      // to correct the problem.
      throw new Store_Model_Exception('There was an error processing your ' .
        'transaction. Please try again later.');
    }


    $order->save();

    // Get payment status
    $paymentStatus = null;
    $orderStatus = null;

    switch (strtolower($params['status'])) {
      case 'created':
      case 'pending':
        $paymentStatus = 'pending';
        break;

      case 'completed':
      case 'processed':
      case 'succeeded':
      case 'canceled_reversal': // Probably doesn't apply
        $paymentStatus = 'okay';
        break;

      case 'denied':
      case 'failed':
      case 'voided': // Probably doesn't apply
      case 'reversed': // Probably doesn't apply
      case 'refunded': // Probably doesn't apply
      case 'expired': // Probably doesn't apply
      default: // No idea what's going on here
        $paymentStatus = 'failed';
        break;
    }

    /**
     * Insert transaction
     *
     * @var $transactionsTable Store_Model_DbTable_Transactions
     * */
    $transactionsTable = Engine_Api::_()->getDbtable('transactions', 'store');
    $db = $transactionsTable->getAdapter();
    $db->beginTransaction();

    try {
      $transactionsTable->insert(array(
        'item_id' => $order->item_id,
        'item_type' => $order->item_type,
        'order_id' => $order->order_id,
        'user_id' => $order->user_id,
        'timestamp' => new Zend_Db_Expr('NOW()'),
        'state' => $paymentStatus,
        'gateway_id' => $this->_gatewayInfo->gateway_id,
        'gateway_transaction_id' => $params['transaction_id'],
        'gateway_fee' => 0.00,
        'amt' => $order->total_amt,
        'currency' => $order->currency,
        'token' => $order->token
      ));

      $db->commit();
    } catch (Exception $e) {
      $db->rollBack();
      print_log($e);
      throw $e;
    }
    try {
      // Insert transaction
      $transactionsTable = Engine_Api::_()->getDbtable('transactions', 'payment');
      $transactionsTable->insert(array(
        'user_id' => $order->user_id,
        'gateway_id' => $this->_gatewayInfo->gateway_id,
        'timestamp' => new Zend_Db_Expr('NOW()'),
        'order_id' => $order->order_id,
        'type' => 'payment',
        'state' => 'okay',
        'gateway_transaction_id' => $params['transaction_id'],
        'amount' => $order->total_amt, // @todo use this or gross (-fee)?
        'currency' => $order->currency
      ));
    } catch (Exception $e) {
      print_log($e);
      throw $e;
    }

    $user = $order->getUser();

    // Check payment status
    if ($paymentStatus == 'okay') {
      try {
        // Payment success
        $order->onPaymentSuccess();

        // send notification
        if ($order->didStatusChange()) {
          try {
            Engine_Api::_()->getApi('mail', 'core')->sendSystem($user, 'store_cart_complete', array(
              'order_details' => $order->getDetails(),
              'order_link' => 'http://' . $_SERVER['HTTP_HOST'] .
                Zend_Controller_Front::getInstance()->getRouter()->assemble(array(), 'user_login', true),
            ));
          } catch (Exception $e) {
            print_log($e, 'mail');
          }
        }
        $order->gateway_transaction_id = $params['transaction_id'];
        $order->save();
      } catch (Exception $e) {
        print_die('filed ' . $e);
      }

      return $order->status;
    } else if ($paymentStatus == 'pending') {

      // Payment pending
      $order->onPaymentPending();

      // send notification
      if ($order->didStatusChange()) {
        try {
          Engine_Api::_()->getApi('mail', 'core')->sendSystem($user, 'store_cart_pending', array(
            'order_details' => $order->getDetails(),
            'order_link' => 'http://' . $_SERVER['HTTP_HOST'] .
              Zend_Controller_Front::getInstance()->getRouter()->assemble(array(), 'user_login', true),
          ));
        } catch (Exception $e) {
          print_log($e, 'mail');
        }
      }

      return $order->status;
    } else if ($paymentStatus == 'failed') {

      // Payment failed
      $order->onPaymentFailure();

      throw new Store_Model_Exception('Your payment could not be ' .
        'completed. Please ensure there are sufficient available funds ' .
        'in your account.');
    } else {
      // This is a sanity error and cannot produce information a user could use
      // to correct the problem.
      throw new Store_Model_Exception('There was an error processing your ' .
        'transaction. Please try again later.');
    }
  }

  public function onRequestTransactionReturn(Store_Model_Order $order, array $params = array())
  {

  }

  public function onCartTransactionIpn(Store_Model_Order $order, Experts_Payment_Ipn $ipn)
  {

    return $this;
  }

  public function getGatewayForm()
  {
    return new Advbilling_Form_Admin_Stripe();
  }
  // Actions

  /**
   * Create a transaction object from specified parameters
   *
   * @return Engine_Payment_Transaction
   */
  public function createTransaction(array $params)
  {
    $transaction = new Engine_Payment_Transaction($params);
    $transaction->process($this->getGateway());
    return $transaction;
  }
  public function createOfferTransaction(User_Model_User $user,
                                         Zend_Db_Table_Row_Abstract $subscription,
                                         Offers_Model_Offer $offer,
                                         array $params = array()){
    $session = new Zend_Session_Namespace('Offer_Subscription');
    $session->return_url = $params['return_url'];
    $session->cancel_url = $params['cancel_url'];
    $session->offers_id = $offer->getIdentity();
    $h = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
    $h->gotoRoute(array('action' => 'offers','order_id' => $params['vendor_order_id'],'offer_id' => $offer->getIdentity(),'subscrition' => 1,'type' => 'offer','gateway_id' => 555), 'advbilling_transaction', true);
    return;

  }
  public function createAdsTransaction( Socialads_Model_Ad $ad, array $params = array()){

    $session = new Zend_Session_Namespace('Socialads_Transaction');
    $session->return_url = $params['return_url'];
    $session->cancel_url = $params['cancel_url'];
    $session->ad_id = $ad->getIdentity();
    $h = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
    $h->gotoRoute(array('action' => 'ads','order_id' => $params['vendor_order_id'],'ad_id' => $ad->getIdentity(),'subscrition' => 1,'type' => 'ads','gateway_id' => 555), 'advbilling_transaction', true);
    return;

  }
  public function createGiftsTransaction( Hegift_Model_Gift $gift, array $params = array()){
    $session = new Zend_Session_Namespace('Hegift_Transaction');
    $session->return_url = $params['return_url'];
    $session->cancel_url = $params['cancel_url'];
    $session->gift_id = $gift->getIdentity();
    $h = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
    $h->gotoRoute(array('action' => 'gifts','order_id' => $params['vendor_order_id'],'gift_id' => $gift->getIdentity(),'subscrition' => 1,'type' => 'gifts','gateway_id' => 555), 'advbilling_transaction', true);
    return;
  }
  public function createHeeventTransaction( User_Model_User $user,
                                            Zend_Db_Table_Row_Abstract $subscription,
                                            Event_Model_Event $event,
                                            array $params = array()){

    $session = new Zend_Session_Namespace('Event_Subscription');
    $session->return_url = $params['return_url'];
    $session->cancel_url = $params['cancel_url'];
    $session->event_id = $event->getIdentity();
    $h = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
    $h->gotoRoute(array('action' => 'events','order_id' => $params['vendor_order_id'],'event_id' => $event->getIdentity(),'subscription_id' => $subscription->getIdentity(),'subscrition' => 1,'type' => 'events','gateway_id' => 555), 'advbilling_transaction', true);
    return;

  }
  public function onEventTransactionReturn(Heevent_Model_Order $order, array $params = array())
  {
    // Check that gateways match
    if( $order->gateway_id != $this->_gatewayInfo->gateway_id ) {
      throw new Engine_Payment_Plugin_Exception('Gateways do not match');
    }

    // Get related info
    $user = $order->getUser();
    $subscription = $order->getSource();
    $event = $subscription->getEvent();

    // Check subscription state
    if( $subscription->status == 'active' ||
      $subscription->status == 'trial') {
      return 'active';
    } else if( $subscription->status == 'pending' ) {
      return 'pending';
    }

    // Check for cancel state - the user cancelled the transaction
    if( $params['state'] == 'cancel' ) {
      // Cancel order and subscription?
      $order->onCancel();
      $subscription->onPaymentFailure();
      // Error
      throw new Payment_Model_Exception('Your payment has been cancelled and ' .
        'not been charged. If this is not correct, please try again later.');
    }
    // Check for cancel state - the user cancelled the transaction
    $orderStatus = 'failed';
    $paymentStatus = 'failed';

    if( $params['state'] == 'succeeded' ) {
      $orderStatus = 'complete';
      $paymentStatus = 'okay';
    }







    // Update order with profile info and complete status?
    $order->state = $orderStatus;
    $order->gateway_transaction_id = $params['transaction_id'];
    $order->save();


    // Insert transaction
    $transactionsTable = Engine_Api::_()->getDbtable('transactions', 'heevent');
    $transactionsTable->insert(array(
      'user_id' => $order->user_id,
      'gateway_id' => 555,
      'timestamp' => new Zend_Db_Expr('NOW()'),
      'order_id' => $order->order_id,
      'type' => 'payment',
      'state' => $paymentStatus,
      'gateway_transaction_id' => $params['transaction_id'],
      'amount' => $params['amount'], // @todo use this or gross (-fee)?
      'currency' => $params['currency'],
    ));
    $cardTable = Engine_Api::_()->getDbtable('cards', 'heevent');
    for($i=1;$i<=$subscription->quantity; $i++){
      $cardTable->insert(array(
        'user_id' => $order->user_id,
        'order_id' => $order->order_id,
        'ticked_code' =>  $event->getCardCode($event->getIdentity()),
        'event_id' => $event->getIdentity(),
        'state' => $paymentStatus,
      ));
    }


    // Get benefit setting
    $giveBenefit = Engine_Api::_()->getDbtable('transactions', 'payment')
      ->getBenefitStatus($user);

    // Check payment status
    if( $paymentStatus == 'okay' ||
      ($paymentStatus == 'pending' && $giveBenefit) ) {

      // Update subscription info
      $subscription->gateway_id = 555;
      $subscription->gateway_profile_id = $params['transaction_id'];

      // Payment success
      $subscription->onPaymentSuccess();

      // send notification
      if( $subscription->didStatusChange() ) {
        Engine_Api::_()->getApi('mail', 'core')->sendSystem($user, 'heevent_subscription_active', array(
          'subscription_title' => $event->title,
          'subscription_description' => $event->description,
          'subscription_terms' => $event->getEventDescription('active'),
          'object_link' => 'http://' . $_SERVER['HTTP_HOST'] .
            Zend_Controller_Front::getInstance()->getRouter()->assemble(array(), 'user_login', true),
        ));
      }

      return 'active';
    }
    else if( $paymentStatus == 'pending' ) {

      // Update subscription info
      $subscription->gateway_id = $this->_gatewayInfo->gateway_id;
      $subscription->gateway_profile_id = $params['transaction_id'];

      // Payment pending
      $subscription->onPaymentPending();

      // send notification
      if( $subscription->didStatusChange() ) {
        Engine_Api::_()->getApi('mail', 'core')->sendSystem($user, 'heevent_subscription_pending', array(
          'subscription_title' => $event->title,
          'subscription_description' => $event->description,
          'subscription_terms' => $event->getEventDescription(),
          'object_link' => 'http://' . $_SERVER['HTTP_HOST'] .
            Zend_Controller_Front::getInstance()->getRouter()->assemble(array(), 'user_login', true),
        ));
      }

      return 'pending';
    }
    else if( $paymentStatus == 'failed' ) {
      // Cancel order and subscription?
      $order->onFailure();
      $subscription->onPaymentFailure();
      // Payment failed
      throw new Payment_Model_Exception('Your payment could not be ' .
        'completed. Please ensure there are sufficient available funds ' .
        'in your account.');
    }
    else {
      // This is a sanity error and cannot produce information a user could use
      // to correct the problem.
      throw new Payment_Model_Exception('There was an error processing your ' .
        'transaction. Please try again later.');
    }
  }
  public function onOfferTransactionReturn(Offers_Model_Order $order, array $params = array())
  {
    // Check that gateways match
    if( $order->gateway_id != $this->_gatewayInfo->gateway_id ) {
      throw new Engine_Payment_Plugin_Exception('Gateways do not match');
    }

    // Get related info
    $user = $order->getUser();
    $subscription = $order->getSource();
    $offer = $subscription->getOffer();

    // Check subscription state
    if( $subscription->status == 'active' ||
      $subscription->status == 'trial') {
      return 'active';
    } else if( $subscription->status == 'pending' ) {
      return 'pending';
    }

    // Check for cancel state - the user cancelled the transaction
    if( $params['state'] == 'cancel' ) {
      // Cancel order and subscription?
      $order->onCancel();
      $subscription->onPaymentFailure();
      // Error
      throw new Payment_Model_Exception('Your payment has been cancelled and ' .
        'not been charged. If this is not correct, please try again later.');
    }





    // Update order with profile info and complete status?
    $order->state =  'complete';
    $order->gateway_transaction_id = $params['transaction_id'];
    $paymentStatus = 'okay';
    $order->save();

    // Insert transaction
    $transactionsTable = Engine_Api::_()->getDbtable('transactions', 'offers');

    $transactionsTable->insert(array(
      'user_id' => $order->user_id,
      'gateway_id' => $this->_gatewayInfo->gateway_id,
      'timestamp' => new Zend_Db_Expr('NOW()'),
      'order_id' => $order->order_id,
      'type' => 'payment',
      'state' => $paymentStatus,
      'gateway_transaction_id' => $params['transaction_id'],
      'amount' => $params['amount'], // @todo use this or gross (-fee)?
      'currency' => $params['currency'],
    ));

    // Get benefit setting
    $giveBenefit = Engine_Api::_()->getDbtable('transactions', 'payment')
      ->getBenefitStatus($user);

    // Check payment status
    if( $paymentStatus == 'okay' ||
      ($paymentStatus == 'pending') ) {

      // Update subscription info
      $subscription->gateway_id = $this->_gatewayInfo->gateway_id;
      $subscription->gateway_profile_id = $params['transaction_id'];

      // Payment success
      $subscription->onPaymentSuccess();

      // send notification
      if( $subscription->didStatusChange() ) {
        Engine_Api::_()->getApi('mail', 'core')->sendSystem($user, 'offers_subscription_active', array(
          'subscription_title' => $offer->title,
          'subscription_description' => $offer->description,
          'subscription_terms' => $offer->getOfferDescription('active'),
          'object_link' => 'http://' . $_SERVER['HTTP_HOST'] .
            Zend_Controller_Front::getInstance()->getRouter()->assemble(array(), 'user_login', true),
        ));
      }

      return 'active';
    }
    else if( $paymentStatus == 'pending' ) {

      // Update subscription info
      $subscription->gateway_id = $this->_gatewayInfo->gateway_id;
      $subscription->gateway_profile_id = $params['transaction_id'];

      // Payment pending
      $subscription->onPaymentPending();

      // send notification
      if( $subscription->didStatusChange() ) {
        Engine_Api::_()->getApi('mail', 'core')->sendSystem($user, 'offers_subscription_pending', array(
          'subscription_title' => $offer->title,
          'subscription_description' => $offer->description,
          'subscription_terms' => $offer->getOfferDescription(),
          'object_link' => 'http://' . $_SERVER['HTTP_HOST'] .
            Zend_Controller_Front::getInstance()->getRouter()->assemble(array(), 'user_login', true),
        ));
      }

      return 'pending';
    }
    else if( $paymentStatus == 'failed' ) {
      // Cancel order and subscription?
      $order->onFailure();
      $subscription->onPaymentFailure();
      // Payment failed
      throw new Payment_Model_Exception('Your payment could not be ' .
        'completed. Please ensure there are sufficient available funds ' .
        'in your account.');
    }
    else {
      // This is a sanity error and cannot produce information a user could use
      // to correct the problem.
      throw new Payment_Model_Exception('There was an error processing your ' .
        'transaction. Please try again later.');
    }
  }

  public function onAdsTransactionReturn(Payment_Model_Order $order, array $params = array())
  {
    // Check that gateways match
    if( $order->gateway_id != $this->_gatewayInfo->gateway_id ) {
      throw new Engine_Payment_Plugin_Exception('Gateways do not match');
    }

    // Get related info
    $user = $order->getUser();
    $ad = $order->getSource();

    // Check for cancel state - the user cancelled the transaction
    if( $params['state'] == 'cancel' ) {
      // Cancel order and subscription?
      $order->onCancel();
      //$ad->onPaymentFailure();
      // Error
        return 'cancel';

      throw new Payment_Model_Exception('Your payment has been cancelled and ' .
        'not been charged. If this is not correct, please try again later.');
    }

    // Update order with profile info and complete status?
    $order->state =  'complete';
    $order->gateway_transaction_id = $params['transaction_id'];
    $paymentStatus = 'okay';
    $order->save();

    // Insert transaction
    $transactionsTable = Engine_Api::_()->getDbtable('transactions', 'payment');

    $transactionsTable->insert(array(
      'user_id' => $order->user_id,
      'gateway_id' => $this->_gatewayInfo->gateway_id,
      'timestamp' => new Zend_Db_Expr('NOW()'),
      'order_id' => $order->order_id,
      'type' => 'payment',
      'state' => $paymentStatus,
      'gateway_transaction_id' => $params['transaction_id'],
      'amount' => $params['amount'], // @todo use this or gross (-fee)?
      'currency' => $params['currency'],
    ));

    // Get benefit setting
    $giveBenefit = Engine_Api::_()->getDbtable('transactions', 'payment')
      ->getBenefitStatus($user);

    // Check payment status
    if( $paymentStatus == 'okay' ||
      ($paymentStatus == 'pending') ) {

        if( $paymentStatus == 'pending' ) {

            // Update subscription info
            /*$ad->gateway_id = $this->_gatewayInfo->gateway_id;
            $ad->gateway_profile_id = $params['transaction_id'];*/

            // Payment pending
            // $ad->onPaymentPending();

            // send notification
            /* if( $subscription->didStatusChange() ) {
               Engine_Api::_()->getApi('mail', 'core')->sendSystem($user, 'offers_subscription_pending', array(
                 'subscription_title' => $offer->title,
                 'subscription_description' => $offer->description,
                 'subscription_terms' => $offer->getOfferDescription(),
                 'object_link' => 'http://' . $_SERVER['HTTP_HOST'] .
                   Zend_Controller_Front::getInstance()->getRouter()->assemble(array(), 'user_login', true),
               ));
             }*/

            return 'pending';
        }else {

            // Update subscription info
            //$ad->gateway_id = $this->_gatewayInfo->gateway_id;
            //$ad->gateway_profile_id = $params['transaction_id'];

            // Payment success
            //$ad->onPaymentSuccess();

            // send notification
            /*if( $subscription->didStatusChange() ) {
              Engine_Api::_()->getApi('mail', 'core')->sendSystem($user, 'offers_subscription_active', array(
                'subscription_title' => $offer->title,
                'subscription_description' => $offer->description,
                'subscription_terms' => $offer->getOfferDescription('active'),
                'object_link' => 'http://' . $_SERVER['HTTP_HOST'] .
                  Zend_Controller_Front::getInstance()->getRouter()->assemble(array(), 'user_login', true),
              ));
            }*/
        }

        $session = new Zend_Session_Namespace('Socialads_Transaction');
        $session->amount = $params['amount'];
      return 'active';
    }
    else if( $paymentStatus == 'failed' ) {
      // Cancel order and subscription?
      $order->onFailure();
      //$ad->onPaymentFailure();
      // Payment failed
      throw new Payment_Model_Exception('Your payment could not be ' .
        'completed. Please ensure there are sufficient available funds ' .
        'in your account.');
    }
    else {
      // This is a sanity error and cannot produce information a user could use
      // to correct the problem.
      throw new Payment_Model_Exception('There was an error processing your ' .
        'transaction. Please try again later.');
    }
  }

  public function onGiftsTransactionReturn(Payment_Model_Order $order, array $params = array())
  {
    // Check that gateways match
    if( $order->gateway_id != $this->_gatewayInfo->gateway_id ) {
      throw new Engine_Payment_Plugin_Exception('Gateways do not match');
    }

    // Get related info
    $user = $order->getUser();
    $gift = $order->getSource();

    // Check for cancel state - the user cancelled the transaction
    if( $params['state'] == 'cancel' ) {
      // Cancel order and subscription?
      $order->onCancel();
      //$ad->onPaymentFailure();
      // Error
      return 'cancel';

      throw new Payment_Model_Exception('Your payment has been cancelled and ' .
        'not been charged. If this is not correct, please try again later.');
    }

    // Update order with profile info and complete status?
    $order->state =  'complete';
    $order->gateway_transaction_id = $params['transaction_id'];
    $paymentStatus = 'okay';
    $order->save();

    // Insert transaction
    $transactionsTable = Engine_Api::_()->getDbtable('transactions', 'payment');

    $transactionsTable->insert(array(
      'user_id' => $order->user_id,
      'gateway_id' => $this->_gatewayInfo->gateway_id,
      'timestamp' => new Zend_Db_Expr('NOW()'),
      'order_id' => $order->order_id,
      'type' => 'payment',
      'state' => $paymentStatus,
      'gateway_transaction_id' => $params['transaction_id'],
      'amount' => $params['amount'], // @todo use this or gross (-fee)?
      'currency' => $params['currency'],
    ));

    $transactionsGiftsTable = Engine_Api::_()->getDbtable('transactions', 'hegift');
    $transactionsGiftsTable->insert(array(
      'user_id' => $order->user_id,
      'name' => $user->username,
      'email' => $user->email,
      'gateway_id' => $this->_gatewayInfo->gateway_id,
      'creation_date' => new Zend_Db_Expr('NOW()'),
      'order_id' => $order->order_id,
      'item_id' => $gift->gift_id,
      'item_type' => $gift->type,
      'state' => $paymentStatus,
      'gateway_transaction_id' => $params['transaction_id'],
      'amount' => $params['amount'], // @todo use this or gross (-fee)?
      'currency' => $params['currency'],
    ));

    // Get benefit setting
    $giveBenefit = Engine_Api::_()->getDbtable('transactions', 'payment')
      ->getBenefitStatus($user);

    // Check payment status
    if( $paymentStatus == 'okay' ||
      ($paymentStatus == 'pending') ) {

      if( $paymentStatus == 'pending' ) {

        // Update subscription info
        /*$gift->gateway_id = $this->_gatewayInfo->gateway_id;
        $gift->gateway_profile_id = $params['transaction_id'];*/

        // Payment pending
        // $gift->onPaymentPending();

        // send notification
        /* if( $subscription->didStatusChange() ) {
           Engine_Api::_()->getApi('mail', 'core')->sendSystem($user, 'offers_subscription_pending', array(
             'subscription_title' => $offer->title,
             'subscription_description' => $offer->description,
             'subscription_terms' => $offer->getOfferDescription(),
             'object_link' => 'http://' . $_SERVER['HTTP_HOST'] .
               Zend_Controller_Front::getInstance()->getRouter()->assemble(array(), 'user_login', true),
           ));
         }*/

        return 'pending';
      }else {

        // Update subscription info
        //$gift->gateway_id = $this->_gatewayInfo->gateway_id;
        //$gift->gateway_profile_id = $params['transaction_id'];

        // Payment success
        //$gift->onPaymentSuccess();

        // send notification
        /*if( $subscription->didStatusChange() ) {
          Engine_Api::_()->getApi('mail', 'core')->sendSystem($user, 'offers_subscription_active', array(
            'subscription_title' => $offer->title,
            'subscription_description' => $offer->description,
            'subscription_terms' => $offer->getOfferDescription('active'),
            'object_link' => 'http://' . $_SERVER['HTTP_HOST'] .
              Zend_Controller_Front::getInstance()->getRouter()->assemble(array(), 'user_login', true),
          ));
        }*/
      }

      $session = new Zend_Session_Namespace('Hegifts_Transaction');
      $session->amount = $params['amount'];
      return 'active';
    }
    else if( $paymentStatus == 'failed' ) {
      // Cancel order and subscription?
      $order->onFailure();
      //$gift->onPaymentFailure();
      // Payment failed
      throw new Payment_Model_Exception('Your payment could not be ' .
        'completed. Please ensure there are sufficient available funds ' .
        'in your account.');
    }
    else {
      // This is a sanity error and cannot produce information a user could use
      // to correct the problem.
      throw new Payment_Model_Exception('There was an error processing your ' .
        'transaction. Please try again later.');
    }
  }

  /**
   * Process ipn of subscription transaction
   *
   * @param Offers_Model_Order $order
   * @param Engine_Payment_Ipn $ipn
   */
  public function onOfferTransactionIpn(
    Offers_Model_Order $order,
    Engine_Payment_Ipn $ipn)
  {
    // Check that gateways match
    if( $order->gateway_id != $this->_gatewayInfo->gateway_id ) {
      throw new Engine_Payment_Plugin_Exception('Gateways do not match');
    }

    // Get related info
    $user = $order->getUser();
    $subscription = $order->getSource();
    $offer = $subscription->getOffer();

    // Get IPN data
    $rawData = $ipn->getRawData();

    // Chargeback --------------------------------------------------------------
    if( !empty($rawData['case_type']) && $rawData['case_type'] == 'chargeback' ) {
      $subscription->onPaymentFailure(); // or should we use pending?
    }

    // Transaction Type --------------------------------------------------------
    else if( !empty($rawData['txn_type']) ) {
      switch( $rawData['txn_type'] ) {

        // @todo see if the following types need to be processed:
        // — adjustment express_checkout new_case

        case 'express_checkout':
          switch( $rawData['payment_status'] ) {

            case 'Created': // Not sure about this one
            case 'Pending':
              // @todo this might be redundant
              // Get benefit setting
              $giveBenefit = Engine_Api::_()->getDbtable('transactions', 'payment')->getBenefitStatus($user);
              if( $giveBenefit ) {
                $subscription->onPaymentSuccess();
              } else {
                $subscription->onPaymentPending();
              }
              break;

            case 'Completed':
            case 'Processed':
            case 'Canceled_Reversal': // Not sure about this one
              $subscription->onPaymentSuccess();
              // send notification
              if( $subscription->didStatusChange() ) {
                Engine_Api::_()->getApi('mail', 'core')->sendSystem($user, 'offers_subscription_active', array(
                  'subscription_title' => $offer->title,
                  'subscription_description' => $offer->description,
                  'subscription_terms' => $offer->getOfferDescription('active'),
                  'object_link' => 'http://' . $_SERVER['HTTP_HOST'] .
                    Zend_Controller_Front::getInstance()->getRouter()->assemble(array(), 'user_login', true),
                ));
              }
              break;

            case 'Denied':
            case 'Failed':
            case 'Voided':
            case 'Reversed':
              $subscription->onPaymentFailure();
              // send notification
              if( $subscription->didStatusChange() ) {
                Engine_Api::_()->getApi('mail', 'core')->sendSystem($user, 'offers_subscription_overdue', array(
                  'subscription_title' => $offer->title,
                  'subscription_description' => $offer->description,
                  'subscription_terms' => $offer->getOfferDescription(),
                  'object_link' => 'http://' . $_SERVER['HTTP_HOST'] .
                    Zend_Controller_Front::getInstance()->getRouter()->assemble(array(), 'user_login', true),
                ));
              }
              break;

            case 'Refunded':
              $subscription->onRefund();
              // send notification
              if( $subscription->didStatusChange() ) {
                Engine_Api::_()->getApi('mail', 'core')->sendSystem($user, 'offers_subscription_refunded', array(
                  'subscription_title' => $offer->title,
                  'subscription_description' => $offer->description,
                  'subscription_terms' => $offer->getOfferDescription(),
                  'object_link' => 'http://' . $_SERVER['HTTP_HOST'] .
                    Zend_Controller_Front::getInstance()->getRouter()->assemble(array(), 'user_login', true),
                ));
              }
              break;

            case 'Expired': // Not sure about this one
              $subscription->onExpiration();
              // send notification
              if( $subscription->didStatusChange() ) {
                Engine_Api::_()->getApi('mail', 'core')->sendSystem($user, 'offers_subscription_expired', array(
                  'subscription_title' => $offer->title,
                  'subscription_description' => $offer->description,
                  'subscription_terms' => $offer->getOfferDescription(),
                  'object_link' => 'http://' . $_SERVER['HTTP_HOST'] .
                    Zend_Controller_Front::getInstance()->getRouter()->assemble(array(), 'user_login', true),
                ));
              }
              break;

            default:
              throw new Engine_Payment_Plugin_Exception(sprintf('Unknown IPN ' .
                'payment status %1$s', $rawData['payment_status']));
              break;
          }
          break;

        // What is this?
        default:
          throw new Engine_Payment_Plugin_Exception(sprintf('Unknown IPN ' .
            'type %1$s', $rawData['txn_type']));
          break;
      }
    }

    // Payment Status ----------------------------------------------------------
    else if( !empty($rawData['payment_status']) ) {
      switch( $rawData['payment_status'] ) {

        case 'Created': // Not sure about this one
        case 'Pending':
          // Get benefit setting
          $giveBenefit = Engine_Api::_()->getDbtable('transactions', 'payment')->getBenefitStatus($user);
          if( $giveBenefit ) {
            $subscription->onPaymentSuccess();
          } else {
            $subscription->onPaymentPending();
          }
          break;

        case 'Completed':
        case 'Processed':
        case 'Canceled_Reversal': // Not sure about this one
          $subscription->onPaymentSuccess();
          // send notification
          if( $subscription->didStatusChange() ) {
            Engine_Api::_()->getApi('mail', 'core')->sendSystem($user, 'offers_subscription_active', array(
              'subscription_title' => $offer->title,
              'subscription_description' => $offer->description,
              'subscription_terms' => $offer->getOfferDescription('active'),
              'object_link' => 'http://' . $_SERVER['HTTP_HOST'] .
                Zend_Controller_Front::getInstance()->getRouter()->assemble(array(), 'user_login', true),
            ));
          }
          break;

        case 'Denied':
        case 'Failed':
        case 'Voided':
        case 'Reversed':
          $subscription->onPaymentFailure();
          // send notification
          if( $subscription->didStatusChange() ) {
            Engine_Api::_()->getApi('mail', 'core')->sendSystem($user, 'offers_subscription_overdue', array(
              'subscription_title' => $offer->title,
              'subscription_description' => $offer->description,
              'subscription_terms' => $offer->getOfferDescription(),
              'object_link' => 'http://' . $_SERVER['HTTP_HOST'] .
                Zend_Controller_Front::getInstance()->getRouter()->assemble(array(), 'user_login', true),
            ));
          }
          break;

        case 'Refunded':
          $subscription->onRefund();
          // send notification
          if( $subscription->didStatusChange() ) {
            Engine_Api::_()->getApi('mail', 'core')->sendSystem($user, 'offers_subscription_refunded', array(
              'subscription_title' => $offer->title,
              'subscription_description' => $offer->description,
              'subscription_terms' => $offer->getOfferDescription(),
              'object_link' => 'http://' . $_SERVER['HTTP_HOST'] .
                Zend_Controller_Front::getInstance()->getRouter()->assemble(array(), 'user_login', true),
            ));
          }
          break;

        case 'Expired': // Not sure about this one
          $subscription->onExpiration();
          // send notification
          if( $subscription->didStatusChange() ) {
            Engine_Api::_()->getApi('mail', 'core')->sendSystem($user, 'offers_subscription_expired', array(
              'subscription_title' => $offer->title,
              'subscription_description' => $offer->description,
              'subscription_terms' => $offer->getOfferDescription(),
              'object_link' => 'http://' . $_SERVER['HTTP_HOST'] .
                Zend_Controller_Front::getInstance()->getRouter()->assemble(array(), 'user_login', true),
            ));
          }
          break;

        default:
          throw new Engine_Payment_Plugin_Exception(sprintf('Unknown IPN ' .
            'payment status %1$s', $rawData['payment_status']));
          break;
      }
    }

    // Unknown -----------------------------------------------------------------
    else {
      throw new Engine_Payment_Plugin_Exception(sprintf('Unknown IPN ' .
        'data structure'));
    }

    return $this;
  }
  // SEv4 Specific

  /**
   * Process return of subscription transaction
   *
   * @param Payment_Model_Order $order
   * @param array $params
   */
  public function onSubscriptionTransactionReturn(Payment_Model_Order $order, array $params = array())
  {

    // Check that gateways match
    if ($order->gateway_id != $this->_gatewayInfo->gateway_id) {
      throw new Engine_Payment_Plugin_Exception('Gateways do not match');
    }

    // Get related info
    $user = $order->getUser();
    $subscription = $order->getSource();
    $package = $subscription->getPackage();

    // Check subscription state
    if ($subscription->status == 'active' || $subscription->status == 'trial') {
      return 'active';
    } else if ($subscription->status == 'pending') {
      return 'pending';
    }
    // Update order with profile info and complete status?
    $order->state = 'complete';
    $order->gateway_transaction_id = $params['transaction_id'];
    $order->save();

    // Insert transaction
    $transactionsTable = Engine_Api::_()->getDbtable('transactions', 'payment');
    $transactionsTable->insert(array(
      'user_id' => $order->user_id,
      'gateway_id' => $this->_gatewayInfo->gateway_id,
      'timestamp' => new Zend_Db_Expr('NOW()'),
      'order_id' => $order->order_id,
      'type' => 'payment',
      'state' => 'okay',
      'gateway_transaction_id' => $params['transaction_id'],
      'amount' => $params['amount'], // @todo use this or gross (-fee)?
      'currency' => $params['currency']));

    // Get benefit setting
    $giveBenefit = Engine_Api::_()->getDbtable('transactions', 'payment')->getBenefitStatus($user);

    //YN - Random a code
    $sid = 'abcdefghiklmnopqstvxuyz0123456789ABCDEFGHIKLMNOPQSTVXUYZ';
    $max = strlen($sid) - 1;
    $rCode = "";
    for ($i = 0; $i < 16; ++$i) {
      $rCode .= $sid[mt_rand(0, $max)];
    }

    // Update subscription info
    $subscription->gateway_id = $this->_gatewayInfo->gateway_id;
    $subscription->gateway_profile_id = ($params['transaction_id']) ? $params['transaction_id'] : $rCode;

    $subscription->payment_date = date('Y-m-d H:i:s');
    // Payment success
    $subscription->onPaymentSuccess();

    // send notification
    if ($subscription->didStatusChange()) {
      Engine_Api::_()->getApi('mail', 'core')->sendSystem($user, 'payment_subscription_active', array('subscription_title' => $package->title, 'subscription_description' => $package->description, 'subscription_terms' => $package->getPackageDescription(), 'object_link' => 'http://' . $_SERVER['HTTP_HOST'] . Zend_Controller_Front::getInstance()->getRouter()->assemble(array(), 'user_login', true),));
    }
    return 'active';
  }


  /**
   * Cancel a subscription (i.e. disable the recurring payment profile)
   *
   * @params $transactionId
   * @return Engine_Payment_Plugin_Abstract
   */
  public function cancelSubscription($transactionId, $note = null)
  {
    $profileId = null;

    if ($transactionId instanceof Payment_Model_Subscription) {
      $package = $transactionId->getPackage();
      if ($package->isOneTime()) {
        return $this;
      }
      $profileId = $transactionId->gateway_profile_id;
    } else if (is_string($transactionId)) {
      $profileId = $transactionId;
    } else {
      // Should we throw?
      return $this;
    }

    try {
      $r = $this->getService()->cancelRecurringPaymentsProfile($profileId, $note);
    } catch (Exception $e) {
      // throw?
    }

    return $this;
  }


  /**
   * Generate href to a page detailing the transaction
   *
   * @param string $transactionId
   * @return string
   */
  public function getTransactionDetailLink($transactionId)
  {
    // @todo make sure this is correct
    if ($this->getGateway()->getTestMode()) {
      // Note: it doesn't work in test mode
      return 'https://dashboard.stripe.com/test/payments/' . $transactionId;
    } else {
      return 'https://dashboard.stripe.com/payments/' . $transactionId;
    }
  }

  /**
   * Get raw data about an order or recurring payment profile
   *
   * @param string $orderId
   * @return array
   */
  public function getOrderDetails($orderId)
  {

    try {
      return $this->getTransactionDetails($orderId);
    } catch (Exception $e) {
      echo $e;
    }

    return false;
  }

  /**
   * Get raw data about a transaction
   *
   * @param $transactionId
   * @return array
   */
  public function getTransactionDetails($transactionId)
  {
    return $this->getService()->detailTransaction($transactionId);
  }
  // Forms

  /**
   * Get the admin form for editing the gateway info
   *
   * @return Engine_Form
   */
  public function getAdminGatewayForm()
  {
    return new Advbilling_Form_Admin_Stripe();
  }

  public function processAdminGatewayForm(array $values)
  {
    return $values;
  }

  public function createSubscriptionTransaction(User_Model_User $user,
                                                Zend_Db_Table_Row_Abstract $subscription,
                                                Payment_Model_Package $package,
                                                array $params = array())
  {
    $session = new Zend_Session_Namespace('Payment_Subscription');
    $session->return_url = $params['return_url'];
    $session->cancel_url = $params['cancel_url'];
    $h = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
    $h->gotoRoute(array('action' => 'subscription','order_id' => $params['vendor_order_id'],'subscrition' => 1,'type' => 'subscrition','subscription_id' => $subscription->getIdentity(),'gateway_id' => 555), 'advbilling_transaction', true);
    return;
  }
  public function createPageSubscription(  Zend_Db_Table_Row_Abstract $subscription,
                                              Page_Model_Package $package,
                                              array $params = array())
  {
    $session = new Zend_Session_Namespace('Page_Subscription');
    $session->return_url = $params['return_url'];
    $session->cancel_url = $params['cancel_url'];
    $h = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
    $h->gotoRoute(array('action' => 'subscriptionpage','order_id' => $params['vendor_order_id'],'subscrition' => 1,'type' => 'page','subscription_id' => $subscription->getIdentity(),'gateway_id' => 555), 'advbilling_transaction', true);
    return;
  }
  public function createCreditTransaction(   Credit_Model_Order $co,	array $params = array())
  {


    if (!$co->isOrderPending()) {
      throw new Engine_Payment_Plugin_Exception('CREDIT_No orders found');
    }
    $session = new Zend_Session_Namespace('Credit_Transaction');
    $session->return_url = $params['return_url'];
    $session->cancel_url = $params['cancel_url'];
    $h = Zend_Controller_Action_HelperBroker::getStaticHelper('Redirector');
    $h->gotoRoute(array('action' => 'creditbuy','order_id' => $params['credit_order_id'],'subscrition' => 1,'type' => 'credit','gateway_id' => 555), 'advbilling_transaction', true);
    return;
  }

  public function onSubscriptionTransactionIpn(
    Payment_Model_Order $order,
    Engine_Payment_Ipn $ipn)
  {
  }
  public function gotoRoute(array $urlOptions = array(), $name = null, $reset = false, $encode = true)
  {

    $view = Zend_Registry::get('Zend_View');
    $url = $view->url($urlOptions, $name, $reset, $encode);

    $front = Zend_Controller_Front::getInstance();
    $request = $front->getRequest();

    $params = array(
      'parentRedirect'=>$url,
    );

    $request->setActionName('simple')
      ->setControllerName('utility')
      ->setModuleName('touch')
      ->setParams($params)
      ->setDispatched(false);
  }
  public function createIpn(array $params)
  {
  }

  public function onIpn(Engine_Payment_Ipn $ipn)
  {
  }

  public function createCartTransaction(Store_Model_Order $order, array $params = array())
  {
    // Check that gateways match
    if ($order->gateway_id != $this->_gatewayInfo->gateway_id) {
      throw new Experts_Payment_Plugin_Exception('Gateways do not match');
    }

    // Check that item_type match
    if ($order->item_type != 'store_cart') {
      throw new Experts_Payment_Plugin_Exception("Wrong item_type has been provided. Method requires 'store_cart'");
    }

    // Check if the cart has any items
    if (!$order->hasItems()) {
      throw new Experts_Payment_Plugin_Exception("Provided store_cart doesn't have any order items");
    }

    $transaction = $this->createTransaction($params);

    return $transaction;
  }
  public function onPageSubscriptionReturn(
    Payment_Model_Order $order, array $params = array())
  {
    // Check that gateways match
    if ($order->gateway_id != $this->_gatewayInfo->gateway_id) {
      throw new Engine_Payment_Plugin_Exception('Gateways do not match');
    }

    // Get related info
    $user = $order->getUser();
    $subscription = $order->getSource();
    $package = $subscription->getPackage();

    // Check subscription state
    if ($subscription->status == 'active' || $subscription->status == 'trial') {
      return 'active';
    } else if ($subscription->status == 'pending') {
      return 'pending';
    }
    // Update order with profile info and complete status?
    $order->state = 'complete';
    $order->gateway_transaction_id = $params['transaction_id'];
    $order->save();

    // Insert transaction
    $transactionsTable = Engine_Api::_()->getDbtable('transactions', 'payment');
    $transactionsTable->insert(array(
      'user_id' => $order->user_id,
      'gateway_id' => $this->_gatewayInfo->gateway_id,
      'timestamp' => new Zend_Db_Expr('NOW()'),
      'order_id' => $order->order_id,
      'type' => 'page',
      'state' => 'okay',
      'gateway_transaction_id' => $params['transaction_id'],
      'amount' => $params['amount'], // @todo use this or gross (-fee)?
      'currency' => $params['currency']));

    // Get benefit setting
    $giveBenefit = Engine_Api::_()->getDbtable('transactions', 'payment')->getBenefitStatus($user);

    //YN - Random a code
    $sid = 'abcdefghiklmnopqstvxuyz0123456789ABCDEFGHIKLMNOPQSTVXUYZ';
    $max = strlen($sid) - 1;
    $rCode = "";
    for ($i = 0; $i < 16; ++$i) {
      $rCode .= $sid[mt_rand(0, $max)];
    }

    // Update subscription info
    $subscription->gateway_id = $this->_gatewayInfo->gateway_id;
    $subscription->gateway_profile_id = ($params['transaction_id']) ? $params['transaction_id'] : $rCode;

    $subscription->payment_date = date('Y-m-d H:i:s');
    // Payment success
    $subscription->onPaymentSuccess();

    // send notification
    if ($subscription->didStatusChange()) {
      Engine_Api::_()->getApi('mail', 'core')->sendSystem($user, 'payment_subscription_active', array('subscription_title' => $package->title, 'subscription_description' => $package->description, 'subscription_terms' => $package->getPackageDescription(), 'object_link' => 'http://' . $_SERVER['HTTP_HOST'] . Zend_Controller_Front::getInstance()->getRouter()->assemble(array(), 'user_login', true),));
    }
    return 'active';

     }
  public function onCreditTransactionReturn(Credit_Model_Order $order, array $params = array())
  {
    // Check that gateways match
    if ($order->gateway_id != $this->_gatewayInfo->gateway_id) {
      throw new Engine_Payment_Plugin_Exception('Gateways do not match');
    }

    //Get created orders
    if (!$order->isOrderPending()) {
      throw new Engine_Payment_Plugin_Exception('CREDIT_No orders found');
    }

    /**
     * @var $user User_Model_User
     * @var $item Credit_Model_Payment
     */

    $user = $order->getUser();
    $item = $order->getSource();

    // Check order states
    if ($order->status == 'completed') {
      return 'completed';
    }



    // Check for cancel state - the user cancelled the transaction
    if ($params['state'] == 'cancel') {
      $order->onCancel();
      // Error
      throw new Payment_Model_Exception('Your payment has been cancelled and ' .
        'not been purchased. If this is not correct, please try again later.');
    }




    // Update order with profile info and complete status?
    $order->status = 'complete';
    $order->gateway_transaction_id = $params['transaction_id'];
    $order->save();

    /**
     * @var $transactionsTable Credit_Model_DbTable_Transactions
     */
    $real_price = 0;
    if ($item instanceof Credit_Model_Payment) {
      $real_price = (float)$order->price;
    }

    $transactionsTable = Engine_Api::_()->getDbTable('transactions', 'credit');
    $db = $transactionsTable->getAdapter();
    $db->beginTransaction();

    try {
      $transactionsTable->insert(array(
        'order_id' => $order->getIdentity(),
        'user_id' => $order->user_id,
        'gateway_id' => $order->gateway_id,
        'creation_date' => new Zend_Db_Expr('NOW()'),
        'state' => 'okay',
        'gateway_transaction_id' => $params['transaction_id'],
        'credits' => $order->price,
        'price' => $real_price,
        'currency' => $this->getGateway()->getCurrency(),
      ));

      $db->commit();
    } catch (Exception $e) {
      $db->rollBack();
      throw $e;
    }

    $order->onPaymentSuccess();
    return 'completed';
  }
}

