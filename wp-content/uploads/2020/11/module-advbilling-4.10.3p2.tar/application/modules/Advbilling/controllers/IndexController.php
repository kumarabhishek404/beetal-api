<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: IndexController.php 22.11.16 07:11 bolot $
 * @author     Bolot
 */

/**
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */
class Advbilling_IndexController extends Core_Controller_Action_Standard
{
  public function indexAction()
  {
    $this->view->someVar = 'someVal';
  }

  public function getformdonateAction()
  {
    $id = $this->getParam('donate_id', 0);
    $stripe = Engine_Api::_()->getDbTable('donatesettings', 'advbilling');
    $select_d = $stripe->select()->where('donate_id = ?', $id);
    $this->view->stripe_setting = $stripe->fetchRow($select_d);
    $this->view->viewer = Engine_Api::_()->user()->getViewer();

    $this->view->amount = $this->getParam('amount', 0);
    $this->view->currency = Engine_Api::_()->getDbTable('settings', 'core')->getSetting('payment.currency', 'USD');
    $predefine_list = array();
    $_subject = Engine_Api::_()->getItem('donation', $id);
    $this->view->donation = $_subject;
    if ($_subject->predefine_list) {
      $predefine_list = explode(',', $_subject->predefine_list);
    }

    $this->view->predefine_list = $predefine_list;
    $this->view->html = $this->view->partial('index/getformdonate.tpl', array(
      'amount' => $this->view->amount,
      'currency' => $this->view->currency,
      'donation' => $this->view->donation,
      'stripe_setting' => $this->view->stripe_setting
    ));
  }

  public function donateAction()
  {
    $Stripe = new Advbilling_Api_Core();
    $Stripe->include_files();
    $curency = Engine_Api::_()->getDbTable('settings', 'core')->getSetting('payment.currency', 'USD');
    $amount = $this->getParam('amount', 0);

    $token = $this->getParam('token', '');
    $donate_id = $this->getParam('donate_id', 0);
    $donation = Engine_Api::_()->getItem('donation', $donate_id);
    $email = $this->getParam('email', 0);
    $stripe = Engine_Api::_()->getDbTable('donatesettings', 'advbilling');
    $select_d = $stripe->select()->where('donate_id = ?', $donate_id);
    $stripe_setting = $stripe->fetchRow($select_d);

    if(!$stripe_setting && $donation->parent_id > 0){
      $select_d = $stripe->select()->where('donate_id = ?', $donation->parent_id);
      $stripe_setting  = $stripe->fetchRow($select_d);
    }
    Stripe\Stripe::setApiKey($stripe_setting->secret_key);

    try {
      $charge = Stripe\Charge::create(array(
        'card' => $token,
        'amount' => $amount,
        'currency' => $curency,
      ));
      /**
       * @var $user User_Model_User;
       */
      $amount = $amount / 100;
      if ($charge->paid == true) {
        $paymentStatus = 'completed';
        $user = Engine_Api::_()->user()->getViewer();
        $gateway = Engine_Api::_()->getItem('payment_gateway', 555);
        $ordersTable = Engine_Api::_()->getDbtable('orders', 'payment');

        $niw = new Zend_Db_Expr('NOW()');
        $ordersTable->insert(array(
          'user_id' => $user->getIdentity(),
          'gateway_id' => $gateway->gateway_id,
          'state' => 'pending',
          'creation_date' => $niw,
          'source_type' => $donation->getType(),
          'source_id' => $donation->getIdentity(),
        ));
        $order_id = $ordersTable->getAdapter()->lastInsertId();
        //check for exists this transaction
        $transactionsTable = Engine_Api::_()->getDbtable('transactions', 'donation');

        $transactionsTable->insert(array(
          'order_id' => $order_id,
          'user_id' => $user->getIdentity(),
          'name' => $user->getTitle(),
          'email' => ($email) ? $email : $user->email,
          'gateway_id' => $gateway->getIdentity(),
          'item_id' => $donate_id,
          'item_type' => 'donation',
          'state' => $paymentStatus,
          'gateway_transaction_id' => $token,
          'amount' => $amount,
          'currency' => $curency,
          'description' => ' ',
          'creation_date' => $niw,
        ));


        //Update the raised money
        if ($paymentStatus == 'completed') {
          // Earning credits for donation
          if (Engine_Api::_()->getDbTable('modules', 'core')->isModuleEnabled('credit')) {
            $user = Engine_Api::_()->getItem('user', $user->getIdentity());
            $object_id = $donate_id;
            $creditApi = Engine_Api::_()->getApi('core', 'credit');
            $creditApi->updateDonationCredits($user, $object_id);
          }


          $donation->raised_sum = $donation->raised_sum + $amount;
          $donation->save();
          $parentDonation = $donation->getParent();
          if ($parentDonation) {
            $parentDonation->raised_sum = $donation->raised_sum + $amount;
            $parentDonation->save();
          }
        }
      } else {
        die($this->view->translate('Failed to send payment '));
      }
    } catch (Exception $e) {
      die($e->getMessage());
    }
    die($this->view->translate('Your payment has been sent. Thank you for your donation!'));
  }
}
