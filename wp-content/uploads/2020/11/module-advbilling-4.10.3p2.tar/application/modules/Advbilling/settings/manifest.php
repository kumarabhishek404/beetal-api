<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: manifest.php 16.12.16 05:40 bolot $
 * @author     Bolot
 */

/**
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

return array(
  'package' =>
    array(
      'type' => 'module',
      'name' => 'advbilling',
      'version' => '4.10.3p2',
      'path' => 'application/modules/Advbilling',
      'title' => 'Advanced Billing system',
      'description' => 'Advanced Billing system',
      'sku' => 'HEADBILLING',
      'author' => '<a href="http://www.hire-experts.com" title="Hire-Experts LLC" target="_blank">Hire-Experts LLC</a>',
      'dependencies' => array(
        array(
          'type' => 'module',
          'name' => 'core',
          'minVersion' => '4.1.8',
        ),
      ),
      'callback' =>
        array(
          'path' => 'application/modules/Advbilling/settings/install.php',
          'class' => 'Advbilling_Installer',
        ),
      'actions' =>
        array(
          0 => 'install',
          1 => 'upgrade',
          2 => 'refresh',
          3 => 'enable',
          4 => 'disable',
        ),
      'directories' =>
        array(
          0 => 'application/modules/Advbilling',
          1 => 'application/libraries/Experts',
          2 => 'application/libraries/Hireexperts',
        ),
      'files' =>
        array(
          0 => 'application/languages/en/advbilling.csv',
          1 => 'application/languages/en/hecore.csv',
        ),
    ),
  'routes' => array(
    'advbilling_admin_index' => array(
      'route' => 'admin/advbilling/:action/*',
      'defaults' => array(
        'module' => 'advbilling',
        'controller' => 'admin-index',
        'action' => 'index'
      ),
      'reqs' => array(
        'action' => '(index|detail-transaction|detail|transaction)',
      )
    ),
    'advbilling_payment' => array(
      'route' => 'payment/pay/:action/*',
      'defaults' => array(
        'module' => 'advbilling',
        'controller' => 'pay',
        'action' => 'index'
      )
    ),
    'advbilling_donate' => array(
      'route' => 'advbilling/donate_payment/donate',
      'defaults' => array(
        'module' => 'advbilling',
        'controller' => 'index',
        'action' => 'donate'
      )
    ),
    'advbilling_get_stripe_donate_form' => array(
      'route' => 'advbilling/donate_payment/getform',
      'defaults' => array(
        'module' => 'advbilling',
        'controller' => 'index',
        'action' => 'getformdonate'
      )
    ),
    'advbilling_transaction' => array(
      'route' => 'advbilling/transaction/:action/*',
      'defaults' => array(
        'module' => 'advbilling',
        'controller' => 'transaction',
        'action' => 'index',
      ),
      'reqs' => array(
        'action' => '(index|info|gateway|stripe|process|subscriptionpage|subscription|return|finish)',
      )
    ),

  )
); ?>