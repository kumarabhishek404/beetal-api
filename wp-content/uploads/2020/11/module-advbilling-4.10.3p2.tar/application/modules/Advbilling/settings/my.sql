INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`)
VALUES  ('advbilling', 'Advanced Billing system', 'Advanced Billing system', '4.10.3p2', 1, 'extra') ;
