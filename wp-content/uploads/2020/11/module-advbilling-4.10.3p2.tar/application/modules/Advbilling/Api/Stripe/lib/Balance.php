<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: Balance.php 16.12.16 05:40 bolot $
 * @author     Bolot
 */

/**
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */


namespace Stripe;

/**
 * Class Balance
 *
 * @property string $object
 * @property mixed $available
 * @property bool $livedmode
 * @property mixed $pending
 *
 * @package Stripe
 */
class Balance extends SingletonApiResource
{
    /**
     * @param array|string|null $opts
     *
     * @return Balance
     */
    public static function retrieve($opts = null)
    {
        return self::_singletonRetrieve($opts);
    }
}
