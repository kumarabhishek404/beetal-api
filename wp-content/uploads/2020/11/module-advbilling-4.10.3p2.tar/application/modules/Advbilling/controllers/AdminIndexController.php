<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: AdminIndexController.php 22.11.16 07:11 bolot $
 * @author     Bolot
 */

/**
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */
class Advbilling_AdminIndexController extends Core_Controller_Action_Admin
{

  public function indexAction()
  {
    $this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
      ->getNavigation('advbilling_admin_main', array(), 'advbilling_admin_main_settings');
    $form = new Advbilling_Form_Admin_Stripe();
    $this->view->form = $form;
    $gateway = Engine_Api::_()->getDbtable('gateways', 'payment')
      ->find(555)
      ->current();
    // Populate form
    $form->populate($gateway->toArray());
    if (is_array($gateway->config)) {
      $form->populate($gateway->config);
    }
    // Check method/valid
    if (!$this->getRequest()->isPost()) {
      return;
    }
    if (!$form->isValid($this->getRequest()->getPost())) {
      return;
    }
    // Process
    $values = $form->getValues();

    $enabled = (bool)$values['enabled'];
    //$testMode = !empty($values['test_mode']);
    unset($values['enabled']);
    //unset($values['test_mode']);

    // Validate gateway config
    if ($enabled) {
      $gatewayObject = $this->getGateway($gateway);

      try {
        $gatewayObject->setConfig($values);
        $response = $gatewayObject->test();
      } catch (Exception $e) {
        $enabled = false;
        $form->populate(array('enabled' => false));
        $form->addError(sprintf('Gateway login failed. Please double check ' .
          'your connection information. The gateway has been disabled. ' .
          'The message was: [%2$d] %1$s', $e->getMessage(), $e->getCode()));
      }
    } else {
      $form->addError('Gateway is currently disabled.');
    }

    // Process
    $message = null;
    try {
      $values = $this->getPlugin($gateway)->processAdminGatewayForm($values);
    } catch (Exception $e) {
      $message = $e->getMessage();
      $values = null;
    }

    if (null !== $values) {
      $gateway->setFromArray(array(
        'enabled' => $enabled,
        'config' => $values,
      ));
      $gateway->save();

      $form->addNotice('Changes saved.');
    } else {
      $form->addError($message);
    }

    // Try to update/create all product if enabled
    $gatewayPlugin = $this->getGateway($gateway);
    if ($gateway->enabled &&
      method_exists($gatewayPlugin, 'createProduct') &&
      method_exists($gatewayPlugin, 'editProduct') &&
      method_exists($gatewayPlugin, 'detailVendorProduct')
    ) {
      $packageTable = Engine_Api::_()->getDbtable('packages', 'payment');
      try {
        foreach ($packageTable->fetchAll() as $package) {
          if ($package->isFree()) {
            continue;
          }
          // Check billing cycle support
          if (!$package->isOneTime()) {
            $sbc = $this->getGateway($gateway)->getSupportedBillingCycles();
            if (!in_array($package->recurrence_type, array_map('strtolower', $sbc))) {
              continue;
            }
          }
          // If it throws an exception, or returns empty, assume it doesn't exist?
          try {
            $info = $gatewayPlugin->detailVendorProduct($package->getGatewayIdentity());
          } catch (Exception $e) {
            $info = false;
          }
          // Create
          if (!$info) {
            $gatewayPlugin->createProduct($package->getGatewayParams());
          }
        }
        $form->addNotice('All plans have been checked successfully for products in this gateway.');
      } catch (Exception $e) {
        $form->addError('We were not able to ensure all packages have a product in this gateway.');
        $form->addError($e->getMessage());
      }
    }
  }

  public function transactionAction()
  {
    $this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
      ->getNavigation('advbilling_admin_main', array(), 'advbilling_admin_main_transactions');
    // Test curl support
    if (!function_exists('curl_version') ||
      !($info = curl_version())
    ) {
      $this->view->error = $this->view->translate('The PHP extension cURL ' .
        'does not appear to be installed, which is required ' .
        'for interaction with payment gateways. Please contact your ' .
        'hosting provider.');
    } // Test curl ssl support
    else if (!($info['features'] & CURL_VERSION_SSL) ||
      !in_array('https', $info['protocols'])
    ) {
      $this->view->error = $this->view->translate('The installed version of ' .
        'the cURL PHP extension does not support HTTPS, which is required ' .
        'for interaction with payment gateways. Please contact your ' .
        'hosting provider.');
    } // Check for enabled payment gateways
    else if (Engine_Api::_()->getDbtable('gateways', 'payment')->getEnabledGatewayCount() <= 0) {
      $this->view->error = $this->view->translate('There are currently no ' .
        'enabled payment gateways. You must %1$sadd one%2$s before this ' .
        'page is available.', '<a href="' .
        $this->view->escape($this->view->url(array('controller' => 'gateway'))) .
        '">', '</a>');
    }


    // Make form
    $this->view->formFilter = $formFilter = new Payment_Form_Admin_Transaction_Filter();

    // Process form
    if ($formFilter->isValid($this->_getAllParams())) {
      $filterValues = $formFilter->getValues();
    } else {
      $filterValues = array();
    }
    if (empty($filterValues['order'])) {
      $filterValues['order'] = 'transaction_id';
    }
    if (empty($filterValues['direction'])) {
      $filterValues['direction'] = 'DESC';
    }
    $this->view->filterValues = $filterValues;
    $this->view->order = $filterValues['order'];
    $this->view->direction = $filterValues['direction'];

    // Initialize select
    $transactionsTable = Engine_Api::_()->getDbtable('transactions', 'payment');
    $transactionSelect = $transactionsTable->select();

    // Add filter values
    if (!empty($filterValues['gateway_id'])) {
      $transactionSelect->where('gateway_id = ?', $filterValues['gateway_id']);
    }
    if (!empty($filterValues['type'])) {
      $transactionSelect->where('type = ?', $filterValues['type']);
    }
    if (!empty($filterValues['state'])) {
      $transactionSelect->where('state = ?', $filterValues['state']);
    }
    if (!empty($filterValues['query'])) {
      $transactionSelect
        ->from($transactionsTable->info('name'))
        ->joinLeft('engine4_users', 'engine4_users.user_id=engine4_payment_transactions.user_id', null)
        ->where('(gateway_transaction_id LIKE ? || ' .
          'gateway_parent_transaction_id LIKE ? || ' .
          'gateway_order_id LIKE ? || ' .
          'displayname LIKE ? || username LIKE ? || ' .
          'email LIKE ?)', '%' . $filterValues['query'] . '%');;
    }
    if (($user_id = $this->_getParam('user_id', @$filterValues['user_id']))) {
      $this->view->filterValues['user_id'] = $user_id;
      $transactionSelect->where('engine4_payment_transactions.user_id = ?', $user_id);
    }
    if (!empty($filterValues['order'])) {
      if (empty($filterValues['direction'])) {
        $filterValues['direction'] = 'DESC';
      }
      $transactionSelect->order($filterValues['order'] . ' ' . $filterValues['direction']);
    }


    $this->view->paginator = $paginator = Zend_Paginator::factory($transactionSelect);
    $paginator->setCurrentPageNumber($this->_getParam('page', 1));

    // Preload info
    $gatewayIds = array();
    $userIds = array();
    $orderIds = array();
    foreach ($paginator as $transaction) {
      if (!empty($transaction->gateway_id)) {
        $gatewayIds[] = $transaction->gateway_id;
      }
      if (!empty($transaction->user_id)) {
        $userIds[] = $transaction->user_id;
      }
      if (!empty($transaction->order_id)) {
        $orderIds[] = $transaction->order_id;
      }
    }
    $gatewayIds = array_unique($gatewayIds);
    $userIds = array_unique($userIds);
    $orderIds = array_unique($orderIds);

    // Preload gateways
    $gateways = array();
    if (!empty($gatewayIds)) {
      foreach (Engine_Api::_()->getDbtable('gateways', 'payment')->find($gatewayIds) as $gateway) {
        $gateways[$gateway->gateway_id] = $gateway;
      }
    }
    $this->view->gateways = $gateways;

    // Preload users
    $users = array();
    if (!empty($userIds)) {
      foreach (Engine_Api::_()->getItemTable('user')->find($userIds) as $user) {
        $users[$user->user_id] = $user;
      }
    }
    $this->view->users = $users;

    // Preload orders
    $orders = array();
    if (!empty($orderIds)) {
      foreach (Engine_Api::_()->getDbtable('orders', 'payment')->find($orderIds) as $order) {
        $orders[$order->order_id] = $order;
      }
    }
    $this->view->orders = $orders;
  }

  public function detailAction()
  {
    // Missing transaction
    if (!($transaction_id = $this->_getParam('transaction_id')) ||
      !($transaction = Engine_Api::_()->getItem('payment_transaction', $transaction_id))
    ) {
      return;
    }

    $this->view->transaction = $transaction;
    $this->view->gateway = Engine_Api::_()->getItem('payment_gateway', $transaction->gateway_id);
    $this->view->order = Engine_Api::_()->getItem('payment_order', $transaction->order_id);
    $this->view->user = Engine_Api::_()->getItem('user', $transaction->user_id);
  }

  public function detailTransactionAction()
  {
    $transaction_id = $this->_getParam('transaction_id');
    $transaction = Engine_Api::_()->getItem('payment_transaction', $transaction_id);
    $gateway = Engine_Api::_()->getItem('payment_gateway', $transaction->gateway_id);

    $link = null;
    if ($this->_getParam('show-parent')) {
      if (!empty($transaction->gateway_parent_transaction_id)) {
        $class = $gateway->plugin;
        Engine_Loader::loadClass($class);
        $plugin = new $class($this);
        $link = $plugin->getTransactionDetailLink($transaction->gateway_parent_transaction_id);
      }
    } else {
      if (!empty($transaction->gateway_transaction_id)) {
        $class = $gateway->plugin;
        Engine_Loader::loadClass($class);
        $plugin = new $class($gateway);
        $link = $plugin->getTransactionDetailLink($transaction->gateway_transaction_id);
      }
    }

    if ($link) {
      return $this->_helper->redirector->gotoUrl($link, array('prependBase' => false));
    } else {
      die();
    }
  }
  protected $_plugin;
  public function getPlugin($plugin)
  {
    if( null === $this->_plugin ) {
      $class = $plugin->plugin;
      Engine_Loader::loadClass($class);
      $plugin = new $class($plugin);
      $this->_plugin = $plugin;
    }
    return $this->_plugin;
  }

  /**
   * Get the payment gateway
   *
   * @return Engine_Payment_Gateway
   */
  public function getGateway($plugin)
  {
    return $this->getPlugin($plugin)->getGateway();
  }
}

