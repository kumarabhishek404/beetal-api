<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: Core.php 22.11.16 07:11 bolot $
 * @author     Bolot
 */

/**
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */
class Advbilling_Api_Core extends Core_Api_Abstract
{
  function  include_files()
  {
// Stripe singleton
    require(dirname(__FILE__) . '/Stripe/lib/Stripe.php');

// Utilities
    require(dirname(__FILE__) . '/Stripe/lib/Util/AutoPagingIterator.php');
    require(dirname(__FILE__) . '/Stripe/lib/Util/RequestOptions.php');
    require(dirname(__FILE__) . '/Stripe/lib/Util/Set.php');
    require(dirname(__FILE__) . '/Stripe/lib/Util/Util.php');

// HttpClient
    require(dirname(__FILE__) . '/Stripe/lib/HttpClient/ClientInterface.php');
    require(dirname(__FILE__) . '/Stripe/lib/HttpClient/CurlClient.php');

// Errors
    require(dirname(__FILE__) . '/Stripe/lib/Error/Base.php');
    require(dirname(__FILE__) . '/Stripe/lib/Error/Api.php');
    require(dirname(__FILE__) . '/Stripe/lib/Error/ApiConnection.php');
    require(dirname(__FILE__) . '/Stripe/lib/Error/Authentication.php');
    require(dirname(__FILE__) . '/Stripe/lib/Error/Card.php');
    require(dirname(__FILE__) . '/Stripe/lib/Error/InvalidRequest.php');
    require(dirname(__FILE__) . '/Stripe/lib/Error/Permission.php');
    require(dirname(__FILE__) . '/Stripe/lib/Error/RateLimit.php');

// Plumbing
    require(dirname(__FILE__) . '/Stripe/lib/ApiResponse.php');
    require(dirname(__FILE__) . '/Stripe/lib/JsonSerializable.php');
    require(dirname(__FILE__) . '/Stripe/lib/StripeObject.php');
    require(dirname(__FILE__) . '/Stripe/lib/ApiRequestor.php');
    require(dirname(__FILE__) . '/Stripe/lib/ApiResource.php');
    require(dirname(__FILE__) . '/Stripe/lib/SingletonApiResource.php');
    require(dirname(__FILE__) . '/Stripe/lib/AttachedObject.php');
    require(dirname(__FILE__) . '/Stripe/lib/ExternalAccount.php');

// Stripe API Resources
    require(dirname(__FILE__) . '/Stripe/lib/Account.php');
    require(dirname(__FILE__) . '/Stripe/lib/AlipayAccount.php');
    require(dirname(__FILE__) . '/Stripe/lib/ApplePayDomain.php');
    require(dirname(__FILE__) . '/Stripe/lib/ApplicationFee.php');
    require(dirname(__FILE__) . '/Stripe/lib/ApplicationFeeRefund.php');
    require(dirname(__FILE__) . '/Stripe/lib/Balance.php');
    require(dirname(__FILE__) . '/Stripe/lib/BalanceTransaction.php');
    require(dirname(__FILE__) . '/Stripe/lib/BankAccount.php');
    require(dirname(__FILE__) . '/Stripe/lib/BitcoinReceiver.php');
    require(dirname(__FILE__) . '/Stripe/lib/BitcoinTransaction.php');
    require(dirname(__FILE__) . '/Stripe/lib/Card.php');
    require(dirname(__FILE__) . '/Stripe/lib/Charge.php');
    require(dirname(__FILE__) . '/Stripe/lib/Collection.php');
    require(dirname(__FILE__) . '/Stripe/lib/CountrySpec.php');
    require(dirname(__FILE__) . '/Stripe/lib/Coupon.php');
    require(dirname(__FILE__) . '/Stripe/lib/Customer.php');
    require(dirname(__FILE__) . '/Stripe/lib/Dispute.php');
    require(dirname(__FILE__) . '/Stripe/lib/Event.php');
    require(dirname(__FILE__) . '/Stripe/lib/FileUpload.php');
    require(dirname(__FILE__) . '/Stripe/lib/Invoice.php');
    require(dirname(__FILE__) . '/Stripe/lib/InvoiceItem.php');
    require(dirname(__FILE__) . '/Stripe/lib/Order.php');
    require(dirname(__FILE__) . '/Stripe/lib/OrderReturn.php');
    require(dirname(__FILE__) . '/Stripe/lib/Plan.php');
    require(dirname(__FILE__) . '/Stripe/lib/Product.php');
    require(dirname(__FILE__) . '/Stripe/lib/Recipient.php');
    require(dirname(__FILE__) . '/Stripe/lib/Refund.php');
    require(dirname(__FILE__) . '/Stripe/lib/SKU.php');
    require(dirname(__FILE__) . '/Stripe/lib/Source.php');
    require(dirname(__FILE__) . '/Stripe/lib/Subscription.php');
    require(dirname(__FILE__) . '/Stripe/lib/SubscriptionItem.php');
    require(dirname(__FILE__) . '/Stripe/lib/ThreeDSecure.php');
    require(dirname(__FILE__) . '/Stripe/lib/Token.php');
    require(dirname(__FILE__) . '/Stripe/lib/Transfer.php');
    require(dirname(__FILE__) . '/Stripe/lib/TransferReversal.php');

  }
}