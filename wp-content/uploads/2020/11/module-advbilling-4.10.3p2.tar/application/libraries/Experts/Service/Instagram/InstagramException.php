<?php

//namespace Experts_Service_Instagram_Instagram;

class Experts_Service_Instagram_InstagramException extends Experts_Service_Instagram_Instagram
{
}
class InstagramException extends Exception {
    
}