<?php

/**
 * @author Eldar
 * @copyright Hire-Experts LLC
 * @version Fans 3.1
 */

define('SE_PAGE_AJAX', TRUE);
$page = "fan_ajax";

include("header.php");

$task = $_POST["task"] ? $_POST["task"] : $_GET["task"];
$fans_type = $_POST["fans_type"];
$fans_id = $_POST["fans_id"];
$fans_owner_id = $_POST["fans_owner_id"];


if ( $user->user_exists ) {

    switch ($fans_type) {
        case "profile":
            $fan = new se_profilefans($fans_id,$fans_owner_id);
            $level_allow = $user->level_info['level_fans_allow'];
        break;
        case "group":
            $fan = new se_groupfans($fans_id,$fans_owner_id);
            $level_allow = $user->level_info['level_fans_group_allow'];
        break;
        case "pages":
            $fan = new se_pagesfans($fans_id,$fans_owner_id);
            $level_allow = $user->level_info['level_fans_page_allow'];
        break;
    }

    $result = array();

    switch ($task) {
        case "initialize":
            break;

        case "join":
            $result['status'] = $fan->join_fan_club($user->user_info['user_id']);
            break;

        case "leave":
            $result['status'] = $fan->leave_fan_club($user->user_info['user_id']);
            break;

        case "create_fan_club":
            $result['status'] = ( $level_allow ) ? $fan->create_fan_club() : false;
            break;
        
        case "enable_fan_club":
            $result['status'] = ( $level_allow ) ? $fan->enable_fan_club() : false;
            break;

        case "disable_fan_club":
            $result['status'] = ( $level_allow ) ? $fan->disable_fan_club() : false;
            break;
    }

    $result['info'] = get_formatted_fan_js_for_current_user($fan);
    echo json_encode($result);

}
?>