<?php

/**
 * @author Eldar
 * @copyright Hire-Experts LLC
 * @version Fans 3.1
 */

$page = 'fans_suggest_to_contacts';
include('header.php');


if( !$user->user_exists ) exit();


$fans_id = intval($_REQUEST['fans_id']);
$type = $_REQUEST['type'];

if( $_REQUEST['contacts_choosed'] ) {
    //validation
    switch ( $type ) {
        case 'pages' :
            $pages = new he_pages($fans_id, 0, false);
            if( !$pages->page_exists ) exit();
            break;
    }
    
    //get contacts and suggest
    $contacts = explode(',', $_REQUEST['contacts']);
    if( $contacts ) {
        foreach($contacts as $user_id) {
            se_fans::add_suggest($user_id, $user->user_info['user_id'], $type, $fans_id);
        }
        $result = array( 'message' => SE_Language::_get(690704203), 'status' => true );
    }
    else {
        $result = array( 'message' => SE_Language::_get(690704204), 'status' => false );
    }
}

he_print_json($result);

?>