<?php

/**
 * @author Eldar
 * @copyright Hire-Experts LLC
 * @version Fans 3.1
 */

$page = "he_contacts";
include "header.php";
include_once "include/class_he_contacts.php";

if (!$user->user_exists) {
    exit;
}

$fans_id = intval($_REQUEST['fans_id']);
$type = $_REQUEST['type'];
$callback_url = $_REQUEST['callback_url'];
$get_contacts_url = "fans_get_contacts.php?fans_id=$fans_id&type=$type&";
$message_allowed = intval($_REQUEST['message_allowed']);
$emails_allowed = intval($_REQUEST['emails_allowed']);
$start = intval($_REQUEST['start']);
$count = 16;

//keep up to date
$he_contacts = new he_contacts();

$contacts = se_fans::get_contacts($user->user_info['user_id'], $type, $fans_id, $start, $count);
$smarty->assign_by_ref('contacts', $contacts);
$contacts_compiled = $contacts ? $smarty->fetch('he_contacts_list.tpl') : '';


$contacts_total = se_fans::get_contacts_count($user->user_info['user_id'], $type, $fans_id);
$more_contacts_existed = ( $contacts_total > $start + $count ) ? 1 : 0;

if ($_REQUEST['is_ajax']) {
    he_print_json( array( 'html_code'=> $contacts_compiled, 'more' => $more_contacts_existed, 'start' => $start + $count ) );
}


$smarty->assign('contacts_compiled', $contacts_compiled);
$smarty->assign('last', $start + $count);
$smarty->assign('more_contacts_existed', $more_contacts_existed);
$smarty->assign('message_allowed', $message_allowed);
$smarty->assign('emails_allowed', $emails_allowed);
$smarty->assign('callback_url', $callback_url);
$smarty->assign('get_contacts_url', $get_contacts_url);

include "footer.php";
?>