<?php

/**
 * @author Eldar
 * @copyright Hire-Experts LLC
 * @version Fans 3.1
 */

class se_fans {
    var $fans_id;
    var $fans_club_id;
    var $fans_owner_id;
    var $fans_type;
    var $active;
    var $title;
    var $total_fans;
    var $fans;

    
    function se_fans($fans_id, $fans_type, $fans_owner_id=0) {
        $fans_id = intval($fans_id);
        $this->fans_id = $fans_id;
        $this->fans_type = $fans_type;
        
        $this->set_fan_club_info($fans_id, $fans_type);
        $this->fans_owner_id = $fans_owner_id;
        
        $this->total_fans = $this->total_fans();
    }
    
    
    function get_fan_club_id($fans_id, $type) {
        $sql = he_database::placeholder("SELECT id FROM se_fan_club WHERE type='?' AND fans_id=?", $type, $fans_id);
        return he_database::fetch_field($sql);
    }


    function get_fan_club($fans_id, $type) {
        $sql = he_database::placeholder("SELECT * FROM se_fan_club WHERE type='?' AND fans_id=?", $type, $fans_id);
        return he_database::fetch_row($sql);
    }
    
    function set_fan_club_info($fans_id, $fans_type) {
        $row = he_database::fetch_row(he_database::placeholder("SELECT * FROM se_fan_club WHERE type='?' AND fans_id=?", $fans_type, $fans_id));
        $this->fans_club_id = $row['id'];
        $this->fans_owner_id = $row['owner_id'];
        $this->active = $row['active'];
    }
    
    
    function create_fan_club() {
        if ( !$this->is_club() ) {
            he_database::query(he_database::placeholder("INSERT INTO se_fan_club SET type='?', fans_id=?, created_time=".time().", `active`=1, owner_id=?", $this->fans_type, $this->fans_id, $this->fans_owner_id));
            $this->set_fan_club_info($this->fans_id, $this->fans_type);
            return true;
        }
        return false;
    }
    
    
    function enable_fan_club() {
        $this->active = ( he_database::query("UPDATE se_fan_club SET `active`=1 WHERE id={$this->fans_club_id}") );
        return $this->active;
    }


    function disable_fan_club() {
        $this->active = !( he_database::query("UPDATE se_fan_club SET `active`=0 WHERE id={$this->fans_club_id}") );
        return !$this->active;
    }


    function join_fan_club($user_id) {
        global $actions, $user;
        $user_id = intval($user_id);
        if ( !$this->is_fan($user_id) ) {
            //ADD ACTIVITY
            $sql = he_database::placeholder("DELETE FROM `se_actions` WHERE `action_object_owner`='fans' "
                . "AND `action_object_owner_id`=? AND `action_user_id`=?", $this->fans_club_id, $user_id);
            he_database::query($sql);
                
            $fans_club = '<a href="' . $this->get_url() . '" target="_blank">' . $this->get_title() . '</a>';
            $replace_arr = array($user->user_info['user_username'], $user->user_displayname, $fans_club);

            $actions->actions_add($user, 'become_fan', $replace_arr, array(), 0, false, 'fans', $this->fans_club_id, 63);
            
            he_database::query("INSERT INTO se_fans SET fans_club_id={$this->fans_club_id}, fans_user_id={$user_id}");
            $this->total_fans++;
            return true;
        }
        
        return false;
    }
    

    function leave_fan_club($user_id) {
        $user_id = intval($user_id);
        if ( $this->is_fan($user_id) ) {
            he_database::query("DELETE FROM se_fans WHERE fans_club_id={$this->fans_club_id} AND fans_user_id={$user_id}");
            $this->total_fans--;
            return true;
        }
        return false;
    }
    
    
    function get_fans($start = 0, $count = 0)    {
        if (!$this->fans)
        {
            $limit = ($count != 0) ? he_database::placeholder("LIMIT ?, ?", $start, $count) : '';

            $res = he_database::query("SELECT * FROM se_fans  WHERE fans_club_id={$this->fans_club_id} ORDER BY id ASC $limit");
            $fans_array = array();
            while ($row = he_database::fetch_row_from_resource($res))
            {
                $f_user = new se_user(array(0 => $row["fans_user_id"]));
                $fan_user["user_id"] = $f_user->user_info["user_id"];
                $fan_user["user_display_name"] = $f_user->user_info["user_displayname"];
                $fan_user["user_photo"] = $f_user->user_photo("./images/nophoto.gif",true);
                $fan_user["user_name"] = $f_user->user_info["user_username"];
                $fans_array[]=$fan_user;
            }
            $this->fans=$fans_array;
        }
        return $this->fans;
    }
    
    
    function total_fans()
    {
        if( !$this->total_fans )
        {
            if ($this->fans_club_id)
                $this->total_fans = he_database::fetch_field("SELECT COUNT(id) AS total_fans FROM se_fans WHERE fans_club_id={$this->fans_club_id}");
            else 
                $this->total_fans = 0;
        }
        
        return $this->total_fans;
    }
    
    
    function is_fan($user_id) {
        $sql = he_database::placeholder("SELECT 1 FROM se_fans "
            . "WHERE fans_club_id=? AND fans_user_id=?", $this->fans_club_id, $user_id);
        
        return he_database::fetch_row($sql) ? true : false;
    }
    
    
    function is_club() {
        return he_database::fetch_row("SELECT 1 FROM se_fan_club WHERE type='{$this->fans_type}' AND fans_id={$this->fans_id} LIMIT 1") ? true : false;
    }
    
    
    function is_club_enabled() {
        if ($this->is_club())
        {
            return he_database::fetch_row("SELECT 1 FROM se_fan_club WHERE id={$this->fans_club_id} AND active=1 LIMIT 1") ? true : false;
        }
        return false;
    }


    function total_user_suggest($user_id) {
        $sql = he_database::placeholder( "SELECT COUNT(suggest_id) FROM se_fans_suggest WHERE suggest_user_to=?", $user_id );
        return he_database::fetch_field($sql);
    }


    function remove_suggest($suggest_id, $user_id) {
        $sql = he_database::placeholder( "DELETE FROM se_fans_suggest WHERE suggest_id=? AND suggest_user_to=?", $suggest_id, $user_id);
        return ( he_database::query($sql) );
    }


    function get_suggest($suggest_id, $user_id) {
        $sql = he_database::placeholder( "SELECT se_fans_suggest.*, se_fan_club.* FROM se_fans_suggest INNER JOIN se_fan_club ON (se_fan_club.id = se_fans_suggest.suggest_club_id) WHERE suggest_id=? AND suggest_user_to=?", $suggest_id, $user_id );
        
        return he_database::fetch_row($sql);
    }


    function add_suggest($user_to, $user_from, $entity_type, $entity_id)
    {
        global $url, $notify, $user;
        
        $club_id = se_fans::get_fan_club_id($entity_id, $entity_type);
        $recipient = new se_user(array($user_to));
        
        //SEND EMAIL NOTIFICATION
        if ($recipient->usersetting_info['usersetting_notify_fans_invitation']) {
            $login_url = '<a href="' . $url->url_base . "login.php\">" . $url->url_base . "login.php</a>";
            $replace_arr = array( $recipient->user_displayname, $user->user_displayname, $login_url );
            
            send_systememail('fans_invitation', $recipient->user_info['user_email'], $replace_arr);
        }
        
        //SEND NOTIFICATION
        $notify->notify_add($recipient->user_info['user_id'], 'fans_invitation', $club_id);
        
        return ( he_database::query("INSERT INTO se_fans_suggest SET suggest_user_to={$user_to}, suggest_user_from={$user_from}, suggest_club_id=$club_id") );
    }


    function get_fan_ad( $user_id ) {
        $sql = he_database::placeholder("SELECT fc.fans_id, fc.type, fc.owner_id ".
           "FROM se_fan_club as fc ".
           "LEFT JOIN se_fans as f ON (fc.id = f.fans_club_id ) ".
           "INNER JOIN se_users as u ON (fc.owner_id = u.user_id) ".
           "INNER JOIN se_levels as l ON(l.level_id = u.user_level_id) ".
           "WHERE fc.owner_id!=? AND f.fans_club_id IS NULL AND fc.active=1 AND l.level_fans_ad_allow ORDER BY RAND() LIMIT 1", $user_id);
        
        return he_database::fetch_row($sql);
    }


    function get_contacts($user_id, $entity_type, $entity_id, $start, $count) {
    
        $club = se_fans::get_fan_club($entity_id, $entity_type);
        
        $sql = he_database::placeholder("SELECT se_users.user_id, se_users.user_username, se_users.user_displayname, se_users.user_fname, se_users.user_lname, se_users.user_photo 
            FROM `se_friends`
            INNER JOIN se_users ON ( friend_user_id2=se_users.user_id )
            WHERE 
            friend_user_id1 = ? AND 
            friend_user_id2 NOT IN (
                SELECT fans_user_id FROM `se_fans` WHERE fans_club_id = ?
            )
            AND 
            friend_user_id2 NOT IN (
                SELECT suggest_user_to FROM `se_fans_suggest` WHERE suggest_club_id = ?
            )
            AND friend_user_id2!=?
            LIMIT ?, ?
        ", $user_id, $club['id'], $club['id'], $club['owner_id'], $start, $count);
        
        $res = he_database::query($sql);
        $contacts = array();
        while ($contact = he_database::fetch_row_from_resource($res)) {
            $profile = new se_user();
            $profile->user_info['user_id'] = $contact['user_id'];
            $profile->user_info['user_username'] = $contact['user_username'];
            $profile->user_info['user_fname'] = $contact['user_fname'];
            $profile->user_info['user_lname'] = $contact['user_lname'];
            $profile->user_info['user_photo'] = $contact['user_photo'];
            $profile->user_displayname();
            $contacts[] = $profile;
        }
        
        return $contacts;
    }


    function get_contacts_count($user_id, $entity_type, $entity_id) {
    
        $club = se_fans::get_fan_club($entity_id, $entity_type);
        $sql = he_database::placeholder("SELECT COUNT(se_users.user_id) 
            FROM `se_friends`
            LEFT JOIN se_users ON ( friend_user_id2=se_users.user_id )
            WHERE 
            friend_user_id1 = ? AND 
            friend_user_id2 NOT IN (
                SELECT fans_user_id FROM `se_fans` WHERE fans_club_id = ?
            )
            AND 
            friend_user_id2 NOT IN (
                SELECT suggest_user_to FROM `se_fans_suggest` WHERE suggest_club_id = ?
            )
            AND friend_user_id2!=?
        ", $user_id, $club['id'], $club['id'], $club['owner_id']);
        
        return he_database::fetch_field($sql);
    }

    function get_notifytype_id($notifytype_name = 'fans_invitation')
    {
        $sql = he_database::placeholder("SELECT `notifytype_id` FROM `se_notifytypes` "
            . "WHERE `notifytype_name`='?'", $notifytype_name);

        return he_database::fetch_field($sql);
    }

    function delete_notify($user_id)
    {
        if (!$user_id) {
            return false;
        }

        $notifytype_id = se_fans::get_notifytype_id('fans_invitation');

        $sql = he_database::placeholder("DELETE FROM `se_notifys` "
            . "WHERE `notify_user_id`=? AND `notify_notifytype_id`=?", $user_id, $notifytype_id);
        
        he_database::query($sql);
    }

    function get_title()
    {
    }

    function get_photo()
    {
    }

    function get_url()
    {
    }

}
?>