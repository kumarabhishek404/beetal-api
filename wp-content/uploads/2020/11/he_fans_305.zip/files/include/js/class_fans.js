
/**
 * @author Eldar
 * @copyright Hire-Experts LLC
 * @version Fans 3.1
 */

var Fans = {
	
	fans_owner_id : false,
	
	fans_id : false,
	
	user_id : 0,
	
	fans_type : '',
	
	processing : false,
	
	//methods
	initialize: function(fans_info) {
	    if( fans_info!=null ) {
	        this.init_controls(fans_info);
	    }
	    else {
            var self = this;
            var request = new Request.JSON({
                'url' : "fan_ajax.php",
                'method' : "post",
                'data' : {
                    'task' : 'initialize',
                    'fans_owner_id' : self.fans_owner_id,
                    'fans_id' : self.fans_id,
                    'fans_type' : self.fans_type
                },
                'onComplete' : function(response) {
                    self.init_controls(response.info);
                }
            }).send();
	    }
    },
	
	leave: function() {
        if( this.processing ) return false;
        
        var self = this;
        this.processing = true;
        var request = new Request.JSON({
            'url' : "fan_ajax.php",
            'method' : "post",
            'data' : {
                'task' : 'leave',
                'fans_owner_id' : self.fans_owner_id,
                'fans_id' : self.fans_id,
                'fans_type' : self.fans_type
            },
            'onComplete' : function(response) {
                if ( response.status )
                    self.init_controls(response.info);
                
                self.processing = false;
            }
        }).send();
	},
	
	join: function() {
        if( this.processing ) return false;
        
        var self = this;
        this.processing = true;
        var request = new Request.JSON({
            'url' : "fan_ajax.php",
            'method' : "post",
            'data' : {
                'task' : 'join',
                'fans_owner_id' : self.fans_owner_id,
                'fans_id' : self.fans_id,
                'fans_type' : self.fans_type
            },
            'onComplete' : function(response) {
                if ( response.status )
                    self.init_controls(response.info);
                
                self.processing = false;
            }
        }).send();
	},
	
    create_fan_club : function() {
        if( this.processing ) return false;
        
        var self = this;
        this.processing = true;
        var request = new Request.JSON({
            'url' : "fan_ajax.php",
            'method' : "post",
            'data' : {
                'task' : 'create_fan_club',
                'fans_owner_id' : self.fans_owner_id,
                'fans_id' : self.fans_id,
                'fans_type' : self.fans_type
            },
            'onComplete' : function(response) {
                if (response.status)
                    self.init_controls(response.info);
                
                self.processing = false;
            }
        }).send();
    },
	
    enable_fan_club : function() {
        if( this.processing ) return false;
        
        var self = this;
        this.processing = true;
        var request = new Request.JSON({
            'url' : "fan_ajax.php",
            'method' : "post",
            'data' : {
                'task' : 'enable_fan_club',
                'fans_owner_id' : self.fans_owner_id,
                'fans_id' : self.fans_id,
                'fans_type' : self.fans_type
            },
            'onComplete' : function(response) {
                if (response.status)
                    self.init_controls(response.info);
                
                self.processing = false;
            }
        }).send();
    },
	
    disable_fan_club : function() {
        if( this.processing ) return false;
        
        var self = this;
        this.processing = true;
        var request = new Request.JSON({
            'url' : "fan_ajax.php",
            'method' : "post",
            'data' : {
                'task' : 'disable_fan_club',
                'fans_owner_id' : self.fans_owner_id,
                'fans_id' : self.fans_id,
                'fans_type' : self.fans_type
            },
            'onComplete' : function(response) {
                if (response.status)
                    self.init_controls(response.info);
                
                self.processing = false;
            }
        }).send();
    },
	
	init_controls: function(fans_info) {
        //if user is owner or not
        this.hide_all_control();
        
        if (!fans_info || !fans_info.level_fans_allow) {
                return false;
        }
        
        if ( this.user_id==this.fans_owner_id ) {
            if ( !fans_info.fan_exists ) { //fan club should be created
                if( fans_info.level_fans_allow )
                    this.show_control('create');
            }
            else {
                if( fans_info.status ) { //enable/disable fan club
                    
                    if( fans_info.level_fans_allow ) {
                        this.show_control('disable');
                    
                        //fan box code
                        this.show_control('html');
                    }
                    
                    //suggest form
                    this.show_control('suggest');
                    
                    //send mass message box
                    if ( fans_info.total_fans > 0 && fans_info.level_fans_allow ) {
                        this.show_control('mass_message');
                    }
                }
                else if( fans_info.level_fans_allow ){
                    this.show_control('enable');
                }
            }
        }
        else if( fans_info.fan_exists && fans_info.status ) {//user can join/leave if fan club is enabled
            if( fans_info.is_fan ) {
                this.show_control('leave');
            }
            else {
                this.show_control('join');
            }
            
            //suggest form
            this.show_control('suggest');
        }
	},
	
    show_control : function(key) {
        $('fans_menu_' + key + '_' + this.fans_id).style.display = '';
    },
	
    hide_control : function(key) {
        $('fans_menu_' + key + '_' + this.fans_id).style.display = 'none';
    },
    
    hide_all_control : function() {
        $('fans_menu_join_' + this.fans_id).style.display = 'none';
        $('fans_menu_leave_' + this.fans_id).style.display = 'none';
        $('fans_menu_create_' + this.fans_id).style.display = 'none';
        $('fans_menu_enable_' + this.fans_id).style.display = 'none';
        $('fans_menu_disable_' + this.fans_id).style.display = 'none';
        $('fans_menu_suggest_' + this.fans_id).style.display = 'none';
        $('fans_menu_html_' + this.fans_id).style.display = 'none';
        $('fans_menu_mass_message_' + this.fans_id).style.display = 'none';
    }
}