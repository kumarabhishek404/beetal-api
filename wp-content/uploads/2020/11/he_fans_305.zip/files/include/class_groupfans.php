<?php

/**
 * @author Vadim
 * @copyright Hire-Experts LLC
 * @version Fans 3.1
 */

class se_groupfans extends se_fans 
{
    function se_groupfans($fans_id, $fans_owner_id)
    {
        parent::se_fans($fans_id, 'group', $fans_owner_id);
    }
    
    function get_title()
    {
        $group = $this->get_group();
        return $group->group_info['group_title'];
    }
    function get_photo()
    {
        $group = $this->get_group();
        $group_photo=$group->group_photo("./images/nophoto.gif",true);
        return $group_photo;
    }
    function get_url()
    {
        global $url;
        $url_all="group.php?group_id={$this->fans_id}";
        return $url_all;
    }

    function get_group()
    {
        static $group;
        if( !$group ) {
            $group =& new se_group($this->fans_owner_id, $this->fans_id);
        }
        
        return $group;
    }


    function get_user_fan_clubs($user_id) {
        global $url;
        
        $user_id = intval($user_id);
        $clubs = array();
        $res = he_database::query("SELECT se_fans.*, club.*  FROM se_fans ".
           "INNER JOIN se_fan_club as club ON (club.id = se_fans.fans_club_id) ".
           "WHERE club.type='group' AND se_fans.fans_user_id=$user_id");
        
        while ($club = he_database::fetch_row_from_resource($res)) {
            $group = new se_group(NULL, $club['fans_id']);
            
            $club['url'] = $url->url_create('group', NULL, $group->group_info['group_id']);
            $club['title'] = $group->group_info['group_title'];
            $club['photo'] = $group->group_photo("./images/nophoto.gif", true);
            $clubs[] = $club;
        }
        return $clubs;
    }

    function get_user_suggestions($user_id) {
        global $url;

        $sql = he_database::placeholder( "SELECT suggest.*, club.*, u.user_username, u.user_fname, u.user_lname, u.user_photo ". 
            "FROM se_fans_suggest as suggest ".
            "INNER JOIN se_fan_club as club ON ( club.id = suggest.suggest_club_id ) ".
            "INNER JOIN se_users as u ON( u.user_id = suggest.suggest_user_from ) ".
            "WHERE club.type = 'group' AND suggest.suggest_user_to = ?", $user_id );
        $res = he_database::query($sql);

        $clubs = array();
        while( $club = he_database::fetch_row_from_resource($res) ) {
            //fan club
            $group = new se_group(NULL, $club['fans_id']);
            $club['url'] = $url->url_create('group', NULL, $group->group_info['group_id']);
            $club['title'] = $group->group_info['group_title'];
            $club['photo'] = $group->group_photo("./images/nophoto.gif", true);
            
            //suggestor
            $suggestor = new se_user();
            $suggestor->user_info['user_id'] = $club['suggest_user_from'];
            $suggestor->user_info['user_username'] = $club['user_username'];
            $suggestor->user_info['user_fname'] = $club['user_fname'];
            $suggestor->user_info['user_lname'] = $club['user_lname'];
            $suggestor->user_info['user_photo'] = $club['user_photo'];
            $suggestor->user_displayname();
            $club['suggestor'] = $suggestor;
            
            $clubs[] = $club;
        }
        return $clubs;
    }

}
?>