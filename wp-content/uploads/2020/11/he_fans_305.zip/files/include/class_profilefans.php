<?php

/**
 * @author Eldar
 * @copyright Hire-Experts LLC
 * @version Fans 3.1
 */

class se_profilefans extends se_fans {
    
    function se_profilefans($fans_id, $fans_owner_id ) {
        parent::se_fans($fans_id, 'profile', $fans_owner_id);
    }
    
    function get_title() {
        $user = $this->get_user();
        return $user->user_info["user_displayname"];
    }
    
    function get_photo() {    
        $user = $this->get_user();
        return $user->user_photo("./images/nophoto.gif",true);
    }
    
    function get_url() {
        global $url;
        $user = $this->get_user();
        return $url->url_create('profile', $user->user_info['user_username']);
    }
    
    function get_user_fan_clubs($user_id) {
        global $url;
        
        $user_id = intval($user_id);
        $clubs = array();
        $res = he_database::query("SELECT se_fans.*, club.*, u.user_username, u.user_fname, u.user_lname, u.user_photo ".
           "FROM se_fans ".
           "INNER JOIN se_fan_club as club ON (club.id=se_fans.fans_club_id) ".
           "INNER JOIN se_users as u ON(u.user_id=club.fans_id) ".
           "WHERE club.type='profile' AND se_fans.fans_user_id=$user_id");
        
        while ($club = he_database::fetch_row_from_resource($res)) {
            $profile = new se_user();
            $profile->user_info['user_id'] = $club['fans_id'];
            $profile->user_info['user_username'] = $club['user_username'];
            $profile->user_info['user_fname'] = $club['user_fname'];
            $profile->user_info['user_lname'] = $club['user_lname'];
            $profile->user_info['user_photo'] = $club['user_photo'];
            $profile->user_displayname();
            
            $club['url'] = $url->url_create('profile', $profile->user_info['user_username']);
            $club['title'] = $profile->user_displayname;
            $club['photo'] = $profile->user_photo("./images/nophoto.gif", true);
            $clubs[] = $club;
        }
        
        return $clubs;
    }
    
    function get_user_suggestions($user_id) {
        global $url;
    
        $sql = he_database::placeholder( "SELECT suggest.*, club.*, u.user_username, u.user_fname, u.user_lname, u.user_photo, u2.user_username as user_username2, u2.user_fname as user_fname2, u2.user_lname as user_lname2, u2.user_photo as user_photo2 ". 
            "FROM se_fans_suggest as suggest ".
            "INNER JOIN se_fan_club as club ON ( club.id = suggest.suggest_club_id ) ".
            "INNER JOIN se_users as u2 ON( u2.user_id = club.fans_id ) ".
            "INNER JOIN se_users as u ON( u.user_id = suggest.suggest_user_from ) ".
            "WHERE club.type = 'profile' AND suggest.suggest_user_to = ?", $user_id );
        $res = he_database::query($sql);
        $clubs = array();
        while( $club = he_database::fetch_row_from_resource($res) ) {
            //fan club
            $profile = new se_user();
            $profile->user_info['user_id'] = $club['fans_id'];
            $profile->user_info['user_username'] = $club['user_username2'];
            $profile->user_info['user_fname'] = $club['user_fname2'];
            $profile->user_info['user_lname'] = $club['user_lname2'];
            $profile->user_info['user_photo'] = $club['user_photo2'];
            $profile->user_displayname();
            $club['url'] = $url->url_create('profile', $profile->user_info['user_username']);
            $club['title'] = $profile->user_displayname;
            $club['photo'] = $profile->user_photo("./images/nophoto.gif", true);
            
            //suggestor
            $suggestor = new se_user();
            $suggestor->user_info['user_id'] = $club['suggest_user_from'];
            $suggestor->user_info['user_username'] = $club['user_username'];
            $suggestor->user_info['user_fname'] = $club['user_fname'];
            $suggestor->user_info['user_lname'] = $club['user_lname'];
            $suggestor->user_info['user_photo'] = $club['user_photo'];
            $suggestor->user_displayname();
            $club['suggestor'] = $suggestor;
            
            $clubs[] = $club;
        }
        
        return $clubs;
    }
    
    function get_user() {
        static $user;
        if( !$user ) {
            $user =& new se_user(array(0=>$this->fans_id));
        }
        
        return $user;
    }
    
}

?>