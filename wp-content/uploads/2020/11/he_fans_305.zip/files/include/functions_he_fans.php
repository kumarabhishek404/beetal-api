<?php

/**
 * @author Eldar
 * @copyright Hire-Experts LLC
 * @version Fans 3.1
 */

function he_fans_delete_user( $user_id ) {
    if ( !$user_id ) {
        return false;
    }

    $sql = he_database::placeholder("SELECT id FROM `se_fan_club` WHERE `owner_id`=?", $user_id);
    $res = he_database::query($sql);
    while( $club = he_database::fetch_row_from_resource($res) ) {
        he_database::query( he_database::placeholder("DELETE FROM `se_fans` WHERE `fans_club_id`=?", $club['id']) );
        he_database::query( he_database::placeholder("DELETE FROM `se_fans_suggest` WHERE `suggest_club_id`=?", $club['id']) );
    }
    
    $sql = he_database::placeholder("DELETE FROM `se_fans` WHERE `fans_user_id`=?", $user_id);
    $res = he_database::query($sql);
    
    $sql = he_database::placeholder("DELETE FROM `se_fans_suggest` WHERE `suggest_user_to`=? OR `suggest_user_from`=?", $user_id, $user_id);
    $res = he_database::query($sql);

    $sql = he_database::placeholder("DELETE FROM `se_fan_club` WHERE `owner_id`=?", $user_id);
    he_database::query($sql);
}


function he_fans_delete_group( $group_id ) {
    if ( !$group_id ) {
        return false;
    }

    $sql = he_database::placeholder("SELECT id FROM `se_fan_club` WHERE `type`='group' AND `fans_id`=?", $group_id);
    $club_id = he_database::fetch_field($sql);
    
    he_database::query( he_database::placeholder("DELETE FROM `se_fans` WHERE `fans_club_id`=?", $club_id) );
    he_database::query( he_database::placeholder("DELETE FROM `se_fans_suggest` WHERE `suggest_club_id`=?", $club_id) );
    
    $sql = he_database::placeholder("DELETE FROM `se_fan_club` WHERE `id`=?", $club_id);
    he_database::query($sql);
}


function he_fans_delete_page( $page_id ) {
    if ( !$page_id ) {
        return false;
    }

    $sql = he_database::placeholder("SELECT id FROM `se_fan_club` WHERE `type`='pages' AND `fans_id`=?", $page_id);
    $club_id = he_database::fetch_field($sql);
    
    he_database::query( he_database::placeholder("DELETE FROM `se_fans` WHERE `fans_club_id`=?", $club_id) );
    he_database::query( he_database::placeholder("DELETE FROM `se_fans_suggest` WHERE `suggest_club_id`=?", $club_id) );
    
    $sql = he_database::placeholder("DELETE FROM `se_fan_club` WHERE `id`=?", $club_id);
    he_database::query($sql);
}


function get_formatted_fan_js_for_current_user($fan) {
    global $user;
    if( !is_object($fan) ) return null;

    $owner = new se_user(array($fan->fans_owner_id));
    
    if (!$owner || !$owner->user_exists) {
        return array();
    }
    
    if ($fan->fans_type == 'profile') {
        $level_fans_allow = (bool)$owner->level_info["level_fans_allow"];
    } elseif ($fan->fans_type == 'group') {
        $level_fans_allow = (bool)$owner->level_info["level_fans_group_allow"];
    } elseif($fan->fans_type == 'pages') {
        $level_fans_allow = (bool)$owner->level_info["level_fans_page_allow"];
    } else {
        $level_fans_allow = true;
    }

    return array(
        'fan_exists' => $fan->is_club(),
        'status' => $fan->is_club_enabled(),
        'is_fan' => $fan->is_fan($user->user_info['user_id']),
        'total_fans' => $fan->total_fans(),
        'fans_title' => $fan->get_title(),
        'level_fans_allow' => $level_fans_allow
    );
}


function he_fans_group_integration() {

    global $smarty;

    $group_id = (int)$_GET['group_id'];
    $group_owner_id = he_database::fetch_field("SELECT `group_user_id` FROM `se_groups` WHERE `group_id`=".$group_id);

    $fan = new se_groupfans($group_id, $group_owner_id);
    $smarty->assign_by_ref("fan", $fan);
    
    $smarty->assign('fan_js', json_encode(get_formatted_fan_js_for_current_user($fan)));

    if (isset($_GET['v']) && $_GET['v'] == 'fans') {
        $smarty->assign('group_fans_show_tab', true);
    }

    $smarty->assign('group_fans_tab', true);

    $fans_paging = array();
    $fans_paging['on_page'] = 24; // TODO get from settings
    $fans_paging['start'] = (isset($_GET['page']) && $_GET['page']) ? ((int)$_GET['page'] - 1) * $fans_paging['on_page'] : 0;
    $fans_paging['total'] = $fan->total_fans;
    $fans_paging['request_uri'] = $url->url_base . "group.php?group_id=" . $group_id . '&v=fans';

    $smarty->assign('fans_paging', $fans_paging);

}


?>