<?php

/**
 * @author Vadim
 * @copyright Hire-Experts LLC
 * @version Fans 3.1
 */

class se_pagesfans extends se_fans {
    
    function se_pagesfans($fans_id, $fans_owner_id ) {
        parent::se_fans($fans_id, 'pages', $fans_owner_id);
    }
    
    function get_title()
    {
        $page = $this->get_page();
        return $page->page_info["pages_title"];    
    }
    
    function get_photo()
    {    
        $page = $this->get_page();
        return $page->pages_photo();
    }
    
    function get_url()
    {
        global $url;
        $page = $this->get_page();
        return $page->page_info['pages_url'];
    }
    
    function get_user_fan_clubs($user_id) {
        global $url;
        
        $user_id = intval($user_id);
        $clubs = array();
        $res = he_database::query("SELECT se_fans.*, club.*  FROM se_fans ".
           "INNER JOIN se_fan_club as club ON (club.id = se_fans.fans_club_id) ".
           "WHERE club.type='pages' AND se_fans.fans_user_id=$user_id");
        
        while ($club = he_database::fetch_row_from_resource($res)) {
            $page = new he_pages($club['fans_id'], 0, false);
            
            $club['url'] = $url->url_base."pages.php?pages_id={$club['fans_id']}";
            $club['title'] = $page->page_info['pages_title'];
            $club['photo'] = $page->pages_photo();
            $clubs[] = $club;
        }
        return $clubs;
    }
    
    function get_user_suggestions($user_id) {
        global $url;
    
        $sql = he_database::placeholder( "SELECT suggest.*, club.*, u.user_username, u.user_fname, u.user_lname, u.user_photo ". 
            "FROM se_fans_suggest as suggest ".
            "INNER JOIN se_fan_club as club ON ( club.id = suggest.suggest_club_id ) ".
            "INNER JOIN se_users as u ON( u.user_id = suggest.suggest_user_from ) ".
            "WHERE club.type = 'pages' AND suggest.suggest_user_to = ?", $user_id );
        $res = he_database::query($sql);
        $clubs = array();
        while( $club = he_database::fetch_row_from_resource($res) ) {
            $page = new he_pages($club['fans_id'], 0, false);
            
            $club['url'] = $url->url_base."pages.php?pages_id={$club['fans_id']}";
            $club['title'] = $page->page_info['pages_title'];
            $club['photo'] = $page->pages_photo();
            
            $suggestor = new se_user();
            $suggestor->user_info['user_id'] = $club['suggest_user_from'];
            $suggestor->user_info['user_username'] = $club['user_username'];
            $suggestor->user_info['user_fname'] = $club['user_fname'];
            $suggestor->user_info['user_lname'] = $club['user_lname'];
            $suggestor->user_info['user_photo'] = $club['user_photo'];
            $suggestor->user_displayname();
            $club['suggestor'] = $suggestor;
            
            $clubs[] = $club;
        }
        
        return $clubs;
    }
    
    function get_page() {
        static $page;
        if( !$page ) {
            $page =& new he_pages($this->fans_id);
        }
        
        return $page;
    }
}
?>