<?php

/**
 * @author Eldar
 * @copyright Hire-Experts LLC
 * @version Fans 3.1
 */

$page = "user_fans";
include("header.php");

if(isset($_POST['tab'])) { $tab = $_POST['tab']; } elseif(isset($_GET['tab'])) { $tab = $_GET['tab']; } else { $tab = 'fans'; }
if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = ''; }

//handle POST datas:
if ($task == 'leave_fan') {
    if ( $_GET['fan_type']=='profile' || $_GET['fan_type']=='group' || $_GET['fan_type']=='pages' ) {

        $fan_type = $_GET['fan_type'];
        $fans_id = $_GET['fans_id'];

        $fan = new se_fans( $fans_id, $fan_type );

        if( $fan ) {
          $fan->leave_fan_club($user->user_info['user_id']);
        }
    }
}
elseif ($task == 'join_fan') {
    $suggest = se_fans::get_suggest($_GET['suggest_id'], $user->user_info['user_id']);

    switch ($suggest['type']) {
        case 'profile':
            $fans = new se_profilefans($suggest['fans_id'], $suggest['owner_id']);
        break;
        
        case 'pages':
            $fans = new se_pagesfans($suggest['fans_id'], $suggest['owner_id']);
        break;
        
        case 'group':
            $fans = new se_groupfans($suggest['fans_id'], $suggest['owner_id']);
        break;
        
        default:
    $fans = new se_fans( $suggest['fans_id'], $suggest['type'] );
        break;
    }
    
    $fans->join_fan_club($user->user_info['user_id']);

    se_fans::remove_suggest($_GET['suggest_id'], $user->user_info['user_id']);
}
elseif ($task == 'decline_fan') {
    se_fans::remove_suggest($_GET['suggest_id'], $user->user_info['user_id']);
}




switch ($tab) {
    case 'fans':
        $fans_type = array();
        $fans_type['profile'] = se_profilefans::get_user_fan_clubs($user->user_info['user_id']);
        $fans_type['pages'] = se_pagesfans::get_user_fan_clubs($user->user_info['user_id']);
        $fans_type['group'] = se_groupfans::get_user_fan_clubs($user->user_info['user_id']);

        $smarty->assign_by_ref("fans_type", $fans_type);
    break;

    case 'invite':
    break;

    case 'invited':
        //DELETE NOTIFYS
        se_fans::delete_notify($user->user_info['user_id']);

        $fans_type['profile'] = se_profilefans::get_user_suggestions($user->user_info['user_id']);
        $fans_type['pages'] = se_pagesfans::get_user_suggestions($user->user_info['user_id']);
        $fans_type['group'] = se_groupfans::get_user_suggestions($user->user_info['user_id']);

        $smarty->assign_by_ref("fans_type", $fans_type);
    break;
}


$total_invites = se_fans::total_user_suggest($user->user_info['user_id']);

$smarty->assign("tab",$tab);
$smarty->assign("total_invites",$total_invites);

include("footer.php");
?>