<?php

/**
 * @author Eldar
 * @copyright Hire-Experts LLC
 * @version Fans 3.1
 */

defined('SE_PAGE') or exit();

include_once "./header_he_core.php";
include_once "./include/class_fans.php";
include_once "./include/class_profilefans.php";
include_once "./include/class_groupfans.php";
include_once "./include/class_pagesfans.php";
include_once "./include/functions_he_fans.php";

if (isset($global_plugins['he_pages'])) {
    include_once "./include/class_he_pages.php";
}

if ($user->user_exists) {
    //USER APPS MENU
    $plugin_vars['menu_user'] = array(
        'file' => 'user_fans.php', 
        'icon' => 'he_fans_icon16.png', 
        'title' => 690790050
    );
}

// Use new template hooks
if (is_a($smarty, 'SESmarty')) {
    
    if (!empty($plugin_vars['menu_user'])) {
        $smarty->assign_hook('menu_user_apps', $plugin_vars['menu_user']);
    }
    
}


//SET MENU VARS
if ($page == 'profile') {

    $fan = new se_profilefans($owner->user_info["user_id"], $owner->user_info["user_id"]);
    $smarty->assign_by_ref("fan", $fan);
    
    $fans_paging = array();
    $fans_paging['on_page'] = 24; // TODO get from settings
    $fans_paging['start'] = (isset($_GET['page']) && $_GET['page']) ? ((int)$_GET['page'] - 1) * $fans_paging['on_page'] : 0;
    $fans_paging['total'] = $fan->total_fans;
    $fans_paging['request_uri'] = $url->url_base . "profile.php?user=" . $owner->user_info['user_username'] . '&v=he_fans';

    $smarty->assign('fans_paging', $fans_paging);

    $smarty->assign('fan_js', json_encode(get_formatted_fan_js_for_current_user($fan)));

    if ($fan->is_club_enabled()) {
        $plugin_vars['menu_profile_tab'] = Array('file'=> 'fans_tab.tpl', 'title' => 690790006);
    }

    $smarty->assign('fans_club_available');
}

elseif ($page == "pages") {
    
    $pages = new he_pages($_GET['pages_id'], 0, FALSE);
    $fan = new se_pagesfans($pages->page_info['pages_id'],$pages->page_info['pages_owner_id']);
    unset($pages);
    
    $fans_paging = array();
    $fans_paging['on_page'] = 24; // TODO get from settings
    $fans_paging['tab_name'] = false;
    $fans_paging['start'] = (isset($_GET['page']) && $_GET['page']) ? ((int)$_GET['page'] - 1) * $fans_paging['on_page'] : 0;
    $fans_paging['total'] = $fan->total_fans;
    $fans_paging['request_uri'] = $url->url_base . "pages.php?pages_id=" . $fan->fans_id . '&tab_id=fans';

    $smarty->assign('fans_paging', $fans_paging);

    $smarty->assign('fan_js', json_encode(get_formatted_fan_js_for_current_user($fan)));
    $smarty->assign_by_ref("fan", $fan);
}

elseif ($page == "user_home" ) {
    
    $fan_info = se_fans::get_fan_ad($user->user_info["user_id"]);
    switch ($fan_info['type']) {
        case 'profile' :
            $fan_ad = new se_profilefans($fan_info['fans_id'], $fan_info['owner_id']);
            break;
        case 'pages' :
            $fan_ad = new se_pagesfans($fan_info['fans_id'], $fan_info['owner_id']);
            break;
        case 'group' :
            $fan_ad = new se_groupfans($fan_info['fans_id'], $fan_info['owner_id']);
            break;
    }
    
    if ( $fan_ad ) {
        $smarty->assign_by_ref("fan_ad", $fan_ad);
        $plugin_vars['menu_userhome'] = array('file'=> 'fans_ad.tpl');
    }
}

elseif ($page == "group" ) {
    SE_Hook::register("se_footer", 'he_fans_group_integration');
}

//keep fans database clear
SE_Hook::register("se_user_delete", 'he_fans_delete_user');
$task = ( !$task && isset($_POST['task']) ) ? $_POST['task'] : $task;

if ( $page == 'user_group_edit' && $task == 'delete_do' ) {
    $group_id = isset($_POST['group_id']) ? (int)$_POST['group_id'] : 0;
    he_fans_delete_group($group_id);
}


$smarty->assign("page", $page);
?>