<?php

$plugin_name = "Fans Plugin";
$plugin_version = "3.05";
$req_core_version = "3.02";
$plugin_type = "he_fans";
$plugin_desc = "This plugin allows your users to create own fans club for profile, groups and page; users can become fan. It groups small communities around famous peoples/stars/politics and by interest(groups/fan clubs, etc).";
$plugin_icon = "he_fans_icon16.png";
$plugin_menu_title = "0";    
$plugin_pages_main = "";
$plugin_pages_level = "690790023<!>admin_levels_fanssettings.php<~!~>";
$plugin_url_htaccess = "";
$plugin_db_charset = 'utf8';
$plugin_db_collation = 'utf8_unicode_ci';


if ($install == "he_fans")
{
    //check core library
    $sql = "SELECT `plugin_version` FROM `se_plugins` WHERE plugin_type='he_core' AND `plugin_disabled`=0 LIMIT 1";
    $resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
    $core_version = $database->database_fetch_array($resource);
    if ( floatval($core_version[0]) < floatval($req_core_version) ) {
        die ('This plugin requires Hire-Experts Core Library. Please install latest version of Hire-Experts Core Library plugin. You can download it from My Plugins section in Hire-Experts.com for FREE.');
    }

  //######### INSERT ROW INTO se_plugins
  if($database->database_num_rows($database->database_query("SELECT plugin_id FROM se_plugins WHERE plugin_type='$plugin_type'")) == 0) {
    $database->database_query("INSERT INTO se_plugins (plugin_name,
                    plugin_version,
                    plugin_type,
                    plugin_desc,
                    plugin_icon,
                    plugin_menu_title,
                    plugin_pages_main,
                    plugin_pages_level,
                    plugin_url_htaccess
                    ) VALUES (
                    '$plugin_name',
                    '$plugin_version',
                    '$plugin_type',
                    '".str_replace("'", "\'", $plugin_desc)."',
                    '$plugin_icon',
                    '$plugin_menu_title',
                    '$plugin_pages_main',
                    '$plugin_pages_level',
                    '$plugin_url_htaccess')");
  }
  
  //######### UPDATE PLUGIN VERSION IN se_plugins
  else
  {
    $database->database_query("UPDATE se_plugins SET plugin_name='$plugin_name',
                    plugin_version='$plugin_version',
                    plugin_desc='".str_replace("'", "\'", $plugin_desc)."',
                    plugin_icon='$plugin_icon',
                    plugin_menu_title='$plugin_menu_title',
                    plugin_pages_main='$plugin_pages_main',
                    plugin_pages_level='$plugin_pages_level',
                    plugin_url_htaccess='$plugin_url_htaccess' WHERE plugin_type='$plugin_type'");
  }
    
    //######## ADDD COLUMNS/VALUES TO se_usersettings
    $sql = "SHOW COLUMNS FROM `".$database_name."`.`se_usersettings` LIKE 'usersetting_notify_fans_invitation'";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
     
    if ( !$database->database_num_rows($resource) )
    {
        $sql = "ALTER TABLE `se_usersettings` ADD COLUMN `usersetting_notify_fans_invitation` TINYINT(1) NOT NULL DEFAULT '1'";
          $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql); 
    }

    
    
    //######### ADD VALUES TO SYSTEM EMAILS TABLE
    $fans_system_emails = array();
    
    $fans_system_emails[] = array(
        'systememail_name' => 'fans_invitation', 
        'systememail_title' => '690790051', 
        'systememail_desc' => '690790052', 
        'systememail_subject' => '690790053', 
        'systememail_body' => '690790054', 
        'systememail_vars' => '[displayname],[sender],[link]', 
    );
    
    foreach ( $fans_system_emails as $fans_system_email )
    {
        $res = $database->database_query("SELECT `systememail_id` FROM `se_systememails`
            WHERE `systememail_name`='{$fans_system_email['systememail_name']}' LIMIT 1");
        
        $systememail = $database->database_fetch_assoc($res);
        $systememail_id = (int)$systememail['systememail_id'];

        if ( $systememail_id == 0 )
        {
            $sql = "INSERT INTO `se_systememails`
                (
                  `systememail_name`,
                  `systememail_title`,
                  `systememail_desc`,
                  `systememail_subject`,
                  `systememail_body`,
                  `systememail_vars`
                )
                VALUES (
                  '{$fans_system_email['systememail_name']}',
                  {$fans_system_email['systememail_title']},
                  {$fans_system_email['systememail_desc']},
                  {$fans_system_email['systememail_subject']},
                  {$fans_system_email['systememail_body']},
                  '{$fans_system_email['systememail_vars']}'
                )";

            $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
            
            $systememail_id = $database->database_insert_id();
        }
        else
        {
            $sql = "UPDATE `se_systememails`
                SET 
                  `systememail_title`={$fans_system_email['systememail_title']},
                  `systememail_desc`={$fans_system_email['systememail_desc']},
                  `systememail_subject`={$fans_system_email['systememail_subject']},
                  `systememail_body`={$fans_system_email['systememail_body']},
                  `systememail_vars`='{$fans_system_email['systememail_vars']}'
                WHERE `systememail_name`='{$fans_system_email['systememail_name']}'";

            $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
        }
    }

    
    //######### ADD VALUES TO NOTIFY TYPES TABLE
    $fans_notify_types = array();
    
    $fans_notify_types[] = array(
        'notifytype_name' => 'fans_invitation',
        'notifytype_desc' => '690790055',
        'notifytype_icon' => 'he_fans_icon16.png',
        'notifytype_url' => 'user_fans.php?tab=invited',
        'notifytype_title' => '690790056',
        'notifytype_group' => 1
    );
    
    foreach ( $fans_notify_types as $fans_notify_type )
    {
        $res = $database->database_query("SELECT `notifytype_id` FROM `se_notifytypes`
            WHERE `notifytype_name`='{$fans_notify_type['notifytype_name']}' LIMIT 1");
        
        $notify_type = $database->database_fetch_assoc($res);
        $notify_type_id = (int)$notify_type['notifytype_id'];

        if ( $notify_type_id == 0 )
        {
            $sql = "INSERT INTO `se_notifytypes`
                (
                  `notifytype_name`,
                  `notifytype_desc`,
                  `notifytype_icon`,
                  `notifytype_url`,
                  `notifytype_title`,
                  `notifytype_group`
                )
                VALUES (
                  '{$fans_notify_type['notifytype_name']}',
                  {$fans_notify_type['notifytype_desc']},
                  '{$fans_notify_type['notifytype_icon']}',
                  '{$fans_notify_type['notifytype_url']}',
                  {$fans_notify_type['notifytype_title']},
                  {$fans_notify_type['notifytype_group']}
                )";

            $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
            
            $notify_type_id = $database->database_insert_id();
        }
        else
        {
            $sql = "UPDATE `se_notifytypes`
                SET 
                  `notifytype_desc`={$fans_notify_type['notifytype_desc']},
                  `notifytype_icon`='{$fans_notify_type['notifytype_icon']}',
                  `notifytype_url`='{$fans_notify_type['notifytype_url']}',
                  `notifytype_title`={$fans_notify_type['notifytype_title']},
                  `notifytype_group`={$fans_notify_type['notifytype_group']}
                WHERE `notifytype_name`='{$fans_notify_type['notifytype_name']}'";

            $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
        }
    }
    

    //######### ADD VALUES TO ACTION TYPES TABLE
    $fans_action_types = array();

    $fans_action_types[] = array(
        'actiontype_name' => 'become_fan',
        'actiontype_icon' => 'he_fans_enable.png',
        'actiontype_setting' => '1',
        'actiontype_enabled' => '1',
        'actiontype_desc' => '690790057',
        'actiontype_text' => '690790058',
        'actiontype_vars' => '[username],[displayname],[fans_club]',
        'actiontype_media' => '0'
    );
    
    $sql = "ALTER TABLE `se_usersettings` CHANGE `usersetting_actions_display` `usersetting_actions_display` TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL";
    $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    
    foreach ( $fans_action_types as $fans_action_type )
    {
        $res = $database->database_query("SELECT `actiontype_id` FROM `se_actiontypes` 
            WHERE `actiontype_name`='{$fans_action_type['actiontype_name']}' LIMIT 1");

        $actiontype = $database->database_fetch_assoc($res);
        $actiontype_id = (int)$actiontype['actiontype_id'];

        if ( $actiontype_id == 0 )
        {
            $sql = "INSERT INTO `se_actiontypes`
                (
                  `actiontype_name`,
                  `actiontype_icon`,
                  `actiontype_setting`,
                  `actiontype_enabled`,
                  `actiontype_desc`,
                  `actiontype_text`,
                  `actiontype_vars`,
                  `actiontype_media`
                )
                VALUES (
                  '{$fans_action_type['actiontype_name']}',
                  '{$fans_action_type['actiontype_icon']}',
                  {$fans_action_type['actiontype_setting']},
                  {$fans_action_type['actiontype_enabled']},
                  {$fans_action_type['actiontype_desc']},
                  {$fans_action_type['actiontype_text']},
                  '{$fans_action_type['actiontype_vars']}',
                  {$fans_action_type['actiontype_media']}
                )";

             $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);

            $actiontype_id = $database->database_insert_id();
        }
        else
        {
            $sql = "UPDATE `se_actiontypes`
                SET 
                  `actiontype_icon`='{$fans_action_type['actiontype_icon']}',
                  `actiontype_setting`='{$fans_action_type['actiontype_setting']}',
                  `actiontype_enabled`='{$fans_action_type['actiontype_enabled']}',
                  `actiontype_desc`='{$fans_action_type['actiontype_desc']}',
                  `actiontype_text`='{$fans_action_type['actiontype_text']}',
                  `actiontype_vars`='{$fans_action_type['actiontype_vars']}',
                  `actiontype_media`='{$fans_action_type['actiontype_media']}'
                WHERE `actiontype_name`='{$fans_action_type['actiontype_name']}'";

            $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
        }

        
        if ( $actiontype_id )
        {
            $database->database_query("UPDATE `se_usersettings`
                SET `usersetting_actions_display` = CONCAT(`usersetting_actions_display`, ',', '" . $actiontype_id . "')");
        }
    }
    
    //######### ADD VALUES TO LANGS TABLE
    $he_languagevars = array
    (
        '690790000' => 'Fans Plugin',
        '690790001' => 'Fans Settings',
        '690790003' => 'Become a fan',
        '690790004' => 'Remove me from fans',
        '690790005' => '%1$s members joined %2$s fan club. Become a fan to be up to date %2$s fans news ',
        '690790006' => 'Fans',
        '690790007' => '%2$s members joined %1$s fan club',
        '690790008' => 'Add Fan Box to your site',
        '690790009' => 'Fan Box Widget',
        '690790010' => 'Copy the code below and paste it on your website:',
        '690790011' => 'Fan Box Preview:',
        '690790012' => 'hide myself from fans box',
        '690790013' => 'Fan Club',
        '690790014' => '%1$s members joined %2$s fan club ',
        '690790015' => 'View All',
        '690790016' => 'Send an Update to Fans',
        '690790017' => 'Using this simple form you can easily send message to all your fans.',
        '690790018' => 'Subject',
        '690790019' => 'There is no fans',
        '690790020' => 'Do you know about %1$s?',
        '690790021' => 'Disable your fan club',
        '690790022' => 'Enable a fan club',
        '690790023' => 'Fans Settings',
        '690790024' => 'Here you can manage fans level settings',
        '690790025' => 'Can users create fan clubs?',
        '690790026' => 'If set to yes, users can create profile fan clubs',
        '690790027' => 'Yes, users can create profile fan clubs',
        '690790028' => 'No, users cannot create profile fan clubs',
        '690790029' => 'Can users promote their fan clubs in user_home?',
        '690790030' => 'If set to yes, then it shows a random fan club in user home page so it makes easy owners to promote their fan club. Owners should not do anything - it is fully automated. If you do not like fan box on user home then just set to no for all users levels this setting.',
        '690790031' => 'Yes, users can promote their fan clubs',
        '690790032' => 'No, users cannot promote their fan clubs',
        '690790033' => 'You are fan of',
        '690790034' => 'Fan invitations (%1$s)',
        '690790035' => 'You are invite (%1$s)',
        '690790036' => 'You are fan of the following profiles:',
        '690790037' => 'You are fan of the following groups:',
        '690790038' => 'You are fan of the following pages:',
        '690790039' => 'You are invited to the following profiles:',
        '690790040' => 'You are invited to the following groups:',
        '690790041' => 'You are invited to the following pages:',
        '690790042' => 'Your message successfully has been sent.',
        '690790043' => 'You do not have any fan invitations',
        '690790044' => 'You are not in any fan club',
        '690790045' => 'You are fan',
        '690790046' => 'Suggest to friends',
        '690790047' => 'Accept',
        '690790048' => 'Decline',
        '690790049' => 'Invited by',
        '690790050' => 'My Fans',
        
        '690790051' => 'New fans club invitation',        
        '690790052' => 'This is the email that gets sent to a user when a new fans club invitation is sent',
        '690790053' => 'New fans club invitation',
        '690790054' => 'Hello %1$s, a new fans invitation has been sent by %2$s. Please click the following link to view it: %3$s',
        '690790055' => '%1$d New Fans Invitation(s)',
        '690790056' => 'When a new fans invitation is sent to me',
        '690790057' => 'Becoming a fan',
        '690790058' => '<a href="profile.php?user=%1$s">%2$s</a> became fan of %3$s',
    
        '690790059' => 'If set to yes, users can create group fan clubs',
        '690790060' => 'Yes, users can create group fan clubs',
        '690790061' => 'No, users cannot create group fan clubs',
        '690790062' => 'If set to yes, users can create page fan clubs',
        '690790063' => 'Yes, users can create page fan clubs',
        '690790064' => 'No, users cannot create page fan clubs'
    );
    
    foreach ($he_languagevars as $langvar_id => $langvar_value)
    {
        $sql = "SELECT `languagevar_id` FROM `se_languagevars`
           WHERE `languagevar_id`=$langvar_id AND `languagevar_language_id`=1";
        
        if ( $database->database_num_rows($database->database_query($sql)) == 0 )
        {
            $sql = "INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`)
                VALUES('$langvar_id', '1', '$langvar_value', 'fans')";
        }
        else
        {
            $sql = "UPDATE `se_languagevars` SET `languagevar_value`='$langvar_value', `languagevar_default`='fans'
                WHERE `languagevar_id`=$langvar_id AND `languagevar_language_id`=1";
        }
        
        $resource = $database->database_query($sql) or die("<b>Error: </b>" . $database->database_error() . "<br /><b>File: </b>" . __FILE__ . "<br /><b>Line: </b>" . __LINE__ . "<br /><b>Query: </b>" . $sql);
    }

    
    //CREATE MAIN TABLE se_fan_club
     if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE ' se_fan_club'")) == 0) 
     {
        $database->database_query("CREATE TABLE `se_fan_club` (
            `id` int(11) NOT NULL auto_increment,
            `type` varchar(255) NOT NULL,
            `fans_id` int(11) NOT NULL,
            `owner_id` int(11) NOT NULL,
            `active` tinyint(4) NOT NULL,
            `created_time` int(11) NOT NULL,
            PRIMARY KEY  (`id`),
            KEY `type` (`type`),
            KEY `fans_id` (`fans_id`)
            ) ENGINE=MyISAM DEFAULT CHARSET={$plugin_db_charset}
        ");
     }
     
     //CREATE TABLE se_fans
     if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE ' se_fans'")) == 0) 
     {
        $database->database_query("CREATE TABLE `se_fans` (
            `id` int(11) NOT NULL auto_increment,
            `fans_club_id` int(11) NOT NULL,
            `fans_user_id` int(11) NOT NULL,
            PRIMARY KEY  (`id`),
            KEY `fans_club_id` (`fans_club_id`)
            ) ENGINE=MyISAM CHARSET={$plugin_db_charset}
        ");
     }
     
     //CREATE TABLE se_fans_suggest
     if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE ' se_fans_suggest'")) == 0) 
     {
        $database->database_query("CREATE TABLE `se_fans_suggest` (
            `suggest_id` int(10) unsigned NOT NULL auto_increment,
            `suggest_user_to` int(10) unsigned NOT NULL,
            `suggest_user_from` int(10) unsigned NOT NULL,
            `suggest_club_id` int(10) unsigned NOT NULL,
            PRIMARY KEY  (`suggest_id`),
            KEY `suggest_user_to` (`suggest_user_to`)
            ) ENGINE=MyISAM DEFAULT CHARSET={$plugin_db_charset}
        ");
     }
     
     //ADD USER LEVEL RESTRICTION
     if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM `$database_name`.`se_levels` LIKE 'level_fans_allow'")) == 0) 
     {
        $database->database_query("ALTER TABLE `se_levels` ADD `level_fans_allow` TINYINT NOT NULL DEFAULT '1' ;");
     }
     
     if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM `$database_name`.`se_levels` LIKE 'level_fans_group_allow'")) == 0) 
     {
        $database->database_query("ALTER TABLE `se_levels` ADD `level_fans_group_allow` TINYINT NOT NULL DEFAULT '1' ;");
     }
     
     if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM `$database_name`.`se_levels` LIKE 'level_fans_page_allow'")) == 0) 
     {
        $database->database_query("ALTER TABLE `se_levels` ADD `level_fans_page_allow` TINYINT NOT NULL DEFAULT '1' ;");
     }
     
     if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM `$database_name`.`se_levels` LIKE 'level_fans_ad_allow'")) == 0) 
     {
        $database->database_query("ALTER TABLE `se_levels` ADD `level_fans_ad_allow` TINYINT NOT NULL DEFAULT '1' ;");
     }
}

?>