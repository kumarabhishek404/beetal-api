<?php

$page = "admin_levels_fanssettings";
include "admin_header.php";

if (isset($_POST['level_id'])) {
    $level_id = $_POST['level_id'];
} elseif(isset($_GET['level_id'])) {
    $level_id = $_GET['level_id'];
} else {
    $level_id = 0;
}

// VALIDATE LEVEL ID
$level = $database->database_query("SELECT * FROM se_levels WHERE level_id='$level_id'");
if($database->database_num_rows($level) != 1) { header("Location: admin_levels.php"); exit(); }
$level_info = $database->database_fetch_assoc($level);

// SET RESULT VARIABLE
$result = 0;

// SAVE CHANGES
if ($_POST) {
    $level_info['level_fans_allow'] = $_POST['level_fans_allow'];
    $level_info['level_fans_group_allow'] = $_POST['level_fans_group_allow'];
    $level_info['level_fans_page_allow'] = $_POST['level_fans_page_allow'];
    $level_info['level_fans_ad_allow'] = $_POST['level_fans_ad_allow'];

    $database->database_query("UPDATE se_levels SET "
        . "level_fans_allow={$level_info['level_fans_allow']}, "
        . "level_fans_group_allow={$level_info['level_fans_group_allow']}, "
        . "level_fans_page_allow={$level_info['level_fans_page_allow']}, "
        . "level_fans_ad_allow={$level_info['level_fans_ad_allow']} WHERE level_id='$level_id'");

    $result = 1;
}

$smarty->assign('result', $result);
$smarty->assign('level_info', $level_info);
include "admin_footer.php";
?>