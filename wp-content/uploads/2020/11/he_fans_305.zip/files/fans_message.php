<?php

/**
 * @author Eldar
 * @copyright Hire-Experts LLC
 * @version Fans 3.1
 */

$page="fans_message";

include("header.php");

$fan_id = ($_GET["fan"]) ? $_GET["fan"] : $_POST["fan"];
$fan_type = ($_GET["fan_type"]) ? $_GET["fan_type"] : $_POST["fan_type"];
$fan_owner_id = ($_GET["fan_owner_id"]) ? $_GET["fan_owner_id"] : $_POST["fan_owner_id"];

if (($fan_type == 'profile' && !$user->level_info['level_fans_allow'])
    || ($fan_type == 'group' && !$user->level_info['level_fans_group_allow'])
    || ($fan_type == 'pages' && !$user->level_info['level_fans_page_allow'])) {
    exit();
}

switch ($fan_type) {
    case "profile":
        $fan=new se_profilefans($fan_id,$fan_owner_id);
    break;

    case "group":
        $fan=new se_groupfans($fan_id,$fan_owner_id);
    break;

    case "pages":
        $fan=new se_pagesfans($fan_id,$fan_owner_id);
    break;
}

$fan->get_fans();

if ($_POST) {
    $message = nl2br(htmlspecialchars_decode($_POST['body'], ENT_QUOTES));
    $subject = htmlspecialchars_decode($_POST['subject'], ENT_QUOTES);
    $mass_mailing = new he_mass_mailing();
    $campaign_id = $mass_mailing->create_campaign($subject, $message, -1, true);

    if( $campaign_id ) {
        foreach ($fan->fans as $user_fan) {
            if( intval($user_fan['user_id']) )
                $mass_mailing->add_message_into_queue_for_user($campaign_id, $user_fan['user_id'], $replace);
        }

        $result = array( 'message' => SE_Language::_get(690704203), 'status' => true );
    }
    else {
        $result = array( 'message' => SE_Language::_get(690704204), 'status' => false );
    }

    $smarty->assign("ready",true);
    $smarty->assign("result",$result);
}


$smarty->assign("fan",$fan_id);
$smarty->assign("fan_type",$fan_type);
$smarty->assign("fan_owner_id",$fan_owner_id);

include("footer.php");
?>