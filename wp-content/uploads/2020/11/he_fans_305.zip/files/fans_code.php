<?php

/**
 * @author Eldar
 * @copyright Hire-Experts LLC
 * @version Fans 3.1
 */

$page="fans_code";

include("header.php");


$fan_id = $_GET["fan"];
$fan_type = $_GET["fan_type"];
$fan_owner_id = $_GET["fan_owner_id"];

switch ($fan_type)
{
    case "profile":
        $fan = new se_profilefans($fan_id, $fan_owner_id);
    break;
    case "group":
        $fan = new se_groupfans($fan_id, $fan_owner_id);
    break;
    case "pages":
        $fan = new se_pagesfans($fan_id, $fan_owner_id);
    break;
}
if( !$fan ) exit;


$smarty->assign_by_ref("fan", $fan);

include("footer.php");
?>