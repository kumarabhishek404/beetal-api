<?php return array(
  array(
    'title' => 'Weather',
    'description' => 'Displays the location widget',
    'category' => 'Weather',
    'type' => 'widget',
    'name' => 'weather.weather',
    'defaultParams' => array(
      'title' => 'Weather',
      'titleCount' => false,
    ),
  ),
) ?>