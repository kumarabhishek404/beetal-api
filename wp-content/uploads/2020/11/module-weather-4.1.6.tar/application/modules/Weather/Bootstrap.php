<?php

class Weather_Bootstrap extends Engine_Application_Bootstrap_Abstract
{
  public function __construct($application)
  {
    parent::__construct($application);
    $this->initViewHelperPath();
//    $log = Zend_Registry::get('Zend_Log');
//      $log->addWriter(new Hecore_Plugin_CrashLog(Engine_Db_Table::getDefaultAdapter(), 'engine4_hecore_log'));
    // clear scaffold cache
    Core_Model_DbTable_Themes::clearScaffoldCache();
  }
}