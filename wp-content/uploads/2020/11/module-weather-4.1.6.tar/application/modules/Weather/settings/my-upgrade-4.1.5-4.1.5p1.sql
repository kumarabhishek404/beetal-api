--
-- Update module Weather
--

UPDATE `engine4_core_modules` SET `version` = '4.1.5p1'  WHERE `name` = 'weather';