
INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES  ('weather', 'Weather Plugin', 'Weather Plugin', '4.1.6', 1, 'extra') ;