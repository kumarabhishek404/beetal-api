<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Donation
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @author     adik
 * @date       03.09.12
 * @time       11:50
 */
class Donation_Widget_DonorsController extends Engine_Content_Widget_Abstract
{
  public function indexAction()
  {
    $log = Zend_Registry::get('Zend_Log');

    $settings = Engine_Api::_()->getDbTable('settings', 'core');
    $table = Engine_Api::_()->getDbTable('transactions','donation');

    $this->view->currency = Engine_Api::_()->getDbTable('settings', 'core')->getSetting('payment.currency', 'USD');
    $select = $table->select()
      ->setIntegrityCheck(false)
      ->from(array('o' => $table->info('name')), array(
        'user_id',
        'amounted' => 'SUM(amount)'))
      ->where('o.user_id > ?', 0)
      ->group('user_id')
      ->order(new Zend_Db_Expr('SUM(o.amount) DESC'));
    $log->log("Step :::".$select,Zend_Log::DEBUG);
    $this->view->paginator = $paginator = Zend_Paginator::factory($select);
    //
    $request = Zend_Controller_Front::getInstance()->getRequest();
    $paramsp = $request->getParams();
    $page = $paramsp['page'];
    $paginator->setItemCountPerPage($settings->getSetting('donation.donors_page_count', 5));
    $paginator->setCurrentPageNumber($page);
  }
}
