<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Ravshanbek
 * Date: 28.08.12
 * Time: 9:48
 * To change this template use File | Settings | File Templates.
 */
class Donation_Model_DbTable_FinInfos extends Engine_Db_Table
{
  protected $_name = 'donation_fin_infos';

  protected $_rowClass = 'Donation_Model_FinInfo';
}
