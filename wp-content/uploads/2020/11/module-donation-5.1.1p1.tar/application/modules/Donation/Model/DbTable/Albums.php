<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Donation
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @author     adik
 * @date       06.08.12
 * @time       12:46
 */
class Donation_Model_DbTable_Albums extends Engine_Db_Table
{
    protected $_rowClass = 'Donation_Model_Album';
}
