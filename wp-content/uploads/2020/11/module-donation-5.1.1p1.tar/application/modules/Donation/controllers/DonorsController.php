<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Donation
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @author     adik
 * @date       03.09.12
 * @time       11:41
 */
class Donation_DonorsController extends Core_Controller_Action_Standard
{
  public function init()
  {

  }

  public function indexAction()
  {
  	$this->_helper->content
    //->setNoRender()
      ->setEnabled();
  }
}
