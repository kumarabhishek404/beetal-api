<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Photos
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @author     adik
 * @date       01.08.12
 * @time       12:42
 */
class Donation_Model_DbTable_Photos extends Engine_Db_Table
{
    protected $_rowClass = 'Donation_Model_Photo';
}
