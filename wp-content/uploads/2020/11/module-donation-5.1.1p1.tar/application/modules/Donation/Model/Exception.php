<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Ravshanbek
 * Date: 07.08.12
 * Time: 16:47
 * To change this template use File | Settings | File Templates.
 */
class Donation_Model_Exception extends Engine_Exception
{

}
