INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES
('donation', 'Donations', 'Hire-Experts Donations Plugin', '5.1.1p1', 1, 'extra') ;

INSERT IGNORE INTO `engine4_activity_actiontypes` (`type`, `module`, `body`, `displayable`) VALUES
('donation_project_new', 'donation', '{item:$subject} posted a new project:', 7),
('donation_charity_new', 'donation', '{item:$subject} posted a new charity:', 7),
('donation_fundraise_new', 'donation', '{item:$subject}  is raising funds for {itemParent:$object}:', 7),
('page_project_new', 'donation', '{actors:$subject:$object} posted a new project:', 7),
('page_charity_new', 'donation', '{actors:$subject:$object} posted a new charity:', 7);