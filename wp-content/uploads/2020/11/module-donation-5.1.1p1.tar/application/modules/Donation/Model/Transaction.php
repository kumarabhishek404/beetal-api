<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Ravshanbek
 * Date: 07.08.12
 * Time: 17:35
 * To change this template use File | Settings | File Templates.
 */
class Donation_Model_Transaction extends Core_Model_Item_Abstract
{

}
