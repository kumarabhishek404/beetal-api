<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Hegift
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: content.php 03.02.12 12:50 TeaJay $
 * @author     Taalay
 */

return array(
  array(
    'title' => 'Advanced comment',
    'description' => 'Displays comments for subject',
    'category' => 'He-Comment',
    'type' => 'widget',
    'name' => 'hecomment.comments',
  ),
);