<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Wall
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: Core.php 18.06.12 10:52 michael $
 * @author     Michael
 */

/**
 * @category   Application_Extensions
 * @package    Wall
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */
class Hecomment_Api_Core extends Activity_Api_Core
{
    public function addComment($resource, $poster, $body)
    {
        $table = Engine_Api::_()->getDbTable('comments', 'core');
        // $row = $table->createRow();
        $row = $table->insert(
            array(
                'resource_type' => 'comment',
                'resource_id' => $resource,
                'poster_type' => $poster->getType(),
                'poster_id' => $poster->getIdentity(),
                'body' => $body,
                'creation_date' => date('Y-m-d H:i:s'),
            )
        );

        $select = $table->select()->where('comment_id=?', $row);
        $comment = $table->fetchRow($select);

        return $comment;
    }

    public function removeReplyComment($resource, $comment)
    {
        $row = $comment;
        if (null === $row) {
            throw new Core_Model_Exception('No comment found to delete');
        }

        $row->delete();

        if (isset($resource->comment_count)) {
            $resource->save();
        }

        return $this;
    }

    //Add Like for  Comments Reply
    public function addLikeReplyComment($resource, $poster)
    {
        $thisLike = Engine_Api::_()->getDbtable('likes', 'core');
        $table = $thisLike;
        $row = $table->createRow();
        $row->resource_type = $resource->getType();
        $row->resource_id = $resource->getIdentity();
        $row->poster_type = 'user';
        $row->poster_id = $poster->getIdentity();
        $row->save();
        if (isset($resource->like_count)) {
            $resource->like_count++;
            $resource->save();
        }
        return $row;
    }

    //Remove Like for Comments Reply
    public function removeLikeReplyComment($resource, $poster)
    {
        $row = $this->getLike($resource, $poster);
        if (null === $row) {
            throw new Core_Model_Exception('No like to remove');
        }
        $row->delete();
        if (isset($resource->like_count)) {
            $resource->like_count--;
            $resource->save();
        }
        return $this;
    }

    // Get Like comment reply
    protected function getLike($resource, $poster)
    {
        $table = Engine_Api::_()->getDbtable('likes', 'core');
        $select = $table->select()->where('resource_type = ?', $resource->getType())->where('resource_id = ?', $resource->getIdentity())->where('poster_type = ?', $poster->getType())->where('poster_id = ?', $poster->getIdentity())->order('like_id ASC')->limit(1);
        return $table->fetchRow($select);
    }

    public function addDefaultPrices()
    {
        print_die(0);
        $settings = Engine_Api::_()->getDbTable('settings', 'core');
        $installed = $settings->getSetting('socialads.adddefaultprices', 0);
        //print_die($installed);
        // if($installed == 1) return;
        $viewer = Engine_Api::_()->user()->getViewer();
        if (!$viewer && !$viewer->getIdentity()) return;

        $table = Engine_Api::_()->getDbTable('prices', 'socialads');
        $tableViewmodes = Engine_Api::_()->getDbTable('viewmodes', 'socialads');
        $viewmodes = $tableViewmodes->fetchAll($tableViewmodes->select());
        $prices = $table->fetchAll($table->select());

        // print_die($viewmodes->toArray());
        if (!count($prices) && count($viewmodes)) {

            try {
                foreach ($viewmodes as $viewmode) {
                    print_arr($viewmode->id);
                    $CPC = array(
                        'type_pay' => 'CPC',
                        'viewmode_id' => $viewmode->id,
                        'price' => 1,
                        'discount_percent' => 0,
                        'count' => 100,
                    );
                    $CPM = array(
                        'type_pay' => 'CPM',
                        'viewmode_id' => $viewmode->id,
                        'price' => 1,
                        'discount_percent' => 0,
                        'count' => 100,
                    );
                    $CPD = array(
                        'type_pay' => 'CPD',
                        'viewmode_id' => $viewmode->id,
                        'price' => 1,
                        'discount_percent' => 0,
                        'count' => 1,
                    );

                    $table = Engine_Api::_()->getDbTable('prices', 'socialads');
                    $price = $table->createRow();
                    $price->setFromArray($CPC);
                    $price->save();
                    $table = Engine_Api::_()->getDbTable('prices', 'socialads');
                    $price = $table->createRow();
                    $price->setFromArray($CPM);
                    $price->save();
                    $table = Engine_Api::_()->getDbTable('prices', 'socialads');
                    $price = $table->createRow();
                    $price->setFromArray($CPD);
                    $price->save();
                }

                $settings->setSetting('socialads.adddefaultprices', 1);
            } catch (Exception $exception) {
                print_die($exception . '');
            }
        }

        $settings->setSetting('socialads.adddefaultprices', 1);
    }
}