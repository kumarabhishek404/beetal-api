
UPDATE `engine4_core_modules` SET `version` = '4.0.0p2' WHERE `name` = 'hecomment';