<?php
/**
 * iPragmatech Solution Pvt. Ltd.
 *
 * @category   Application_Groupannouncement
 * @package    Group Announcement
 * @copyright  Copyright 2008-2013 iPragmatech Solution Pvt. Ltd.
 * @license    � 2013 iPragmatech. All Rights Reserved.
 * @version    $Id: Menus.php 9747 2013-07-06 02:08:08Z iPrgamtech $
 * @author     iPragmatech
 */

/**
 * @category   Application_Groupannouncement
 * @package    Group Announcement
 * @copyright  Copyright 2008-2013 iPragmatech Solution Pvt. Ltd.
 * @license    � 2013 iPragmatech. All Rights Reserved.
 */
class Groupannouncement_Plugin_Menus
{
   
  public function onMenuInitialize_CreateAnnouncement()
  {

  	    $viewer = Engine_Api::_()->user()->getViewer();
	    $subject = Engine_Api::_()->core()->getSubject();
	    if( $subject->getType() !== 'group' )
	    {
	      throw new Group_Model_Exception('Whoops, not a group!');
	    }
	
	    if( !$viewer->getIdentity() || !$subject->authorization()->isAllowed($viewer, 'create') )
	    {
	      return false;
	    }
	 
	    return array(
	      'label' => 'Post New Announcement',
	      //'icon' => 'application/modules/Groupannouncement/externals/images/post.png',
	      'route' => 'create_announcement',
	      'params' => array(
	        'controller' => 'announcement',
	        'action' => 'create',
	        'group_id' => $subject->getIdentity(),
	        
	      )
	    );
  	
  }
  public function onMenuInitialize_ManageGroupAnnouncements()
  {
  
  	$viewer = Engine_Api::_()->user()->getViewer();
  	$subject = Engine_Api::_()->core()->getSubject();
  	if( $subject->getType() !== 'group' )
  	{
  		throw new Group_Model_Exception('Whoops, not a group!');
  	}
  	
  	if( !$viewer->getIdentity() || !$subject->authorization()->isAllowed($viewer, 'edit') )
  	{
  		return false;
  	}
     return array(
  			'label' => 'Manage Announcements',
  			//'icon' => 'application/modules/Groupannouncement/externals/images/manage.png',
  			'route' => 'manage_group_announcements',
  			'params' => array(
  					'controller' => 'announcement',
  					'action' => 'manage',
  					'group_id' => $subject->getIdentity(),
  					 
  			)
  	);
  	 
  }
  

  }