<?php
/**
 * iPragmatech Solution Pvt. Ltd.
 *
 * @package    Group Announcement
 * @copyright  Copyright 2008-2018 iPragmatech Solution Pvt. Ltd.
 * @license    � 2018 iPragmatech. All Rights Reserved.
 * @version    $Id: AdminSettingsController.php 9747 2013-07-06 02:08:08Z iPrgamtech $
 * @author     iPragmatech
 */

/**
 * @package    Group Announcement
 * @copyright  Copyright 2008-2018 iPragmatech Solution Pvt. Ltd.
 * @license   � 2018 iPragmatech. All Rights Reserved.
 */
class Groupannouncement_Installer extends Engine_Package_Installer_Module
{
  
	public function onPreInstall()
    {
    	
    	parent::onPreInstall();
    	
    	    $db = $this->getDb();
		  	$select = new Zend_Db_Select($db);
		  	$select
	  	    ->from('engine4_core_modules')
		  	->where('name = ?', 'group');
		  	$check_groups = $select->query()->fetchAll();
		  	$group_error_message = "Group plugin is not installed. Please install Group module";
		  	if(empty($check_groups)){
		  		return $this->_error($group_error_message);
		  	}
  }
  
}