<?php
/**
 * SocialEngine
 *
 * @category   Application_Groupannouncement
 * @package    Announcement
 * @copyright  Copyright 2008-2013 iPragmatech
 * @license    � 2013 iPragmatech. All Rights Reserved.
 * @version    $Id: Announcement.php 9747 2013-07-26 02:08:08Z iPragmatech $
 * @author     iPragmatech
 */

/**
 * @category   Application_Groupannouncement
 * @package    Announcement
 * @copyright  Copyright 2008-2013 iPragmatech Solutions
 * @license    � 2013 iPragmatech. All Rights Reserved.
 */
class Groupannouncement_Model_Announcement extends Core_Model_Item_Abstract
{
  protected $_parent_type = 'user';
  protected $_owner_type = 'user';

  
}