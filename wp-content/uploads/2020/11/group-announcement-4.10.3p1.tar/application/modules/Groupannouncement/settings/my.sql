INSERT INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES  ('groupannouncement', 'Group Announcement', 'This module let you to create announcement for group', '4.8.11', 1, 'extra') ;

CREATE TABLE IF NOT EXISTS `engine4_group_announcements` (
  `announcement_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `enable` tinyint(4) NOT NULL,
  `url` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`announcement_id`),
  KEY `group_id` (`group_id`,`enable`)
);

INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES
('core_admin_main_plugins_groupannouncement', 'groupannouncement', 'Group Announcements', '', '{"route":"admin_default","module":"groupannouncement", "controller":"settings"}', 'core_admin_main_plugins', NULL, 1, 0, 999);

INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES
('groupannouncement_admin_main_settings', 'groupannouncement', 'Global Settings', '', '{"route":"admin_default","module":"groupannouncement","controller":"settings"}', 'groupannouncement_admin_main', '', 1, 0, 1);

INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES
('create_announcement', 'groupannouncement', 'Post Group Announcement', 'Groupannouncement_Plugin_Menus', '', 'group_profile', '', 1, 0, 999);

INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES
('manage_group_announcements', 'groupannouncement', 'Manage Announcements', 'Groupannouncement_Plugin_Menus', '', 'group_profile', '', 1, 0, 999);


INSERT IGNORE INTO `engine4_core_menus` (`name`, `type`, `title`, `order`) VALUES
('groupannouncement_admin_main', 'standard', 'Group Announcement Main Navigation Menu', 999);
