<?php
/**
 * iPragmatech Solution Pvt. Ltd.
 *
 * @category   Application_Announcement
 * @package    Group Announcement
 * @copyright  Copyright 2008-2013 iPragmatech Solution Pvt. Ltd.
 * @license    � 2013 iPragmatech. All Rights Reserved.
 * @version    $Id: Install.php 9747 2013-07-06 02:08:08Z iPrgamtech $
 * @author     iPragmatech
 */

/**
 * @category   Application_Announcement
 * @package    Group Announcement
 * @copyright  Copyright 2008-2013 iPragmatech Solution Pvt. Ltd.
 * @license    � 2013 iPragmatech. All Rights Reserved.
 */
class Groupannouncement_AnnouncementController extends Core_Controller_Action_Standard
{
	
	public function init()
	{

		$id = $this->_getParam('group_id', $this->_getParam('id', null));
		if( $id ) {
			$group = Engine_Api::_()->getItem('group', $id);
			if( $group ) {
				Engine_Api::_()->core()->setSubject($group);
			}
		}
	}
	
	public function createAction()
    {
      $this->view->form = $form = new Groupannouncement_Form_Create();
      if( $this->getRequest()->isPost() && $form->isValid($this->getRequest()->getPost()) )
       {
  		$params = $form->getValues();
  		$params['user_id'] = Engine_Api::_()->user()->getViewer()->getIdentity();
        $params['group_id'] = $this->_getParam('group_id');
        $params['enable'] = 1;
        $announcement_table = Engine_Api::_()->getDbtable('announcements', 'groupannouncement');
        $announcement = $announcement_table->createRow();
  		 $announcement->setFromArray($params);
  		 $announcement->save();
        // Redirect
        return $this->_helper->redirector->gotoRoute(array('group_id' =>  $announcement->group_id), 'manage_group_announcements', true);
  	   }
    }
     
    public function editAction()
    {
   	    $announcement_id = $this->_getParam('announcement_id');
        $announcement_table = Engine_Api::_()->getDbtable('announcements', 'groupannouncement');
		$select = $announcement_table->select()->where('announcement_id = ?', $announcement_id);
		$this->view->announcement = $announcement = $announcement_table->fetchRow($select);
   	    $this->view->form = $form = new Groupannouncement_Form_Edit();
        $form->populate($announcement->toArray());
		// Process
		$db = Engine_Db_Table::getDefaultAdapter();
		if( !$this->getRequest()->isPost() ) {
			return;
		}

		if( !$form->isValid($this->getRequest()->getPost()) ) {
			return;
		}
		try
		{
			$values = $form->getValues();
            $announcement->setFromArray($values);
            $announcement->save();
			$db->commit();
			// Redirect
			return $this->_helper->redirector->gotoRoute(array('group_id' => $announcement->group_id), 'manage_group_announcements', true);
		}
		catch( Exception $e )
		{
			$db->rollBack();
			throw $e;
		}
    }
   	   	
   
   public function deleteAction()
   {
   	
	   	$viewer = Engine_Api::_()->user()->getViewer();
	    $announcement_id = $this->_getParam('announcement_id');
	   	// Make form
	   	$this->view->form = $form = new Groupannouncement_Form_Delete();
	   	if(!$announcement_id )
	   	{
	   		$this->view->status = false;
	   		$this->view->error = Zend_Registry::get('Zend_Translate')->_("Group  Announcement doesn't exists or not authorized to delete");
	   		return;
	   	}
	   	
   	    if( !$this->getRequest()->isPost() )
     	{
   		  $this->view->status = false;
   		  $this->view->error = Zend_Registry::get('Zend_Translate')->_('Invalid request method');
   		  return;
    	}
    	try
    	{
	   		Engine_Api::_()->getDbtable('announcements', 'groupannouncement')->delete(array(
			'announcement_id = ?' => $announcement_id,
			));
    	}
    	catch( Exception $e )
    	{
    		throw $e;
    	}
		$this->view->status = true;
   		$this->view->message = $message = Zend_Registry::get('Zend_Translate')->_('The selected group Announcement has been deleted.');
   		return $this->_forward('success' ,'utility', 'core', array(
   		 		'smoothboxClose' => true,
   		 		'parentRefresh' => true,
   		 		'messages' => array($message)
   		 ));
     }
     public function manageAction()
     {
        
     	if( !$this->_helper->requireAuth()->setAuthParams(null, null, 'edit')->isValid() ) {
     		return;
     	}
     	
     	$this->view->viewer = $viewer = Engine_Api::_()->user()->getViewer();
        $subject = null;
        if( Engine_Api::_()->core()->hasSubject() ) 
        {
	    	// Get subject
	    	$this->view->subject = $subject = Engine_Api::_()->core()->getSubject('group');
	    	$group_id = $subject->getIdentity();
        } 	
        // Get paginator
	    $group_announcement_table = Engine_Api::_()->getDbtable('announcements', 'groupannouncement');
	    $select = $group_announcement_table->select()
	    ->where('group_id=?', $group_id) 
	    ->order('creation_date DESC');   
	    $this->view->announcements = $paginator = Zend_Paginator::factory($select);
	    
	    // Set item count per page and current page number
	    $paginator->setItemCountPerPage($this->_getParam('itemCountPerPage', 10));
	    $paginator->setCurrentPageNumber($this->_getParam('page', 1));   
        
     }
     public function enableAction()
     {
     	$announcement_id = $this->getRequest()->getParam('announcement_id');
     	$announcement_table = Engine_Api::_()->getDbtable('announcements', 'groupannouncement');
     	$this->view->form = $form = new Groupannouncement_Form_Enable();
     	if( !$this->getRequest()->isPost() )
     	{
     		$this->view->status = false;
     		$this->view->error = Zend_Registry::get('Zend_Translate')->_('Invalid request method');
     		return;
     	}
     	if( !$announcement_id )
     	{
     		$this->view->status = false;
     		$this->view->error = Zend_Registry::get('Zend_Translate')->_("Group Announcement doesn't exists or not authorized to delete");
     		return;
     	}
     	try
     	{
	     	$announcement_table->update(array(
	     			'enable' => 1,
	     	), array(
	     			'announcement_id= ?' => $announcement_id,
	     	));
     	}
     	catch( Exception $e ) {
     		throw $e;
     	}
     	$this->view->status = true;
     	$this->view->message = $message= Zend_Registry::get('Zend_Translate')->_('Announcement is successfully enabled.');
     	 return $this->_forward('success', 'utility', 'core', array(
        		'smoothboxClose' => true,
        		'parentRefresh' => true,
        		'messages' => array($message)
     	));
     }
     public function disableAction()
     {
     	
     	$announcement_id = $this->getRequest()->getParam('announcement_id');
     	$announcement_table = Engine_Api::_()->getDbtable('announcements', 'groupannouncement');
     	$this->view->form = $form = new Groupannouncement_Form_Disable();
     	if( !$this->getRequest()->isPost() )
     	{
     		$this->view->status = false;
     		$this->view->error = Zend_Registry::get('Zend_Translate')->_('Invalid request method');
     		return;
     	}
     	if(!$announcement_id )
     	{
     		$this->view->status = false;
     		$this->view->error = Zend_Registry::get('Zend_Translate')->_("Group Announcement doesn't exists or not authorized to delete");
     		return;
     	}
     	try
     	{
	     	$announcement_table->update(array(
	     			'enable' => 0,
	     	), array(
	     			'announcement_id = ?' => $announcement_id,
	     	));
     	}
     	catch( Exception $e ) 
     	{
     		throw $e;
     	}
     		
	    $this->view->status = true;
	    $this->view->message = $message = Zend_Registry::get('Zend_Translate')->_('Announcement is successfully disabled.');
        return $this->_forward('success', 'utility', 'core', array(
     			'smoothboxClose' => true,
     			'parentRefresh' => true,
     			'messages' => array($message)
        		
     	));
     }
      
  
}

