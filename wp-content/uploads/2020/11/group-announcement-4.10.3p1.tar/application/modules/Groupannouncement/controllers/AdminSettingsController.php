<?php
/**
 * iPragmatech Solution Pvt. Ltd.
 *
 * @category   Application_Groupannouncement
 * @package    Group Announcement
 * @copyright  Copyright 2008-2013 iPragmatech Solution Pvt. Ltd.
 * @license    � 2013 iPragmatech. All Rights Reserved.
 * @version    $Id: Install.php 9747 2013-07-06 02:08:08Z iPrgamtech $
 * @author     iPragmatech
 */

/**
 * @category   Application_Groupannouncement
 * @package    Group Announcement
 * @copyright  Copyright 2008-2013 iPragmatech Solution Pvt. Ltd.
 * @license    � 2013 iPragmatech. All Rights Reserved.
 */



class Groupannouncement_AdminSettingsController extends Core_Controller_Action_Admin
{
	
	public function indexAction()
	{
		$this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
		->getNavigation('groupannouncement_admin_main', array(), 'groupannouncement_admin_main_settings');
	
		$settings = Engine_Api::_()->getApi('settings', 'core');
	
		$this->view->form = $form = new Groupannouncement_Form_Admin_Global();
		$form->announcement_page->setValue($settings->getSetting('announcement_page', 10));
		if( $this->getRequest()->isPost()&& $form->isValid($this->getRequest()->getPost()))
		{
			$values = $form->getValues();
			foreach ($values as $key => $value){
				Engine_Api::_()->getApi('settings', 'core')->setSetting($key, $value);
			}
			$form->addNotice('Your changes have been saved.');
		}
	}

}