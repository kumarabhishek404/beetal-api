<?php

return array(
    'package' => array(
        'type' => 'module',
        'name' => 'groupannouncement',
        'version' => '4.10.3p1',
        'path' => 'application/modules/Groupannouncement',
        'title' => 'Group Announcement',
        'description' => 'This module let you to create announcement for group',
        'author' => '<a href="ipragmatech.com"> iPragmatech</a>',
        'sku' => 'ip-announcement',
        'callback' => array(
            'path' => 'application/modules/Groupannouncement/settings/install.php',
            'class' => 'Groupannouncement_Installer'
        ),
        'dependencies' => array(
            array(
                'type' => 'module',
                'name' => 'core',
                'minVersion' => '4.9.4p3'
            )
        ),
        'actions' => array(
            0 => 'install',
            1 => 'upgrade',
            2 => 'refresh',
            3 => 'enable',
            4 => 'disable'
        ),
        'directories' => array(
            0 => 'application/modules/Groupannouncement'
        ),
        'files' => array(
            0 => 'application/languages/en/groupannouncement.csv'
        )
    ),
    // Routes --------------------------------------------------------------------
    'routes' => array(
        'create_announcement' => array(
            'route' => 'announcement/:group_id/create',
            'defaults' => array(
                'module' => 'groupannouncement',
                'controller' => 'announcement',
                'action' => 'create'
            )
        ),
        'edit_announcement' => array(
            'route' => 'announcement/:announcement_id/edit/*',
            'defaults' => array(
                'module' => 'groupannouncement',
                'controller' => 'announcement',
                'action' => 'edit'
            )
        ),
        'delete_announcement' => array(
            'route' => 'announcement/:announcement_id/delete/*',
            'defaults' => array(
                'module' => 'groupannouncement',
                'controller' => 'announcement',
                'action' => 'delete'
            )
        ),
        'enable_announcement' => array(
            'route' => 'announcement/:announcement_id/enable/*',
            'defaults' => array(
                'module' => 'groupannouncement',
                'controller' => 'announcement',
                'action' => 'enable'
            )
        ),
        'disable_announcement' => array(
            'route' => 'announcement/:announcement_id/disable/*',
            'defaults' => array(
                'module' => 'groupannouncement',
                'controller' => 'announcement',
                'action' => 'disable'
            )
        ),
        
        'manage_group_announcements' => array(
            'route' => 'announcement/:group_id/manage',
            'defaults' => array(
                'module' => 'groupannouncement',
                'controller' => 'announcement',
                'action' => 'manage'
            )
        )
    
    )

);
?>