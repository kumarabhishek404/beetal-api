<?php
/**
 * iPragmatech Solution Pvt. Ltd.
 *
 * @category   Application_Groupannouncement
 * @package    Group Announcement
 * @copyright  Copyright 2008-2013 iPragmatech Solution Pvt. Ltd.
 * @license    � 2013 iPragmatech. All Rights Reserved.
 * @version    $Id: Install.php 9747 2013-07-06 02:08:08Z iPrgamtech $
 * @author     iPragmatech
 */

/**
 * @category   Application_Groupannouncement
 * @package    Group Announcement
 * @copyright  Copyright 2008-2013 iPragmatech Solution Pvt. Ltd.
 * @license    � 2013 iPragmatech. All Rights Reserved.
 */
class Groupannouncement_Form_Disable extends Engine_Form
{
  public function init()
  {
    $this->setTitle('Disable Group Announcement')
      ->setDescription('Are you sure you want to Disable this Group Announcement?')
      ->setAttrib('class', 'global_form_popup');
     
    // Buttons
    $this->addElement('Button', 'submit', array(
      'label' => 'Disable Group Announcement',
      'type' => 'submit',
      'ignore' => true,
      'decorators' => array('ViewHelper')
    ));

    $this->addElement('Cancel', 'cancel', array(
      'label' => 'cancel',
      'link' => true,
      'prependText' => ' or ',
      'href' => '',
      'onclick' => 'parent.Smoothbox.close();',
      'decorators' => array(
        'ViewHelper'
      )
    ));
    $this->addDisplayGroup(array('submit', 'cancel'), 'buttons');
    $button_group = $this->getDisplayGroup('buttons');
  }
}