<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Group
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: Groups.php 9826 2012-11-21 02:56:50Z richard $
 * @author     John
 */

/**
 * @category   Application_Extensions
 * @package    Group
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
class Groupannouncement_Model_DbTable_Announcements extends Engine_Db_Table
{
	
	protected $_rowClass = 'Groupannouncement_Model_Announcement';
	protected $_name = 'group_announcements';
	
}