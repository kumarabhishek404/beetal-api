--
-- Dumping data for table `engine4_core_modules`
--

INSERT INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES
('daylogo', 'Daylogo', 'Site Daylogo', '4.10.5', 1, 'extra');
