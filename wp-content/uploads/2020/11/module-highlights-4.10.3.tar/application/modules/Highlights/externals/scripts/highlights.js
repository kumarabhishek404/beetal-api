/*
 var highlights = {


 more_photos: function (page_id, btn, type) {

 console.log(type);

 (new Request.HTML({
 url: en4.core.baseUrl + 'highlights/index/more',
 data: {page_id: page_id, type: type},
 onSuccess: function (responseTree, responseElements, responseHTML, responseJavaScript) {
 if (type == 'horizontal') {
 $('content_highlights').set('html', responseHTML);
 } else {
 $('content_highlights_vertical').set('html', responseHTML);
 }
 }
 })).send();
 }


 };
 */


window.addEvent('domready', function () {

    function HighlightCarousel(container) {
        if (!container) return;
        this.container = container;
        this.content = null;
        this.ul = null;
        this.list = null;
        this.pos = 0;
        this.count = 1;
        this.width = 150;
        this.orientation = (this.container.getAttribute('aria-orientation') == 'vertical') ? 'vertical' : 'horizontal';
        this.images = null;
        this.visibleImages = 0;
        this.page = 0;

        var self = this;

        window.addEventListener('resize', function (event) {
            self.setValues();
        });

        this.setValues = function () {
            var self = this;


            self.pos = 0;

            self.content = self.container.getElementsByClassName('c-content')[0];
            self.ul = self.container.querySelector('ul');
            self.list = self.container.querySelectorAll('li');
            self.images = self.container.querySelectorAll('img');

            if (self.orientation == 'vertical') {
                self.count = Math.floor(self.container.getSize().y / self.width);
                self.content.style.maxHeight = (self.count <  self.list.length) ? (self.width * self.count) + 'px' : (self.width * self.list.length) + 'px';
                self.ul.style.marginTop = self.pos + 'px';
            } else {
                self.count = Math.floor(self.container.getSize().x / self.width);
                self.content.style.maxWidth = (self.count <  self.list.length) ? (self.width * self.count) + 'px' : (self.width * self.list.length) + 'px';
                self.ul.style.marginLeft = self.pos + 'px';
            }

            self.showImages();

            self.container.querySelector('.prev-btn').onclick = self.previousClick;
            self.container.querySelector('.next-btn').onclick = self.nextClick;

        };

        this.showImages = function () {
            var self = this;

            for (var i = self.visibleImages; i < self.images.length; i++) {

                if (i >= (self.visibleImages + self.count)) {
                    self.visibleImages = i;
                    break;
                }
                self.images[i].setAttribute('src', self.images[i].getAttribute('image-url'));
            }
        };

        this.previousClick = function () {
            var self = this;

            self.pos = Math.min(self.pos + self.width * self.count, 0);

            if (self.orientation == 'vertical')
                self.ul.style.marginTop = self.pos + 'px';
            else
                self.ul.style.marginLeft = self.pos + 'px';

        }.bind(this);

        this.nextClick = function () {
            var self = this;

            var pos = self.pos;
            var width = self.width;
            var count = self.count;

            self.pos = Math.max(pos - width * count, -width * (((self.list.length - count) < 0) ? 0 : self.list.length - count ));

            if (self.orientation == 'vertical')
                self.ul.style.marginTop = self.pos + 'px';
            else
                self.ul.style.marginLeft = self.pos + 'px';

            if (self.page > self.pos)
                self.showImages();

            self.page = self.pos;

        }.bind(this);

        self.setValues();
    }

    var elems = document.getElementsByClassName('highlight-carousel');

    for (var i = 0; i < elems.length; i++) {
        new HighlightCarousel(elems[i]);
    }
});

