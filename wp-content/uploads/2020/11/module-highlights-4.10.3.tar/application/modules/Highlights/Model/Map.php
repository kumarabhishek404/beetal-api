<?php
/***/
class Highlights_Model_Map extends Core_Model_Item_Abstract {
  public function getHref()
  {

  }
}