<?php
/***/
class Highlights_Form_Admin_Settings extends Engine_Form {
  public function init()
  {
    parent::init();
    $this->setTitle('HIGHLIGHT_Configure Profile highlight settings')
      ->setDescription('HIGHLIGHT_Configure Profile highlight settings cost and number of days');
    $this->setAttrib('class', '');




    $this->addElement('Select', 'highlight_show_title', array(
      'label' => 'Show witget name',
      'value' => Engine_Api::_()->getApi('settings', 'core')->getSetting('highlight.show.title', 0),
      'multiOptions' => array(
        '0' => 'no',
        '1' => 'yes',
      )

    ));


    $this->addElement('Text', 'highlight_count_item', array(
      'label' => 'HIGHLIGHT_Count_item_on_page',
      'value' => Engine_Api::_()->getApi('settings', 'core')->getSetting('highlight.count.item', 8),
      'validators' => array(array('Int', true),
        new Engine_Validate_AtLeast(0),)

    ));


    $this->addElement('Text', 'highlight_num_days', array(
      'label' => 'HIGHLIGHT_Number of days',
      'value' => Engine_Api::_()->getApi('settings', 'core')->getSetting('highlight.num.days', 10),
      'validators' => array(array('Int', true),
        new Engine_Validate_AtLeast(0),)

    ));
    $this->addElement('Text', 'highlight_cost', array(
      'label' => 'HIGHLIGHT_Cost',
      'value' => Engine_Api::_()->getApi('settings', 'core')->getSetting('highlight.cost', 10),
      'validators' => array(array('Int', true),
        new Engine_Validate_AtLeast(0),)
    ));
    $this->addElement('Button', 'submit', array(
      'label' => 'HIGHLIGHT_Save changes',
      'type' => 'submit'
    ));

  }
}