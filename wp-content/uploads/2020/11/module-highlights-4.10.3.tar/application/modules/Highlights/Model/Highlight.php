<?php
/***/
class Highlights_Model_Highlight extends Core_Model_Item_Abstract {
  public function getHref()
  {

  }
}