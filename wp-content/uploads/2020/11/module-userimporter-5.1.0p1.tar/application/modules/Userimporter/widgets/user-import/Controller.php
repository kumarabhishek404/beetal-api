<?php
/**
 * iPragmatech Solution Pvt. Ltd.
 *
 * @category   Widget
 * @package    User Importer
 * @copyright  Copyright 2008-2013 iPragmatech Solution Pvt. Ltd.
 * @license    http://www.ipragmatech.com/license/
 * @version    $Id: Install.php 9747 2013-07-06 02:08:08Z iPrgamtech $
 * @author     iPragmatech
 */

/**
 * @category   Widget
 * @package    User Importer
 * @copyright  Copyright 2008-2013 iPragmatech Solution Pvt. Ltd.
 * @license    http://www.ipragmaetch.com/license/
 */
class Userimporter_Widget_UserImportController extends Engine_Content_Widget_Abstract
{
  public function indexAction()
  {
  		$log = Zend_Registry::get('Zend_Log');
  		$p = Zend_Controller_Front::getInstance()->getRequest()->getParams();

  		$this->view->form = $form = new Userimporter_Form_User();

  		if( $form->isValid($p) ) {
  			$values = $form->getValues();
  		}

	  	// Process
  		//$user_value = $this->_getParam('user_signup');
  		if($values['username']!=null && $values['email']!=null)
  		{
  			$user_table = Engine_Api::_ ()->getDbtable ( 'users', 'user' );
  			$user_select = $user_table->select ()->where ( 'email = ?', $values['email'] );
  			$existing_user = $user_table->fetchRow ( $user_select );

  			if(empty($existing_user))
  			{
	  			$name_email_Arr = array();
	  			$name_email_Arr[$values['email']]=$values['username'];

	  			// Init level
	  			$levelTable = Engine_Api::_()->getDbtable('levels', 'authorization');
	  			$level_select = $levelTable->select()->where('flag=?','default');
	  			$level = $levelTable->fetchRow($level_select);
	  			$signup = Engine_Api::_()->userimporter()->quickSignup($name_email_Arr,null,$level['level_id']);
	  			$form->addNotice('Successfully SignUp this user');
  			}
  			else
  			{
  				$form->addError('User is already exist');
  			}
  		}
  		if(($values['username']==null || $values['email']==null) && isset($values['user_signup'])  )
  		{
  			$form->addError('Both Fields are Required');
  		}


  }
}
