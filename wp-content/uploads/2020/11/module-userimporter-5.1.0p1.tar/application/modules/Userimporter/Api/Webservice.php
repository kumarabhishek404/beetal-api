<?php
class Userimporter_Api_Webservice extends Core_Api_Abstract {
	public function readJson($fileurl) {
		ini_set('auto_detect_line_endings',TRUE);
		$log = Zend_Registry::get('Zend_Log');
		$log->log("url json file: ".$fileurl,Zend_Log::DEBUG);
		
		$values = array ();
		$line_of_text = array ();
		
		$content = file_get_contents($fileurl);
		//$contentData = json_encode($content);
		// $contentData = preg_replace('/\s+/', '', $content);
		$contentArray = json_decode($content,TRUE);
		
// 		$json_errors = array(
// 				JSON_ERROR_NONE => 'No error has occurred',
// 				JSON_ERROR_DEPTH => 'The maximum stack depth has been exceeded',
// 				JSON_ERROR_CTRL_CHAR => 'Control character error, possibly incorrectly encoded',
// 				JSON_ERROR_SYNTAX => 'Syntax error',
// 		);
// 		$log->log('Last error : '. $json_errors[json_last_error()].' >> '. PHP_EOL.' >> '. PHP_EOL,Zend_Log::DEBUG);
		
		if($contentArray && is_array($contentArray)){
			$data = array('status' => true,'content' => $contentArray,'message' => 'Successfully create array');
		}else{
			$data = array('status' => false,'content' => null,'message' => "Not a valid JSON");
		}
		return $data;
	}
	
	public function readXml($fileurl) {
		ini_set('auto_detect_line_endings',TRUE);
		$log = Zend_Registry::get('Zend_Log');
		$log->log("url json file: ".$fileurl,Zend_Log::DEBUG);
	
		$values = array ();
		$line_of_text = array ();
	
		$content = file_get_contents($fileurl);
		$feeds = new SimpleXmlElement($content);
		$contentArray = array();
		if($feeds){
			$log->log("xml element:- ".json_encode($feeds),Zend_Log::DEBUG);
			
			foreach($feeds->user as $userdata){
				$contentUser = json_encode($userdata);
				$contentUser = json_decode($contentUser,true);
				$contentUser['first name'] = $contentUser['first_name'];
				$contentUser['last name'] = $contentUser['last_name'];
				
				$contentArray['users'][] = $contentUser;
			}
		}
	
		// 		$json_errors = array(
		// 				JSON_ERROR_NONE => 'No error has occurred',
		// 				JSON_ERROR_DEPTH => 'The maximum stack depth has been exceeded',
		// 				JSON_ERROR_CTRL_CHAR => 'Control character error, possibly incorrectly encoded',
		// 				JSON_ERROR_SYNTAX => 'Syntax error',
		// 		);
		// 		$log->log('Last error : '. $json_errors[json_last_error()].' >> '. PHP_EOL.' >> '. PHP_EOL,Zend_Log::DEBUG);
	
		if($contentArray && is_array($contentArray)){
			$data = array('status' => true,'content' => $contentArray,'message' => 'Successfully create array');
		}else{
			$data = array('status' => false,'content' => null,'message' => "Not a valid JSON");
		}
		return $data;
	}
	public function uploadJson(array $json_data = array(),$level_id,$verified,$approved,$notify_email,$log_id) {
		$log = Zend_Registry::get('Zend_Log');
		$final_array = array ();
				
		// call the quick sign up method
		 $this->insertUser($json_data['users'],$level_id,$verified,$approved,$notify_email,$log_id);
	
		// $this->quickSignup($name_email_Arr,$type,$level_id);
	}
	public function insertUser(array $userdata = array(),$level_id,$verified,$approved,$notify_email,$log_id) {
		$log = Zend_Registry::get('Zend_Log');
		$log->log("beforre inserting email notification radio ".json_encode($userdata),Zend_Log::DEBUG);
		
		/*** set enable and default timezone user value ***/
			$enabled =0;
			if($approved == 1 && $verified ==1)
			{
				$enabled =1;
			}
			date_default_timezone_set(timezone_name_from_abbr("EST"));
		
		/*** end enable user value ***/
					
		/*** get labels ***/
			// $labels = $this->getLables($userdata);
		/*** end get labels ***/
			
		/*** set user meta option value ***/
					
			$valueArray = $this->getUserMetaFields();

		/*** end user meta option value ***/
			
		/*** get meta enabled fields ***/
			$searchArrya = $this->getEnableMetaFields();
		/*** end meta enable fields ***/
			
		/*** get option meta value ***/
			$metaOptions = $this->getMetaOptionValues();
		/*** end option meta value ***/
			
		/*** get user fields tabels ***/
			$userfieldsearchtable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'search' );
			$userfieldValueTable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'values' );
			$dataTable = Engine_Api::_()->getDbTable('datas','userimporter');
			
		/*** end user fields tables ***/
		
			
		/*** iterating user profile data ***/	
			foreach ( $userdata as $value ) {
				$user_id = null;
				$email = null;
				$image = null;
				$username = null;
				
				array_change_key_case($value,CASE_LOWER);
				if (isset ( $value ['email'] )) {
					$email = $value ['email'];
				}
				if (isset ( $value ['password'] )) {
					$password = $value ['password'];
				}else {
					$password = rand();
				}
				if(isset($value['image'])){
					$image = $value['image'];
				}
				if(isset($value['username'])){
					$username = $value['username'];
				}
				if (isset ( $value ['creation date'] )) {
					//date_default_timezone_set('America/New_York');
					$datestring = $value ['creation date'];  //Pulled in from somewhere
					$creation_date = date('Y-m-d H:i:s T',strtotime($datestring . ' UTC'));
				}
				if (isset ( $value ['modified date'] )) {
					$datestring = $value ['modified date'];  //Pulled in from somewhere
					$modified_date = date('Y-m-d H:i:s T',strtotime($datestring . ' UTC'));
			
				}
				
				// if email address exist
					$user_table = Engine_Api::_ ()->getDbtable ( 'users', 'user' );
					$existing_user = null;
					if($email){
						$user_select = $user_table->select ()->where ( 'email = ?', $email );
						$existing_user = $user_table->fetchRow ( $user_select );
					}
					
				$importData = array(
							'email' => $email,
							'params' => json_encode($value),
							'log_id' => $log_id
				);
				if (empty ( $existing_user )) {
						
					try {
							
						if (empty ( $modified_date )) {
							$modified_date = new Zend_Db_Expr ( 'NOW()' );
						}
						if (empty ( $creation_date )) {
							$creation_date = new Zend_Db_Expr ( 'NOW()' );
						}
						$salt = ( string ) rand ( 1000000, 9999999 );
						$salt1 = Engine_Api::_ ()->getApi ( 'settings', 'core' )->getSetting ( 'core.secret', 'staticSalt' );
						$incrypt_password = md5 ( $salt1 . $password . $salt );
							
						// if user_id empty , inserting into users
						
							$new_user_id = $user_table->insert ( array (
									'email' => $email,
									'username' => $user_id,
									'level_id' => $level_id,
									'password' => $incrypt_password,
									'salt' => $salt,
									'modified_date' => $modified_date,
									'creation_date' => $creation_date,
									'approved' => $approved,
									'verified' => $verified,
									'enabled' => $enabled
							) );
						
						// inserting into search
						$userfieldsearchtable->insert ( array (
								'item_id' => $new_user_id,
								'profile_type' => 1
						));

						$userfieldValueTable->insert ( array (
								'item_id' => $new_user_id,
								'field_id' => 1,
								'value' =>1,
								'privacy' => "everyone"
						) );
			
						foreach ( $value as $key => $values ) {
							// $log->log("inserting meta value:- ".$key,Zend_Log::DEBUG);
							if (array_key_exists ( $key, $valueArray )) {
								$field_id = $valueArray [$key];
								$value = $values;
								if(array_key_exists($field_id, $metaOptions)){
									$optValue = strtolower($values);
									if($metaOptions[$field_id][$optValue]){
										$value = $metaOptions[$field_id][$optValue];
									}
								}
								$userfieldValueTable->insert ( array (
										'item_id' => $new_user_id,
										'field_id' => $valueArray [$key],
										'value' =>$value,
										'privacy' => "everyone"
								));
							}
						}
							
						$user = Engine_Api::_ ()->getItem ( 'user', $new_user_id );
						$aliasValues = Engine_Api::_()->fields()->getFieldsValuesByAlias($user);
						$user->setDisplayName($aliasValues);
						//$user['username'] = $new_user_id;
						$user->save();
						//$log->log("email gone for simle login>>>".$notify_email,Zend_Log::DEBUG);
						$values = Engine_Api::_()->fields()->getFieldsValues($user);
						Engine_Api::_()->getApi('core', 'fields')->updateSearch($user, $values);
						
						$importData['status'] = 1;
						$importData['message'] = "Import Successfull";
						$data_id = $dataTable->insert($importData);
						 
						if(isset($image) && $image != "" && !empty($image)){
							try{
								$tmpfile = $this->_fetchImage($image);
								$user->setPhoto($tmpfile);
								$dataTable->update(array('message' => "User imported with image succesfully."),'data_id ='.$data_id);
								
							}catch(Exception $e){
								$log->log("Exception while uploading image:- ".$e->getMessage(),Zend_Log::DEBUG);
								$dataTable->update(array('message' => "User imported without image succesfully."),'data_id ='.$data_id);
									
							}
						}
						try{
							if(isset($username) && !empty($username)){
								$user->username = $username;
							}else{
								$user->username = $new_user_id;
							}
							$user->save();
						}
						catch(Exception $e){
							$dataTable->update(array('message' => "User imported with image succesfully.Username already exists"),'data_id ='.$data_id);
						}
						if($notify_email){
							
							$mail_template = 'core_welcome_password';
							$mailParams = array(
									'host' => $_SERVER['HTTP_HOST'],
									'email' => $email,
									'date' => time(),
									'recipient_title' => $new_user_id,
									'recipient_link' => $user->getHref(),
									'recipient_photo' => $user->getPhotoUrl('thumb.icon'),
									'object_link' => $user->getHref(),
									'queue' => false,
									'password' => $password
									
							);
							try {
								$email_sent = Engine_Api::_ ()->getApi ( 'mail', 'core' )->sendSystem ( $email, $mail_template, $mailParams );
						
								$status = true;
								$message = 'User sucessfully signup';
							} catch ( Exception $ex ) {
								// throw $ex;
							}
						}
						
						
					} catch ( Exception $e ) {
						$status = false;
						$message = 'User creation failed' . $e;
						
						$importData['status'] = 0;
						$importData['message'] = "Import failed";
						$dataTable->insert($importData);
							
					}
		
				}else{
					$importData['status'] = 0;
					$importData['message'] = "User already exists with email";
					$dataTable->insert($importData);
				}
				
			}
		/*** end iterating user profile data ***/
			
		
	}
	public function getOptionsIds($value)
	{
		$log = Zend_Registry::get('Zend_Log');
		//$log->log("getOptions return array".json_encode($value),Zend_Log::DEBUG);
		$userfieldOptionTable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'options' );
		$select = $userfieldOptionTable->select();
		if(is_array($value))
		{
			$select->where("label IN (?)",$value);
			$res = $userfieldOptionTable->fetchAll($select);
			return $res;
		}
		else{
			$select->where("label = ? ",$value);
			$res = $userfieldOptionTable->fetchRow($select);
			return $res['option_id'];
		}
	}
	
	public function getUserMetaFields(){
		$log = Zend_Registry::get('Zend_Log');
		
		$userfieldMetaTable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'meta' );
		$userfieldsearchtable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'search' );
		$userfieldValueTable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'values' );
		
			
		// for values table
		$valueArray =array();
			$seletFieldID= $userfieldMetaTable->select();
			$log->log("user data".$seletFieldID,Zend_Log::DEBUG);
			
			$resfieldsValues = $userfieldMetaTable->fetchAll($seletFieldID)->toArray();
			
			foreach($resfieldsValues as $value)
			{
				$label = strtolower($value['label']);
				$valueArray[$label] = $value['field_id'];
			}
		
		
		return $valueArray;
		
	}
	
	public function getEnableMetaFields(){
		$userfieldMetaTable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'meta' );
		$userfieldsearchtable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'search' );
		$userfieldValueTable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'values' );
		
		
		$seletFieldID= $userfieldMetaTable->select();
		$seletFieldID->where("search = 1");
		$resfieldsSearch = $userfieldMetaTable->fetchAll($seletFieldID)->toArray();
		$searchArrya =array();
		foreach($resfieldsSearch as $search)
		{
			$label = strtolower($search['label']);
			if(!empty($search['alias']))
			{
				$searchArrya[$label] =$search['alias'] ;
			}
			else {
				$searchArrya[$label] = $search['field_'.$search['field_id']];
			}
		}
		
		return $searchArrya;
	}
	
	public function getMetaOptionValues(){
		$userMetaTable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'meta' );
		$userOptionTable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'options' );
		
		$optionsSearch= $userMetaTable->select()
						->setIntegrityCheck(false)
						->from(array('meta' => $userMetaTable->info('name')),array('field_id'))
						->join(array('opn' => $userOptionTable->info('name')),'meta.field_id = opn.field_id',array('option_id','label'))
						;
		
		$optionsLists = $userMetaTable->fetchAll($optionsSearch)->toArray();
		$optionArrya =array();
		foreach($optionsLists as $search)
		{
			$label = strtolower($search['label']);
			$optionArrya[$search['field_id']][$label] = $search['option_id'];
			
		}
		
		return $optionArrya;
	}
	
	public function getLables($userdata){
		$labels = array();
		foreach($userdata['label'] as $values)
		{
			$labels[] = $values;
		}
		
		return $labels;
	}
	
	protected function _fetchImage($photo_url)
	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $photo_url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($ch, CURLOPT_MAXREDIRS, 5);
		$data = curl_exec($ch);
		curl_close($ch);
			
		$tmpfile = APPLICATION_PATH_TMP . DS . md5($photo_url) . '.jpg';
		@file_put_contents( $tmpfile, $data );
		return $tmpfile;
	}
	
}
