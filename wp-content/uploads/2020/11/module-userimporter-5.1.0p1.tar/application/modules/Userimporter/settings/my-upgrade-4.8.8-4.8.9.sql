update engine4_core_modules SET version = '4.8.9' where name = "userimporter";

INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES ('userimporter_admin_main_webservice', 'userimporter', 'Webservice Import', '', '{"route":"admin_default","module":"userimporter","controller":"settings","action":"webservice"}', 'userimporter_admin_main', '', 1, 0, 2);

INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES ('userimporter_admin_main_logs', 'userimporter', 'Import Logs', '', '{"route":"admin_default","module":"userimporter","controller":"settings","action":"logs"}', 'userimporter_admin_main', '', 1, 0, 3);


CREATE TABLE IF NOT EXISTS `engine4_userimporter_datas` (
  `data_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` text,
  `creation_date` datetime DEFAULT NULL,
  `params` text,
  `status` int(11) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `log_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`data_id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `engine4_userimporter_logs` (
  `log_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `import_type` varchar(255) DEFAULT NULL,
  `creation_date` datetime DEFAULT NULL,
  `params` text,
  `import_url` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=latin1;

