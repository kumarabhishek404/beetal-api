<?php
class Userimporter_Model_DbTable_Datas extends Engine_Db_Table
{
 
}