<?php
class Userimporter_Model_DbTable_Logs extends Engine_Db_Table
{
 
}