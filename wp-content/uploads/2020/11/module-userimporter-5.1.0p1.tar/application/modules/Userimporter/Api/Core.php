<?php
class Userimporter_Api_Core extends Core_Api_Abstract {
	public function uploadCsv(array $csv_data = array(),$level_id,$verified,$approved,$notify_email,$log_id) {
		$log = Zend_Registry::get('Zend_Log');
		$final_array = array ();

		$keys = $csv_data [0];
		$pos = array_search ( "Email", $csv_data [0] );

		foreach ( $csv_data as $row ) {
			$i = 0;
			$name_email_Arr = array ();
			foreach ( $keys as $key ) {

				$name_email_Arr [$key] = $row [$i];

				$i ++;
			}
			if ($row [$pos] != "") {
				$final_array [$row [$pos]] = $name_email_Arr;
			}
		}

		$log->log ("upload csv notify email" .$notify_email, Zend_Log::DEBUG );

		// call the quick sign up method
		$this->insertUser($final_array,$level_id,$verified,$approved,$notify_email,$log_id);

		// $this->quickSignup($name_email_Arr,$type,$level_id);
	}
	public function getCsv($usercsv) {
		if ($usercsv instanceof Zend_Form_Element_File) {
			$file = $usercsv->getFileName ();
			$fileName = $file;
		} else if ($usercsv instanceof Storage_Model_File) {
			$file = $usercsv->temporary ();
			$fileName = $usercsv->name;
		} else if ($usercsv instanceof Core_Model_Item_Abstract && ! empty ( $usercsv->file_id )) {
			$tmpRow = Engine_Api::_ ()->getItem ( 'storage_file', $usercsv->file_id );
			$file = $tmpRow->temporary ();
			$fileName = $tmpRow->name;
		} else if (is_array ( $usercsv ) && ! empty ( $usercsv ['tmp_name'] )) {
			$file = $usercsv ['tmp_name'];
			$fileName = $usercsv ['name'];
		} else if (is_string ( $usercsv ) && file_exists ( $usercsv )) {
			$file = $usercsv;
			$fileName = $usercsv;
		} else {
			throw new User_Model_Exception ( 'invalid argument passed to setfile' );
		}

		if (! $fileName) {
			$fileName = $file;
		}

		if (! file_exists ( 'public/csv' )) {
			mkdir ( 'public/csv' );
		}
		rename ( $fileName, 'public/csv/' . basename ( $file ) );
		return 'public/csv/' . basename ( $file );
	}
	public function readCsv($filepath) {
		ini_set('auto_detect_line_endings',TRUE);
		$log = Zend_Registry::get('Zend_Log');
		$values = array ();
		$line_of_text = array ();
		$file_handle = fopen ( $filepath, "r" );
		/* while ( ! feof ( $file_handle ) ) {

			$line_of_text [] = fgetcsv ( $file_handle, 1024 );
		} */
		while (($line = fgetcsv($file_handle)) !== FALSE ) {

			$line_of_text [] = $line;
		}
		fclose ( $file_handle );
		ini_set('auto_detect_line_endings',FALSE);
		//$log->log("read file array".json_encode($line_of_text),Zend_Log::DEBUG);
		return $line_of_text;
	}
	public function quickSignup(array $userdata = array(), $type, $level_id) {
		$log = Zend_Registry::get ( 'Zend_Log' );
		foreach ( $userdata as $key => $value ) {
			if (! empty ( $key ) && ! empty ( $value )) {
				$email = $key;
				$user_name = $value;
				$password = Engine_Api::_ ()->user ()->randomPass ( 10 );
				$last_name = '';
				$userarry = explode ( " ", $user_name );
				$user_table = Engine_Api::_ ()->getDbtable ( 'users', 'user' );
				$user_select = $user_table->select ()->where ( 'email = ?', $email );

				// If post exists
				$existing_user = $user_table->fetchRow ( $user_select );

				if (empty ( $existing_user )) {
					$first_name = $userarry [0];
					if (count ( $userarry ) > 1 && $userarry [1]) {
						$last_name = $userarry [1];
					}

					try {

						$salt = ( string ) rand ( 1000000, 9999999 );
						$salt1 = Engine_Api::_ ()->getApi ( 'settings', 'core' )->getSetting ( 'core.secret', 'staticSalt' );
						$incrypt_password = md5 ( $salt1 . $password . $salt );
						$new_user_id = $user_table->insert ( array (
								'user_id' => null,
								'email' => $email,
								'level_id' => $level_id,
								'password' => $incrypt_password,
								'salt' => $salt,
								'modified_date' => new Zend_Db_Expr ( 'NOW()' ),
								'creation_date' => new Zend_Db_Expr ( 'NOW()' )
						) );

						$userfieldsearchtable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'search' );
						$userfieldsearchtable->insert ( array (
								'item_id' => $new_user_id,
								'profile_type' => $type,
								'first_name' => $first_name,
								'last_name' => $last_name
						) );

						/**
						 * * code start for send welcome email on each email address**
						 */

						$mail_Params = array (
								'host' => $_SERVER ['HTTP_HOST'],
								'email' => $email,
								'recipient_title' => $first_name,
								'password' => $password,
								'object_link' => '/login',

						)
						;

						Engine_Api::_ ()->getApi ( 'mail', 'core' )->sendSystem ( $email, 'core_welcome_password', $mail_Params );
						//Force login
						    Zend_Auth::getInstance()->getStorage()->write($new_user_id);

					    // Redirect
					  
					/**
					 * * code end for send welcome email on each email address**
					 */
					} catch ( Exception $e ) {
						$status = false;
						$message = 'User creation failed' . $e;
					}
				}
			}
		}
	}
	public function insertUser(array $userdata = array(),$level_id,$verified,$approved,$notify_email,$log_id) {
		$log = Zend_Registry::get('Zend_Log');
		$log->log("beforre inserting email notification radio ".json_encode($userdata),Zend_Log::DEBUG);

		/*** set enable and default timezone user value ***/
			$enabled =0;
			if($approved == 1 && $verified ==1)
			{
				$enabled =1;
			}
			date_default_timezone_set(timezone_name_from_abbr("EST"));

		/*** end enable user value ***/

		/*** get labels ***/
			$labels = $this->getLables($userdata);
		/*** end get labels ***/

		/*** set user meta option value ***/

			$valueArray = $this->getUserMetaFields($labels);

		/*** end user meta option value ***/

		/*** get meta enabled fields ***/
			$searchArrya = $this->getEnableMetaFields($labels);
		/*** end meta enable fields ***/

		/*** get option meta value ***/
			$metaOptions = $this->getMetaOptionValues($labels);
		/*** end option meta value ***/

		/*** get user fields tabels ***/
			$userfieldsearchtable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'search' );
			$userfieldValueTable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'values' );
			$dataTable = Engine_Api::_()->getDbTable('datas','userimporter');

		/*** end user fields tables ***/


		/*** iterating user profile data ***/
			foreach ( $userdata as $value ) {
				$user_id = null;
				$email = null;
				$username = null;
				$image = null;
				if (isset ( $value ['User_ID'] )) {
					$user_id = $value ['User_ID'];
				}

				if (isset ( $value ['Email'] )) {
					$email = $value ['Email'];
					if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
						$importData['status'] = 0;
						$importData['message'] = "User has invalid email";
						$dataTable->insert($importData);
						$email = null;
					}
				}
				if (isset ( $value ['Password'] )) {
					$password = $value ['Password'];
				}else {
					$password = rand();
				}
				if(isset($value['Image'])){
					$image = $value['Image'];
				}
				if(isset($value['Username'])){
					$username = $value['Username'];
				}
				if (isset ( $value ['Creation Date'] )) {
					//date_default_timezone_set('America/New_York');
					$datestring = $value ['Creation Date'];  //Pulled in from somewhere
					$creation_date = date('Y-m-d H:i:s T',strtotime($datestring . ' UTC'));
				}
				if (isset ( $value ['Modified Date'] )) {
					$datestring = $value ['Modified Date'];  //Pulled in from somewhere
					$modified_date = date('Y-m-d H:i:s T',strtotime($datestring . ' UTC'));

				}

				if($email == 'Email')
				{
					continue;
				}
				// if email address exist
					$user_table = Engine_Api::_ ()->getDbtable ( 'users', 'user' );
					$existing_user = null;
					if($email){
						$user_select = $user_table->select ()->where ( 'email = ?', $email );
						$existing_user = $user_table->fetchRow ( $user_select );
					}

					$importData = array(
							'email' => $email,
							'params' => json_encode($value),
							'log_id' => $log_id
					);

				if (empty ( $existing_user )) {
					$log->log("start creating ".json_encode($value),Zend_Log::DEBUG);

					try {

						if (empty ( $modified_date )) {
							$modified_date = new Zend_Db_Expr ( 'NOW()' );
						}
						if (empty ( $creation_date )) {
							$creation_date = new Zend_Db_Expr ( 'NOW()' );
						}
						$salt = ( string ) rand ( 1000000, 9999999 );
						$salt1 = Engine_Api::_ ()->getApi ( 'settings', 'core' )->getSetting ( 'core.secret', 'staticSalt' );
						$incrypt_password = md5 ( $salt1 . $password . $salt );

						// if user_id empty , inserting into users

							$new_user_id = $user_table->insert ( array (
									'email' => $email,
									'username' => $user_id,
									'level_id' => $level_id,
									'password' => $incrypt_password,
									'salt' => $salt,
									'modified_date' => $modified_date,
									'creation_date' => $creation_date,
									'approved' => $approved,
									'verified' => $verified,
									'enabled' => $enabled
							) );

						// inserting into search
						$userfieldsearchtable->insert ( array (
								'item_id' => $new_user_id,
								'profile_type' => 1
						));

						$userfieldValueTable->insert ( array (
								'item_id' => $new_user_id,
								'field_id' => 1,
								'value' =>1,
								'privacy' => "everyone"
						) );

						foreach ( $value as $key => $values ) {
							if (array_key_exists ( $key, $valueArray )) {
								$field_id = $valueArray [$key];
								$value = $values;
								if(array_key_exists($field_id, $metaOptions)){
									if($metaOptions[$field_id][$values]){
										$value = $metaOptions[$field_id][$values];
									}
								}
								$userfieldValueTable->insert ( array (
										'item_id' => $new_user_id,
										'field_id' => $valueArray [$key],
										'value' =>$value,
										'privacy' => "everyone"
								));
							}
						}

						$user = Engine_Api::_ ()->getItem ( 'user', $new_user_id );
						$aliasValues = Engine_Api::_()->fields()->getFieldsValuesByAlias($user);
						$user->setDisplayName($aliasValues);
						//$user['username'] = $new_user_id;
						$user->save();
						//$log->log("email gone for simle login>>>".$notify_email,Zend_Log::DEBUG);
						$values = Engine_Api::_()->fields()->getFieldsValues($user);
						Engine_Api::_()->getApi('core', 'fields')->updateSearch($user, $values);

						$importData['status'] = 1;
						$importData['message'] = "Import Successfull";
						$data_id = $dataTable->insert($importData);

						if(isset($image) && $image != "" && !empty($image)){
							try{
								$tmpfile = $this->_fetchImage($image);
								$user->setPhoto($tmpfile);
								$dataTable->update(array('message' => "User imported with image succesfully."),'data_id ='.$data_id);

							}catch(Exception $e){
								$log->log("Exception while uploading image:- ".$e->getMessage(),Zend_Log::DEBUG);
								$dataTable->update(array('message' => "User imported without image succesfully."),'data_id ='.$data_id);

							}
						}
						try{
							if(isset($username) && !empty($username)){
								$user->username = $username;
							}else{
								$user->username = $new_user_id;
							}
							$user->save();
						}
						catch(Exception $e){
							$dataTable->update(array('message' => "User imported with image succesfully.Username already exists"),'data_id ='.$data_id);
						}

						if(isset($image) && $image != "" && !empty($image)){
							try{
								$log->log("start creating ".$image,Zend_Log::DEBUG);

								$tmpfile = $this->_fetchImage($image);
								$user->setPhoto($tmpfile);
								$dataTable->update(array('message' => "User imported with image succesfully."),'data_id ='.$data_id);

							}catch(Exception $e){
								$log->log("Exception while uploading image:- ".$e->getMessage(),Zend_Log::DEBUG);
								$dataTable->update(array('message' => "User imported without image succesfully."),'data_id ='.$data_id);
							}
						}
						if($notify_email){

							$mail_template = 'core_welcome_password';
							$mailParams = array(
									'host' => $_SERVER['HTTP_HOST'],
									'email' => $email,
									'date' => time(),
									'recipient_title' => $new_user_id,
									'recipient_link' => $user->getHref(),
									'recipient_photo' => $user->getPhotoUrl('thumb.icon'),
									'object_link' => $user->getHref(),
									'queue' => false,
									'password' => $password

							);
							try {
								$email_sent = Engine_Api::_ ()->getApi ( 'mail', 'core' )->sendSystem ( $email, $mail_template, $mailParams );

								$status = true;
								$message = 'User sucessfully signup';
							} catch ( Exception $ex ) {
								// throw $ex;
							}
						}


					} catch ( Exception $e ) {
						$status = false;
						$message = 'User creation failed' . $e;

						$importData['status'] = 0;
						$importData['message'] = "Import failed";
						$dataTable->insert($importData);
					}

				}else{
					$importData['status'] = 0;
					$importData['message'] = "User already exists with email";
					$dataTable->insert($importData);
				}
			}
		/*** end iterating user profile data ***/


	}
	public function getOptionsIds($value)
	{
		$log = Zend_Registry::get('Zend_Log');
		//$log->log("getOptions return array".json_encode($value),Zend_Log::DEBUG);
		$userfieldOptionTable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'options' );
		$select = $userfieldOptionTable->select();
		if(is_array($value))
		{
			$select->where("label IN (?)",$value);
			$res = $userfieldOptionTable->fetchAll($select);
			return $res;
		}
		else{
			$select->where("label = ? ",$value);
			$res = $userfieldOptionTable->fetchRow($select);
			return $res['option_id'];
		}
	}

	public function getUserMetaFields($labels){
		$log = Zend_Registry::get('Zend_Log');

		$userfieldMetaTable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'meta' );
		$userfieldsearchtable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'search' );
		$userfieldValueTable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'values' );


		// for values table
		$valueArray =array();
		if(count($labels) > 0){
			$seletFieldID= $userfieldMetaTable->select()->where("label IN (?)",$labels);

			$resfieldsValues = $userfieldMetaTable->fetchAll($seletFieldID)->toArray();

			foreach($resfieldsValues as $value)
			{
				$valueArray[$value['label']] = $value['field_id'];
			}
		}

		return $valueArray;

	}

	public function getEnableMetaFields($labels){
		$userfieldMetaTable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'meta' );
		$userfieldsearchtable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'search' );
		$userfieldValueTable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'values' );


		$seletFieldID= $userfieldMetaTable->select()->where("label IN (?)",$labels);
		$seletFieldID->where("search = 1");
		$resfieldsSearch = $userfieldMetaTable->fetchAll($seletFieldID)->toArray();
		$searchArrya =array();
		foreach($resfieldsSearch as $search)
		{
			if(!empty($search['alias']))
			{
				$searchArrya[$search['label']] =$search['alias'] ;
			}
			else {
				$searchArrya[$search['label']] = $search['field_'.$search['field_id']];
			}
		}

		return $searchArrya;
	}

	public function getMetaOptionValues($labels){
		$userMetaTable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'meta' );
		$userOptionTable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'options' );

		$optionsSearch= $userMetaTable->select()
						->setIntegrityCheck(false)
						->from(array('meta' => $userMetaTable->info('name')),array('field_id'))
						->join(array('opn' => $userOptionTable->info('name')),'meta.field_id = opn.field_id',array('option_id','label'))
						->where("meta.label IN (?)",$labels);

		$optionsLists = $userMetaTable->fetchAll($optionsSearch)->toArray();
		$optionArrya =array();
		foreach($optionsLists as $search)
		{

			$optionArrya[$search['field_id']][$search['label']] = $search['option_id'];

		}

		return $optionArrya;
	}

	public function getLables($userdata){
		$labels = array();
		foreach($userdata['Email'] as $values)
		{
			$labels[] = $values;
		}

		return $labels;
	}


	protected function _fetchImage($photo_url)
	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $photo_url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($ch, CURLOPT_MAXREDIRS, 5);
		$data = curl_exec($ch);
		curl_close($ch);

		$tmpfile = APPLICATION_PATH_TMP . DS . md5($photo_url) . '.jpg';
		@file_put_contents( $tmpfile, $data );
		return $tmpfile;
	}
public function getEnablePackage($level_id){
	$table = Engine_Api::_()->getDbtable('packages', 'payment');
    $select = $table->select();
    $select->where('level_id = ?', $level_id);
    $select->where('enabled = ?', 1);
    $packagesRows = $table->fetchAll($select);
    return $packagesRows;
}

}
