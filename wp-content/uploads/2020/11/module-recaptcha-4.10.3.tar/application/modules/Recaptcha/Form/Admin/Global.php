<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Page
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: Global.php 2010-08-31 16:05 idris $
 * @author     Idris
 */

/**
 * @category   Application_Extensions
 * @package    Recaptcha
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */
class Recaptcha_Form_Admin_Global extends Engine_Form
{
    public function init()
    {
        $view = Zend_Registry::get('Zend_View');
        $this
            ->setTitle($view->translate('Recaptcha Settings'))
            ->setDescription($view->translate('Register API keys at').' <a target="_blank" href ="https://www.google.com/recaptcha/admin">https://www.google.com/recaptcha/admin</a>');

        // Decorators
        $this->loadDefaultDecorators();
        $this->getDecorator('Description')->setOption('escape', false);

        $settings = Engine_Api::_()->getDbTable('settings', 'core');


        $this->addElement('Radio', 'show_signup', array(
            'label' => $view->translate('Enable anti-spamming technique in signup form?'),
            'multiOptions' => array(
                1 => $view->translate('Yes, enable anti-spamming technique in signup form for email field.'),
                0 => $view->translate('No, do not enable anti-spamming technique in signup form for email field.')
            ),
            'value' => $settings->getSetting('recaptcha.show.signup', '0'),
        ));

        $this->addElement('Radio', 'show_signing', array(
            'label' => 'Require users to enter validation code when signing in?',
            'multiOptions' => array(
                1 => $view->translate('Yes, make members complete the CAPTCHA form.'),
                0 => $view->translate('No, do not show a CAPTCHA form.')
            ),
            'value' => $settings->getSetting('recaptcha.show.signing', '0'),
        ));
        $this->addElement('Radio', 'show_login_popup', array(
            'label' => $view->translate('Require users to enter a confirmation code when logging into the system in a pop-up'),
            'multiOptions' => array(
                1 => $view->translate('Yes, make members complete the CAPTCHA form.'),
                0 => $view->translate('No, do not show a CAPTCHA form.')
            ),
            'value' => $settings->getSetting('recaptcha.show.popup', '0'),
        ));


        $this->addElement('Text', 'site_key', array(
            'label' => $view->translate('ReCaptcha Public Key'),
            'description' => '',
            'value' => $settings->getSetting('recaptcha.site.key', '')
        ));


        $this->addElement('Text', 'secret_key', array(
            'label' => $view->translate('ReCaptcha Private Key'),
            'description' => '',
            'value' => $settings->getSetting('recaptcha.secret.key', '')
        ));

        $this->addElement('Button', 'submit', array(
            'label' => 'Save Changes',
            'type' => 'submit',
            'ignore' => true
        ));
    }
}

