<?php return array (
  'package' => 
  array (
    'type' => 'module',
    'name' => 'recaptcha',
    'version' => '4.10.3',
     'SKU'=>'HERECAPTCHA',
    'path' => 'application/modules/Recaptcha',
    'title' => 'ReCaptcha',
    'description' => 'Recaptcha Plugin',
    'author' => '<a href="http://www.hire-experts.com" title="Hire-Experts LLC" target="_blank">Hire-Experts LLC</a>',
    'meta' =>
          array(
              'title' => 'Recaptcha',
              'description' => 'Recaptcha Plugin',
              'author' => '<a href="http://www.hire-experts.com" title="Hire-Experts LLC" target="_blank">Hire-Experts LLC</a>',
          ),
    'callback' => 
    array (
        'path' => 'application/modules/Recaptcha/settings/install.php',
        'class' => 'Recaptcha_Installer',
    ),
    'actions' => 
    array (
      0 => 'install',
      1 => 'upgrade',
      2 => 'refresh',
      3 => 'enable',
      4 => 'disable',
    ),
    'directories' => 
    array (
      0 => 'application/modules/Recaptcha',
    ),
    'files' => 
    array (
      0 => 'application/languages/en/recaptcha.csv',
    ),

  ),
  // Routes --------------------------------------------------------------------
  'routes' => array(
      'recaptcha_login' => array(
        //'type' => 'Zend_Controller_Router_Route_Static',
          'route' => '/recaptcha/*',
          'defaults' => array(
              'module' => 'recaptcha',
              'controller' => 'index',
              'action' => 'login'
          )
      ),
  )
); ?>