<?php
require_once __DIR__ . '/controllers/IndexController.php';
class Recaptcha_Bootstrap extends Engine_Application_Bootstrap_Abstract
{
    public function __construct($application)
    {
        parent::__construct($application);
        $this->initViewHelperPath();
        $view = Zend_Registry::get('Zend_View');
        $moduleTable = Engine_Api::_()->getDbTable('modules', 'core');
        $Apptouch_Enabled = $moduleTable->isModuleEnabled('apptouch');
        if( $Apptouch_Enabled && !Engine_Api::_()->apptouch()->isApp()){
            $baseUrl = $view->layout()->staticBaseUrl;
            $view->headScript()->appendFile($baseUrl . 'application/modules/Recaptcha/externals/scripts/core.js');
            $view->headLink()->appendStylesheet($baseUrl . 'application/modules/Recaptcha/externals/styles/main.css');
            $view->headScript()->appendFile('https://www.google.com/recaptcha/api.js');

            $frontController = Zend_Controller_Front::getInstance();
            $response = new Zend_Controller_Response_Http();

            $settings = Engine_Api::_()->getDbTable('settings', 'core');
            $sitekey = $settings->getSetting('recaptcha.site.key', '');

            $router = new Zend_Controller_Router_Rewrite();
            $request = new Zend_Controller_Request_Http();
            $router->route($request);
            $post = empty($_POST)?'':'/post';
            $post = $request->getModuleName().'/'.$request->getControllerName().'/'.$request->getActionName().$post ;

            if('core/signup/index/post' == $post && isset($_POST["password"]) && $settings->getSetting('recaptcha.show.signup', '0') ){
                $capcha = $_POST['g-recaptcha-response'];
                $capcha_check = Recaptcha_IndexController::check_captcha($capcha,$_SERVER['REMOTE_ADDR']);
                if(!$capcha_check){
                    $response->setRedirect($baseUrl.'signup');
                    $frontController->setResponse($response);
                }
                //

            }

            if( $settings->getSetting('recaptcha.show.signup', '0') )
                if('core/signup/index/post' == $post || 'core/signup/index' == $post ){

                    $script_signup = <<<CONTENT
            window.addEvent('domready', function() {
            if($('signup_account_form')){
                var el = $('signup_account_form').getElement('div.form-elements');
                var capcha  = new Element('div', {class: 'g-recaptcha'});

                capcha.set('data-sitekey','{$sitekey}');
                capcha.setStyle('height','80');
                capcha.setStyle('margin-top','20px');
                capcha.setStyle('width','210');
                capcha.inject(el.getElement('div#timezone-element'));
            }
        });
CONTENT;
                    $view->headScript()->appendScript($script_signup);

                }



            if(!empty($sitekey) && $settings->getSetting('recaptcha.show.signing', '0') ) {
                if($post == 'core/index/index')
                    $class = 'my-recaptcha';
                else
                    $class = '';

                $content = <<<CONTENT
            window.addEvent('domready', function() {
            if($('user_form_login')){
                $('user_form_login').set('action', '{$baseUrl}recaptcha/index/login');
                var el = $('user_form_login').getElement('div.form-elements');
                var capcha  = new Element('div', {class: 'g-recaptcha {$class}'});

                capcha.set('data-sitekey','{$sitekey}');
                capcha.setStyle('margin-top','20px');
                capcha.inject(el.getElement('div#password-element'));
            }

        });
CONTENT;
                $view->headScript()->appendScript($content);

                if ($post == 'core/login/index/post') {
                    $response->setRedirect($baseUrl.'login');
                    $frontController->setResponse($response);
                }
            }
        }


    }

}

