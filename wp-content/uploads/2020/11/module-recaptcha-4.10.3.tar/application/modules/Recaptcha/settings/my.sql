INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES
('recaptcha', 'Recaptcha', 'Recaptcha Plugin', '4.10.3', 1, 'extra');
