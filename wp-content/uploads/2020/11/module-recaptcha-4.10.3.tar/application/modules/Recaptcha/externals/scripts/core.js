/**
 * Created by Kalys on 06.09.2016.
 */
function on_enable_plugin(el)
{
    var text = el.get('text');
    if(text == 'ON' ){
        el.set('text','OFF');
        el.set('class','button_box_off');
        $('plugin_state').set('value','0');
    }else{
        el.set('text','ON');
        el.set('class','button_box_on');
        $('plugin_state').set('value','1');
    }

}