<?php
require_once APPLICATION_PATH . '/application/modules/User/controllers/AuthController.php';
//require_once('recaptchalib.php');
require_once __DIR__ . '/../recaptcha/src/autoload.php';

class Recaptcha_IndexController extends User_AuthController
{
    public function indexAction()
    {

    }
    public static function check_captcha($capcha,$ip)
    {
        $settings = Engine_Api::_()->getDbTable('settings', 'core');
        $privatekey = $settings->getSetting('recaptcha.secret.key', '');
        $recaptcha = new \ReCaptcha\ReCaptcha($privatekey);
        $resp = $recaptcha->verify($capcha, $ip );
        if ($resp->isSuccess()){
            return true;
        }else{
            return false;
        }

    }

    public function loginAction()
    {

        if ( self::check_captcha($_POST['g-recaptcha-response'],$_SERVER['REMOTE_ADDR']) ){

            parent::loginAction();

        }else{
            
            return $this->_helper->redirector->gotoRoute(array('action' => 'login'), 'user_login', true);

        }

    }
}