<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Page
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: AdminSettingsController.php 2010-08-31 16:05 idris $
 * @author     Idris
 */

/**
 * @category   Application_Extensions
 * @package    Recaptcha
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */
class Recaptcha_AdminSettingsController extends Core_Controller_Action_Admin
{
    public function init()
    {

        $this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
            ->getNavigation('recaptcha_admin_main', array(), 'recaptcha_admin_main_settings');
    }

    public function indexAction()
    {
        $this->view->form = $form = new Recaptcha_Form_Admin_Global();

        $settings = Engine_Api::_()->getDbTable('settings', 'core');

        if (!$this->getRequest()->isPost()) {
            return;
        }

        if (!$form->isValid($this->getRequest()->getPost())) {
            return;
        }
        //ReCaptcha Public Key
        $value = $form->getValue('site_key');
        $settings->setSetting('recaptcha.site_key', $value);
        $form->site_key->setValue($value);
        //ReCaptcha Private Key
        $value = $form->getValue('secret_key');
        $settings->setSetting('recaptcha.secret.key', $value);
        $form->secret_key->setValue($value);
        //SIGN UP
        $value = $form->getValue('show_signup');
        $settings->setSetting('recaptcha.show.signup', $value);
        $form->show_signup->setValue($value);
        //SIGN IN
        $value = $form->getValue('show_signing');
        $settings->setSetting('recaptcha.show.signing', $value);
        $form->show_signing->setValue($value);
        //LOGIN POPUP
        $value = $form->getValue('show_login_popup');
        $settings->setSetting('recaptcha.show.popup', $value);
        $form->show_login_popup->setValue($value);

        $form->addNotice('Your changes have been saved.');
    }


}