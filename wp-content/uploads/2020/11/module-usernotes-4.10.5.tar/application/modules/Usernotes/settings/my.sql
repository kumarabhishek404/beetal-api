--
-- Insert module Usernotes
--

INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES
('usernotes', 'User Notes', 'User Notes; Profile User Notes', '4.10.5', 1, 'extra');
