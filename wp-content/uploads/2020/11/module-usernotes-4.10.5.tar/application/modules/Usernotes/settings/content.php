<?php

return array(
  array(
    'title' => 'Profile User Notes',
    'description' => 'Displays a member\'s polls on their profile.',
    'category' => 'User Notes',
    'type' => 'widget',
    'name' => 'usernotes.profile-usernotes',
    'defaultParams' => array(
      'title' => 'User Notes',
      'titleCount' => true,
    ),
  ),
);
?>