--
-- Dumping data for table `engine4_core_modules`
--

INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES
('quiz', 'Quizzes', 'Quizzes Plugin', '4.1.5p4', 1, 'extra');