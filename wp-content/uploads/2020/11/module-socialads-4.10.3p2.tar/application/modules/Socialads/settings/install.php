<?php

/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Socialads
 * @author     KALYSKIN
 */
class Socialads_Installer extends Engine_Package_Installer_Module
{
    public function onPreInstall()
    {
        parent::onPreInstall();

        $db = $this->getDb();
        $translate = Zend_Registry::get('Zend_Translate');

        $db->query("CREATE TABLE IF NOT EXISTS `engine4_socialads_ads` (
`ad_id` INT(11) NOT NULL AUTO_INCREMENT,
`viewmode_id` VARCHAR(50) NOT NULL COLLATE 'utf8_unicode_ci',
`order` INT(11) NOT NULL DEFAULT '0',
`price_id` INT(11) NOT NULL,
`user_id` INT(11) NOT NULL,
`title` VARCHAR(255) NULL DEFAULT NULL COLLATE 'utf8_unicode_ci',
`description` TEXT NULL COLLATE 'utf8_unicode_ci',
`ad_url` VARCHAR(255) NOT NULL COLLATE 'utf8_unicode_ci',
`file_id` INT(11) NULL DEFAULT NULL,
`start_date` DATE NOT NULL,
`end_date` DATE NULL DEFAULT NULL,
`view_count` INT(11) NOT NULL DEFAULT '0',
`click_count` INT(11) NOT NULL DEFAULT '0',
`approved` TINYINT(4) NOT NULL DEFAULT '0',
`payd` TINYINT(4) NOT NULL DEFAULT '0',
`creation_date` DATETIME NOT NULL,
`modified_date` DATETIME NULL DEFAULT NULL,
`method_pay` VARCHAR(50) NOT NULL COLLATE 'latin1_swedish_ci',
`email` VARCHAR(50) NULL DEFAULT NULL COLLATE 'latin1_swedish_ci',
`active` TINYINT(4) NOT NULL DEFAULT '0',
`price` DOUBLE NOT NULL,
`raised_sum` DOUBLE NOT NULL DEFAULT '0',
`extend` TINYINT(4) NOT NULL DEFAULT '0',
`extend_count` INT(11) NOT NULL DEFAULT '0',
PRIMARY KEY (`ad_id`)
)
COLLATE='utf8_unicode_ci'
ENGINE=InnoDB ");

        $db->query("CREATE TABLE IF NOT EXISTS `engine4_socialads_clicks` (
`click_id` int(11) NOT NULL AUTO_INCREMENT,
`ad_id` int(11) NOT NULL DEFAULT '0',
`week_date` varchar(100) NOT NULL DEFAULT '0',
`day1` int(11) NOT NULL DEFAULT '0',
`day2` int(11) NOT NULL DEFAULT '0',
`day3` int(11) NOT NULL DEFAULT '0',
`day4` int(11) NOT NULL DEFAULT '0',
`day5` int(11) NOT NULL DEFAULT '0',
`day6` int(11) NOT NULL DEFAULT '0',
`day7` int(11) NOT NULL DEFAULT '0',
PRIMARY KEY (`click_id`)
) COLLATE='utf8_unicode_ci'
ENGINE=InnoDB");

        $db->query("CREATE TABLE IF NOT EXISTS `engine4_socialads_prices` (
`price_id` int(11) NOT NULL AUTO_INCREMENT,
`type_pay` varchar(20) NOT NULL DEFAULT '0',
`viewmode_id` int(11) NOT NULL DEFAULT '0',
`price` double NOT NULL DEFAULT '0',
`discount_percent` double NOT NULL DEFAULT '0',
`count` int(11) NOT NULL DEFAULT '0',
PRIMARY KEY (`price_id`)
) COLLATE='utf8_unicode_ci'
ENGINE=InnoDB");

        $db->query("CREATE TABLE IF NOT EXISTS `engine4_socialads_transactions` (
`transaction_id` int(11) NOT NULL AUTO_INCREMENT,
`order_id` int(10) unsigned NOT NULL DEFAULT '0',
`user_id` int(10) unsigned NOT NULL DEFAULT '0',
`name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
`email` varchar(128) CHARACTER SET ucs2 COLLATE ucs2_unicode_ci DEFAULT NULL,
`item_id` int(11) unsigned NOT NULL DEFAULT '0',
`item_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
`state` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
`gateway_id` int(11) unsigned NOT NULL DEFAULT '0',
`gateway_transaction_id` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
`amount` double(62,6) NOT NULL DEFAULT '0.000000',
`currency` char(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
`description` text COLLATE utf8_unicode_ci,
`creation_date` datetime NOT NULL,
PRIMARY KEY (`transaction_id`)
) COLLATE='utf8_unicode_ci'
ENGINE=InnoDB");

        $db->query("DROP TABLE IF EXISTS `engine4_socialads_viewmodes`");


        $db->query("CREATE TABLE IF NOT EXISTS `engine4_socialads_viewmodes` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`label` varchar(50) NOT NULL,
`name` varchar(30) NOT NULL,
`cpc` tinyint(4) NOT NULL DEFAULT '1',
`cpm` tinyint(4) NOT NULL DEFAULT '0',
`cpd` tinyint(4) NOT NULL DEFAULT '0',
`params` text,
`active` tinyint(4) NOT NULL DEFAULT '1',
PRIMARY KEY (`id`),
UNIQUE INDEX `name` (`name`)
) COLLATE='utf8_unicode_ci'
ENGINE=InnoDB");

        $db->query("CREATE TABLE IF NOT EXISTS `engine4_socialads_views` (
`view_id` int(11) NOT NULL AUTO_INCREMENT,
`ad_id` int(11) NOT NULL DEFAULT '0',
`week_date` varchar(100) NOT NULL DEFAULT '0',
`day1` int(11) NOT NULL DEFAULT '0',
`day2` int(11) NOT NULL DEFAULT '0',
`day3` int(11) NOT NULL DEFAULT '0',
`day4` int(11) NOT NULL DEFAULT '0',
`day5` int(11) NOT NULL DEFAULT '0',
`day6` int(11) NOT NULL DEFAULT '0',
`day7` int(11) NOT NULL DEFAULT '0',
PRIMARY KEY (`view_id`)
) COLLATE='utf8_unicode_ci'
ENGINE=InnoDB");


        $db->query("INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES
('core_main_socialads', 'socialads', 'Social Ads', '', '{\"route\":\"socialads_general\"}', 'core_main', '', '1', '0', '10'),
('socialads_main_manage', 'socialads', 'My ads', '', '{\"route\":\"socialads_general\"}', 'socialads_main', '', '1', '0', '1'),
('socialads_main_create', 'socialads', 'Create new Ads', '', '{\"route\":\"socialads_general\",\"action\":\"create\"}', 'socialads_main', '', '1', '0', '2'),
('socialads_admin_main_packages', 'socialads', 'Manage ads', '', '{\"route\":\"admin_default\",\"module\":\"socialads\",\"controller\":\"index\",\"action\":\"index\"}', 'socialads_admin_main', '', '1', '0', '1'),
('core_admin_main_plugins_socialads', 'socialads', 'HE - Socialads', '', '{\"route\":\"admin_default\",\"module\":\"socialads\",\"controller\":\"index\"}', 'core_admin_main_plugins', '', '1', '0', '2'),
('socialads_admin_main_adlisting', 'socialads', 'Ads Listing', '', '{\"route\":\"admin_default\",\"module\":\"socialads\",\"controller\":\"index\",\"action\":\"ad-listing\"}', 'socialads_admin_main', '', '1', '0', '1'),
('socialads_admin_main_level_settings', 'socialads', 'Member Level Settings', '', '{\"route\":\"admin_default\",\"module\":\"socialads\",\"controller\":\"level\",\"action\":\"index\"}', 'socialads_admin_main', '', '1', '0', '4'),
('socialads_admin_main_global_settings', 'socialads', 'Global Settings', '', '{\"route\":\"admin_default\",\"module\":\"socialads\",\"controller\":\"index\",\"action\":\"global-settings\"}', 'socialads_admin_main', '', '1', '0', '1')");

        $db->query("INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES ('socialads_admin_main_package_manage', 'socialads', 'Manage plans', '', '{\"route\":\"admin_default\",\"module\":\"socialads\",\"controller\":\"package\",\"action\":\"manage\"}', 'socialads_admin_main', '', 1, 0, 5);");

        $db->query("INSERT IGNORE INTO `engine4_authorization_permissions` (`level_id`, `type`, `name`, `value`, `params`) VALUES
(1, 'socialads', 'allow_delete', 1, NULL),
(1, 'socialads', 'allow_edit', 1, NULL),
(1, 'socialads', 'allow_stop_start', 1, NULL),
(1, 'socialads', 'create_ad', 1, NULL),
(1, 'socialads', 'show_ad', 1, NULL),
(1, 'socialads', 'show_link', 1, NULL),
(2, 'socialads', 'allow_delete', 1, NULL),
(2, 'socialads', 'allow_edit', 1, NULL),
(2, 'socialads', 'allow_stop_start', 1, NULL),
(2, 'socialads', 'create_ad', 1, NULL),
(2, 'socialads', 'show_ad', 1, NULL),
(2, 'socialads', 'show_link', 1, NULL),
(3, 'socialads', 'allow_delete', 1, NULL),
(3, 'socialads', 'allow_edit', 1, NULL),
(3, 'socialads', 'allow_stop_start', 1, NULL),
(3, 'socialads', 'create_ad', 1, NULL),
(3, 'socialads', 'show_ad', 1, NULL),
(3, 'socialads', 'show_link', 1, NULL),
(4, 'socialads', 'allow_delete', 1, NULL),
(4, 'socialads', 'allow_edit', 1, NULL),
(4, 'socialads', 'allow_stop_start', 1, NULL),
(4, 'socialads', 'create_ad', 1, NULL),
(4, 'socialads', 'show_ad', 1, NULL),
(4, 'socialads', 'show_link', 1, NULL),
(5, 'socialads', 'allow_delete', 0, NULL),
(5, 'socialads', 'allow_edit', 0, NULL),
(5, 'socialads', 'allow_stop_start', 0, NULL),
(5, 'socialads', 'create_ad', 0, NULL),
(5, 'socialads', 'show_ad', 0, NULL),
(5, 'socialads', 'show_link', 0, NULL);");

$db->query("
INSERT IGNORE INTO `engine4_socialads_viewmodes` ( `label`, `name`, `cpc`, `cpm`, `cpd`, `params`, `active`) VALUES
( 'Default', 'default', 1, 1, 1, '{\"required_fields\":{\"space\":true,\"title\":true,\"description\":true,\"url\":true,\"image\":true,\"start_date\":true}}', 1),
( 'Default-Extra', 'default-extra', 1, 1, 1, '{\"required_fields\":{\"space\":true,\"title\":true,\"description\":true,\"url\":true,\"image\":true,\"start_date\":true}}', 1),
( 'Side links', 'side-links', 1, 1, 1, '{\"background_color\":\"0C1F2B\",\"font_color\":\"3CC42D\",\"count_in_widget\":\"3\",\"required_fields\":{\"space\":true,\"title\":true,\"description\":true,\"url\":true,\"image\":false,\"start_date\":true}}', 1),
( 'Sticker Style', 'sticker-style', 1, 1, 1, '{\"background_color\":\"f44336\",\"font_color\":\"000000\",\"count_in_widget\":\"3\",\"required_fields\":{\"space\":true,\"title\":true,\"description\":true,\"url\":true,\"image\":false,\"start_date\":true}}', 1),
( 'FB-style', 'FB-style', 1, 1, 1, '{\"background_color\":\"F7FFFF\",\"font_color\":\"485C59\",\"count_in_widget\":\"1\",\"required_fields\":{\"space\":true,\"title\":true,\"description\":true,\"url\":true,\"image\":true,\"start_date\":true}}', 1),
( 'Full-Image', 'Full-Image', 1, 1, 1, '{\"required_fields\":{\"space\":true,\"title\":true,\"description\":false,\"url\":true,\"image\":true,\"start_date\":true}}', 1),
( 'Responsive-Image', 'Responsive-Image', 1, 1, 1, '{\"required_fields\":{\"space\":true,\"title\":true,\"description\":false,\"url\":true,\"image\":true,\"start_date\":true}}', 1),
( 'Standart-block', 'Standart-block', 1, 1, 1, '{\"required_fields\":{\"space\":true,\"title\":true,\"description\":false,\"url\":true,\"image\":true,\"start_date\":true}}', 1),
( 'Wall-feed-mini', 'Wall-feed-mini', 1, 1, 1, '{\"required_fields\":{\"space\":true,\"title\":true,\"description\":true,\"url\":true,\"image\":true,\"start_date\":true}}', 1),
( 'Sidebar-ads', 'Sidebar-ads', 1, 1, 1, '{\"required_fields\":{\"space\":true,\"title\":true,\"description\":true,\"url\":true,\"image\":true,\"start_date\":true}}', 1),
( 'Wall-feed-large', 'Wall-feed-large', 1, 1, 0, '{\"required_fields\":{\"space\":true,\"title\":true,\"description\":true,\"url\":true,\"image\":true,\"start_date\":true}}', 1);
");

        if ($result = $db->query("SHOW TABLES LIKE 'engine4_credit_actiontypes'")->fetchAll()) {

            $db->query("INSERT IGNORE INTO `engine4_credit_actiontypes` (`action_type`, `group_type`, `action_module`, `action_name`, `credit`, `max_credit`, `rollover_period`) VALUES ('buy_socialads', 'spent', NULL, 'Socialads', 0, 0, 0);");



    }

    $db->query("DROP TABLE IF EXISTS `engine4_socialads_viewmodes`");


    $db->query("CREATE TABLE IF NOT EXISTS `engine4_socialads_viewmodes` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`label` varchar(50) NOT NULL,
`name` varchar(30) NOT NULL,
`cpc` tinyint(4) NOT NULL DEFAULT '1',
`cpm` tinyint(4) NOT NULL DEFAULT '0',
`cpd` tinyint(4) NOT NULL DEFAULT '0',
`params` text,
`active` tinyint(4) NOT NULL DEFAULT '1',
PRIMARY KEY (`id`),
UNIQUE INDEX `name` (`name`)
) COLLATE='utf8_unicode_ci'
ENGINE=InnoDB");


    $db->query("
INSERT IGNORE INTO `engine4_socialads_viewmodes` ( `label`, `name`, `cpc`, `cpm`, `cpd`, `params`, `active`) VALUES
( 'Default', 'default', 1, 1, 1, '{\"required_fields\":{\"space\":true,\"title\":true,\"description\":true,\"url\":true,\"image\":true,\"start_date\":true}}', 1),
( 'Default-Extra', 'default-extra', 1, 1, 1, '{\"required_fields\":{\"space\":true,\"title\":true,\"description\":true,\"url\":true,\"image\":true,\"start_date\":true}}', 1),
( 'Side links', 'side-links', 1, 1, 1, '{\"background_color\":\"0C1F2B\",\"font_color\":\"3CC42D\",\"count_in_widget\":\"3\",\"required_fields\":{\"space\":true,\"title\":true,\"description\":true,\"url\":true,\"image\":false,\"start_date\":true}}', 1),
( 'Sticker Style', 'sticker-style', 1, 1, 1, '{\"background_color\":\"f44336\",\"font_color\":\"000000\",\"count_in_widget\":\"3\",\"required_fields\":{\"space\":true,\"title\":true,\"description\":true,\"url\":true,\"image\":false,\"start_date\":true}}', 1),
( 'FB-style', 'FB-style', 1, 1, 1, '{\"background_color\":\"F7FFFF\",\"font_color\":\"485C59\",\"count_in_widget\":\"1\",\"required_fields\":{\"space\":true,\"title\":true,\"description\":true,\"url\":true,\"image\":true,\"start_date\":true}}', 1),
( 'Full-Image', 'Full-Image', 1, 1, 1, '{\"required_fields\":{\"space\":true,\"title\":true,\"description\":false,\"url\":true,\"image\":true,\"start_date\":true}}', 1),
( 'Responsive-Image', 'Responsive-Image', 1, 1, 1, '{\"required_fields\":{\"space\":true,\"title\":true,\"description\":false,\"url\":true,\"image\":true,\"start_date\":true}}', 1),
( 'Standart-block', 'Standart-block', 1, 1, 1, '{\"required_fields\":{\"space\":true,\"title\":true,\"description\":false,\"url\":true,\"image\":true,\"start_date\":true}}', 1),
( 'Wall-feed-mini', 'Wall-feed-mini', 1, 1, 1, '{\"required_fields\":{\"space\":true,\"title\":true,\"description\":true,\"url\":true,\"image\":true,\"start_date\":true}}', 1),
( 'Sidebar-ads', 'Sidebar-ads', 1, 1, 1, '{\"required_fields\":{\"space\":true,\"title\":true,\"description\":true,\"url\":true,\"image\":true,\"start_date\":true}}', 1),
( 'Wall-feed-large', 'Wall-feed-large', 1, 1, 0, '{\"required_fields\":{\"space\":true,\"title\":true,\"description\":true,\"url\":true,\"image\":true,\"start_date\":true}}', 1);
");

}
}

?>