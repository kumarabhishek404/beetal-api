<?php

/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Socialads
 * @author     KALYSKIN
 */
class Socialads_Form_Admin_Level extends Authorization_Form_Admin_Level_Abstract
{
    public function init()
    {
        parent::init();
        $view = Zend_Registry::get('Zend_View');
        $this->setTitle('Member Level Settings')
            ->setDescription($view->translate('These settings are applied on a per member level basis. Start by selecting the member level you want to modify, then adjust the settings for that level below.'));


        $this->addElement('Radio', 'create_ad', array(
            'label' => $view->translate('Allow members to create ads ?'),
            'value' => 1,
            'multiOptions' => array(
                '1' => $view->translate('Yes, allow.'),
                '0' => $view->translate('No, disable.'),
            ),
        ));

        $this->addElement('Radio', 'show_ad', array(
            'label' => 'Show ads to members ?',
            'value' => 1,
            'multiOptions' => array(
                '1' => $view->translate('Yes, show ads to this member level.'),
                '0' => $view->translate('No, don\'t show any ads.'),
            ),
        ));

        $this->addElement('Radio', 'show_link', array(
            'label' => $view->translate('Show Create link in ads blocks ?'),
            'value' => 1,
            'multiOptions' => array(
                '1' => $view->translate('Yes, Show link.'),
                '0' => $view->translate('No, Hide link.'),
            ),

        ));
        $this->addElement('Radio', 'allow_edit', array(
            'label' => $view->translate('Allow users to edit ads ?'),
            'value' => 1,
            'multiOptions' => array(
                '1' => $view->translate('Yes allow.'),
                '0' => $view->translate('No, disable.'),
            ),

        ));
        $this->addElement('Radio', 'allow_delete', array(
            'label' => $view->translate('Allow users to delete ads?'),
            'value' => 1,
            'multiOptions' => array(
                '1' => $view->translate('Yes allow.'),
                '0' => $view->translate('No, disable.'),
            ),
        ));
        $this->addElement('Radio', 'allow_stop_start', array(
            'label' => $view->translate('Allow stop and start ads?'),
            'value' => 1,
            'multiOptions' => array(
                '1' => $view->translate('Yes allow.'),
                '0' => $view->translate('No, disable.'),
            ),
        ));

    }


}

