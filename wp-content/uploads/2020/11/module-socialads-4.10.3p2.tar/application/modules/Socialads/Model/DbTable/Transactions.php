<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Kalyskin
 * Date: 21.11.16
 * Time: 08:00
 * To change this template use File | Settings | File Templates.
 */
class Socialads_Model_DbTable_Transactions extends Engine_Db_Table
{
  protected $_rowClass = "Socialads_Model_Transaction";

  public function getAds($params = array()){
    $settings = Engine_Api::_()->getDbTable('settings', 'core');
    return $this->select()
      ->where('item_id = ?', $params['ad_id'])
      ->where('state = ?', 'completed')
      ->where('user_id > 0')
      ->order('amount DESC')
      ->limit($settings->getSetting('socialads.per.page', 10));
  }

}
