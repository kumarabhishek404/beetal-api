<?php

/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Socialads
 * @author     KALYSKIN
 */
class Socialads_AdminPackageController extends Core_Controller_Action_Admin
{
    public function indexAction()
    {
        $this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
            ->getNavigation('socialads_admin_main', array(), 'socialads_admin_main_packages');
        $id_model = $this->getParam('id_model', 0);
        $model = Engine_Api::_()->getItem('viewmode', $id_model);
        if ($model == null) return;
        $form = new Socialads_Form_Admin_PackageSettings();
        $form->setPreview($model);
        $this->view->form = $form;

        if (!$this->getRequest()->isPost()) {
            return;
        }
        $values = $_POST;

        $db = Engine_Db_Table::getDefaultAdapter();
        $db->beginTransaction();

        try {
            $model->setParam('background_color', $values['background_color']);
            $model->setParam('font_color', $values['font_color']);
            $model->setParam('count_in_widget', $values['count_ads']);
            $model->setParam('wall_count', $values['wall_count']);
            $model->label = $values['label_model'];
            $model->save();

            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
        }
        return $this->_helper->redirector->gotoRoute(array('module' => 'socialads', "controller" => "index", "action" => "index"), 'admin_default', true);


    }

    public function editPackageAction()
    {
        $id_pack = $this->getParam('package_id', 0);
        $model = Engine_Api::_()->getItem('price', $id_pack);
        if ($model == null) return;
        $form = new Socialads_Form_Admin_Package();

        $view_model = Engine_Api::_()->getDbtable('viewmodes', 'socialads');
        $view_modes = $view_model->getModesAssoc(false,'id');
        if (!empty($view_modes) && is_array($view_modes) && $form->getElement('space')) {
            $form->getElement('space')->addMultiOptions($view_modes);
        }
        $form->populate_($model);
        $this->view->form = $form;

        if (!$this->getRequest()->isPost()) {
            return;
        }
        if (!$form->isValid($this->getRequest()->getPost())) {
            return;
        }
        $values = $this->getRequest()->getPost();
        $db = Engine_Db_Table::getDefaultAdapter();
        $db->beginTransaction();

        try {
            $model->type_pay = trim($values['billing_model']);
            $model->count = intval($values['count']);
            $model->discount_percent = is_numeric($values['discount']) ? $values['discount'] : 0;
            $model->price = is_numeric($values['discount']) ? $values['price'] : 0;
            $model->viewmode_id = intval($values['space']);
            $model->save();
            $form->addNotice('Package have been successfully saved');

            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
        }


    }

    public function deletePackagesAction()
    {
        $id_pack = $this->getParam('package_id', 0);
        $this->view->package_id = $id_pack;
        $adsTable = Engine_Api::_()->getDbtable('ads', 'socialads');
        if ($id_pack) {
            $price = Engine_Api::_()->getItem('price', $id_pack);

            if (!$price) {
                return $this->_forward('success', 'utility', 'core', array(
                    'smoothboxClose' => 10,
                    'parentRefresh' => 10,
                    'messages' => array('')
                ));
            }

            if (!$this->getRequest()->isPost()) {
                // Output
                $this->renderScript('admin-package/delete-package.tpl');
                return;
            }
            // Process
            $db = $adsTable->getAdapter();
            $db->beginTransaction();

            try {

                $price->delete();
                $db->commit();
            } catch (Exception $e) {
                $db->rollBack();
                throw $e;
            }

            return $this->_forward('success', 'utility', 'core', array(
                'smoothboxClose' => 10,
                'parentRefresh' => 10,
                'messages' => array('')
            ));

        } else return;
    }

    public function manageAction()
    {
        $this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
            ->getNavigation('socialads_admin_main', array(), 'socialads_admin_main_package_manage');

        $this->view->form = $form = new Socialads_Form_Admin_PackageManage();

        $table = Engine_Api::_()->getDbTable('prices', 'socialads');
        $select = $table->select();
        $this->view->paginator = $paginator = Zend_Paginator::factory($select);
        $paginator->setCurrentPageNumber($this->getParam('page', 1));
        $paginator->setItemCountPerPage(15);

        $view_model = Engine_Api::_()->getDbtable('viewmodes', 'socialads');
        $view_modes = $view_model->getModesAssoc(false,'id');
        if (!empty($view_modes) && is_array($view_modes) && $form->getElement('space')) {
            $form->getElement('space')->addMultiOptions($view_modes);
        }
        if (!$this->getRequest()->isPost()) {
            return;
        }
        if (!$form->isValid($this->getRequest()->getPost())) {
            return;
        }
        $values = $this->getRequest()->getPost();

        $db = $table->getAdapter();
        $db->beginTransaction();
        try {
            $val = array(
                'type_pay' => $values['billing_model'],
                'viewmode_id' => $values['space'],
                'price' => $values['price'],
                'discount_percent' => $values['discount'],
                'count' => $values['count'],
            );

            $price = $table->createRow();
            $price->setFromArray($val);
            $price->save();
            $db->commit();

            //$this->view->form = $form = new Engine_Form();
            $form->addNotice("Package have been successfully added!");


        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
            $form->addError("An error occurred while saving data");
        }
    }

}

