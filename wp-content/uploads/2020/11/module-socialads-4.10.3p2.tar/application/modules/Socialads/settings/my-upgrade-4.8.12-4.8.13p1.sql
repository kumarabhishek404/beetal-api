UPDATE `engine4_core_modules` SET `version` = '4.8.13p1' WHERE `name` = 'socialads';
