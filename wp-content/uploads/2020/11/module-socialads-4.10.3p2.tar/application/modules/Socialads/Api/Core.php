<?php

/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Socialads
 * @author     KALYSKIN
 */
class Socialads_Api_Core extends Core_Api_Abstract
{
    public $_cache = null;
    protected $_plugin;

    public function Chache()
    {
        if($this->_cache === null) {

            if( Zend_Registry::isRegistered('Zend_Cache') )
            {
                $this->_cache = Zend_Registry::get('Zend_Cache');
            }
        }
        return $this->_cache;

    }

    public function getThisWeek($format = 'd.m')
    {
        $days = array(
            'Monday' => date($format,    strtotime("Monday this week")),
            'Tuesday' => date($format,   strtotime("Tuesday this week")),
            'Wednesday' => date($format, strtotime("Wednesday this week")),
            'Thursday' => date($format,  strtotime("Thursday this week")),
            'Friday' => date($format,    strtotime("Friday this week")),
            'Saturday' => date($format,  strtotime("Saturday this week")),
            'Sunday' => date($format,    strtotime("Sunday this week")),
        );
        return $days;
    }
    public function getPrevWeek($format = 'd.m',$i)
    {
        $days = array(
            'Monday' => date($format,   strtotime("-{$i} Monday this week")),
            'Tuesday' => date($format,  strtotime("-{$i} Tuesday this week")),
            'Wednesday' => date($format,strtotime("-{$i} Wednesday this week")),
            'Thursday' => date($format, strtotime("-{$i} Thursday this week")),
            'Friday' => date($format,   strtotime("-{$i} Friday this week")),
            'Saturday' => date($format, strtotime("-{$i} Saturday this week")),
            'Sunday' => date($format,   strtotime("-{$i} Sunday this week")),
        );
        return $days;
    }

    public function generateLine($value = array(), $data2 = array())
    {
        if (!count($value)) {
            $value = array(
                1 => 0,
                2 => 0,
                3 => 0,
                4 => 0,
                5 => 0,
                6 => 0,
                7 => 0,
            );
            $data2 = $value;
        }
        asort($value);
        end($value);
        asort($data2);
        end($data2);
        if ($value[key($value)] >= $data2[key($data2)]) $max = $value[key($value)];
        else $max = $data2[key($data2)];
        $max = $this->getMax($max);
        define('MAX_COUNT', $max);
        define('MIN_COUNT', 0);
        define('MAX_VAL', 35);
        define('MIN_VAL', 165);
        define('ONE_PERCENT', (MIN_VAL - MAX_VAL) / 100);


        $p = function ($val) {
            return MIN_VAL - (($val * 100 / MAX_COUNT) * ONE_PERCENT);
        };
        $path = "
            M45,
            {$p($value[1])}
            C75.38095238095238,
            {$p($value[1])},

            154.52380952380955,
            {$p($value[2])},
            209.28571428571428,
            {$p($value[2])}
            C270.04761904761904,
            {$p($value[2])},

            318.8095238095238,
            {$p($value[3])},
            373.57142857142856,
            {$p($value[3])}
            C428.3333333333333,
            {$p($value[3])},

            483.0952380952381,
            {$p($value[4])},
            537.8571428571429,
            {$p($value[4])}
            C592.6190476190477,
            {$p($value[4])},

            647.3809523809524,
            {$p($value[5])},
            702.1428571428571,
            {$p($value[5])}
            C756.9047619047619,
            {$p($value[5])},

            811.6666666666664,
            {$p($value[6])},
            866.4285714285713,
            {$p($value[6])}
            C921.1904761904761,
            {$p($value[6])},

            1003.3333333333334,
            {$p($value[7])},
            1030.7142857142858,
            {$p($value[7])}";
        // print_die($path);
        return $path;

    }

    public function generateDots($value = array(), $data2 = array())
    {
        if (!count($value)) {
            $value = array(
                1 => 0,
                2 => 0,
                3 => 0,
                4 => 0,
                5 => 0,
                6 => 0,
                7 => 0,
            );
            $data2 = $value;
        }
        asort($value);
        end($value);
        asort($data2);
        end($data2);
        if ($value[key($value)] >= $data2[key($data2)]) $max = $value[key($value)];
        else $max = $data2[key($data2)];
        $max = $this->getMax($max);
        define('MAX_COUNT', $max);
        define('MIN_COUNT', 0);

        define('MAX_VAL', 35);
        define('MIN_VAL', 165);
        define('ONE_PERCENT', (MIN_VAL - MAX_VAL) / 100);
        $p = function ($val) {
            return MIN_VAL - (($val * 100 / MAX_COUNT) * ONE_PERCENT);
        };
        $path = array(
            1 => $p($value[1]),
            2 => $p($value[2]),
            3 => $p($value[3]),
            4 => $p($value[4]),
            5 => $p($value[5]),
            6 => $p($value[6]),
            7 => $p($value[7]),
        );
        return $path;

    }

    public function getLefLabel($value = array(), $data2 = array())
    {
        if (!count($value)) {
            $value = array(
                1 => 0,
                2 => 0,
                3 => 0,
                4 => 0,
                5 => 0,
                6 => 0,
                7 => 0,
            );
            $data2 = $value;
        }
        asort($value);
        end($value);
        asort($data2);
        end($data2);
        if ($value[key($value)] >= $data2[key($data2)]) $max = $value[key($value)];
        else $max = $data2[key($data2)];
        $max = $this->getMax($max);
        define('MAX_COUNT', $max);
        define('MIN_COUNT', 0);

        $uu = (MAX_COUNT / 4);
        $path = array(
            0 => ($uu * 0),
            1 => ($uu * 1),
            2 => ($uu * 2),
            3 => ($uu * 3),
            4 => ($uu * 4),
        );
        return $path;
    }

    public function getMax($max)
    {
        $r = true;
        $i = 20;
        $step = 20;
        while ($r) {
            if ($max <= $i && $max >= 0) {
                $max = $i;
                $r = false;
                return $max;
            }
            if ($i >= 100) {
                $step = 100;
            }
            $i += $step;
        }
    }

    public function getWallActionAd()
    {
        $table = Engine_Api::_()->getDbtable('ads', 'socialads');
        $tableModes = Engine_Api::_()->getDbtable('viewmodes', 'socialads');
        $selectModes = $tableModes->select()
            ->where("name LIKE '%wall%'");
        $res = $tableModes->fetchAll($selectModes);

        $vmodel = $res[rand(0, count($res)-1)];

        $id = $vmodel->id;
        $select = $table->select()
            ->where('approved = ?', 1)
            ->where('payd = ?', 1)
            ->where('viewmode_id = ?', $id)
            ->where('start_date <= ?', date('Y-m-d'))
            ->where('active = ?', 1)
            ->order('order ASC')
            ->limit(1);
        $item = $table->fetchRow($select);
        

        if($item != null && $item->getRestPercent() >= 100){
            try{
                $item->active = 0;
                $item->extend = 1;
                $item->save();
                return;
            }catch (Exception $e)
            {
                print_die($e);
            }

        }
        if ($item != null) {
            try {
                $item->incViewCount();
                $item->incOrderCount();
                $item->save();
            } catch (Exception $e) {
                print_die($e->getMessage());
            }
            $view = Zend_Registry::get('Zend_View');
            return array(
                'html' => $view->partial('_ads.php', 'socialads', array(
                    'view_mode' => $item->getBlockType()->name,
                    'model_ad' => $item,
                )),
                'order' => $vmodel->getParam('wall_count', 5)
            );
        } else {
            return false;
        }

    }

    public function getPayPalEmail()
    {
        $settings = Engine_Api::_()->getDbTable('settings', 'core');
        $email = $settings->getSetting('socialads.paypalemail','');
        return $email ; 
    }

    public function sinhronizeClicks($id_ad)
    {
        if(!is_numeric($id_ad) || $id_ad == 0 ) return;
        $ad_item = Engine_Api::_()->getItem('ad', $id_ad);
        $clicks = Engine_Api::_()->getDbtable('clicks', 'socialads');
        $select_click = $clicks
            ->select()
            ->where('ad_id=?', $id_ad);
        $items = $clicks->fetchAll($select_click);
        $summ = 0;
        foreach($items as $row)
        {
            $summ += ($row->day1+$row->day2+$row->day3+$row->day4+$row->day5+$row->day6+$row->day7);
        }
        if($ad_item->click_count != $summ) $res = '!='; else $res = '=';
        $ad_item->click_count = $summ;
        $ad_item->save();
        return $res;
    }

    public function sinhronizeViews($id_ad)
    {
        if(!is_numeric($id_ad) || $id_ad == 0 ) return;
        $ad_item = Engine_Api::_()->getItem('ad', $id_ad);
        $clicks = Engine_Api::_()->getDbtable('views', 'socialads');
        $select_click = $clicks
            ->select()
            ->where('ad_id=?', $id_ad);
        $items = $clicks->fetchAll($select_click);
        $summ = 0;
        foreach($items as $row)
        {
            $summ += ($row->day1+$row->day2+$row->day3+$row->day4+$row->day5+$row->day6+$row->day7);
        }
        if($ad_item->view_count != $summ) $res = '!='; else $res = '=';
        $ad_item->view_count = $summ;
        $ad_item->save();
        return $res;
    }

    public function addDefaultPrices()
    {

        $settings = Engine_Api::_()->getDbTable('settings', 'core');
        $installed = $settings->getSetting('socialads.adddefaultprices',0);

        if($installed == 1) return;

        $viewer = Engine_Api::_()->user()->getViewer();
        if(!$viewer && !$viewer->getIdentity())return;

        $table = Engine_Api::_()->getDbTable('prices', 'socialads');
        $tableViewmodes = Engine_Api::_()->getDbTable('viewmodes', 'socialads');
        $viewmodes = $tableViewmodes->fetchAll($tableViewmodes->select());
        $prices = $table->fetchAll($table->select());

        $settings = Engine_Api::_()->getDbTable('settings', 'core');
        $settings->setSetting('socialads.auto.approve', 1);
        
        if( !count($prices) && count($viewmodes)){

            try{
                foreach ($viewmodes as $viewmode){

                    $CPC = array(
                        'type_pay' => 'CPC',
                        'viewmode_id' => $viewmode->id,
                        'price' => 1,
                        'discount_percent' => 0,
                        'count' => 100,
                    );
                    $CPM = array(
                        'type_pay' => 'CPM',
                        'viewmode_id' => $viewmode->id,
                        'price' => 1,
                        'discount_percent' => 0,
                        'count' => 100,
                    );
                    $CPD = array(
                        'type_pay' => 'CPD',
                        'viewmode_id' => $viewmode->id,
                        'price' => 1,
                        'discount_percent' => 0,
                        'count' => 1,
                    );

                    $table = Engine_Api::_()->getDbTable('prices', 'socialads');
                    $price = $table->createRow();
                    $price->setFromArray($CPC);
                    $price->save();
                    $table = Engine_Api::_()->getDbTable('prices', 'socialads');
                    $price = $table->createRow();
                    $price->setFromArray($CPM);
                    $price->save();
                    $table = Engine_Api::_()->getDbTable('prices', 'socialads');
                    $price = $table->createRow();
                    $price->setFromArray($CPD);
                    $price->save();
                }

                $settings->setSetting('socialads.adddefaultprices',1);
            }catch (Exception $exception){
                print_die($exception.'');
            }
        }else{
            $settings->setSetting('socialads.adddefaultprices',1);
        }


    }

    public function getPlugin($gateway_id)
    {
        if (null === $this->_plugin) {
            /**
             * @var $gatewayTb Payment_Model_Gateway
             */
            if (null == ($gateway = Engine_Api::_()->getItem('payment_gateway', $gateway_id))) {
                return null;
            }

            Engine_Loader::loadClass($gateway->plugin);
            if (!class_exists($gateway->plugin)) {
                return null;
            }

            $class =  $gateway->plugin;

            if($gateway_id !== 555){
                $class = str_replace('Payment', 'Socialads', $gateway->plugin);
            }


            Engine_Loader::loadClass($class);
            if (!class_exists($class)) {
                return null;
            }

            $plugin = new $class($gateway);

            if (!($plugin instanceof Engine_Payment_Plugin_Abstract)) {
                throw new Engine_Exception(sprintf('Payment plugin "%1$s" must ' . 'implement Engine_Payment_Plugin_Abstract', $class));
            }
            $this->_plugin = $plugin;
        }

        return $this->_plugin;
    }


}
