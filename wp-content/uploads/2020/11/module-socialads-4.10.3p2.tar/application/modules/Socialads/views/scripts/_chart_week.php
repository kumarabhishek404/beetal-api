<?php
/**
 * Created by PhpStorm.
 * User: Kalys
 * Date: 10.11.2016
 * Time: 9:58
 */
$this->headLink()
    ->prependStylesheet($this->baseUrl().'/application/css.php?request=application/modules/Socialads/externals/styles/user_manage.css');

$this->headLink()
    ->prependStylesheet($this->baseUrl().'/application/css.php?request=application/modules/Socialads/externals/styles/bootstrap.css');

$data = $this->click_data;
$data2 = $this->view_data;
$week_click_count = 0;
$week_view_count = 0;
$i = 0;
foreach($data as $d){
    $week_click_count += $d;
    $week_view_count += $data2[++$i];
}
//print_die($week_click_count.' - '.$week_view_count);
$res = Engine_Api::_()->getApi('core', 'socialads')->generateLine($data,$data2);
$dots = Engine_Api::_()->getApi('core', 'socialads')->generateDots($data,$data2);

$res2 = Engine_Api::_()->getApi('core', 'socialads')->generateLine($data2,$data);
$dots2 = Engine_Api::_()->getApi('core', 'socialads')->generateDots($data2,$data);
$week = $this->week;
$week_range = $this->week_range;

$LeftLabel = Engine_Api::_()->getApi('core', 'socialads')->getLefLabel($data,$data2);
?>
<div class="chart_week">
    <div class="info_row">
        <div class="container-fluid">
            <div class="row">
                <h3><?php echo $this->translate('Statistics for this week').'  '.$week_range['Monday'].' - '.$week_range['Sunday']?></h3>
            </div>
            <div class="row">
                <div class="col-md-4 col-lg-4 col-sm-4">
                    <h4><?php
                        $clt = $this->translate('Clicks');
                        $vst = $this->translate('Views');
                        echo $this->translate('All')?></h4>
                    <p><span class="click_dot"></span> <?php echo $this->item_ad->click_count.' '.$clt;?></p>
                    <p><span class="views_dot"></span> <?php echo $this->item_ad->view_count.' '.$vst;;?></p>
                </div>
                <div class="col-md-4 col-lg-4 col-sm-4">
                    <h4><?php echo $this->translate('Today')?></h4>
                    <p><span class="click_dot"></span> <?php echo $data[date("N",time())].' '.$clt;?></p>
                    <p><span class="views_dot"></span> <?php echo $data2[date("N",time())].' '.$vst;;?></p>
                </div>
                <div class="col-md-3 col-lg-3 col-sm-3">
                    <h4><?php echo $this->translate('Week')?></h4>
                    <p><span class="click_dot"></span> <?php echo $week_click_count.' '.$clt;?></p>
                    <p><span class="views_dot"></span> <?php echo $week_view_count.' '.$vst;;?></p>
                </div>
            </div>
        </div>
    </div>
<div class="ct-chart">
    <?php  if(isset($this->prev_url)):?><a href="<?php echo $this->prev_url;?>"><div class="prev_week"></div></a><?php endif;?>
    <?php  if(isset($this->next_url)):?><a href="<?php echo $this->next_url;?>"><div class="next_week"></div></a><?php endif;?>

        <br/>
    <svg width="100%" height="200px" >
        <g class="ct-grids">
            <line x1="45" y1="165" x2="45" y2="5" class="ct-grid ct-horizontal"></line>
            <line x1="209.28571428571428" y1="165" x2="209.28571428571428" y2="5" class="ct-grid ct-horizontal"></line>
            <line x1="373.57142857142856" y1="165" x2="373.57142857142856" y2="5" class="ct-grid ct-horizontal"></line>
            <line x1="537.8571428571429" y1="165" x2="537.8571428571429" y2="5" class="ct-grid ct-horizontal"></line>
            <line x1="702.1428571428571" y1="165" x2="702.1428571428571" y2="5" class="ct-grid ct-horizontal"></line>
            <line x1="866.4285714285713" y1="165" x2="866.4285714285713" y2="5" class="ct-grid ct-horizontal"></line>
            <line x1="1030.7142857142858" y1="165" x2="1030.7142857142858" y2="5" class="ct-grid ct-horizontal"></line>
            <line x1="45" y1="165" x2="1195" y2="165" class="ct-grid ct-vertical"></line>
            <line x1="45" y1="133" x2="1195" y2="133" class="ct-grid ct-vertical"></line>
            <line x1="45" y1="101" x2="1195" y2="101" class="ct-grid ct-vertical"></line>
            <line x1="45" y1="69" x2="1195" y2="69" class="ct-grid ct-vertical"></line>
            <line x1="45" y1="37" x2="1195" y2="37" class="ct-grid ct-vertical"></line>
        </g>
        <g class="ct-labels">
            <foreignObject x="45" y="170" width="164.28571428571428" height="30" style="overflow: visible;">
                <span class="ct-label ct-horizontal" ><?php echo $week['Monday'];?></span>
            </foreignObject>
            <foreignObject x="209.28571428571428" y="170" width="164.28571428571428" height="30" style="overflow: visible;">
                <span class="ct-label ct-horizontal" ><?php echo $week['Tuesday'];?></span>
            </foreignObject>
            <foreignObject x="373.57142857142856" y="170" width="164.28571428571428" height="30" style="overflow: visible;">
                <span class="ct-label ct-horizontal" ><?php echo $week['Wednesday'];?></span>
            </foreignObject>
            <foreignObject x="537.8571428571429" y="170" width="164.28571428571428" height="30" style="overflow: visible;">
                <span class="ct-label ct-horizontal"><?php echo $week['Thursday'];?></span>
            </foreignObject>
            <foreignObject x="702.1428571428571" y="170" width="164.28571428571428" height="30" style="overflow: visible;">
                <span class="ct-label ct-horizontal"><?php echo $week['Friday'];?></span>
            </foreignObject>
            <foreignObject x="866.4285714285713" y="170" width="164.28571428571428" height="30" style="overflow: visible;">
                <span class="ct-label ct-horizontal"><?php echo $week['Saturday'];?></span>
            </foreignObject>
            <foreignObject x="1030.7142857142858" y="170" width="164.28571428571428" height="30" style="overflow: visible;">
                <span class="ct-label ct-horizontal" ><?php echo $week['Sunday'];?></span>
            </foreignObject>
            <foreignObject x="0" y="150" width="40" height="32" style="overflow: visible;">
                <span  class="ct-label ct-vertical" ><?php echo $LeftLabel[0];?></span>
</foreignObject>
<foreignObject x="0" y="118" width="40" height="32" style="overflow: visible;">
    <span class="ct-label ct-vertical" ><?php echo $LeftLabel[1];?></span>
</foreignObject>
<foreignObject x="0" y="86" width="40" height="32" style="overflow: visible;">
    <span class="ct-label ct-vertical" ><?php echo $LeftLabel[2];?></span>
</foreignObject>
<foreignObject x="0" y="54" width="40" height="32" style="overflow: visible;">
    <span class="ct-label ct-vertical" ><?php echo $LeftLabel[3];?></span>
</foreignObject>
<foreignObject x="0" y="22" width="40" height="32" style="overflow: visible;">
    <span class="ct-label ct-vertical" ><?php echo $LeftLabel[4];?></span>
</foreignObject>
</g>
<g series-name="Clicks" class="ct-series ct-series-a">
    <path d="<?php echo $res;?>"
          class="ct-line" values="0,0,0,1,0,0,0"></path>
    <line x1="45" y1="<?php echo $dots[1];?>" x2="45.01" y2="<?php echo $dots[1];?>" class="ct-point" count="<?php echo $data[1];?>"></line>
    <line x1="209.28571428571428" y1="<?php echo $dots[2];?>" x2="209.29571428571427" y2="<?php echo $dots[2];?>" class="ct-point" count="<?php echo $data[2];?>"></line>
    <line x1="373.57142857142856" y1="<?php echo $dots[3];?>" x2="373.58142857142855" y2="<?php echo $dots[3];?>" class="ct-point" count="<?php echo $data[3];?>"></line>
    <line x1="537.8571428571429" y1="<?php echo $dots[4];?>" x2="537.8671428571429" y2="<?php echo $dots[4];?>" class="ct-point" count="<?php echo $data[4];?>"></line>
    <line x1="702.1428571428571" y1="<?php echo $dots[5];?>" x2="702.1528571428571" y2="<?php echo $dots[5];?>" class="ct-point" count="<?php echo $data[5];?>"></line>
    <line x1="866.4285714285713" y1="<?php echo $dots[6];?>" x2="866.4385714285713" y2="<?php echo $dots[6];?>" class="ct-point" count="<?php echo $data[6];?>"></line>
    <line x1="1030.7142857142858" y1="<?php echo $dots[7];?>" x2="1030.7242857142858" y2="<?php echo $dots[7];?>" class="ct-point" count="<?php echo $data[7];?>"></line>
</g>
<g series-name="Views" class="ct-series ct-series-b">
    <path d="<?php echo $res2;?>"
          class="ct-line" values="0,0,0,1,0,0,0"></path>
    <line x1="45" y1="<?php echo $dots2[1];?>" x2="45.01" y2="<?php echo $dots2[1];?>" class="ct-point" count="<?php echo $data2[1];?>"></line>
    <line x1="209.28571428571428" y1="<?php echo $dots2[2];?>" x2="209.29571428571427" y2="<?php echo $dots2[2];?>" class="ct-point" count="<?php echo $data2[2];?>"></line>
    <line x1="373.57142857142856" y1="<?php echo $dots2[3];?>" x2="373.58142857142855" y2="<?php echo $dots2[3];?>" class="ct-point" count="<?php echo $data2[3];?>"></line>
    <line x1="537.8571428571429" y1="<?php echo $dots2[4];?>" x2="537.8671428571429" y2="<?php echo $dots2[4];?>" class="ct-point" count="<?php echo $data2[4];?>"></line>
    <line x1="702.1428571428571" y1="<?php echo $dots2[5];?>" x2="702.1528571428571" y2="<?php echo $dots2[5];?>" class="ct-point" count="<?php echo $data2[5];?>"></line>
    <line x1="866.4285714285713" y1="<?php echo $dots2[6];?>" x2="866.4385714285713" y2="<?php echo $dots2[6];?>" class="ct-point" count="<?php echo $data2[6];?>"></line>
    <line x1="1030.7142857142858" y1="<?php echo $dots2[7];?>" x2="1030.7242857142858" y2="<?php echo $dots2[7];?>" class="ct-point" count="<?php echo $data2[7];?>"></line>
</g>
        <g>
            <text style="cursor: pointer; fill:#ffffff;font-weight: bold;" id="count_info_onover" x="-50" y="0" transform="rotate(0)">
                0
            </text>
        </g>

</svg>
</div>
</div>
<style>
    body{
        background: #fff;
    }
</style>
<script>
    window.addEvent('domready', function() {
        function show_info(el)
        {
            if(window.round_info_last){
                window.round_info_last.setStyle('stroke-width','10px');
            }
            var info_box = $('count_info_onover');
            info_box.set('text',el.get('count'));
            var w = (parseInt( info_box.get('text').length)*5);
            info_box.set('x',el.get('x1')-(w-3));
            info_box.set('y',(parseInt( el.get('y1'))+5));
            el.setStyle('stroke-width',(20+w)+'px');
            window.round_info_last = el;
        }
        function hide_info(el)
        {
            var info_box = $('count_info_onover');
            setTimeout(function(){
                info_box.set('x',-30);
                info_box.set('y',0);
                el.setStyle('stroke-width','10px');
            },10000);
        }

        $('count_info_onover').addEvent('mouseleave',function(e){
           // hide_info(window.round_info_last);
        });
        $$('.ct-series-a')[0].getElements('line').addEvent('mouseover',function(e){
            var val = $(this);
            show_info(val);
        });
        $$('.ct-series-a')[0].getElements('line').addEvent('mouseleave',function(){
            var val = $(this);
           //hide_info(val);

        });
        $$('.ct-series-b')[0].getElements('line').addEvent('mouseover',function(e){
            var val = $(this);
            show_info(val);
        });
        $$('.ct-series-b')[0].getElements('line').addEvent('mouseleave',function(){
            var val = $(this);
           // hide_info(val);

        });

    });


</script>