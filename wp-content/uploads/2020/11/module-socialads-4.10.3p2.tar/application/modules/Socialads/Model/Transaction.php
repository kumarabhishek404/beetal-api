<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Kalyskin
 * Date: 21.11.16
 * Time: 08:00
 * To change this template use File | Settings | File Templates.
 */
class Socialads_Model_Transaction extends Core_Model_Item_Abstract
{

}
