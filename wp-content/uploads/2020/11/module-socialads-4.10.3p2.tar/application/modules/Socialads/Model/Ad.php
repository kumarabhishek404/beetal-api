<?php

/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Socialads
 * @author     KALYSKIN
 */
class Socialads_Model_Ad extends Core_Model_Item_Abstract
{
    protected $_searchTriggers = false;
    protected $_owner_type = 'user';
    protected $_user = null;
    protected $_price = null;
    protected $_view = null;
    protected $_parent= null;
    protected $_block_type = null;
    public $owner_id = 0;

    public function setPhoto($photo)
    {
        if ($photo instanceof Zend_Form_Element_File) {
            $file = $photo->getFileName();
            $fileName = $file;
        } else if ($photo instanceof Storage_Model_File) {
            $file = $photo->temporary();
            $fileName = $photo->name;
        } else if ($photo instanceof Core_Model_Item_Abstract && !empty($photo->file_id)) {
            $tmpRow = Engine_Api::_()->getItem('storage_file', $photo->file_id);
            $file = $tmpRow->temporary();
            $fileName = $tmpRow->name;
        } else if (is_array($photo) && !empty($photo['tmp_name'])) {
            $file = $photo['tmp_name'];
            $fileName = $photo['name'][0];
        } else if (is_string($photo) && file_exists($photo)) {
            $file = $photo;
            $fileName = $photo;
        } else {
            throw new User_Model_Exception('invalid argument passed to setPhoto');
        }

        if (!$fileName) {
            $fileName = $file[0];
        }

        $name = basename($file);
        $extension = ltrim(strrchr(basename($fileName), '.'), '.');
        $base = rtrim(substr(basename($fileName), 0, strrpos(basename($fileName), '.')), '.');
        $path = APPLICATION_PATH . DIRECTORY_SEPARATOR . 'temporary';
        $params = array(
            'parent_type' => $this->getType(),
            'parent_id' => $this->getIdentity(),
            'user_id' => Engine_Api::_()->user()->getViewer()->getIdentity(),
            'name' => basename($fileName),
        );

        // Save
        $filesTable = Engine_Api::_()->getDbtable('files', 'storage');

        // Resize image (main)
        $mainPath = $path . DIRECTORY_SEPARATOR . $base . '_m.' . $extension;
        $iconPath = $path . DIRECTORY_SEPARATOR . $base . '_is.' . $extension;
        $image = Engine_Image::factory();
        $image->open($file[0])
            ->resize(1200, 480)
            ->write($mainPath)
            ->destroy();

        // Resize image (icon)
        $image = Engine_Image::factory();
        $image->open($file[0]);

        $size = min($image->height, $image->width);
        $x = ($image->width - $size) / 2;
        $y = ($image->height - $size) / 2;
        $image->resample($x, $y, $size, $size, 48, 48)
            ->write($iconPath)
            ->destroy();
        // Store
        try {
            $iMain = $filesTable->createFile($mainPath, $params);
            $iSquare = $filesTable->createFile($iconPath, $params);
            $iMain->bridge($iSquare, 'thumb.icon');
            // Remove temp files
            @unlink($mainPath);
        } catch (Exception $e) {
            @unlink($mainPath);
            @unlink($iconPath);
            @unlink($iMain);
            @unlink($iSquare);
            print_die($e->getMessage());
        }
        // Update row
        $this->modified_date = date('Y-m-d H:i:s');
        $this->file_id = $iMain->file_id;
        $this->save();

        return $this;
    }

    public function getPhotoUrl($type = null)
    {
        $photo_id = $this->file_id;
        if (!$photo_id) {
            return null;
        }

        $file = Engine_Api::_()->getApi('storage', 'storage')->get($photo_id, $type);
        if (!$file) {
            return null;
        }

        return $file->map();
    }

    public function getUser()
    {
        if (null === $this->_user) {
            $this->_user = Engine_Api::_()->getItem('user', $this->user_id);
        }

        return $this->_user;
    }

    public function getTitleAsLink()
    {
        return '<a target="_blank" href="' . $this->ad_url . '">' . $this->title . '</a>';
    }

    public function getTitle()
    {
        return $this->title;
    }

    public function getPrice()
    {
        if (!$this->_price) {
            $this->_price = $pr = Engine_Api::_()->getItem('price', $this->price_id);
            $this->price = $pr->price - ($pr->price * intval($pr->discount_percent) / 100);
            $this->save();
        }
        return $this->_price;
    }

    public function getPriceLabel()
    {
        $pr = Engine_Api::_()->getItem('price', $this->price_id);

        return $pr->getPriceLabel();

    }

    public function getBillingName()
    {
        if ($this->_view == null) {
            $this->_view = Zend_Registry::get('Zend_View');
        }
        $click = $this->_view->translate('Cost per Click (CPC)');
        $views = $this->_view->translate('Cost per Views (CPV)');
        $days = $this->_view->translate('Cost per Day (CPD)');
        switch (strtolower($this->method_pay)) {
            case 'cpc':
                $label = $click;
                break;
            case 'cpm':
                $label = $views;
                break;
            case 'cpd':
                $label = $days;
                break;
        }
        return $label;
    }

    public function getPaypalTitle()
    {
        if ($this->_view == null) {
            $this->_view = Zend_Registry::get('Zend_View');
        }
        $title = $this->_view->translate('Payment for placement of ads for');
        return $title . ' ' . $this->getPriceLabel();
    }

    public function getBlockType()
    {
        try {
            if (null === $this->_block_type) {
                $table = Engine_Api::_()->getDbtable('viewmodes', 'socialads');
                $this->_block_type = $table->fetchRow($table->select()->where('name=?',trim($this->viewmode_id)));
            }
            return $this->_block_type;
        } catch (Exeption $e) {
            //print_die($e->getMessage());
        }
    }

    public function getRestPercent()
    {
        if ($this->end_date != null && $this->method_pay == 'cpd') {
            $all_time = strtotime($this->end_date) - strtotime($this->start_date);
            if (strtotime($this->start_date) < time()) {
                $from_today = strtotime(date('Y-m-d')) - strtotime($this->start_date);
            } else {
                return 0;
            }
            $a = floor($all_time / (60 * 60 * 24));
            $b = floor($from_today / (60 * 60 * 24));
            $percent = ($b * 100 / $a);

            return ($percent > 100) ? 100 : $percent;
        } else {
            $price = Engine_Api::_()->getItem('price', $this->price_id);
            if ($price == null) return 0;
            $count = $price->count;
            $res = 0;
            if (strtolower($price->type_pay) == 'cpc') {
                $res = $this->click_count * 100 / $count;
            }
            if (strtolower($price->type_pay) == 'cpm') {
                $res = $this->view_count * 100 / $count;
            }
            return ($res > 100) ? 100 : $res;
            //print_die($res);

        }
    }

    public function getRedUrl()
    {
        if ($this->_view == null) {
            $this->_view = Zend_Registry::get('Zend_View');
        }
        return $this->_view->url(array('ad_id' => $this->getIdentity()), 'socialads_redirect', true);
    }

    public function incOrderCount($i = 1)
    {
        $this->order = ($i + $this->order);
    }

    public function incViewCount($i = 1)
    {
        $this->view_count = ($i + $this->view_count);

        $week = Engine_Api::_()->getApi('core', 'socialads')->getThisWeek('d/m/Y');
        $views = Engine_Api::_()->getDbtable('views', 'socialads');
        $this->_block_type = $ViewMode = Engine_Api::_()->getItem('viewmode', $this->viewmode_id);
        $select_views = $views
            ->select()
            ->where('ad_id=?', $this->getIdentity())
            ->where('week_date=?', $week['Monday'] . '-' . $week['Sunday'])
            ->limit(1);
        $item_views = $views->fetchRow($select_views);
        if ($item_views == null) {
            $row = $views->createRow();
            $row->week_date = $week['Monday'] . '-' . $week['Sunday'];
            $row->ad_id = $this->getIdentity();
            $row->save();
            $item_views = $row;
        }
        if ($item_views != null) {
            switch ((int)date('N', strtotime("today"))) {
                case 1:
                    $item_views->day1 = $item_views->day1 + 1;
                    break;
                case 2:
                    $item_views->day2 = $item_views->day2 + 1;
                    break;
                case 3:
                    $item_views->day3 = $item_views->day3 + 1;
                    break;
                case 4:
                    $item_views->day4 = $item_views->day4 + 1;
                    break;
                case 5:
                    $item_views->day5 = $item_views->day5 + 1;
                    break;
                case 6:
                    $item_views->day6 = $item_views->day6 + 1;
                    break;
                case 7:
                    $item_views->day7 = $item_views->day7 + 1;
                    break;
            }
            try {
                $item_views->save();
            } catch (Exception $e) {
                print_die($e->getMessage());
            }
        }
    }

    public function incClickCount()
    {
        $this->click_count = (1 + $this->click_count);
        $week = Engine_Api::_()->getApi('core', 'socialads')->getThisWeek('d/m/Y');
        $clicks = Engine_Api::_()->getDbtable('clicks', 'socialads');
        $select_click = $clicks
            ->select()
            ->where('ad_id=?', $this->getIdentity())
            ->where('week_date=?', $week['Monday'] . '-' . $week['Sunday'])
            ->limit(1);
        $item_click = $clicks->fetchRow($select_click);
        if ($item_click == null) {
            $row = $clicks->createRow();
            $row->week_date = $week['Monday'] . '-' . $week['Sunday'];
            $row->ad_id = $this->getIdentity();
            $row->save();
            $item_click = $row;
        }
        if ($item_click != null) {
            switch ((int)date('N', strtotime("today"))) {
                case 1:
                    $item_click->day1 = $item_click->day1 + 1;
                    break;
                case 2:
                    $item_click->day2 = $item_click->day2 + 1;
                    break;
                case 3:
                    $item_click->day3 = $item_click->day3 + 1;
                    break;
                case 4:
                    $item_click->day4 = $item_click->day4 + 1;
                    break;
                case 5:
                    $item_click->day5 = $item_click->day5 + 1;
                    break;
                case 6:
                    $item_click->day6 = $item_click->day6 + 1;
                    break;
                case 7:
                    $item_click->day7 = $item_click->day7 + 1;
                    break;
            }
            try {
                $item_click->save();
            } catch (Exception $e) {

            }
        }
    }

    public function extendOrPay($type = 'pay')
    {
        if (strtolower($this->method_pay) == 'cpd') {
            $this->end_date = date('Y-m-d', strtotime(date('Y-m-d') . " + {$this->getPrice()->count} day"));
        }
        $this->click_count = 0;
        $this->view_count = 0;
        $this->payd = 1;
        $this->active = 1;
        $table = $this->_parent = $this->_parent?$this->_parent: Engine_Api::_()->getDbtable('ads', 'socialads');
        $this->order = $table->getLastOrder($this->viewmode_id);
        if ($type == 'extend') {
            $this->start_date = date('Y-m-d');
            $this->extend_count = $this->extend_count + 1;
            $this->extend = 0;
        }
        $this->save();
        $clicks = Engine_Api::_()->getDbtable('clicks', 'socialads');
        $views = Engine_Api::_()->getDbtable('views', 'socialads');
        $clicks->clearByAdId($this->getIdentity());
        $views->clearByAdId($this->getIdentity());
    }

}
