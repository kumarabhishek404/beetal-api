<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Wall
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: WallElemDesc.php 18.06.12 10:52 michael $
 * @author     Michael
 */

/**
 * @category   Application_Extensions
 * @package    Wall
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */


class Socialads_Form_Decorator_ElemDesc extends Zend_Form_Decorator_Abstract
{

  public function render($content)
  {
    $description = $this->getOption('description');
    if ($description){
      return '<div class="ads-elem-content">' . $content . '</div><div class="ads-elem-desc">' . $description . '</div>';
    } else {
      return $content;
    }

  }
  

}