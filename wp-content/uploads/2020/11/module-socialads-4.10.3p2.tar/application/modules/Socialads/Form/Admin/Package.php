<?php

/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Socialads
 * @author     KALYSKIN
 */
class Socialads_Form_Admin_Package extends Engine_Form
{
    public function init()
    {
        $this
            ->setTitle('New plan');
        // Decorators
        $this->loadDefaultDecorators();
        $this->getDecorator('Description')->setOption('escape', false);
        $view = Zend_Registry::get('Zend_View');

        $this->addElement('Select', 'space', array(
            'label' => $view->translate('Choose ads'),
            'id' => 'space_id',
            'style' => 'width:200px;',
            'required' => true,
            'multiOptions' => array(),
        ));

        $this->addElement('Radio', 'billing_model', array(
            'label' => 'Choose Billing model',
            'multiOptions' => array(
                "CPC" => $view->translate('Cost per Click (CPC)'),
                "CPM" => $view->translate('Cost per Views (CPV)'),
                "CPD" => $view->translate('Cost per Day (CPD)'),
            ),
            'value' => 'CPC',
        ));


        $this->addElement('text', 'count', array(
            'label' => '<span id="count_label">Click count</span>',
            'value' => 0
        ));
        $this->getElement('count')->addFilter(new Zend_Filter_Int());

        $this->getElement('count')->getDecorator('label')->setOption('escape', false);

        $this->addElement('text', 'price', array());
        $this->getElement('price')
            ->addDecorator(new Socialads_Form_Decorator_Textbox(array('label' => 'Price', 'value' => '0', 'name' => 'price', 'id' => 'price', 'type' => 'text')));


        $this->addElement('Text', 'discount', array(
            'label' => 'Discount',
            'value' => 0
        ));

        $this->addElement('Button', 'submit', array(
            'label' => 'Save',
            'type' => 'submit',
            'ignore' => true
        ));
    }

    public function populate_($model)
    {
        $this->setTitle('Edit package');
        $this->getElement('price')->getDecorator('Textbox')->setOption('value', $model->price);
        $this->getElement('space')->setValue($model->viewmode_id);
        $this->getElement('billing_model')->setValue($model->type_pay);
        $this->getElement('count')->setValue($model->count);
        $this->getElement('discount')->setValue($model->discount_percent);
        $this->removeElement('submit');
        $this->addElement('Dummy', 'ok_cancel', array(
            'content' => '<button align="left">Save changes</button> <a href=\'javascript:void(0);\' onclick=\'javascript:parent.Smoothbox.close()\'>cancel</a>',
        ));

    }
    public function setCountLabel()
    {
        $view = Zend_Registry::get('Zend_View');
        $elem_value = $this->getElement('billing_model')->getValue();
        switch (strtolower($elem_value)) {
            case 'cpc':
                $count_label = $view->translate('Click count');
                break;
            case 'cpm':
                $count_label = $view->translate('View count');
                break;
            case 'cpd':
                $count_label = $view->translate('Day count');
                break;
            default:
                $count_label = $view->translate('Click count');
        }
        $this->getElement('count')->setLabel('<span id="count_label">' . $count_label . '</span>');

    }
}

