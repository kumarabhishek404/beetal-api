<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Blog
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: Category.php 9747 2012-07-26 02:08:08Z john $
 * @author     Jung
 */

/**
 * @category   Application_Extensions
 * @package    Blog
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
class Socialads_Model_Price extends Core_Model_Item_Abstract
{
    protected $_searchTriggers = false;
    protected $_view = null;
    protected $_block_type = null;

    public function getPrice()
    {
        return $this->price;
    }

    public function getPriceLabel()
    {
        if ($this->_view == null) {
            $this->_view = Zend_Registry::get('Zend_View');
        }
        $click = $this->_view->translate('clicks');
        $views = $this->_view->translate('views');
        $days = $this->_view->translate('days');
        $label = '';
        switch (strtolower($this->type_pay)) {
            case 'cpc':
                $label = $this->count . ' ' . $click;
                break;
            case 'cpm':
                $label = $this->count . ' ' . $views;
                break;
            case 'cpd':
                $label = $this->count . ' ' . $days;
                break;
        }
        return $label;

    }

    public function getBlockType()
    {
        try {
            if (null === $this->_block_type) {
                $this->_block_type = Engine_Api::_()->getItem('viewmode', $this->viewmode_id);
            }

            return $this->_block_type;
        } catch (Exeption $e) {
            print_die($e->getMessage());
        }
    }

}