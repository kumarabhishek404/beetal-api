<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Socialads
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @author     KAlYSKIN
 */
class Socialads_Form_Admin_PackageManage extends Engine_Form
{
    public function init()
    {
        $view = Zend_Registry::get('Zend_View');
        $this->setTitle($view->translate('Package Manage'));
        // Decorators
        $this->loadDefaultDecorators();
        $this->addElement('Select', 'space', array(
            'label' => 'Block Type',
            'id' => 'space_id',
            'style' => 'width:200px;',
            'required' => true,
            'multiOptions' => array(),
        ));

        $this->addElement('Radio', 'billing_model', array(
            'label' => 'Choose Billing model',
            'onchange' => '$("count_label").set("text",window.translateTypes($(this).get("value")))',
            'multiOptions' => array(
                "CPC" => $view->translate('Cost per Click (CPC)'),
                "CPM" => $view->translate('Cost per Views (CPV)'),
                "CPD" => $view->translate('Cost per Day (CPD)'),
            ),
            'value' => 'CPC',
        ));
        $this->addElement('text', 'count', array(
            'id' => 'count_ad',
            'label' => '<span id="count_label">' . $view->translate('Click count') . '</span>',
            'value' => 0
        ));
        $this->addElement('text', 'price', array(
            'id' => 'price_ad',
            'label' => 'Price',
            'value' => 0
        ));
        $this->addElement('Text', 'discount', array(
            'id' => 'discount_ad',
            'label' => 'Discount',
            'value' => 0
        ));
        $this->getElement('count')->getDecorator('label')->setOption('escape', false);

        $this->addElement('Button', 'submit', array(
            'label' => $view->translate('Add Package'),
            'type' => 'submit',
            'ignore' => true
        ));
    }
}

