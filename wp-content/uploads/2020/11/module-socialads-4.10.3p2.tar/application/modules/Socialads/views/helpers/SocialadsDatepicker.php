<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Socialads
 * @author     KALYSKIN
 */


class Socialads_View_Helper_SocialadsDatepicker extends Zend_View_Helper_FormElement
{

  public function SocialadsDatepicker($name, $value = null, $attibs = null)
  {
    $localeObject = Zend_Registry::get('Locale');

    $months = Zend_Locale::getTranslationList('months', $localeObject);
    $months = $months['format'][$months['default']];

    $days = Zend_Locale::getTranslationList('days', $localeObject);
    $days = $days['format'][$days['default']];

  /*  $js_str = "
      window.addEvent('domready', function (){
        new DatePicker('input[name=date_ad]', {
          pickerClass: 'datepicker_vista',
          inputOutputFormat: 'd-m-Y',
          minDate: { date: '".date('d-m-Y')."', format: 'd-m-Y' },
		  maxDate: { date: '".date('d-m-Y',strtotime('+8 Monday this week'))."', format: 'd-m-Y' },
          yearPicker: false
        });
      });
    ";*/
    $js_str = "
      window.addEvent('domready', function(){

		new Picker.Date('date_ad', {
			pickerClass: 'datepicker_bootstrap',
			format: '%Y-%m-%d',
			startView: 'days',
			yearPicker: false,
			minDate: '".date('Y-m-d')."',
			maxDate: '".date('Y-m-d',strtotime(date("Y-m-d", mktime()) . " + 365 day"))."'

		});

	});
    ";
    /*
     *
     *
    months : " . Zend_Json::encode(array_values($months)) . ",
          days : " . Zend_Json::encode(array_values($days)) . ",
          allowEmpty: true*/

    $this->view->headScript()
        ->appendFile( $this->view->baseUrl() . '/application/modules/Socialads/externals/scripts/datepicker/datepicker.js')
        ->appendScript($js_str);
    $this->view->headLink()
            ->prependStylesheet($this->view->baseUrl().'/application/css.php?request=application/modules/Socialads/externals/styles/datepicker.css');

    if($name !='no-return')
      return '<div class="datepicker_container '.$name.'-container">'.$this->view->formText($name, $value, $attibs).'</div>';

  }

}