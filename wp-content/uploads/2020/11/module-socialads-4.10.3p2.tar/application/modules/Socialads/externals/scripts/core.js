/**
 * Created by Kalys on 25.10.2016.
 */
window.social_ad_plugin = {
    wrapper:null,
    preview_loader:null,
    model_limit_loader:null,
    preview_box:null,
    pay_now:null,
    fields:[],
    validation_errors:{
       email:false
    },

    initEditForm: function () {
        var self = this;

        if($$('.socialads_ads_form.global_form').length){
            self.wrapper = $$('.socialads_ads_form.global_form')[0];
            self.wrapper.getElement('#image_file_ad').addEvent('change',function(event){
                self.setImageEditForm(event, $$(this) );
            });
        }

    },
    init: function () {
        var self = this;

        if($$('.socialads_ads_form.global_form').length){
            self.wrapper = $$('.socialads_ads_form.global_form')[0];
            self.preview_loader = self.wrapper.getElement('span#preview_loader');
            self.preview_box = self.wrapper.getElement('div#preview_box');
            self.pay_now = self.wrapper.getElement('button#pay_now');
            self.paymant_block = self.wrapper.getElement('div.paymant_block_row');
            self.model_limit_loader = self.wrapper.getElement('span#model_limit_loader');
            self.addEvents();
            self.loadAdModel(self.wrapper.getElement('select#space_id')?self.wrapper.getElement('select#space_id').get("value"):0);
            self.loadAdModelPrice(self.wrapper.getElement('select#space_id')?self.wrapper.getElement('select#space_id').get("value"):0);
        }

    },
    loadAdModel:function(val){
        var self = this;
        new Request.JSON({
            url: en4.core.baseUrl+'socialads/getspace',
            method: 'post',
            data:{
                type:val,
                format:'json'
            },
            headers: {'X-Request': 'JSON'},
            onRequest: function(){
                self.onPreview_loader(true);
                self.preview_box.setStyle('min-height', 0);
               //self.preview_box.set('html', '');
            },
            onSuccess: function( response){
                if(response.status){
                    self.fields = response.fields;
                    self.setFields();
                    self.preview_box.set('html', response.html);
                    setTimeout(function(){
                        self.preview_box.setStyle('min-height', '400px');
                    },100);
                    self.onPreview_loader(false);
                    self.updateInfo();
                }

            },
            onFailure: function(){
                self.preview_box.set('html', 'Sorry, request failed!');
                self.preview_box.setStyle('min-height', '50px');
            }
        }).send();

    },
    updateInfo: function () {
        var self = this;

        var title = self.wrapper.getElement('input#ad_title').get('value');
        self.setTitle(title);

        var Description = self.wrapper.getElement('input#ad_description').get('value');
        self.setDescription(Description);

        var Url = self.wrapper.getElement('input#ad_url').get('value');
        self.setUrl(Url);

        var Image = self.preview_box.getElement('#ad_img_div');
        if(Image)
            self.setImage(window._tmp_file);

    },
    setFields:function(){
        var self = this;
        if(self.fields){
            if(self.wrapper.getElement('#space-wrapper'))
            {
                self.wrapper.getElement('#space-wrapper').setStyle('display',self.fields.space?'block':'none');
            }
            if(self.wrapper.getElement('#email-wrapper'))
            {
                self.wrapper.getElement('#email-wrapper').setStyle('display',self.fields.email?'block':'none');
            }
            if(self.wrapper.getElement('#title-wrapper'))
            {
                self.wrapper.getElement('#title-wrapper').setStyle('display',self.fields.title?'block':'none');
            }
            if(self.wrapper.getElement('#description-wrapper'))
            {
                self.wrapper.getElement('#description-wrapper').setStyle('display',self.fields.description?'block':'none');
            }
            if(self.wrapper.getElement('#ad_url-wrapper'))
            {
                self.wrapper.getElement('#ad_url-wrapper').setStyle('display',self.fields.url?'block':'none');
            }
            if(self.wrapper.getElement('#image1-wrapper'))
            {
                self.wrapper.getElement('#image1-wrapper').setStyle('display',self.fields.image?'block':'none');
            }
            if(self.wrapper.getElement('.datepicker_con'))
            {
                self.wrapper.getElement('.datepicker_con').setStyle('display',self.fields.start_date?'block':'none');
            }
        }

    },
    loadAdModelPrice:function(val){
        var self = this;
        new Request({
            url: en4.core.baseUrl+'socialads/getpaymantblock',
            method: 'post',
            data:{
                type:val
            },
            onRequest: function(){
                self.onModel_Limit_loader(true);
                self.paymant_block.setStyle('height', 0);
                //self.preview_box.set('html', '');
            },
            onSuccess: function(responseText){
                self.paymant_block.set('html', responseText);
                self.onModel_Limit_loader(false);
                self.updateEvents();
                setTimeout(function(){
                    self.paymant_block.setStyle('height', '85px');
                },100);
            },
            onFailure: function(){
                self.paymant_block.set('html', 'Sorry, request failed!');
            }
        }).send();

    },
    updateEvents:function(){
        var self = this;
        if(self.wrapper.getElement('input.method_pay_inputs')){
            self.wrapper.getElements('input.method_pay_inputs').addEvent('change',function(event){
                self.paymant_block.setStyle('height', '200px');
                self.openPriceBlock(event.target.value);
                var tmp = $(this).getParent();
                tmp.getParent().getElements('div.right_input_radios').addClass('opacity05');
                tmp.removeClass('opacity05');
            });
        }
    },
    openPriceBlock:function(type){
        var self = this;
        self.wrapper.getElements('div.prices_block input').set('checked',false);

        if(self.wrapper.getElement('div.cpc_prices') && type == 'cpc' ){
            self.wrapper.getElement('div.cpd_prices').setStyle('opacity','0').setStyle('height','0');
            self.wrapper.getElement('div.cpm_prices').setStyle('opacity','0').setStyle('height','0');

            self.wrapper.getElement('div.cpc_prices').setStyle('height','100px').setStyle('opacity','1');
        }
        if(self.wrapper.getElement('div.cpm_prices') && type == 'cpm' ){
            self.wrapper.getElement('div.cpc_prices').setStyle('opacity','0').setStyle('height','0');
            self.wrapper.getElement('div.cpd_prices').setStyle('opacity','0').setStyle('height','0');

            self.wrapper.getElement('div.cpm_prices').setStyle('height','100px').setStyle('opacity','1');
        }
        if(self.wrapper.getElement('div.cpd_prices') && type == 'cpd' ){
            self.wrapper.getElement('div.cpc_prices').setStyle('opacity','0').setStyle('height','0');
            self.wrapper.getElement('div.cpm_prices').setStyle('opacity','0').setStyle('height','0');

            self.wrapper.getElement('div.cpd_prices').setStyle('height','100px').setStyle('opacity','1');
        }
    },
    addEvents:function(){
        var self = this;

        if(self.wrapper.getElement('select#space_id')){
            self.wrapper.getElement('select#space_id').addEvent('change',function(){
                self.onChangeSpace($(this));
            });
        }
        if(self.wrapper.getElement('input#ad_title')){
            self.wrapper.getElement('input#ad_title').addEvent('keyup',function(){
                self.setTitle($(this).get('value'));
            });
        }
        if(self.wrapper.getElement('input#ad_description')){
            self.wrapper.getElement('input#ad_description').addEvent('keyup',function(){
                self.setDescription($(this).get('value'));
            });
        }
        if(self.wrapper.getElement('input#ad_url')){
            self.wrapper.getElement('input#ad_url').addEvent('keyup',function(){
                self.setUrl($(this).get('value'));
            });
        }
        if(self.wrapper.getElement('input#image_file_ad')){
            self.wrapper.getElement('input#image_file_ad').addEvent('change',function(event){
                self.setImage(event);
            });

            self.wrapper.getElement('input#image_file_ad').addEvent('dragover',function(evt){
                    evt.stopPropagation();
                    evt.preventDefault();
                    evt.dataTransfer.dropEffect = 'copy'; // Explicitly show this is a copy.
            });
            self.wrapper.getElement('input#image_file_ad').addEvent('drop',function(event){
                self.setImage(event);
            });
        }
        if(self.pay_now != null){
            self.pay_now.addEvent('click',function(e){
                if(self.checkForm()){
                    return true;
                }else{
                    return false;
                }

            });
        }

    },
    checkForm:function(){
        var self = this;
        var ff = self.wrapper.getElements('input[name="price"]:checked').length?self.wrapper.getElements('input[name="price"]:checked')[0].get('value'):0;
        console.log(ff);
        if(ff)
            return true;
        else
           // self.wrapper.getElement('input[name="price"]').focus();
            return false;
    },
    setImage:function(evt){
        var self = this;
        if(!evt) return;
        window._tmp_file = evt;
        // Check for the various File API support.
        if (window.File && window.FileReader && window.FileList && window.Blob) {
            if(evt.target && evt.target.files)
                var files = evt.target.files; // FileList object
            else if(evt.files)
                var files = evt.files; // FileList object
            else
                var files = evt; // FileList object

            var f = files[0];

                // Only process image files.
                if (!f.type.match('image.*')) {
                    alert("Not a valid format!");
                    self.wrapper.getElement('input#image_file_ad').set('value','');
                }else {
                    var reader = new FileReader();

                    // Closure to capture the file information.
                    reader.onload = (function (theFile) {
                        return function (e) {
                            // Render thumbnail.
                            var img = self.preview_box.getElement('#ad_img_div');
                            if(img.get('ref') == 'image'){
                                img.set('src', e.target.result);
                            }else
                                img.setStyle('background-image', 'url(' + e.target.result + ')');
                        };
                    })(f);
                    // Read in the image file as a data URL.
                    reader.readAsDataURL(f);
                }
        } else {
            alert('The File APIs are not fully supported in this browser.');
        }
    },
    setImageEditForm:function(evt,input){
        var self = this;
        // Check for the various File API support.
        if (window.File && window.FileReader && window.FileList && window.Blob) {
            var files = evt.target.files; // FileList object
            // Loop through the FileList and render image files as thumbnails.
            var f = files[0];
                // Only process image files.
                if (!f.type.match('image.*')) {
                    alert("Not a valid format!");
                    input.set('value','');
                }else {
                    var reader = new FileReader();

                    // Closure to capture the file information.
                    reader.onload = (function (theFile) {
                        return function (e) {
                            // Render thumbnail.
                            var img = self.wrapper.getElement('#image_icon-element').getElement('img');
                            img.set('src', e.target.result);
                        };
                    })(f);
                    // Read in the image file as a data URL.
                    reader.readAsDataURL(f);
                }
        } else {
            alert('The File APIs are not fully supported in this browser.');
        }
    },
    setTitle:function(title){
        var self = this;
        if(title.trim().length > 0)
            if(self.preview_box.getElement('.social-ad-content__title'))
                self.preview_box.getElement('.social-ad-content__title').set('text',title);
        else
            if(self.preview_box.getElement('.social-ad-content__title'))
                self.preview_box.getElement('.social-ad-content__title').set('text','Example of the Title');
    },
    setTitleColor:function(color){
        var self = this;
        self.preview_box.getElement('.social-ad-content__title').setStyle('color',color);
    },
    setDescription:function(desc){
        var self = this;
        if(desc.trim().length > 0)
            if(self.preview_box.getElement('.social-ad-content__desc'))
                self.preview_box.getElement('.social-ad-content__desc').set('text',desc);
        else
            if(self.preview_box.getElement('.social-ad-content__desc'))
                self.preview_box.getElement('.social-ad-content__desc').set('text','Example description. Lorem Ipsum is simply dummy text of the printing and type..');
    },
    setDescriptionColor:function(color){
        var self = this;
        self.preview_box.getElement('.social-ad-content__desc').setStyle('color',color);
    },
    setUrl:function(url){
        var self = this;
        if(url.trim().length > 0)
            if(url.indexOf("http://") > -1 || url.indexOf("https://") > -1)
                if(self.preview_box.getElement('.social-ad-content__url'))
                    self.preview_box.getElement('.social-ad-content__url').set('text',url);
            else
                if(self.preview_box.getElement('.social-ad-content__url'))
                    self.preview_box.getElement('.social-ad-content__url').set('text',"http://"+url);
        else
            if(self.preview_box.getElement('.social-ad-content__url'))
                self.preview_box.getElement('.social-ad-content__url').set('text','http://example.com');
    },
    onPreview_loader:function(state){
        var self = this;
        if(!state){
            self.preview_loader.setStyle('display','none');
        }else{
            self.preview_loader.setStyle('display','inline-block');
        }
    },
    onModel_Limit_loader:function(state){
        var self = this;
        if(!state){
            self.model_limit_loader.setStyle('display','none');
        }else{
            self.model_limit_loader.setStyle('display','inline-block');
        }
    },
    onChangeSpace:function(space){
        var self = this;
        self.loadAdModel(space.get('value'));
        self.loadAdModelPrice(space.get('value'));

    },
    validateEmail:function (email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email);
    },
    initForColors:function(){
        var self = this;
        self.wrapper = $$('.package_settings')[0];

    },
    setBgColor:function (picker) {
        var self = this;
        var input = $$(picker);
        if(self.wrapper.getElement('#fieldset-right').getElement('div')){
            var ad = self.wrapper.getElement('#fieldset-right').getElement('div');
            ad.setStyle('background','#' + input.get('value'));
            if(ad.getElement('div.right_angle'))
                ad.getElement('div.right_angle').setStyle('background','#' + input.get('value'));

        }
    },
    setTextColor:function (picker) {
        var self = this;
        var input = $$(picker);
        if(self.wrapper.getElement('#fieldset-right').getElement('div')){
            var ad = self.wrapper.getElement('#fieldset-right').getElement('div');
            ad.getElement('.social-ad-content__desc').setStyle('color','#'+input.get('value'));
            ad.getElement('.social-ad-content__title').setStyle('color','#'+input.get('value'));
        }
    },
    invertColor:function (hexTripletColor) {
        var color = hexTripletColor;
            color = color.substring(1);           // remove #
            color = parseInt(color, 16);          // convert to integer
            color = 0xFFFFFF ^ color;             // invert three bytes
            color = color.toString(16);           // convert to hex
            color = ("000000" + color).slice(-6); // pad with leading zeros
            color = "#" + color;                  // prepend #
        return color;
    }
};
window.social_ad_admin = {
    wrapper:null,
    wrapper_edit:null,
    initAdmin: function () {
        var self = this;
        if($('admin_new_package')){
            self.wrapper = $('admin_new_package');
            self.addEvents();
        }

    },
    initAdminManage: function () {
        var self = this;
        if($('global_content')){
            self.wrapper = $('global_content');
            self.addEvents();
        }

    },
    initAdminEditAdForm: function () {
        var self = this;
        if($('admin_edit_ad_form')){
            self.wrapper_edit = $('admin_edit_ad_form');
            self.addEventsEditForm();
        }

    },
    addEventsEditForm:function()
    {
        var self = this;
        if(self.wrapper_edit.getElement('select#space_id'))
        {
            self.wrapper_edit.getElement('select#space_id').addEvent('change',function(){
                var data = {
                    id_vm: $(this).get('value'),
                    type_pay: self.wrapper_edit.getElement('input[name="method_pay"]').get('value'),
                    format: 'json'
                };
                self.getPrice(data);
            });
            self.wrapper_edit.getElements('input[name="method_pay"]').addEvent('change',function(){
                var data = {
                    id_vm: self.wrapper_edit.getElement('#space_id').get('value') ,
                    type_pay: $(this).get('value'),
                    format: 'json'

                };
                self.getPrice(data);
            });
        }
    },
    getPrice:function(data)
    {
        var self = this;
        new Request.JSON({
            url: en4.core.baseUrl + 'admin/socialads/index/getprice',
            data: data,
            onSuccess: function( res){
                if(!res.status)
                    alert("An error occurred on the server!");
                else{
                    self.wrapper_edit.getElement('#price_id').set('html',res.options);
                }
            },
            onFailure: function(){
                alert("An error occurred!");
            }
        }).send();
    },
    addEvents:function(){
        var self = this;
        if(self.wrapper.getElements('input[name="billing_model"]')){
            self.wrapper.getElements('input[name="billing_model"]').addEvent('change',function(event){
                var tmp = window.translateTypes(event.target.value);
                self.wrapper.getElements('#count_label').set('text',tmp);

            });
        }

        self.wrapper.getElements('a.package_down').addEvent('click',function(event){
            var btn = $(this);
            window.tmp_btn = btn;
            var container = $('prices_content_'+btn.get('data-id')).getElement('div.content88');
            if(btn.get('state') == 1){
                container.setStyle('max-height','0');
                btn.set('state',0);
                return;
            }
            var data ={
                id:btn.get('data-id'),
                format: 'json'
            };
            new Request.JSON({
                url: en4.core.baseUrl + 'admin/socialads/index/getpackages',
                data: data,
                onSuccess: function( res){
                    if(!res.status) {
                        alert("An error occurred while changing settings on the server!");
                        return;
                    }
                    if(res.status){
                        console.log(btn.get('data-id'));
                        container.set('html',res.content);
                        container.setStyle('max-height','800px');
                        btn.set('state',1);
                        self.inin_price_actions(container);
                        Smoothbox.bind($$('.prices_block'));
                    }
                },
                onFailure: function(){
                    alert("An error occurred while changing settings!");
                }
            }).send();


        });
        self.wrapper.getElements('img.on-off-btn-ajax').addEvent('click',function(event){
            var btn = $(this);
            var src = btn.get('src');
            if(btn.get('state') == '1'){
                src = src.replace('on.png','off.png');
                btn.set('state',0);
            }else{
                src = src.replace('off.png','on.png');
                btn.set('state',1);
            }
            btn.set('src',src);
            var data ={
                typepay:btn.getParent().get('type-pay'),
                id:btn.getParent().get('data-id'),
                state:btn.get('state'),
                format: 'json'
            };
            self.sendQuery(data,function(mess){
                if(btn.get('state') == '1'){
                    src = src.replace('on.png','off.png');
                    btn.set('state',0);
                }else{
                    src = src.replace('off.png','on.png');
                    btn.set('state',1);
                }
                btn.set('src',src);
                alert(mess);
            });

        });

    },
    inin_price_actions:function(con){
        var self = this;
        if(con.getElement('a.delete_package_icon')){
            con.getElements('a.delete_package_icon').addEvent('click',function(){
               // self.delete_package($$(this));
            });
        }
        if(con.getElements('a.edit_package_icon')){
            con.getElements('a.edit_package_icon').addEvent('click',function(){
               // self.edit_package($$(this));
            });
        }
    },
    delete_package:function(btn){

        new Request.JSON({
            url: en4.core.baseUrl + 'admin/socialads/index/deletepackages',
            data: {
                id_pack: btn.get('data'),
                format: 'json'
            },
            onSuccess: function( res){
                if(!res.status) {
                    alert("An error occurred while changing settings on the server!");
                    return;
                }
                if(res.status){
                    window.tmp_btn.click();
                    window.tmp_btn.click();
                }
            },
            onFailure: function(){
                alert("An error occurred while changing settings!");
            }
        }).send();
    },
    sendQuery:function(data,callback){
        var self = this;
        new Request.JSON({
            url: en4.core.baseUrl + 'admin/socialads/index/settings',
            data: data,
            onSuccess: function( res){
                if(!res.status)
                    callback("An error occurred while changing settings on the server!");
            },
            onFailure: function(){
                callback("An error occurred while changing settings!");
            }
        }).send();
    }
};

window.ContenRefresh = {
    bind:function()
    {
       if($ && $$){
           var links =  $$('a.content_refresh');
           for(var i = 0; i < links.length; i++ ){
               links[i].addEvent('click',function(){
                   var URL = location.href;
                   var self = $(this);
                   var self_text = self.get('html');
                   var self_text_timer = '';
                   var Content = $$(self.get('ref-content-class'))[0];
                   var id_timer = 0;
                   var i_timer = 0;

                   new Request({
                       url: URL,
                       method: 'get',
                       onRequest: function(){
                           id_timer = setInterval(function(){
                               self_text_timer += '.';
                               i_timer++;
                               self.set('html', self_text + self_text_timer);
                               if(i_timer >=3){
                                   self_text_timer  = '';
                               }
                           },500);
                           console.log("test");
                       },
                       onSuccess: function(responseText){
                           var CON = new Element('div',{'html':responseText});
                           var PARSE_CON = CON.getElement(self.get('ref-content-class'));
                           if(PARSE_CON !== null){
                               Content.set('html','');
                               Content.grab(PARSE_CON);
                               self.set('html', self_text);
                               clearInterval(id_timer);
                               setTimeout(function(){
                                   var smoothbox_l = self.getElements('a.smoothbox') ;
                                   if(smoothbox_l.length == 0 || smoothbox_l  == null){
                                       smoothbox_l = $$('body')[0].getElements('a.smoothbox');
                                   }
                                   for(var j =0; j< smoothbox_l.length; j++ )
                                   {
                                       Smoothbox.bind(smoothbox_l[j].getParent());
                                   }
                               },500)

                           }
                       },
                       onFailure: function(){
                           self.set('html', self_text);
                       }
                   }).send();
               });
           }
       }
    }
};

document.addEventListener("DOMContentLoaded", function(){
    window.ContenRefresh.bind();
});















