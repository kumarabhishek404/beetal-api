<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Socialads
 * @author     KALYSKIN
 */
require_once 'QUERY.php';   // include sql query constants

class Socialads_Model_DbTable_Viewmodes extends Engine_Db_Table
{
    protected $_rowClass = 'Socialads_Model_Viewmode';

    public function getModesAssoc($active = false,$field = 'name')
    {
        if ($active) {
            $db = Engine_Db_Table::getDefaultAdapter();
            $stmt = $db->query(GET_PARENT_IF_EXISTS_CHILD);
        } else {
            $stmt = $this->select()
                ->from($this, array($field, 'label'))
                ->order('id ASC')
                ->query();
        }

        $data = array();
        foreach ($stmt->fetchAll() as $modes) {
            $data[trim($modes[$field])] = $modes['label'];
        }

        return $data;
    }

    public function auto_switch_all()
    {
        $db = Engine_Db_Table::getDefaultAdapter();
        $res = $db->query(AUTO_SWITCH_ALL_QUERY);
        return $res;
    }

    public function getAllc()
    {
        $stmt = $this->select()
            ->from($this, array('id', 'label'))
            ->order('id ASC')
            ->query();

        $data = array();
        foreach ($stmt->fetchAll() as $modes) {
            $data[$modes['id']] = $modes['label'];
        }

        return $data;
    }

}

