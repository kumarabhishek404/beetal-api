<?php

class Socialads_RedirecturlController extends Core_Controller_Action_Standard
{
    public function indexAction()
    {
        $ID = (int)$this->getParam('ad_id', 0);
        if (!$this->_helper->requireUser()->isValid()) return;
        $table = Engine_Api::_()->getDbtable('ads', 'socialads');
        $select = $table->select()
            ->where('ad_id = ?',$ID)
            ->where('active = ?', 1)
            ->limit(1);
        $item = $table->fetchRow($select);
        if ($item != null){
            try{
                $item->incClickCount();
                $item->save();
            }catch (Exception $e){
                print_die($e->getMessage());
            }
            return $this->redirect($item->ad_url);
        }else{
            echo "<h1 align='center'>PAGE NOT FOUND!</h1>";
            die();
            return ;
        }



    }

}
