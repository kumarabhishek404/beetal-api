UPDATE `engine4_core_modules` SET `version` = '4.8.12p1' WHERE `name` = 'socialads';
