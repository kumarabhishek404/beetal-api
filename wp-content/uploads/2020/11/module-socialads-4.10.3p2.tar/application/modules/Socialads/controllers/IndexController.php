<?php

/**
 * Created by JetBrains PhpStorm.
 * User: Kalyskin
 * Date: 21.11.16
 * Time: 08:00
 * To change this template use File | Settings | File Templates.
 */
class Socialads_IndexController extends Core_Controller_Action_Standard
{
    public function indexAction()
    {
        $this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
            ->getNavigation('socialads_main', array(), 'socialads_main_create');


    }

    public function createAction()
    {
        if (!$this->_helper->requireUser()->isValid()) return;
        if (!$this->_helper->requireAuth()->setAuthParams('socialads', null, 'create_ad')->isValid()) return;
        Engine_Api::_()->getApi('core', 'socialads')->addDefaultPrices();
        $viewer = Engine_Api::_()->user()->getViewer();
        $this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
            ->getNavigation('socialads_main', array(), 'socialads_main_create');

        $this->view->form = $form = new Socialads_Form_ads();
        $settings = Engine_Api::_()->getDbTable('settings', 'core');
        $model = Engine_Api::_()->getDbtable('viewmodes', 'socialads');
        $view_modes = $model->getModesAssoc(true);
        if(!count($view_modes)){
            $this->view->form = null;
            $this->view->message = $this->view->translate('Unfortunately, now is not the creation of advertising available, please contact your administrator!');
            return;
        }
        if (!empty($view_modes) && is_array($view_modes) && $form->getElement('space')) {
            $form->getElement('space')->addMultiOptions($view_modes);
        }

        if (!$this->getRequest()->isPost()) {
            return;
        }
        if (!$form->isValid($this->getRequest()->getPost())) {
            $form->getElement('title')->setLabel($this->view->translate('Ad title'));
            $form->getElement('ad_url')->setLabel($this->view->translate('Ad URL'));
            $form->isValid($this->getRequest()->getPost());
            return;
        }

        if (!empty($_FILES['image']) && !empty($_FILES['image']['name']) && $_FILES['image']['error'][0] == 0) {
            $image = $_FILES['image'];
        } else {
            $image = false;
        }
        $values = $_POST;
        //validate url
        $url = $values['ad_url'];
        if (filter_var($url, FILTER_VALIDATE_URL) === false) {
            $url = 'http://' . $url;
            if (!filter_var($url, FILTER_VALIDATE_URL) === false) {
                $values['ad_url'] = $url;
            } else {
                $form->addError('Url is not valid!');
                return;
            }
        }
        //save
        $table = Engine_Api::_()->getDbtable('ads', 'socialads');
        $price = Engine_Api::_()->getItem('price', intval($values['price']));
        if ($price == null) {
            $form->addError("Sorry package which you choose not found!");
            return;
        }
        $db = $table->getAdapter();
        $db->beginTransaction();
        $end_date = null;
        if ($values['method_pay'] == 'cpd') {
            $end_date = date('Y-m-d', strtotime($values['date_ad'] . " + {$price->count} day"));
        }
        $order = $table->getLastOrder($values['space']);
        if(isset($view_modes[trim($values['space'])])){
            $space = $values['space'];
        }else{
            $form->addError("Invalid data!");
            return;
        }
        try {
            $val = array(
                'viewmode_id' => $space,
                'title' => htmlspecialchars($values['title']),
                'description' => htmlspecialchars($values['description']),
                'ad_url' => $values['ad_url'],
                'start_date' => $values['date_ad'],
                'end_date' => $end_date,
                'method_pay' => $values['method_pay'],
                'price_id' => intval($values['price']),
                'price' => $price->price - ($price->price * intval($price->discount_percent) / 100),
                'payd' => intval($price->price) <= 0 ? 1 : 0,
                'active' => intval($price->price) <= 0 ? 1 : 0,
                'approved' => $settings->getSetting('socialads.auto.approve', 0),
                'user_id' => $viewer->getIdentity(),
                'creation_date' => date('Y-m-d H:i:s'),
                'modified_date' => date('Y-m-d H:i:s'),
                'order' => $order,
            );

            $ads = $table->createRow();
            $ads->setFromArray($val);
            $ads->save();
            if ($image) {
                $ads->setPhoto($image);
            }
            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
        }
        if (intval($price->price) <= 0) {
            return $this->_helper->redirector->gotoRoute(array(), 'socialads_general', true);
        } else
            return $this->_helper->redirector->gotoRoute(array('ad_id' => $ads->getIdentity(), "user_id" => $viewer->getIdentity()), 'socialads_pay', true);

    }

    public function manageAction()
    {
        // Engine_Api::_()->getApi('socialads', 'core')->getWallActionAd();

        $this->view->user = Engine_Api::_()->user()->getViewer();

        if (!$this->_helper->requireUser()->isValid()) return;

        $this->view->canDelete = Engine_Api::_()->authorization()->isAllowed('socialads', null, 'allow_delete');
        $this->view->canEdit = Engine_Api::_()->authorization()->isAllowed('socialads', null, 'allow_edit');

        $this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
            ->getNavigation('socialads_main', array(), 'socialads_main_manage');

        $viewer = Engine_Api::_()->user()->getViewer();
        $table = Engine_Api::_()->getDbtable('ads', 'socialads');
        $select = $table->select()
            ->where('user_id = ?', $viewer->getIdentity());
        $paginator = Zend_Paginator::factory($select);
        $settings = Engine_Api::_()->getDbTable('settings', 'core');
        $paginator->setCurrentPageNumber($this->getParam('page', 1));
        $paginator->setItemCountPerPage($settings->getSetting('socialads.manage.perpage', 10));

        $this->view->model = $paginator;

    }

    public function getspaceAction()
    {
        if (!$this->_helper->requireUser()->isValid()) return;
        $type = $this->getParam('type', 0);
        $this->_helper->layout->disableLayout();
        $table = Engine_Api::_()->getDbtable('viewmodes', 'socialads');
        $viewmode = $table->fetchRow($table->select()->where('name=?',trim($type)));

        if (!$viewmode->active) return;
        $this->view->html = $this->view->partial('_ads.php', 'socialads', array(
            'view_mode' => $viewmode->name,
            'bg_color' => $viewmode->getParam('background_color'),
            'font_color' => $viewmode->getParam('font_color'),
        ));
        $this->view->fields = $viewmode->getRequiredFields();
        $this->view->status = true;

    }

    public function getpaymantblockAction()
    {
        if (!$this->_helper->requireUser()->isValid()) return;
        $type = $this->getParam('type', 0);
        $this->_helper->layout->disableLayout();

        $table = Engine_Api::_()->getDbtable('viewmodes', 'socialads');
        $viewmode = $table->fetchRow($table->select()->where('name=?',trim($type)));

        $prices = Engine_Api::_()->getDbtable('prices', 'socialads')->getPricesAssoc($viewmode->id);
        // print_die($prices);

        $p = $this->view->partial('_prices.php', 'socialads', array(
            'model' => $viewmode,
            'prices' => $prices,
        ));
        echo $p;
    }


}
