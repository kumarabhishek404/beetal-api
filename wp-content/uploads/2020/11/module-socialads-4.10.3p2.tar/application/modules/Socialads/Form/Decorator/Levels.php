<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Wall
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: WallElemDesc.php 18.06.12 10:52 michael $
 * @author     Michael
 */

/**
 * @category   Application_Extensions
 * @package    Wall
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */


class Socialads_Form_Decorator_Levels extends Zend_Form_Decorator_Abstract
{

  public function render($content)
  {
   // $description = $this->getOption('description');
    if ($content){
      return $content .'<hr class="br-tag-30" style="width: 100%;display: inline-block; margin: 0px 0; border: none;" />';
    } else {
      return $content;
    }

  }
  

}