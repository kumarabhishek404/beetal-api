INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES  ('socialads', 'Social ads plugin', 'Social ads plugin', '4.8.13p1', 1, 'extra') ;


