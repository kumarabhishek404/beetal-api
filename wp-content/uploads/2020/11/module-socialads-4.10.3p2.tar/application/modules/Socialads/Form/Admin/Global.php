<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Socialads
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @author     KAlYSKIN
 */

class Socialads_Form_Admin_Global extends Engine_Form
{
    public function init()
    {
        $view = Zend_Registry::get('Zend_View');
        $this
            ->setTitle($view->translate('Socialads Settings'));
        // Decorators
        $this->loadDefaultDecorators();
        $settings = Engine_Api::_()->getDbTable('settings', 'core');

        $this->addElement('Radio', 'auto_approve', array(
            'label' => $view->translate('Auto approve ads'),
            'multiOptions' => array(
                1 => $view->translate('Yes, auto approve.'),
                0 => $view->translate('No, wait for admin approval.')
            ),
            'value' => $settings->getSetting('socialads.auto.approve', 0),
        ));
        $this->addElement('Text', 'user_manage_perpage', array(
            'label' => $view->translate('Per page ads'),
            'description' => '',
            'value' => $settings->getSetting('socialads.manage.perpage', 10)
        ));
        $this->addElement('Text', 'order_on_wall', array(
            'label' => $view->translate('Order in wall'),
            'description' => '',
            'value' => $settings->getSetting('socialads.orderonwall', 5)
        ));

        /*$this->addElement('Text', 'paypalemail', array(
            'label' => $view->translate('Paypal email'),
            'description' => '',
            'value' => $settings->getSetting('socialads.paypalemail', '')
        ));*/

        $this->addElement('Button', 'submit', array(
            'label' => 'Save Changes',
            'type' => 'submit',
            'ignore' => true
        ));
    }
}

