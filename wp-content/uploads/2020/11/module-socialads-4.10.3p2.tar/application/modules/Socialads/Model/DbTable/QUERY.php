<?php
/**
 * Created by PhpStorm.
 * User: Kalys
 * Date: 11.01.2017
 * Time: 11:23
 */

const AUTO_SWITCH_ALL_QUERY  = "
UPDATE engine4_socialads_viewmodes AS parent
SET cpc = 
   (
	SELECT COUNT(*)>>0 AS my_bool 
	FROM engine4_socialads_prices AS child 
	WHERE
	 child.viewmode_id = parent.id AND 
	 child.type_pay LIKE 'CPC'
	),
	cpm =
	(
	SELECT COUNT(*)>0 AS my_bool 
	FROM engine4_socialads_prices AS child 
	WHERE
	 child.viewmode_id = parent.id AND 
	 child.type_pay LIKE 'CPM'
	),
	cpd =
	(
	SELECT COUNT(*)>0 AS my_bool 
	FROM engine4_socialads_prices AS child 
	WHERE
	 child.viewmode_id = parent.id AND 
	 child.type_pay LIKE 'CPD'
	),
	active =
	(
	SELECT COUNT(*)>0 AS my_bool 
	FROM engine4_socialads_prices AS child 
	WHERE
	 child.viewmode_id = parent.id 
	)
";

const GET_PARENT_IF_EXISTS_CHILD = "
SELECT * FROM engine4_socialads_viewmodes AS parent  WHERE EXISTS  ( SELECT price_id FROM engine4_socialads_prices AS child  WHERE child.viewmode_id = parent.id) AND parent.active >=1
";