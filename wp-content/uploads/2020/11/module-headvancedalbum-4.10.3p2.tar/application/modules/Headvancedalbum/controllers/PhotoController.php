<?php

/**
 * Created by PhpStorm.
 * User: Медербек
 * Date: 03.08.2015
 * Time: 15:19
 */
class Headvancedalbum_PhotoController extends Core_Controller_Action_Standard
{
    public function init()
    {
        if (!$this->_helper->requireAuth()->setAuthParams('album', null, 'view')->isValid()) return;

        if (0 !== ($photo_id = (int)$this->_getParam('photo_id')) &&
            null !== ($photo = Engine_Api::_()->getItem('album_photo', $photo_id))
        ) {
            Engine_Api::_()->core()->setSubject($photo);
        }



        /*
        else if( 0 !== ($album_id = (int) $this->_getParam('album_id')) &&
            null !== ($album = Engine_Api::_()->getItem('album', $album_id)) )
        {
          Engine_Api::_()->core()->setSubject($album);
        }
         */
    }

    public function deleteAction()
    {
        if (!$this->_helper->requireSubject('album_photo')->isValid()) return;
        if (!$this->_helper->requireAuth()->setAuthParams(null, null, 'delete')->isValid()) return;

        $photo = Engine_Api::_()->core()->getSubject('album_photo');
        $album = $photo->getParent();

        $this->view->form = $form = new Headvancedalbum_Form_Photo_Delete();

        if (!$this->getRequest()->isPost()) {
            return;
        }
        if (!$form->isValid($this->getRequest()->getPost())) {
            return;
        }

        try {
            // delete photo
            Engine_Api::_()->getDbtable('photos', 'album')->delete(array('photo_id = ?' => $photo->photo_id));

            // delete files from server
            $filesDB = Engine_Api::_()->getDbtable('files', 'storage');

            $filePath = $filesDB->fetchRow($filesDB->select()->where('file_id = ?', $photo->file_id))->storage_path;
            unlink($filePath);

            $thumbPath = $filesDB->fetchRow($filesDB->select()->where('parent_file_id = ?', $photo->file_id))->storage_path;
            unlink($thumbPath);

            // Delete image and thumbnail
            $filesDB->delete(array('file_id = ?' => $photo->file_id));
            $filesDB->delete(array('parent_file_id = ?' => $photo->file_id));

            // Check activity actions
            $attachDB = Engine_Api::_()->getDbtable('attachments', 'activity');
            $actions = $attachDB->fetchAll($attachDB->select()->where('type = ?', 'album_photo')->where('id = ?', $photo->photo_id));
            $actionsDB = Engine_Api::_()->getDbtable('actions', 'activity');

            foreach ($actions as $action) {
                $action_id = $action->action_id;
                $attachDB->delete(array('type = ?' => 'album_photo', 'id = ?' => $photo->photo_id));

                $action = $actionsDB->fetchRow($actionsDB->select()->where('action_id = ?', $action_id));

                $count = (integer)$action->attachment_count;
                if (!is_null($count) && ($count > 1)) {
                    $action->attachment_count = $count - 1;
                    $action->save();
                } else {
                    $action->delete();
                }
            }
        } catch (Exception $e) {
            throw $e;
        }

        return $this->_forward('success', 'utility', 'core', array(
            'messages' => array(Zend_Registry::get('Zend_Translate')->_('Your changes have been saved.')),
            'layout' => 'default-simple',
            'parentRedirect' => $album->getHref(),
        ));
    }

}