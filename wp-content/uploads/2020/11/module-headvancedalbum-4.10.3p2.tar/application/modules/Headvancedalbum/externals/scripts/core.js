var he_advanced_album = {

    initialize: function () {
        this.html5PhotoUpload();
    },

    resize_line: function (params, width, selector) {
        if (isNaN(width)) {
            // @todo timeline detection
            width = 935;
        }
        width -= 10 * params.length;
        var min_h = this.resize_to_min_height(params, selector);
        var flag = true;
        var e_width = 1;
        var e_height = 1;
        while (flag) {
            var w = 0;
            var i = 0;
            for (i = 0; i < params.length; i++) {
                e_width = $$('#' + selector + '_' + params[i].photo_id).getWidth();
                e_height = $$('#' + selector + '_' + params[i].photo_id).getHeight();
                var e_ratio = e_width / e_height;
                e_height = min_h;
                e_width = min_h * e_ratio;
                w += e_width;

                $$('#' + selector + '_' + params[i].photo_id).setStyle('width', e_width);
                $$('#' + selector + '_' + params[i].photo_id).setStyle('height', e_height);
            }
            if (w <= width) {

                flag = false;
            } else {
                min_h = min_h - 1;
            }
        }
//        if(params.length == 1) {
//            console.log(width);
//            $$('#' + selector + '_' + params[0].photo_id).setStyle('width', width);
//            $$('#' + selector + '_' + params[0].photo_id).setStyle('height', width / params[0].ratio);
//            params[0].height = width / params[0].ratio;
//            params[0].width = width;
//        }
    },

    resize_to_min_height: function (params, selector) {
        var min_h = $$('#' + selector + '_' + params[0].photo_id).getHeight();

        for (var i = 0; i < params.length; i++) {
            if (min_h >= $$('#' + selector + '_' + params[0].photo_id).getHeight())
                min_h = $$('#' + selector + '_' + params[0].photo_id).getHeight();
        }

        return min_h;
    },

    /*
     var widget - widget's class
     var loader = loader's div class
     var selector = main photos wrapper
     var photo_class = photo img tag class
     var params = photos params from server
     */
    resize_photos_on_load: function (widget, loader, selector, photo_class, photo_id, params) {
        var loaded = 0;
        $$('.' + widget).getElements('.' + loader)[0].setStyle('display', 'block');
        $$('.' + selector).setStyle('max-height', '50px');
        $$('.' + selector).setStyle('visibility', 'hidden');
        var album_count = $$('.' + widget).getElements('.' + photo_class)[0].length;

        $$('.' + widget).getElements('.' + photo_class)[0].addEvent('load', function () {
            loaded++;
            if (loaded >= album_count) {

                he_advanced_album.resize_line(params, parseInt($$('.' + selector).getStyle('width')), photo_id);

                $$('.' + widget).getElements('.' + loader)[0].setStyle('display', 'none');
                $$('.' + selector).setStyle('visibility', 'visible');
                $$('.' + selector).setStyle('max-height', 'none');
            }
        });
    },

    html5PhotoUpload: function () {

        if ($('html5PhotoUpload'))
            $('html5PhotoUpload').addEvent('change', function (event) {

                if (this.files[0].size > 0) {

                    var file = this.files[0];

                    var formData = new FormData();

                    if (!file.type.match('image.*'))
                        return;

                    formData.append('Filename', file.name);
                    formData.append('heevent', '1');
                    formData.append('Filedata', file, file.name);
                    readURL($('html5PhotoUpload'));

                    var xhr = new XMLHttpRequest();
                    xhr.upload.addEventListener("progress", function (event) {
                        console.log(event);
                        var loaded = event.loaded, total = event.total;

                        console.log(parseInt(loaded / total * 100, 10));
                    });
                    xhr.upload.addEventListener("error", function (e) {
                        console.log(e);
                    });
                    xhr.onreadystatechange = function () {
                        if (this.readyState == 4 && this.status == 200) success(JSON.parse(this.responseText));
                    };
                    xhr.open('POST', en4.core.baseUrl + 'albums/upload?ul=1', true);
                    xhr.send(formData);

                    var preview = null;

                    var customWrapper = new Element('div', {
                        id: 'custom-file-wrapper'
                    });

                    function success(res) {
                        console.log(res);
                        console.log(res.photo_id);
                        if (res.photo_id) {
                            var hidden = new Element('hidden', {
                                name: 'file',
                                value: '' + res.photo_id
                            });

                            hidden.inject(customWrapper);

                            var remove = new Element('a', {
                                id: 'remove-temporary-pic',
                                html: 'Remove',
                                href: 'javascript:void(0)'
                            });

                            remove.addEvent('click', function () {
                                new Request({
                                    url: en4.core.baseUrl + 'headvancedalbum/index/remove?format=html',
                                    method: 'POST',
                                    onSuccess: function (res) {
                                        res = JSON.parse(res);
                                        customWrapper.remove();
                                        $('html5PhotoUpload').set('value', null);
                                        $('submit-wrapper').setStyle('display', 'none');
                                        he_show_message(res.message, 'success', 3000);
                                    },
                                    onFailure: function () {
                                        he_show_message('Sorry, your request failed :(', 'error', 3000);
                                    }
                                }).send('photo_id=' + res.photo_id);
                            });

                            remove.inject(customWrapper, 'top');
                            if (null !== preview) preview.inject(customWrapper, 'top');
                            else readURL($('html5PhotoUpload'), true);

                            customWrapper.inject($('file-wrapper'));
                            $('submit-wrapper').setStyle('display', 'block');
                        }

                    }

                    function readURL(input, setView) {

                        if (input.files && input.files[0]) {
                            var reader = new FileReader();

                            reader.onload = function (e) {
                                var img = new Element('img', {
                                    src: e.target.result,
                                    style: 'width: 100%; height:auto;'
                                });

                                var div = new Element('div', {
                                    style: 'width: 200px; height: 200px; display: flex; align-items: center;'
                                });
                                div.grab(img);

                                preview = div;

                                if (setView) customWrapper.grab(div, 'top');
                            };

                            reader.readAsDataURL(input.files[0]);
                        }
                    }
                }

            });
    }


};

function he_show_message(message, type, delay) {
    var text = '';
    var duration = 400;
    var delay = (delay == undefined) ? 3000 : delay;

    text = message;

    if (window.$message_container == undefined) {
        window.$message_container = new Element('div', {'class': 'he_message_container'});
        $(document.body).adopt(window.$message_container);
    }

    var className = 'he_msg_text';
    if (type == 'error') {
        className = 'he_msg_error';
    } else if (type == 'notice') {
        className = 'he_msg_notice';
    } else {
        className = 'he_msg_text';
    }

    var $message = new Element('div', {
        'class': className,
        'styles': {
            'opacity': 0
        }
    });
    var $close_btn = new Element('a', {
        'class': 'he_close',
        'href': 'javascript://',
        'events': {
            'click': function () {
                $message.fade('out');
                $message.removeClass('visible');

                window.setTimeout(function () {
                    $message.dispose();
                    if (window.$message_container.getElements('.visible').length == 0) {
                        window.$message_container.empty();
                    }
                    ;
                }, duration);
            }
        }
    });

    $message.addClass('visible');
    $message.adopt($close_btn);
    $message.adopt('html', new Element('span', {'html': message}));
    window.$message_container.adopt($message);

    $message.set('tween', {duration: duration});
    $message.fade('in');

    window.setTimeout(function () {
        $message.fade('out');
        $message.removeClass('visible');
        window.setTimeout(function () {
            if (window.$message_container.getElements('.visible').length == 0) {
                window.$message_container.empty();
            }
        }, duration);
    }, delay);
}

/*

window.addEvent('domready', function () {

    he_advanced_album.initialize();

});
*/

