<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Headvancedalbum
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: Controller.php 2013-01-21 16:48:00 ratbek $
 * @author     Ratbek
 */

/**
 * @category   Application_Extensions
 * @package    Headvancedalbum
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Headvancedalbum_Widget_FeaturedPhotosController extends Engine_Content_Widget_Abstract
{
  public function indexAction()
  {
    $request = Zend_Controller_Front::getInstance()->getRequest();
    $params = $request->getParams();

    $viewer = Engine_Api::_()->user()->getViewer();
    $user_id = $viewer->getIdentity();

    $params['user_id'] = $user_id;
    $params['featured'] = 1;
    $params['search'] = 1;

    $this->view->currentDate = $currentDate = date('Y-m-d h:i:s');
    $this->view->filter = $params['filter'];

    $settings = Engine_Api::_()->getApi('settings', 'core');
    
    $albums_count = $this->_getParam('itemCountPerPage') ? $this->_getParam('itemCountPerPage') : '3';
    $albums_order = $this->_getParam('recentType') ? $this->_getParam('recentType') : 'ASC';
    /////
    $he_featured = 1;
    $table = Engine_Api::_()->getDbtable('photos', 'album');
    $query = $table->select()
    ->from('engine4_album_photos')
    ->joinRight('engine4_headvancedalbum_featurephotos', 'engine4_headvancedalbum_featurephotos.photo_id = engine4_album_photos.photo_id', null)
    ->where('engine4_headvancedalbum_featurephotos.he_featured = ?', $he_featured)
    ->order('engine4_album_photos.photo_id '.$albums_order)
    ;
    $this->view->paginator = $paginator = Zend_Paginator::factory($query);
    
    // Set item count per page and current page number
    $paginator->setItemCountPerPage($albums_count);
  }
}