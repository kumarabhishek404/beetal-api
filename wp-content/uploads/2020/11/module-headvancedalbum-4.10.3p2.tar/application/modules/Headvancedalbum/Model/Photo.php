<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Headvancedalbum
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: Photo.php 08-02-13 17:32 ratbek $
 * @author     Ratbek
 */

/**
 * @category   Application_Extensions
 * @package    Headvancedalbum
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Headvancedalbum_Model_Photo extends Album_Model_Photo
{
    public function getHref($params = array())
    {
        $params = array_merge(array(
            'route' => 'healbum_extended',
            'reset' => true,
            'controller' => 'photo',
            'action' => 'view',
            'album_id' => $this->album_id,
            'photo_id' => $this->getIdentity(),
        ), $params);
        $route = $params['route'];
        $reset = $params['reset'];
        unset($params['route']);
        unset($params['reset']);
        return Zend_Controller_Front::getInstance()->getRouter()
            ->assemble($params, $route, $reset);
    }

    public function setPhoto($photo)
    {

        if( $photo instanceof Zend_Form_Element_File ) {
            $file = $photo->getFileName();
            $fileName = $file;
        } else if( $photo instanceof Storage_Model_File ) {
            $file = $photo->temporary();
            $fileName = $photo->name;
        } else if( $photo instanceof Core_Model_Item_Abstract && !empty($photo->file_id) ) {
            $tmpRow = Engine_Api::_()->getItem('storage_file', $photo->file_id);
            $file = $tmpRow->temporary();
            $fileName = $tmpRow->name;
        } else if( is_array($photo) && !empty($photo['tmp_name']) ) {
            $file = $photo['tmp_name'];
            $fileName = $photo['name'];
        } else if( is_string($photo) && file_exists($photo) ) {
            $file = $photo;
            $fileName = $photo;
        } else {
            throw new User_Model_Exception('invalid argument passed to setPhoto');
        }

        if( !$fileName ) {
            $fileName = $file;
        }

        $name = basename($file);
        $extension = ltrim(strrchr($fileName, '.'), '.');
        $base = rtrim(substr(basename($fileName), 0, strrpos(basename($fileName), '.')), '.');
        $path = APPLICATION_PATH . DIRECTORY_SEPARATOR . 'temporary';
        $params = array(
            'parent_type' => $this->getType(),
            'parent_id' => $this->getIdentity(),
            'user_id' => $this->owner_id,
            'name' => $fileName,
        );

        // Save
        $filesTable = Engine_Api::_()->getDbtable('files', 'storage');

        $originPath = $path . DIRECTORY_SEPARATOR . $base . '_or.' . $extension;
        $image = Engine_Image::factory();
        $image->open($file)
            ->write($originPath)
            ->destroy();

        // Resize image (main)
        $mainPath = $path . DIRECTORY_SEPARATOR . $base . '_m.' . $extension;
        $image = Engine_Image::factory();
        $image->open($file)
            ->resize(720, 720)
            ->write($mainPath)
            ->destroy();

        // Resize image (normal)
        $normalPath = $path . DIRECTORY_SEPARATOR . $base . '_in.' . $extension;
        $image = Engine_Image::factory();
        $image->open($file)
            ->resize(140, 160)
            ->write($normalPath)
            ->destroy();

        // Store
        try {
            $iMain = $filesTable->createFile($mainPath, $params);
            $iIconNormal = $filesTable->createFile($normalPath, $params);
            $iOrigin = $filesTable->createFile($originPath, $params);

            $iMain->bridge($iIconNormal, 'thumb.normal');
            $iMain->bridge($iOrigin, 'thumb.origin');
        } catch( Exception $e ) {
            // Remove temp files
            @unlink($originPath);
            @unlink($mainPath);
            @unlink($normalPath);
            // Throw
            if( $e->getCode() == Storage_Model_DbTable_Files::SPACE_LIMIT_REACHED_CODE ) {
                throw new Album_Model_Exception($e->getMessage(), $e->getCode());
            } else {
                throw $e;
            }
        }

        // Remove temp files
        @unlink($originPath);
        @unlink($mainPath);
        @unlink($normalPath);

        // Update row
        $this->modified_date = date('Y-m-d H:i:s');
        $this->file_id = $iMain->file_id;
        $this->save();

        // Delete the old file?
        if( !empty($tmpRow) ) {
            $tmpRow->delete();
        }

        return $this;
    }
}
