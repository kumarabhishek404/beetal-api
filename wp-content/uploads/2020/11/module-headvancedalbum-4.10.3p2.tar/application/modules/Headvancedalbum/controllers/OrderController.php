<?php

class Headvancedalbum_OrderController extends Core_Controller_Action_Standard
{

    public function sortboxAction(){
        $settings = Engine_Api::_()->getApi('settings', 'core');

        switch($_REQUEST['type_sort']){
            case 'featured':
                $result = Engine_Api::_()->getApi('orders', 'headvancedalbum')->featured();
                break;
            case 'liked':
                $result = Engine_Api::_()->getApi('orders', 'headvancedalbum')->liked();
                break;
            case 'viewed':
                $result = Engine_Api::_()->getApi('orders', 'headvancedalbum')->viewed();
                break;
            case 'commented':
                $result = Engine_Api::_()->getApi('orders', 'headvancedalbum')->commented();
                break;
            case 'recent':
                $result = Engine_Api::_()->getApi('orders', 'headvancedalbum')->recent();
                break;
            case 'random':
                $result = Engine_Api::_()->getApi('orders', 'headvancedalbum')->random();
                break;
            default: case 'featured':
            $result = Engine_Api::_()->getApi('orders', 'headvancedalbum')->commented();
            break;
        }

        $paginator = $result;

        $show_item_on_page = $settings->getSetting('advanced.album.item.count.on.box', 3);

        $this->view->paginator = $paginator;
        if($this->_getParam('page')){
            $page = $this->_getParam('page')+1;
        }else{
            $page = $this->_getParam('page',1);
        }


        $item_page = ceil($paginator->getTotalItemCount()/$show_item_on_page);
        
        if($page > $item_page){
            $this->view->hide_more = 'true';
            return;
        }else{
            $this->view->hide_more = 'false';
        }


        $this->view->type_sort = $_REQUEST['type_sort'];
        $this->view->page = $page;
        $paginator->setItemCountPerPage($show_item_on_page);
        $paginator->setCurrentPageNumber($page);
        $this->view->albums = $photos = Engine_Api::_()->getDbTable('albums', 'headvancedalbum')->getAlbumsByPaginator($paginator);
    }




    public function indexAction()
    {

        $viewer = Engine_Api::_()->user()->getViewer();

        if(!$viewer){return;}

        $age = Engine_Api::_()->getApi('orders', 'headvancedalbum')->getBirthday($viewer);

        $settings = Engine_Api::_()->getApi('settings', 'core');

        $setting_age = $settings->getSetting('headvancedalbum.age.setting');

        if($age<$setting_age ||$age>100){return;}

        switch($_REQUEST['type_sort']){
            case 'featured':
                $result = Engine_Api::_()->getApi('orders', 'headvancedalbum')->featured();
                break;
            case 'liked':
                $result = Engine_Api::_()->getApi('orders', 'headvancedalbum')->liked();
                break;
            case 'viewed':
                $result = Engine_Api::_()->getApi('orders', 'headvancedalbum')->viewed();
                break;
            case 'commented':
                    $result = Engine_Api::_()->getApi('orders', 'headvancedalbum')->commented();
                break;
            case 'recent':
                $result = Engine_Api::_()->getApi('orders', 'headvancedalbum')->recent();
                break;
            case 'random':
                $result = Engine_Api::_()->getApi('orders', 'headvancedalbum')->random();
                break;
            default: case 'featured':
            $result = Engine_Api::_()->getApi('orders', 'headvancedalbum')->commented();
            break;
        }

        $paginator = $result;

        $show_item_on_page = $settings->getSetting('advanced.album.item.count.on.page', 10);

        $this->view->paginator = $paginator;
        if($this->_getParam('page')){
           $page = $this->_getParam('page')+1;
        }else{
            $page = $this->_getParam('page',1);
        }


        $item_page = ceil($paginator->getTotalItemCount()/$show_item_on_page);

        if($page > $item_page){
            $this->view->hide_more = 'true';
            return;
        }else{
            $this->view->hide_more = 'false';
        }

        $this->view->page = $page;
        $paginator->setItemCountPerPage($show_item_on_page);
        $paginator->setCurrentPageNumber($page);
        $this->view->albums = $photos = Engine_Api::_()->getDbTable('albums', 'headvancedalbum')->getAlbumsByPaginator($paginator);
    }
}