Location = function (store) {

    Location.prototype.LoadImages = function (location) {
        console.log(location);

        (new Request.JSON({
            url: en4.core.baseUrl + 'headvancedalbum/index/browse/format/json',
            data: location,
            onSuccess: function (res) {

                console.log(res.body);

                //window.filterLoading = false;
                //$('hapLoader').removeClass('active');

                window.is_next = res.is_next;

                var $c = $$('.layout_core_content');
                if (res.item_count) {
                    $('tipNoResult').hide();
                    $c.show();
                    $c.set('html', res.body);
                } else {
                    $('tipNoResult').show();
                    $c.hide();
                }
            }

        })).send();

    };
};


