<?php

class Headvancedalbum_Widget_OrderBoxRandomController extends Engine_Content_Widget_Abstract
{
  public function indexAction()
  {

  }
}