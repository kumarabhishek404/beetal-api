<?php
class Headvancedalbum_Model_Featurealbum extends Core_Model_Item_Abstract
{
  
}