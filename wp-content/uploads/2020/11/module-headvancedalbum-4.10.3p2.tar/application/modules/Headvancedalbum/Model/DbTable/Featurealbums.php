<?php
class Headvancedalbum_Model_DbTable_Featurealbums extends Core_Model_Item_DbTable_Abstract
{
    protected $_rowClass = 'Headvancedalbum_Model_Featurealbum';
}