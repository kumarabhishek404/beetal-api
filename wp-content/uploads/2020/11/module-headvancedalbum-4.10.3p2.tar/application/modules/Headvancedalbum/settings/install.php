<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Headvancedalbum
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: install.php 17.08.12 06:04 michael $
 * @author     Michael
 */

/**
 * @category   Application_Extensions
 * @package    Headvancedalbum
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */
class Headvancedalbum_Installer extends Engine_Package_Installer_Module
{
    public function onPreInstall()
    {
        parent::onPreInstall();

        $db = $this->getDb();
        $db = Engine_Db_Table::getDefaultAdapter();
        $db->query("CREATE TABLE IF NOT EXISTS `engine4_headvancedalbum_featurealbums` (
  `album_id` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `he_featured` int(11) NOT NULL DEFAULT '0',
  `location` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `sort_age` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  PRIMARY KEY (`album_id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;");
        
        $db->query("CREATE TABLE IF NOT EXISTS `engine4_headvancedalbum_featurephotos` (
  `photo_id` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `album_id` int(11) NOT NULL,
  `he_featured` int(11) NOT NULL DEFAULT '0',
  `location` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  PRIMARY KEY (`photo_id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;");
            
        /* Pages */
        
        $db->query("INSERT IGNORE INTO  `engine4_core_pages` (`name`, `displayname`, `url`, `title`, `description`, `keywords`, `custom`, `fragment`, `layout`, `levels`, `provides`, `view_count`) VALUES ('headvancedalbum_index_index', 'Advanced Album Photos Page', NULL, 'Photos', 'This page displays a list of photos', NULL, NULL, NULL, NULL, NULL, 'no-subject', NULL)");
        
        $page_id = $db->lastInsertId();
        
        if ($page_id) {
            
            $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'container', 'top', 'NULL', '1', '[\"[]\"]', NULL)");
            $parent_content_id = $db->lastInsertId();
            $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'container', 'middle', '$parent_content_id', '6', '[\"[]\"]', NULL)");
            $parent_content_id_0 = $db->lastInsertId();
            $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'widget', 'headvancedalbum.navigation-tabs', '$parent_content_id_0', '3', '[\"[]\"]', NULL)");
            
            
            
            $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'container', 'main', 'NULL', '2', '[\"[]\"]', NULL)");
            $parent_content_id = $db->lastInsertId();
            $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'container', 'middle', '$parent_content_id', '6', '[\"[]\"]', NULL)");
            $parent_content_id_0 = $db->lastInsertId();
            $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'widget', 'core.content', '$parent_content_id_0', '7', '[\"[]\"]', NULL)");
            
            
            //$db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'widget', 'headvancedalbum.featured-albums', '$parent_content_id_0', '6', '{\"title\":\"Featured Albums\"}', NULL)");
            
            
            
        }
        
        /* -------------------------- */
        
        $db->query("INSERT IGNORE INTO  `engine4_core_pages` (`name`, `displayname`, `url`, `title`, `description`, `keywords`, `custom`, `fragment`, `layout`, `levels`, `provides`, `view_count`) VALUES ('headvancedalbum_index_browse', 'Advanced Album Browse Page', NULL, 'Albums', 'This page displays a list of albums', NULL, NULL, NULL, NULL, NULL, 'no-subject', NULL)");
        
        $page_id = $db->lastInsertId();
        
        if ($page_id) {
            
            $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'container', 'top', 'NULL', '1', '[\"[]\"]', NULL)");
            $parent_content_id = $db->lastInsertId();
            $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'container', 'middle', '$parent_content_id', '6', '[\"[]\"]', NULL)");
            $parent_content_id_0 = $db->lastInsertId();
            $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'widget', 'headvancedalbum.navigation-tabs', '$parent_content_id_0', '3', '[\"[]\"]', NULL)");
            
            
            
            $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'container', 'main', 'NULL', '2', '[\"[]\"]', NULL)");
            $parent_content_id = $db->lastInsertId();
            $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'container', 'middle', '$parent_content_id', '6', '[\"[]\"]', NULL)");
            $parent_content_id_0 = $db->lastInsertId();
            $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'widget', 'headvancedalbum.featured-photos', '$parent_content_id_0', '6', '{\"title\":\"Featured Photos\"}', NULL)");
            
            
            $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'widget', 'core.content', '$parent_content_id_0', '7', '[]', NULL)");
            
            
            
        }
        
        /* -------------------------- */
        
        $db->query("INSERT IGNORE INTO  `engine4_core_pages` (`name`, `displayname`, `url`, `title`, `description`, `keywords`, `custom`, `fragment`, `layout`, `levels`, `provides`, `view_count`) VALUES ('headvancedalbum_index_view', 'Advanced Album View Page', NULL, 'Album', 'This page displays a list of photos of an album ', NULL, NULL, NULL, NULL, NULL, 'no-subject', NULL)");
        
        $page_id = $db->lastInsertId();
        
        if ($page_id) {
            
            $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'container', 'main', 'NULL', '2', '[\"[]\"]', NULL)");
            $parent_content_id = $db->lastInsertId();
            $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'container', 'middle', '$parent_content_id', '6', '[\"[]\"]', NULL)");
            $parent_content_id_0 = $db->lastInsertId();
            $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'widget', 'core.content', '$parent_content_id_0', '3', '[\"[]\"]', NULL)");
            
            
            $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'widget', 'core.comments', '$parent_content_id_0', '4', '{\"title\":\"Comments\"}', NULL)");
            
            
            
            $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'container', 'right', '$parent_content_id', '5', '[\"[]\"]', NULL)");
            $parent_content_id_0 = $db->lastInsertId();
            $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'widget', 'headvancedalbum.friends-albums', '$parent_content_id_0', '6', '{\"title\":\"Friends\' Albums\"}', NULL)");
            
            
            $db->query("INSERT IGNORE INTO  `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'widget', 'headvancedalbum.friends-photos', '$parent_content_id_0', '7', '{\"title\":\"Friends\' Photos\"}', NULL)");
            
            
            
        }
         

    }

}
