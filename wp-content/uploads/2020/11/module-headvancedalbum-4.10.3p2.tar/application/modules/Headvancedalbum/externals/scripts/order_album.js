var sort_albums = {

    featured : function(){
      this.ajax_sort('featured');
    },

    liked :function(){
            this.ajax_sort('liked');
    },

    viewed :function(){
        this.ajax_sort('viewed');
    },

    commented :function(){
        this.ajax_sort('commented');
    },

    recent :function(){
        this.ajax_sort('recent');
    },

    random :function(){
        this.ajax_sort('random');
    },


    ajax_sort: function (sort_type){
    new Request.HTML({
        url: en4.core.baseUrl + 'headvancedalbum/order/sortbox',
        data: {
            type_sort: sort_type
        },
        onSuccess: function (responseTree, responseElements, responseHTML, responseJavaScript) {
            var test = new Element('div',{'html':responseHTML});
            test.getElements('ul').each(function(el) {
                if(el.get('id')=='hapPhotos_'+sort_type){
                    $$('#content_'+sort_type)[0].set('html','');
                    el.inject($$('#content_'+sort_type)[0]);
                    $$('#down_sort_'+sort_type).addEvent('click',function(ul){
                        new Request.HTML({
                            url: en4.core.baseUrl + 'headvancedalbum/order/sortbox',
                            data: {
                                type_sort: sort_type, page: $$('#page_sort_box_'+sort_type).get('value')[0]
                            },
                            onSuccess: function (responseTree, responseElements, responseHTML, responseJavaScript) {
                                var test = new Element('div',{'html':responseHTML});
                                test.getElements('ul').each(function(el) {
                                    if(el.get('id')=='hapPhotos_'+sort_type){
                                        $$('#page_sort_box_'+sort_type).set('value',el.getElementById('page_sort_box_'+sort_type).get('value'));
                                        el.getElements('li').each(function(li) {
                                            li.inject($$('#hapPhotos_'+sort_type)[0]);
                                        });
                                        $$('#down_sort_'+sort_type).show();
                                    }else{
                                        $$('#down_sort_'+sort_type).hide();
                                    }
                                });
                            }
                        }).send();
                    });
                }
            });
        }
    }).send();
},


     start :function(){

        $$('.link_menu').addEvent('click',function(e){
            e.stopPropagation();
            e.preventDefault();

            $$('#menu_sort >li').removeClass('active');

            e.target.getParent('li').addClass('active');
            $$('#load_img').show();
                 en4.core.request.send(new Request.HTML({
                        url: en4.core.baseUrl + 'headvancedalbum/order/index',
                        data: {
                            type_sort: e.target.get('id')
                        },
                       onSuccess: function (responseTree, responseElements, responseHTML, responseJavaScript) {
                           var test = new Element('div',{'html':responseHTML});
                           var more = new Element('div',{'html':"<span id='more_sort_w'>More</span>"});
                           test.getElements('ul').each(function(el) {
                               if(el.get('id')=='hapPhotos'){
                                 $$('.layout_core_content')[0].set('html','');
                                 el.inject($$('.layout_core_content')[0]);
                                   more.inject($$('.layout_core_content')[0]);
                                   $$('#load_img').hide();

                                   $$('#more_sort_w').addEvent('click',function(){
                                       $$('#load_img').show();
                                       en4.core.request.send(new Request.HTML({
                                           url: en4.core.baseUrl + 'headvancedalbum/order/index',
                                           data: {
                                               type_sort: e.target.get('id'), page: $$('#page_sort').get('value')[0]
                                           },
                                           onSuccess: function (responseTree, responseElements, responseHTML, responseJavaScript) {
                                               var test = new Element('div',{'html':responseHTML});
                                               test.getElements('ul').each(function(el) {
                                                   if(el.get('id')=='hapPhotos'){
                                                       $$('#page_sort').set('value',el.getElementById('page_sort').get('value'));
                                                       el.getElements('li').each(function(li) {
                                                           li.inject($$('#hapPhotos')[0]);
                                                       });
                                                       $$('#load_img').hide();
                                                       $$('#more_sort_w').show();
                                                   }else{
                                                       $$('#more_sort_w').hide();
                                                       $$('#load_img').hide();
                                                   }
                                               });
                                           }
                                       }));
                                   });
                               }
                           });
                        }
                }));
        });

    }
};


