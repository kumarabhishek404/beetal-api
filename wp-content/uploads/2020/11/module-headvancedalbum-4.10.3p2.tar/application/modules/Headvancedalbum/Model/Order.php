<?php

class Headvancedalbum_Model_Order extends Core_Model_Item_Abstract
{

}
