<?php

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version Seo Tool 3.1
 */

$page = "admin_seotool";
include "admin_header.php";

$task = ( isset($_POST['task'] )) ? $_POST['task'] : '';
$selected_page = isset($_GET['page']) ? $_GET['page'] : '';

if ( $task == 'save_settings' )
{
	$save_page = isset($_POST['select_page']) ? trim($_POST['select_page']) : '';	
	$save_title = isset($_POST['title']) ? trim($_POST['title']) : '' ;
	$save_keywords = isset($_POST['keywords']) ? trim($_POST['keywords']) : '';
	$save_description = isset($_POST['description']) ? trim($_POST['description']) : '';
	$custom_code = isset($_POST['custom_code']) ? trim($_POST['custom_code']) : '';
	
	he_seo_tool::save_page($save_page, $save_title, $save_keywords, $save_description, $custom_code);
}
elseif ( $task == 'save_analytics' )
{
	he_seo_tool::save_analytics_code(trim($_POST['analytics_code']));
}


if( $selected_page != '')
{
	$page_detail = he_seo_tool::find_page($selected_page);
}

$select_pages = he_seo_tool::load_se_pages();


//ASSIGN VARIABLES AND SHOW VIEW USERS PAGE
$smarty->assign('selected_page', $selected_page);
$smarty->assign('select_pages', $select_pages);
$smarty->assign('page_details', $page_detail);

include "admin_footer.php";
?>
