<?php

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version Seo Tool 3.1
 */

$plugin_name="Seo Tool";
$plugin_version = "3.21";
$req_core_version = "3.01";
$plugin_type = "he_seo_tool";
$plugin_desc = "This plugin lets you change the website pages' title, keywords, description to enhance SEO.";
$plugin_icon = "he_seo_tool_icon.png";
$plugin_menu_title = "690705001";
$plugin_pages_main = "690705001<!>he_seo_tool_icon.png<!>admin_seotool.php<~!~>";
$plugin_db_charset = 'utf8';
$plugin_db_collation = 'utf8_unicode_ci';
$plugin_reindex_totals = TRUE;

if( $install=="he_seo_tool" )
{
    //check core library
    $sql = "SELECT `plugin_version` FROM `se_plugins` WHERE plugin_type='he_core' AND `plugin_disabled`=0 LIMIT 1";
    $resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
    $core_version = $database->database_fetch_array($resource);
    if ( floatval($core_version[0]) < floatval($req_core_version) ) {
        die ('This plugin requires Hire-Experts Core Library. Please install latest version of Hire-Experts Core Library plugin. You can download it from My Plugins section in Hire-Experts.com for FREE.');
    }


  //######### GET CURRENT PLUGIN INFORMATION
  $sql = "SELECT * FROM se_plugins WHERE plugin_type='{$plugin_type}' LIMIT 1";
  $resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
  
  $plugin_info = array();
  if( $database->database_num_rows($resource) )
    $plugin_info = $database->database_fetch_assoc($resource);
   
  
  //######### REPLACE HEADER META DETAILS;
  if( !$plugin_info )
  {
	  include_once('../include/functions_seo_tool.php');
	  seo_tool_prepare_header();
  }

  //######### INSERT ROW INTO se_plugins
  $sql = "SELECT NULL FROM se_plugins WHERE plugin_type='$plugin_type'";
  $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
  
  if( !$database->database_num_rows($resource) )
  {
    $sql = "
      INSERT INTO se_plugins (
        plugin_name,
        plugin_version,
        plugin_type,
        plugin_desc,
        plugin_icon,
        plugin_menu_title,
        plugin_pages_main,
        plugin_pages_level,
        plugin_url_htaccess
      ) VALUES (
        '$plugin_name',
        '$plugin_version',
        '$plugin_type',
        '".str_replace("'", "\'", $plugin_desc)."',
        '$plugin_icon',
        '$plugin_menu_title',
        '$plugin_pages_main',
        '',
        ''
      )
    ";
    
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
  }
  
  //######### UPDATE PLUGIN VERSION IN se_plugins
  else
  {
    $sql = "
      UPDATE
        se_plugins
      SET
        plugin_name='$plugin_name',
        plugin_version='$plugin_version',
        plugin_desc='".str_replace("'", "\'", $plugin_desc)."',
        plugin_icon='$plugin_icon',
        plugin_menu_title='$plugin_menu_title',
        plugin_pages_main='$plugin_pages_main',
        plugin_pages_level='',
        plugin_url_htaccess=''
      WHERE
        plugin_type='$plugin_type'
    ";
    
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
  }

  //######### CREATE se_seo_pages
  $sql = "SHOW TABLES FROM `$database_name` LIKE 'se_seo_pages'";
  $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
  
  if( !$database->database_num_rows($resource) )
  {
    $sql = "
		CREATE TABLE `se_seo_pages` (
		  `page` varchar(225) NOT NULL,
		  `title` varchar(225) NOT NULL,
		  `keywords` text,
		  `description` text,
		  `custom_code` text,
		  UNIQUE KEY `page` (`page`)
		) ENGINE=MyISAM DEFAULT CHARSET=utf8;
    ";
    
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
  }
	//######### REPLACE HEADER META DETAILS;
	include_once('../include/functions_seo_tool.php');
    seo_tool_prepare_header();
    
    //######### ADD COLUMNS/VALUES TO SETTINGS TABLE
    $sql = "SHOW COLUMNS FROM `$database_name`.`se_settings` LIKE 'he_google_analytics'";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);

    if( !$database->database_num_rows($resource) )
    {
        $sql = "ALTER TABLE `se_settings` ADD COLUMN `he_google_analytics` VARCHAR(255) NOT NULL";
        $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    }
  
	//######### ADD VALUES TO LANGS TABLE
    $he_languagevars = array
    (
        '690705000' => '%1$s',
        '690705001' => 'Seo Tool',
        '690705002' => 'Select page:',
        '690705003' => 'Page Title:',
        '690705004' => 'META Keywords:',
        '690705005' => 'META Description:',
        '690705006' => 'Here you can edit title, keywords and description of pages to enhance Search Engine Optimization(SEO). Just choose page from drop down choice to edit its SEO items. If you set title/meta information for a specific page then it will override its default title/meta information. Also you can set any custom code (HTML, JS, CSS) for SE pages.<br />
        NEW:<br />
        We have hided many pages from drop down choice to make it easy to edit pages which really help you to improve SEO of your site. Also one of most important thing is placeholders - you can use Group title/event title/forum and topic subjects/etc in page title. We have manually integrated most popular plugins(<b>Placeholders: - page name:</b>):<br />
        <ul>
        	<li>[album_title], [owner_name] - album</li>
        	<li>[article_title], [owner_name] - article (Radcodes plugin)</li>
        	<li>[blog_title], [owner_name] - blog</li>
        	<li>[classified_title], [owner_name] - classified</li>
        	<li>[event_title], [owner_name] - event</li>
        	<li>[forum_title] - forum_view (SocialEngine plugin)</li>
        	<li>[forum_title], [topic_title] - forum_topic (SocialEngine plugin)</li>
        	<li>[group_title], [owner_name] - group</li>
        	<li>[page_title], [owner_name] - pages (Hire-Experts plugin)</li>
        	<li>[poll_title], [owner_name] - poll</li>
        	<li>[question_title], [owner_name] - question</li>
        	<li>[quiz_title], [owner_name] - browse_quiz_results</li>
        	<li>[quiz_title], [owner_name] - quiz (Hire-Experts plugin)</li>
        	<li>[video_title], [owner_name] - video (SocialEngine plugin)</li>
        </ul>
        <b>You can use these placeholders in "Page Title": <code>My title - [owner_name]\\\'s blog - [blog_title]</code></b>
        ',
        '690705007' => 'Additional custom code(HTML, CSS, JS, anything):',
        '690705008' => 'Google Analytics',
        '690705009' => 'Please enter your Google Analytics Account ID if you want to place tracking code on every SE pages. You can find your Account ID in <a href="https://www.google.com/analytics/settings/?et=reset&hl=en">Google Analytics page</a>. It should look like UA-XXXXXXX-X. Leave this text field empty to disable tacking.',
    );
	

    foreach ($he_languagevars as $langvar_id => $langvar_value)
    {
    	$sql = "SELECT `languagevar_id` FROM `se_languagevars`
    	   WHERE `languagevar_id`=$langvar_id AND `languagevar_language_id`=1";
    	
		$langvar_value = $database->database_real_escape_string($langvar_value);
        if ( $database->database_num_rows($database->database_query($sql)) == 0 )
        {
            $sql = "INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`)
                VALUES('$langvar_id', '1', '$langvar_value', 'seo_tool')";
        }
        else
        {
            $sql = "UPDATE `se_languagevars` SET `languagevar_value`='$langvar_value', `languagevar_default`='seo_tool'
                WHERE `languagevar_id`=$langvar_id AND `languagevar_language_id`=1";
        }
        
        $resource = $database->database_query($sql) or die("<b>Error: </b>" . $database->database_error() . "<br /><b>File: </b>" . __FILE__ . "<br /><b>Line: </b>" . __LINE__ . "<br /><b>Query: </b>" . $sql);
    }
	
}
?>