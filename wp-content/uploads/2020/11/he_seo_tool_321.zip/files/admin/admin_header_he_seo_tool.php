<?php

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version Seo Tool 1.02
 */

// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
defined('SE_PAGE') or exit();

include_once "./admin_header_he_core.php";
include_once "../include/class_he_seo_tool.php";
include_once "../include/functions_seo_tool.php";

?>