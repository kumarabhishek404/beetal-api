<?php

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version SEO Tool 3.1
 */

defined('SE_PAGE') or exit();

include_once "./header_he_core.php";
include_once "./include/class_he_seo_tool.php";
include_once "./include/functions_seo_tool.php";

SE_Hook::register('se_footer', 'seo_tool_set_page_globals');

if ( is_a($smarty, 'SESmarty') )
{
	$plugin_vars['uses_tpl_hooks'] = TRUE;
	$smarty->assign_hook('footer', 'footer_he_seo_tool.tpl');
}
?>