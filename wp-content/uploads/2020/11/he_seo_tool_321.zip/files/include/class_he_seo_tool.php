<?php

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version Seo Tool 3.1
 */

class he_seo_tool
{
	
	function find_page( $page_key )
	{
		if ( strlen($page_key) == 0 )
		{
			return array();	
		}
		
		$query = he_database::placeholder("SELECT * FROM `se_seo_pages` WHERE `page` = '?'", $page_key);
		
		return he_database::fetch_row($query);
	}
	
	function save_page( $page_key, $page_title, $page_keywords, $page_description, $page_custom_code )
	{
		if ( strlen($page_key) == 0 )
		{
			return false;			
		}
		
		$query = he_database::placeholder( "SELECT COUNT(*) FROM `se_seo_pages`
			WHERE `page`='?'", $page_key );
		
		if ( he_database::fetch_field($query) == 1 )
		{
			$query = he_database::placeholder("UPDATE `se_seo_pages` SET `title`='?', `keywords`='?', `description`='?', `custom_code`='?'
				WHERE `page`='?'", $page_title, $page_keywords, $page_description, $page_custom_code, $page_key );
		}
		else
		{
			$query = he_database::placeholder("INSERT INTO `se_seo_pages` (`page`,`title`,`keywords`,`description`,`custom_code`) 
				VALUES('?','?','?','?','?')", $page_key, $page_title, $page_keywords, $page_description, $page_custom_code);
		}
		
		he_database::query($query);
		
		return true;
		
	}
	
	function load_se_pages()
	{
		$ignored_pages = array(
			/* SE standard */
			'ad',  'lostpass', 'lostpass_reset', 'misc_js', 'profile_comments', 'profile_photos', 'profile_photos_file', 'signup_verify', 'upload',
			/* Events */
			'profile_event_calendar', 
			/* EPayment */
			'epayment_cancel', 'epayment_done', 'epayment_ipn', 
			/* Gstore */
			'paypal_shipping', 'paypal', 
			/* Cooliris */
			'cooliris', 
			/* Styler */
			'he_styler_uploader', 
			/* Quiz */
			'quiz_suggest_to_friends', 'he_contacts', 'quiz_result', 'quiz_questions', 'quiz_general', 'quiz_publish', 
			/* Fans */
			'fans_suggest_to_contacts', 'fans_block', 'fans_message', 'fans_code', 
			/* Videos */
			'video_conversion_cronjob', 
			/* FacebookConnect */
			'login_openid',
		);
		$pages = array();
	
		$path = dirname(__FILE__) . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR ;
		$res = @opendir($path);
		while( $filename = @readdir($res) )
		{
			if ( !@is_file($path . $filename) )
			{
				continue;
			}
	
			$ext = strtolower(substr(strrchr($filename, '.'), 1));

			if ( $ext != 'php' )
			{
				continue;
			}
	
			$contents = @file_get_contents($path . $filename);
	
			if ( preg_match('/\$page\s*=\s*["\']{1}([^"\']+)["\']\s*;/', $contents, $matches) )
			{
				if( strpos($matches[1], 'ajax')===false && strpos($matches[1], 'user_')===false && !in_array($matches[1], $ignored_pages) )
					$pages[] = $matches[1];
			}
		}
	
		sort( $pages );
		return $pages;
	}
	
	function save_analytics_code($analytics_code) {
		global $setting;
		
		$setting['he_google_analytics'] = $analytics_code;
		
		return he_database::query(he_database::placeholder("UPDATE se_settings SET he_google_analytics='?'", $analytics_code));
	}
	
	function get_analytics_code() {
		global $setting;
	
		return $setting['he_google_analytics'] ?
'<script type="text/javascript">
	var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
	document.write(unescape("%3Cscript src=\'" + gaJsHost + "google-analytics.com/ga.js\' type=\'text/javascript\'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
	try {
	var pageTracker = _gat._getTracker("'.$setting['he_google_analytics'].'");
	pageTracker._trackPageview();
	} catch(err) {}
</script>' : 
		'';
	}
	
}