<?php

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version Seo Tool 3.1
 */

function seo_tool_prepare_header( )
{
	$ds = DIRECTORY_SEPARATOR;
	$file_path = '..' . $ds . 'templates' . $ds . 'header_global.tpl';
	
	$res = @fopen($file_path, 'r');
	if ( $res === false )
	{
		die("<b>Please set 0777 permissions on the 'templates/header_global.tpl' file</b>");
	}
	
	$content = fread($res, filesize($file_path)+100000);
 	if(!strpos($content,"<meta name='Keywords' content='{\$global_page_keywords}'/>"))
	{	
		$content = str_replace("<meta name='Description'", "{\$global_page_custom_code}<meta name='Keywords' content='{\$global_page_keywords}'/><meta name='Description'", $content);
	}
		
	fclose($res);
	
	$res = @fopen($file_path, 'w');
	if ( $res === false )
	{
		die("<b>Please set 0777 permissions on the 'templates/header_global.tpl' file</b>");
	}
	
	fwrite($res, $content);
	fclose($res);
}

function seo_tool_set_page_globals()
{
	global $page, $global_page_title, $global_page_description, $smarty;
	
	$page_info = he_seo_tool::find_page($page);

	if ( !$page_info )
	{
		return false;
	}
	else
	{
		global $owner;
		$owner_name = ( is_object($owner) && $owner->user_exists ) ? $owner->user_displayname : '';
		switch( $page )
		{
			case 'album': 
				global $album_info;
				if( $album_info )
					$page_info['title'] = str_replace('[album_title]', $album_info['album_title'], $page_info['title']);
				break;
			case 'event':
				global $event, $officers;
				if( is_object($event) && $event->event_exists )
				{
					$page_info['title'] = str_replace('[event_title]', $event->event_info['event_title'], $page_info['title']);
					if( is_array($officers) && is_object($officers[0]['member']) )
						$owner_name = $officers[0]['member']->user_info['user_displayname'];
				}
				break;
			case 'article':
				global $rc_article;
				if( is_object($rc_article) )
					$page_info['title'] = str_replace('[article_title]', $rc_article->article_info['article_title'], $page_info['title']);
				break;
			case 'blog':
				global $blogentry_info;
				if( $blogentry_info )
				{
					$seo_page_title = cleanHTML(str_replace('>', '> ', $blogentry_info['blogentry_title']), NULL);
					if( strlen($seo_page_title)>255 ) $seo_page_title = substr($seo_page_title, 0, 251).'...';
					$seo_page_title = addslashes(trim(preg_replace('/\s+/', ' ',$seo_page_title)));
					$page_info['title'] = str_replace('[blog_title]', $seo_page_title, $page_info['title']);
				}
				break;
			case 'pages':
				global $pages;
				if( is_object($pages) && $pages->page_exists )
				{
					$seo_page_title = $pages->page_info['pages_title'];
					$seo_page_title = cleanHTML(str_replace('>', '> ', $seo_page_title), NULL);
					if( strlen($seo_page_title)>255 ) $seo_page_title = substr($seo_page_title, 0, 251).'...';
					$seo_page_title = addslashes(trim(preg_replace('/\s+/', ' ',$seo_page_title)));
					$page_info['title'] = str_replace('[page_title]', $seo_page_title, $page_info['title']);
					$owner_name = $pages->page_owner->user_displayname;
				}
				break;
			case 'classified':
				global $classified;
				if( is_object($classified) )
				{
					$seo_page_title = $classified->classified_info['classified_title'];
					$seo_page_title = cleanHTML(str_replace('>', '> ', $seo_page_title), NULL);
					if( strlen($seo_page_title)>255 ) $seo_page_title = substr($seo_page_title, 0, 251).'...';
					$seo_page_title = addslashes(trim(preg_replace('/\s+/', ' ',$seo_page_title)));
					$page_info['title'] = str_replace('[classified_title]', $seo_page_title, $page_info['title']);
				}
				break;
			case 'group':
				global $group, $officers;
				if( is_object($group) && $group->group_exists )
				{
					$page_info['title'] = str_replace('[group_title]', $group->group_info['group_title'], $page_info['title']);
					if( is_array($officers) && is_object($officers[0]['member']) )
						$owner_name = $officers[0]['member']->user_info['user_displayname'];
				}
				break;
			case 'poll':
				global $poll_object;
				if( is_object($poll_object) && $poll_object->poll_exists )
					$page_info['title'] = str_replace('[poll_title]', $poll_object->poll_info['poll_title'], $page_info['title']);
				break;
			case 'video':
				global $video_info;
				if( is_array($video_info) )
					$page_info['title'] = str_replace('[video_title]', $video_info['video_title'], $page_info['title']);
				break;
			case 'forum_view':
				global $forum_info;
				if( is_array($forum_info) )
					$page_info['title'] = str_replace('[forum_title]', SE_Language::_get($forum_info['forum_title']), $page_info['title']);
				break;
			case 'forum_topic':
				global $forum_info, $topic_info;
				if( is_array($topic_info) )
					$page_info['title'] = str_replace('[topic_title]', $topic_info['forumtopic_subject'], str_replace('[forum_title]', SE_Language::_get($forum_info['forum_title']), $page_info['title']));
				break;
			case 'question':
				global $question;
				if( is_object($question) && $question->user_id )
					$page_info['title'] = str_replace('[question_title]', $question->title, $page_info['title']);
				break;
			case 'browse_quiz_results':
			case 'quiz':
				global $quiz_info;
				if( is_array($quiz_info) )
					$page_info['title'] = str_replace('[quiz_title]', $quiz_info['name'], $page_info['title']);
				break;
				
		}
		if( $owner_name )
			$page_info['title'] = str_replace('[owner_name]', $owner_name, $page_info['title']);
	}

	$global_page_title = ( $page_info['title'] ) ? array(690705000, $page_info['title']) : $global_page_title;
	$global_page_description = ( $page_info['description'] ) ? array(690705000, $page_info['description']) : $global_page_description;
	$global_page_custom_code = ( $page_info['custom_code'] ) ? $page_info['custom_code'] : '';
	
	$smarty->assign('global_page_keywords', $page_info['keywords']);
	$smarty->assign('global_page_custom_code', $global_page_custom_code);
	$smarty->assign('he_google_analytics', he_seo_tool::get_analytics_code());
}