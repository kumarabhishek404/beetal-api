INSERT INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES  ('groupannouncement', 'Group Announcement', 'This module let you to create announcement for group', '5.2.1', 1, 'extra') ;

INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES
('core_admin_main_plugins_groupannouncement', 'groupannouncement', 'Group Announcements', '', '{"route":"admin_default","module":"groupannouncement", "controller":"settings"}', 'core_admin_main_plugins', NULL, 1, 0, 999);

INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES
('groupannouncement_admin_main_settings', 'groupannouncement', 'Global Settings', '', '{"route":"admin_default","module":"groupannouncement","controller":"settings"}', 'groupannouncement_admin_main', '', 1, 0, 1);

INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES
('create_announcement', 'groupannouncement', 'Post Group Announcement', 'Groupannouncement_Plugin_Menus', '', 'group_profile', '', 1, 0, 999);

INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES
('manage_group_announcements', 'groupannouncement', 'Manage Announcements', 'Groupannouncement_Plugin_Menus', '', 'group_profile', '', 1, 0, 999);


INSERT IGNORE INTO `engine4_core_menus` (`name`, `type`, `title`, `order`) VALUES
('groupannouncement_admin_main', 'standard', 'Group Announcement Main Navigation Menu', 999);
