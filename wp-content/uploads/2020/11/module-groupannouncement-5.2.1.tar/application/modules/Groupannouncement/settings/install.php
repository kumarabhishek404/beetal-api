<?php
/**
 * iPragmatech Solution Pvt. Ltd.
 *
 * @package    Group Announcement
 * @copyright  Copyright 2008-2018 iPragmatech Solution Pvt. Ltd.
 * @license    � 2018 iPragmatech. All Rights Reserved.
 * @version    $Id: AdminSettingsController.php 9747 2013-07-06 02:08:08Z iPrgamtech $
 * @author     iPragmatech
 */

/**
 * @package    Group Announcement
 * @copyright  Copyright 2008-2018 iPragmatech Solution Pvt. Ltd.
 * @license   � 2018 iPragmatech. All Rights Reserved.
 */
class Groupannouncement_Installer extends Engine_Package_Installer_Module
{
  
	public function onPreInstall()
    {
    	$this->_myannouncementPage();
        $this->_addannouncementCreatePage();
        $this->_CreateTable();
    	 parent::onPreInstall();
    	
    	    $db = $this->getDb();
		  	$select = new Zend_Db_Select($db);
		  	$select
	  	    ->from('engine4_core_modules')
		  	->where('name = ?', 'group');
		  	$check_groups = $select->query()->fetchAll();
		  	$group_error_message = "Group plugin is not installed. Please install Group module";
		  	if(empty($check_groups)){
		  		return $this->_error($group_error_message);
		  	}
  }
public function _myannouncementPage(){
	    $db     = $this->getDb();
        $select = new Zend_Db_Select($db);

        // Check if it's already been placed
        $select = new Zend_Db_Select($db);
        $select
            ->from('engine4_core_pages')
            ->where('name = ?', 'groupannouncement_announcement_manage')
            ->limit(1);
        ;
        $info = $select->query()->fetch();

        if( empty($info) ) {
            $db->insert('engine4_core_pages', array(
                'name' => 'groupannouncement_announcement_manage',
                'displayname' => 'Group announcement manage page',
                'title' => 'Group announcement manage page',
                'description' => 'This is the manage page for Group announcement.',
                'custom' => 0,
            ));
            $pageId = $db->lastInsertId('engine4_core_pages');

            // Insert top
            $db->insert('engine4_core_content', array(
                'type' => 'container',
                'name' => 'top',
                'page_id' => $pageId,
                'order' => 1,
            ));
            $topId = $db->lastInsertId();

            // Insert main
            $db->insert('engine4_core_content', array(
                'type' => 'container',
                'name' => 'main',
                'page_id' => $pageId,
                'order' => 2,
            ));
            $mainId = $db->lastInsertId();

            // Insert top-middle
            $db->insert('engine4_core_content', array(
                'type' => 'container',
                'name' => 'middle',
                'page_id' => $pageId,
                'parent_content_id' => $topId,
            ));
            $topMiddleId = $db->lastInsertId();

            // Insert main-middle
            $db->insert('engine4_core_content', array(
                'type' => 'container',
                'name' => 'middle',
                'page_id' => $pageId,
                'parent_content_id' => $mainId,
                'order' => 2,
            ));
            $mainMiddleId = $db->lastInsertId();

            // Insert main-right
            $db->insert('engine4_core_content', array(
                'type' => 'container',
                'name' => 'right',
                'page_id' => $pageId,
                'parent_content_id' => $mainId,
                'order' => 1,
            ));
            $mainRightId = $db->lastInsertId();


            // Insert menu
            $db->insert('engine4_core_content', array(
                'type' => 'widget',
                'name' => 'group.browse-menu',
                'page_id' => $pageId,
                'parent_content_id' => $topMiddleId,
                'order' => 1,
            ));

            // Insert content
            $db->insert('engine4_core_content', array(
                'type' => 'widget',
                'name' => 'core.content',
                'page_id' => $pageId,
                'parent_content_id' => $mainMiddleId,
                'order' => 1,
            ));

            // Insert search
            $db->insert('engine4_core_content', array(
                'type' => 'widget',
                'name' => 'group.browse-menu-quick',
                'page_id' => $pageId,
                'parent_content_id' => $mainRightId,
                'order' => 1,
            ));
        }
}
  public function _addannouncementCreatePage()
  {
    $db = $this->getDb();

    // profile page
    $pageId = $db->select()
      ->from('engine4_core_pages', 'page_id')
      ->where('name = ?', 'groupannouncement_announcement_create')
      ->limit(1)
      ->query()
      ->fetchColumn();

    // insert if it doesn't exist yet
    if( !$pageId ) {
      // Insert page
      $db->insert('engine4_core_pages', array(
        'name' => 'groupannouncement_announcement_create',
        'displayname' => 'Group Announcement Create Page',
        'title' => 'Group Announcement Create',
        'description' => 'This page allows users to create Group Announcement.',
        'custom' => 0,
      ));
      $pageId = $db->lastInsertId();

      // Insert top
      $db->insert('engine4_core_content', array(
        'type' => 'container',
        'name' => 'top',
        'page_id' => $pageId,
        'order' => 1,
      ));
      $topId = $db->lastInsertId();

      // Insert main
      $db->insert('engine4_core_content', array(
        'type' => 'container',
        'name' => 'main',
        'page_id' => $pageId,
        'order' => 2,
      ));
      $mainId = $db->lastInsertId();

      // Insert top-middle
      $db->insert('engine4_core_content', array(
        'type' => 'container',
        'name' => 'middle',
        'page_id' => $pageId,
        'parent_content_id' => $topId,
      ));
      $topMiddleId = $db->lastInsertId();

      // Insert main-middle
      $db->insert('engine4_core_content', array(
        'type' => 'container',
        'name' => 'middle',
        'page_id' => $pageId,
        'parent_content_id' => $mainId,
        'order' => 2,
      ));
      $mainMiddleId = $db->lastInsertId();

      // Insert menu
      $db->insert('engine4_core_content', array(
        'type' => 'widget',
        'name' => 'group.browse-menu',
        'page_id' => $pageId,
        'parent_content_id' => $topMiddleId,
        'order' => 1,
      ));

      // Insert content
      $db->insert('engine4_core_content', array(
        'type' => 'widget',
        'name' => 'core.content',
        'page_id' => $pageId,
        'parent_content_id' => $mainMiddleId,
        'order' => 1,
      ));

    }

  }
public function _CreateTable(){
  $log = Zend_Registry::get('Zend_Log');
  $db = $this->getDb();
  $add_fields = $db->query("CREATE TABLE IF NOT EXISTS `engine4_group_announcements` (
  `announcement_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `enable` tinyint(4) NOT NULL,
  `url` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`announcement_id`),
  KEY `group_id` (`group_id`,`enable`)
);");

//
try {
  $add_fields = $db->query("SHOW COLUMNS FROM engine4_group_announcements WHERE Field = 'photo_id'")->fetchAll();          
            if(!count($add_fields)){
              $log->log("Step 1:::",Zend_Log::DEBUG);
                $db->query("ALTER TABLE `engine4_group_announcements`  ADD `photo_id` INT NULL DEFAULT NULL  AFTER `group_id`;");
            }
            
        } catch (Exception $e){
           $log->log("Step 2:::".$e->getMessage(),Zend_Log::DEBUG); 
        }
}
  
}