<?php
/**
 * iPragmatech Solution Pvt. Ltd.
 *
 * @category   Application_Edit
 * @package    Group Announcement
 * @copyright  Copyright 2008-2013 iPragmatech Solution Pvt. Ltd.
 * @license    � 2013 iPragmatech. All Rights Reserved.
 * @version    $Id: Edit.php 9747 2013-07-06 02:08:08Z iPrgamtech $
 * @author     iPragmatech
 */


 class Groupannouncement_Form_Edit extends Engine_Form
{
  public function init()
  {
    $this->setTitle('Edit Group Announcement')
      ->setDescription('Please edit your group announcement below.')
      ->setAttrib('id', 'announcements_edit');     
   
    // Add title
    $this->addElement('Text', 'title', array(
      'label' => 'Title',
      'required' => true,
      'allowEmpty' => false,
     'validators' => array(
        array('NotEmpty', true),
      ),
    ));
    
    $this->addElement('TinyMce', 'body', array(
      'label' => 'Description',
      'required' => true,
      'editorOptions' => array(
        'bbcode' => true,
        'html' => true,
        'validators' => array(
      				array('NotEmpty', true),
       ),
      ),
      'allowEmpty' => false,        
    ));
    
    $this->addElement('File', 'photo', array(
            'label' => 'Choose Profile Photo',
        ));
        $this->photo->addValidator('Extension', false, 'jpg,png,gif,jpeg');
        
    // Add url for read more
    $this->addElement('Text', 'url', array(
    		'label' => 'More Description link',
    		'description' => 'You can choose your desired url for Announcement full description',
    		'required' => true,
    		'allowEmpty' => false,
    
    ));
    

        // Buttons
    $this->addElement('Button', 'submit', array(
      'label' => 'Edit Announcement',
      'type' => 'submit',
      'ignore' => true,
      'decorators' => array('ViewHelper')
    ));

    $this->addElement('Cancel', 'cancel', array(
      'label' => 'cancel',
      'ignore' => true,
      'link' => true,
      'href' => '',
      'prependText' => Zend_Registry::get('Zend_Translate')->_(' or '),
      'decorators' => array(
        'ViewHelper',
      ),
    ));

    $this->addDisplayGroup(array('submit', 'cancel'), 'buttons',array(
        'decorators' => array(
            'FormElements',
            'DivDivDivWrapper',
        ),
    ) );
  }
}