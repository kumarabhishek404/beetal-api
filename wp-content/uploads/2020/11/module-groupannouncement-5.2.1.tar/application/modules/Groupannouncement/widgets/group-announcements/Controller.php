<?php
/**
 * iPragmatech Solution Pvt. Ltd.
 *
 * @category   Widget
 * @package    Group Announcement
 * @copyright  Copyright 2008-2013 iPragmatech Solution Pvt. Ltd.
 * @license    http://www.ipragmatech.com/license/
 * @version    $Id: Install.php 9747 2013-07-06 02:08:08Z iPrgamtech $
 * @author     iPragmatech
 */

/**
 * @category   Widget
 * @package    Group Announcement
 * @copyright  Copyright 2008-2013 iPragmatech Solution Pvt. Ltd.
 * @license    http://www.ipragmaetch.com/license/
 */
class Groupannouncement_Widget_GroupAnnouncementsController extends Engine_Content_Widget_Abstract
{
  public function indexAction()
  {
  	
    $settings = Engine_Api::_()->getApi('settings', 'core');
    // Don't render this if not authorized
    $viewer = Engine_Api::_()->user()->getViewer();
    $subject = null;
    if( Engine_Api::_()->core()->hasSubject() ) {
    	// Get subject
    	$this->view->subject = $subject = Engine_Api::_()->core()->getSubject('group');
    	$group_id = $subject->getIdentity();
    	if( !$subject->authorization()->isAllowed($viewer, 'view') ) {
    		return $this->setNoRender();
    	}
    }
    
    $group_announcement_table = Engine_Api::_()->getDbtable('announcements', 'groupannouncement');
    if($subject == null)
    {
	    $viewer = Engine_Api::_()->user()->getViewer();
	  	$membership = Engine_Api::_()->getDbtable('membership', 'group');
	  	$select = $membership->getMembershipsOfSelect($viewer);
	  	$select->where('group_id IS NOT NULL');
	    $this->view->grouppaginator = $groupPaginator = Zend_Paginator::factory($select);
	  	$groupIds = array();
	  	foreach($groupPaginator as $group){
	  		$groupIds[] = $group->getIdentity();
	  	}
	  	if(!$viewer->getIdentity()){
	  		$select = $group_announcement_table->select()
	  		->where('enable = ?', 1)
	  		->order('creation_date DESC');
	  	}
	    else
	    {
	        $select = $group_announcement_table->select()
	        ->where('group_id IN (?)', $groupIds)
	        ->where('enable = ?', 1)
	        ->order('creation_date DESC');
	     }
     }
    else
    {
        $select = $group_announcement_table->select()
	    ->where('group_id=?', $group_id)
	    ->where('enable = ?', 1)
	    ->order('creation_date DESC');
    }
    
    
    $this->view->announcements = $paginator = Zend_Paginator::factory($select);
    // Set item count per page and current page number
    $paginator->setItemCountPerPage($settings->getSetting('announcement_page'),3);
    $paginator->setCurrentPageNumber( $this->_getParam('page') ); 
    }
  }
