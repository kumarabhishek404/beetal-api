<?php
/**
 * SocialEngine
 *
 * @category   Application_Groupannouncement
 * @package    Announcement
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.ipragmatech.com/license/
 * @version    $Id: content.php 9747 2012-07-26 02:08:08Z ipragmatech $
 * @author     iPragmatech
 */
return array(
  array(
    'title' => 'Group Announcements',
    'description' => 'Displays recent group announcements.',
    'category' => 'Group Announcement',
    'type' => 'widget',
    'name' => 'groupannouncement.group-announcements',
    'isPaginated' => true,
    'defaultParams' => array(
      'title' => 'Group Announcements',
    ),
    'requirements' => array(
      'no-subject',
    ),
  ),
		
) ?>