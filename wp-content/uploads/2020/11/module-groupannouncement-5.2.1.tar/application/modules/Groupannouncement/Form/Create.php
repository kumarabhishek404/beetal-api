<?php
/**
 * iPragmatech Solution Pvt. Ltd.
 *
 * @category   Application_Groupannouncement
 * @package    Group Announcement
 * @copyright  Copyright 2008-2013 iPragmatech Solution Pvt. Ltd.
 * @license   � 2013 iPragmatech. All Rights Reserved.
 * @version    $Id: Install.php 9747 2013-07-06 02:08:08Z iPrgamtech $
 * @author     iPragmatech
 */

/**
 * @category   Application_Groupannouncement
 * @package    Group Announcement
 * @copyright  Copyright 2008-2013 iPragmatech Solution Pvt. Ltd.
 * @license    � 2013 iPragmatech. All Rights Reserved.
 */
class Groupannouncement_Form_Create extends Engine_Form
{
  public function init()
  {
  	$this->setTitle('Post New Announcement')
      ->setDescription('Please compose your new announcement below.')
      ->setAction(Zend_Controller_Front::getInstance()->getRouter()->assemble(array()))
      ->setAttrib('id', 'announcements_create');     
    
    // Prepare url 
  	
  	$subject = Engine_Api::_()->core()->getSubject('group');
  	$group_id = $subject->getIdentity();
  	$groupUrl = 'http://'.$_SERVER['HTTP_HOST'] . $subject->getHref();
  	
   
    // Add title
    $this->addElement('Text', 'title', array(
      'label' => 'Title',
      'required' => true,
      'allowEmpty' => false,
    ));
    
    $this->addElement('TinyMce', 'body', array(
      'label' => 'Description',
      'required' => true,
      'editorOptions' => array(
        'bbcode' => true,
        'html' => true,
      ),
      'allowEmpty' => false,        
    ));

    $this->addElement('File', 'photo', array(
            'label' => 'Choose Profile Photo',
            'required' => true,
            'allowEmpty' => false,
        ));
        $this->photo->addValidator('Extension', false, 'jpg,png,gif,jpeg');
    
    // Add url for read more
      $this->addElement('Text', 'url', array(
      'label' => 'More Description link',
       'value' => $groupUrl,
      'description' => 'You can choose your desired url for Announcement full description',
      'required' => true,
       'allowEmpty' => false,
      
    ));
    
    // Buttons
    $this->addElement('Button', 'submit', array(
      'label' => 'Post Announcement',
      'type' => 'submit',
      'ignore' => true,
      'decorators' => array('ViewHelper')
    ));

    $this->addElement('Cancel', 'cancel', array(
      'label' => 'cancel',
      'ignore' => true,
      'link' => true,
      'href' => $groupUrl,
      'prependText' => Zend_Registry::get('Zend_Translate')->_(' or '),
      'decorators' => array(
        'ViewHelper',
      ),
    ));

    $this->addDisplayGroup(array('submit', 'cancel'), 'buttons',array(
        'decorators' => array(
            'FormElements',
            'DivDivDivWrapper',
        ),
        ) );
  }
}