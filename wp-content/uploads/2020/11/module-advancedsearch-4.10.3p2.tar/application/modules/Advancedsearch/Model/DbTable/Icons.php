<?php
/******/
class Advancedsearch_Model_DbTable_Icons extends Engine_Db_Table {

}