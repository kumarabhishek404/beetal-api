UPDATE `engine4_core_modules` SET `version` = '4.2.2p1'  WHERE `name` = 'suggest';
