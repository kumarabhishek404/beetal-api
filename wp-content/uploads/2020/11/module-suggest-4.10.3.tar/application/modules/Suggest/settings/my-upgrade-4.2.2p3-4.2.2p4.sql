UPDATE `engine4_core_modules` SET `version` = '4.2.2p4'  WHERE `name` = 'suggest';
