INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES
('suggest', 'Suggest', 'Suggest', '4.10.3', 1, 'extra');