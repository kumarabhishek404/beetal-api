<?php

class Suggest_AdminLevelController extends Core_Controller_Action_Admin
{

}