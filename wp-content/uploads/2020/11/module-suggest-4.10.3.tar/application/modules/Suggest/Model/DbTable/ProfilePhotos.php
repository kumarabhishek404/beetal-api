<?php

class Suggest_Model_DbTable_ProfilePhotos extends Engine_Db_Table
{
  protected $_name = 'suggest_profile_photos';

  protected $_rowClass = 'Suggest_Model_ProfilePhoto';
}