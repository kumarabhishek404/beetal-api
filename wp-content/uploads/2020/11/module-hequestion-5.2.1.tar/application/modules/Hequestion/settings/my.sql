INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES  ('hequestion', 'Questions', 'Questions', '5.2.1', 1, 'extra') ;
