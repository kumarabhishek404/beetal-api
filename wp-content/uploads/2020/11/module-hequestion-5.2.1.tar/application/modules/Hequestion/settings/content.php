<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Hequestion
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: content.php 17.08.12 06:04 michael $
 * @author     Michael
 */

/**
 * @category   Application_Extensions
 * @package    Hequestion
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */


return array(

  array(
    'title' => 'Asked By',
    'description' => 'Displays the owner and options of poll.',
    'category' => 'Advance Polls',
    'type' => 'widget',
    'name' => 'hequestion.asked',
    'requirements' => array(
      'subject' => 'hequestion',
    ),
  ),

  array(
    'title' => 'Friends\'s Polls',
    'description' => 'Displays friend\'s polls.',
    'category' => 'Advance Polls',
    'type' => 'widget',
    'name' => 'hequestion.friend-questions',
    'defaultParams' => array(
      'title' => 'HEQUESTION_FRIEND_QUESTIONS'
    ),
    'requirements' => array(
    ),
  ),

  array(
    'title' => 'Popular polls',
    'description' => 'Displays popular polls.',
    'category' => 'Advance Polls',
    'type' => 'widget',
    'name' => 'hequestion.popular-questions',
    'defaultParams' => array(
      'title' => 'HEQUESTION_POPULAR_QUESTIONS'
    ),
    'requirements' => array(
    ),
  ),

  array(
    'title' => 'Recent Answers',
    'description' => 'Displays recent answers.',
    'category' => 'Advance Polls',
    'type' => 'widget',
    'name' => 'hequestion.recent-answers',
    'defaultParams' => array(
      'title' => 'HEQUESTION_RECENT_ANSWERS'
    ),
    'requirements' => array(
    ),
  ),


  array(
    'title' => 'Profile Polls',
    'description' => 'Displays all of the polls by user, event, group, page and etc.',
    'category' => 'Advance Polls',
    'type' => 'widget',
    'name' => 'hequestion.profile-questions',
    'isPaginated' => true,
    'defaultParams' => array(
      'title' => 'HEQUESTION_PROFILE_QUESTIONS',
      'titleCount' => true
    ),
    'requirements' => array(
      'subject' => 'subject',
    ),
  ),


  array(
    'title' => 'Browse Menu',
    'description' => 'Displays navigation menu on browse page.',
    'category' => 'Advance Polls',
    'type' => 'widget',
    'name' => 'hequestion.browse-menu',
    'defaultParams' => array(
    ),
    'requirements' => array(
    ),
  )





);