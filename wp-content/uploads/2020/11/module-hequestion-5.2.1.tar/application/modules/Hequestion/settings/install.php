<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Hequestion
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: install.php 17.08.12 06:04 michael $
 * @author     Michael
 */

/**
 * @category   Application_Extensions
 * @package    Hequestion
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */


class Hequestion_Installer extends Engine_Package_Installer_Module
{
  public function onPreInstall()
  {
    parent::onPreInstall();

    $db = $this->getDb();
    //Query step
    $db->query("CREATE TABLE IF NOT EXISTS `engine4_hequestion_followers` (
`user_id` int(11) NOT NULL,
`question_id` int(11) NOT NULL,
PRIMARY KEY (`user_id`,`question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci");
    
    $db->query("CREATE TABLE IF NOT EXISTS `engine4_hequestion_options` (
`option_id` int(11) NOT NULL AUTO_INCREMENT,
`title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
`user_id` int(11) NOT NULL,
`is_custom` tinyint(1) NOT NULL DEFAULT '0',
`question_id` int(11) NOT NULL,
`vote_count` int(11) NOT NULL,
PRIMARY KEY (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=382 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci");
    
    $db->query("CREATE TABLE IF NOT EXISTS `engine4_hequestion_questions` (
`question_id` int(11) NOT NULL AUTO_INCREMENT,
`user_id` int(11) DEFAULT '0',
`action_id` int(11) DEFAULT '0',
`title` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
`follower_count` int(11) NOT NULL DEFAULT '0',
`vote_count` int(11) NOT NULL DEFAULT '0',
`can_add` tinyint(1) NOT NULL DEFAULT '1',
`creation_date` datetime NOT NULL,
`modified_date` datetime NOT NULL,
`owner_type` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
`owner_id` int(11) NOT NULL,
`parent_type` varchar(90) COLLATE utf8_unicode_ci DEFAULT '',
`parent_id` int(11) DEFAULT '0',
PRIMARY KEY (`question_id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci");
    
    $db->query("CREATE TABLE IF NOT EXISTS `engine4_hequestion_votes` (
`vote_id` int(11) NOT NULL AUTO_INCREMENT,
`user_id` int(11) NOT NULL,
`question_id` int(11) NOT NULL,
`option_id` int(11) DEFAULT NULL,
`creation_date` datetime NOT NULL,
PRIMARY KEY (`vote_id`)
) ENGINE=InnoDB AUTO_INCREMENT=312 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci");
    
    $db->query("INSERT IGNORE INTO `engine4_activity_actiontypes` (`type`, `module`, `body`, `enabled`, `displayable`, `attachable`, `commentable`, `shareable`, `is_generated`) VALUES
('comment_hequestion', 'hequestion', '{item:\\
subject} commented on {item:\\\$owner}\'s {item:\\\$object:\\\question}: {body:\\\$body}.', '1', '1', '1', '1', '1', '1'),
('hequestion_answer', 'hequestion', '{item:\\\$subject} answered {item:\\\$object} with {var:\\\$body}', '1', '7', '1', '0', '0', '1'),
('hequestion_ask', 'hequestion', '{actors:\\\$subject:\\\$object} asked {var:\\\$question}', '1', '7', '1', '0', '1', '1'),
('hequestion_ask_self', 'hequestion', '{item:\\\$subject} asked {var:\\\$question}', '1', '7', '1', '0', '1', '1');");
    
    $db->query("INSERT IGNORE INTO `engine4_activity_notificationtypes` (`type`, `module`, `body`, `is_request`, `handler`, `default`) VALUES
('hequestion_answer', 'hequestion', '{item:\\\$subject} has answered {item:\\\$object}.', '0', '', '1'),
('hequestion_ask', 'hequestion', '{item:\\\$subject} has asked you {item:\\\$object}.', '0', '', '1'),
('hequestion_follow', 'hequestion', '{item:\\\$subject} has answered {item:\\\$object}.', '0', '', '1')");
   
    $db->query("INSERT IGNORE INTO `engine4_core_mailtemplates` (`type`, `module`, `vars`) VALUES
('notify_hequestion_answer', 'hequestion', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link]'),
('notify_hequestion_ask', 'hequestion', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link]'),
('notify_hequestion_follow', 'hequestion', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link]')");
  
  
    $db->query("INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES
('core_main_hequestion', 'hequestion', 'HEQUESTION_QUESTION', '', '{\"route\":\"hequestion_general\"}', 'core_main', '', '1', '0', '5'),
('core_sitemap_hequestion', 'hequestion', 'HEQUESTION_QUESTION', '', '{\"route\":\"hequestion_general\"}', 'core_sitemap', '', '1', '0', '5'),
('core_admin_main_plugins_hequestion', 'hequestion', 'HEQUESTION_ADMIN_HEQUESTION', '', '{\"route\":\"admin_default\",\"module\":\"hequestion\",\"controller\":\"manage\"}', 'core_admin_main_plugins', '', '1', '0', '889'),
('hequestion_admin_main_manage', 'hequestion', 'HEQUESTION_ADMIN_MANAGE', '', '{\"route\":\"admin_default\",\"module\":\"hequestion\",\"controller\":\"manage\"}', 'hequestion_admin_main', '', '1', '0', '1'),
('hequestion_admin_main_settings', 'hequestion', 'Global Settings', '', '{\"route\":\"admin_default\",\"module\":\"hequestion\",\"controller\":\"settings\"}', 'hequestion_admin_main', '', '1', '0', '2'),
('hequestion_admin_main_level', 'hequestion', 'HEQUESTION_ADMIN_LEVELS', '', '{\"route\":\"admin_default\",\"module\":\"hequestion\",\"controller\":\"settings\",\"action\":\"level\"}', 'hequestion_admin_main', '', '1', '0', '3'),
('authorization_admin_level_hequestion', 'hequestion', 'HEQUESTION_ADMIN_HEQUESTION', '', '{\"route\":\"admin_default\",\"module\":\"hequestion\",\"controller\":\"settings\",\"action\":\"level\"}', 'authorization_admin_level', '', '1', '0', '999'),
('hequestion_main_browse', 'hequestion', 'HEQUESTION_BROWSE', NULL, '{\"route\":\"hequestion_general\"}', 'hequestion_main', NULL, '1', '0', '1'),
('hequestion_main_manage', 'hequestion', 'HEQUESTION_MY', 'Hequestion_Plugin_Menus', '{\"route\":\"hequestion_general\", \"action\": \"manage\"}', 'hequestion_main', NULL, '1', '0', '2')");
  
    $db->query("INSERT IGNORE INTO `engine4_core_pages` (`name`, `displayname`, `url`, `title`, `description`, `keywords`, `custom`, `fragment`, `layout`, `levels`, `provides`, `view_count`) VALUES ('hequestion_index_index', 'Advance Poll Home', NULL, 'Browse Advance Polls', NULL, NULL, NULL, NULL, NULL, NULL, 'no-subject', NULL)");
    $page_id = $db->lastInsertId();
    if ($page_id) {
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'container', 'main', 'NULL', '2', '[\"[]\"]', NULL)");
        $parent_content_id = $db->lastInsertId();
        $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'container', 'middle', '$parent_content_id', '6', '[\"[]\"]', NULL)");
        $parent_content_id_0 = $db->lastInsertId();
        $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'widget', 'hequestion.recent-answers', '$parent_content_id_0', '5', '{\"title\":\"HEQUESTION_RECENT_ANSWERS\"}', NULL)");
        
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'widget', 'core.content', '$parent_content_id_0', '4', '[\"[]\"]', NULL)");
        
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'widget', 'hequestion.browse-menu', '$parent_content_id_0', '3', '[]', NULL)");
        
        
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'container', 'right', '$parent_content_id', '5', '[\"[]\"]', NULL)");
        $parent_content_id_0 = $db->lastInsertId();
        $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'widget', 'hequestion.friend-questions', '$parent_content_id_0', '7', '{\"title\":\"HEQUESTION_FRIEND_QUESTIONS\"}', NULL)");
        
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'widget', 'hequestion.popular-questions', '$parent_content_id_0', '8', '{\"title\":\"HEQUESTION_POPULAR_QUESTIONS\"}', NULL)");
        
        
        
    }
    
    /* -------------------------- */
    
    $db->query("INSERT IGNORE INTO `engine4_core_pages` (`name`, `displayname`, `url`, `title`, `description`, `keywords`, `custom`, `fragment`, `layout`, `levels`, `provides`, `view_count`) VALUES ('hequestion_index_view', 'Advance Poll Profile', NULL, 'Advance Poll', NULL, NULL, NULL, NULL, NULL, NULL, 'no-subject', NULL)");
    
    $page_id = $db->lastInsertId();
    
    if ($page_id) {
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'container', 'main', 'NULL', '2', '[\"[]\"]', NULL)");
        $parent_content_id = $db->lastInsertId();
        $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'container', 'middle', '$parent_content_id', '6', '[\"[]\"]', NULL)");
        $parent_content_id_0 = $db->lastInsertId();
        $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'widget', 'core.content', '$parent_content_id_0', '3', '[\"[]\"]', NULL)");
        
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'widget', 'hequestion.asked', '$parent_content_id_0', '4', '[\"[]\"]', NULL)");
        
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'widget', 'core.comments', '$parent_content_id_0', '5', '{\"title\":\"Comments\"}', NULL)");
        
        
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'container', 'right', '$parent_content_id', '5', '[]', NULL)");
        $parent_content_id_0 = $db->lastInsertId();
        $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'widget', 'hequestion.popular-questions', '$parent_content_id_0', '7', '{\"title\":\"HEQUESTION_POPULAR_QUESTIONS\"}', NULL)");
        
        
        
    }
    
    /* -------------------------- */
    
    $db->query("INSERT IGNORE INTO `engine4_core_pages` (`name`, `displayname`, `url`, `title`, `description`, `keywords`, `custom`, `fragment`, `layout`, `levels`, `provides`, `view_count`) VALUES ('hequestion_index_box', 'Advance Poll Box', NULL, 'Advance Poll', NULL, NULL, NULL, NULL, NULL, NULL, 'no-subject', NULL)");
    
    $page_id = $db->lastInsertId();
    
    if ($page_id) {
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'container', 'main', 'NULL', '2', '[\"[]\"]', NULL)");
        $parent_content_id = $db->lastInsertId();
        $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'container', 'middle', '$parent_content_id', '6', '[\"[]\"]', NULL)");
        $parent_content_id_0 = $db->lastInsertId();
        $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'widget', 'core.content', '$parent_content_id_0', '3', '[\"[]\"]', NULL)");
        
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'widget', 'hequestion.asked', '$parent_content_id_0', '4', '[\"[]\"]', NULL)");
        
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'widget', 'core.comments', '$parent_content_id_0', '5', '{\"title\":\"Comments\"}', NULL)");
        
        
        
    }
    
    /* -------------------------- */
    
    $db->query("INSERT IGNORE INTO `engine4_core_pages` (`name`, `displayname`, `url`, `title`, `description`, `keywords`, `custom`, `fragment`, `layout`, `levels`, `provides`, `view_count`) VALUES ('hequestion_index_manage', 'Advance Polls Manage', NULL, 'My Polls', NULL, NULL, NULL, NULL, NULL, NULL, 'no-subject', NULL)");
    
    $page_id = $db->lastInsertId();
    
    if ($page_id) {
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'container', 'main', 'NULL', '2', '[\"[]\"]', NULL)");
        $parent_content_id = $db->lastInsertId();
        $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'container', 'middle', '$parent_content_id', '6', '[\"[]\"]', NULL)");
        $parent_content_id_0 = $db->lastInsertId();
        $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'widget', 'core.content', '$parent_content_id_0', '4', '[\"[]\"]', NULL)");
        
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'widget', 'hequestion.browse-menu', '$parent_content_id_0', '3', '[]', NULL)");
        
        
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'container', 'right', '$parent_content_id', '5', '[\"[]\"]', NULL)");
        $parent_content_id_0 = $db->lastInsertId();
        $db->query("INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ('$page_id', 'widget', 'hequestion.friend-questions', '$parent_content_id_0', '6', '{\"title\":\"HEQUESTION_FRIEND_QUESTIONS\"}', NULL)");
        
        
        
    }
    
    $profile = $db->query("SELECT * FROM engine4_core_pages WHERE name = 'user_profile_index'")->fetch();
    if (!empty($profile )){
        $mcontent = $db->query("SELECT * FROM engine4_core_content WHERE name = 'middle' AND page_id = {$profile ['page_id']}")->fetch();
        if ($mcontent){
            $tcontent = $db->query("SELECT * FROM engine4_core_content WHERE name = 'core.container-tabs' AND parent_content_id = {$mcontent['content_id']}")->fetch();
            if ($tcontent){
                $order = $db->query("SELECT MAX(`order`)+1 as `order` FROM engine4_core_content WHERE parent_content_id = {$tcontent['content_id']}")->fetch();
                if (!empty($order['order'])){
                    $order = $order['order'];
                } else {
                    $order = 1;
                }
                if (!$db->query("SELECT * FROM engine4_core_content WHERE page_id = {$tcontent['page_id']} AND name = 'hequestion.profile-questions' AND parent_content_id = {$tcontent['content_id']}")->fetch()){
                    $db->query("INSERT IGNORE INTO engine4_core_content (page_id, type, name, parent_content_id, `order`, params) VALUES ({$tcontent['page_id']}, 'widget', 'hequestion.profile-questions', {$tcontent['content_id']}, {$order}, '{\"title\":\"HEQUESTION_PROFILE_QUESTIONS\",\"titleCount\":true}');");
                }
                
            }
        }
    }
    $profile = $db->query("SELECT * FROM engine4_core_pages WHERE name = 'group_profile_index'")->fetch();
    if (!empty($profile )){
        $mcontent = $db->query("SELECT * FROM engine4_core_content WHERE name = 'middle' AND page_id = {$profile ['page_id']}")->fetch();
        if ($mcontent){
            $tcontent = $db->query("SELECT * FROM engine4_core_content WHERE name = 'core.container-tabs' AND parent_content_id = {$mcontent['content_id']}")->fetch();
            if ($tcontent){
                $order = $db->query("SELECT MAX(`order`)+1 as `order` FROM engine4_core_content WHERE parent_content_id = {$tcontent['content_id']}")->fetch();
                if (!empty($order['order'])){
                    $order = $order['order'];
                } else {
                    $order = 1;
                }
                if (!$db->query("SELECT * FROM engine4_core_content WHERE page_id = {$tcontent['page_id']} AND name = 'hequestion.profile-questions' AND parent_content_id = {$tcontent['content_id']}")->fetch()){
                    $db->query("INSERT IGNORE INTO engine4_core_content (page_id, type, name, parent_content_id, `order`, params) VALUES ({$tcontent['page_id']}, 'widget', 'hequestion.profile-questions', {$tcontent['content_id']}, {$order}, '{\"title\":\"HEQUESTION_PROFILE_QUESTIONS\",\"titleCount\":true}');");
                }
                
            }
        }
    }
    //
    $profile = $db->query("SELECT * FROM engine4_core_pages WHERE name = 'event_profile_index'")->fetch();
    if (!empty($profile )){
        $mcontent = $db->query("SELECT * FROM engine4_core_content WHERE name = 'middle' AND page_id = {$profile ['page_id']}")->fetch();
        if ($mcontent){
            $tcontent = $db->query("SELECT * FROM engine4_core_content WHERE name = 'core.container-tabs' AND parent_content_id = {$mcontent['content_id']}")->fetch();
            if ($tcontent){
                $order = $db->query("SELECT MAX(`order`)+1 as `order` FROM engine4_core_content WHERE parent_content_id = {$tcontent['content_id']}")->fetch();
                if (!empty($order['order'])){
                    $order = $order['order'];
                } else {
                    $order = 1;
                }
                if (!$db->query("SELECT * FROM engine4_core_content WHERE page_id = {$tcontent['page_id']} AND name = 'hequestion.profile-questions' AND parent_content_id = {$tcontent['content_id']}")->fetch()){
                    $db->query("INSERT IGNORE INTO engine4_core_content (page_id, type, name, parent_content_id, `order`, params) VALUES ({$tcontent['page_id']}, 'widget', 'hequestion.profile-questions', {$tcontent['content_id']}, {$order}, '{\"title\":\"HEQUESTION_PROFILE_QUESTIONS\",\"titleCount\":true}');");
                }
                
            }
        }
    }
    
    /**
     * Privacy
     */
    
    
    
    $db->query("INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'hequestion' as `type`,
    'auth_view' as `name`,
    5 as `value`,
    '[\"owner\", \"owner_member\", \"owner_network\", \"everyone\"]' as `params`
  FROM `engine4_authorization_levels` WHERE `type` NOT IN('public');
");
    $db->query("INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'hequestion' as `type`,
    'auth_comment' as `name`,
    5 as `value`,
    '[\"owner\", \"owner_member\", \"owner_network\", \"everyone\"]' as `params`
  FROM `engine4_authorization_levels` WHERE `type` NOT IN('public');
");
    $db->query("
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'hequestion' as `type`,
    'create' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('moderator', 'admin');
");
    $db->query("
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'hequestion' as `type`,
    'edit' as `name`,
    2 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('moderator', 'admin');
");
    $db->query("
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'hequestion' as `type`,
    'delete' as `name`,
    2 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('moderator', 'admin');
");
    $db->query("
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'hequestion' as `type`,
    'view' as `name`,
    2 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('moderator', 'admin');
");
    $db->query("
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'hequestion' as `type`,
    'comment' as `name`,
    2 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('moderator', 'admin');
");
    $db->query("
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'hequestion' as `type`,
    'vote' as `name`,
    2 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('moderator', 'admin');
");
    
    /*
     -- USER
     -- create, edit, delete, view, comment
     */
    $db->query("
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'hequestion' as `type`,
    'create' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user');
");
    $db->query("
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'hequestion' as `type`,
    'edit' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user');
");
    $db->query("
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'hequestion' as `type`,
    'delete' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user');
");
    $db->query("
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'hequestion' as `type`,
    'view' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user');
");
    $db->query("
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'hequestion' as `type`,
    'comment' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user');
");
    $db->query("
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'hequestion' as `type`,
    'vote' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user');
");
    
    /*
     -- PUBLIC
     -- view
     */
    
    $db->query("
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'hequestion' as `type`,
    'view' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('public');
");
  }

}
