<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Survey
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: install.php 2010-07-02 19:52 ermek $
 * @author     Ermek
 */

/**
 * @category   Application_Extensions
 * @package    Survey
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Survey_Installer extends Engine_Package_Installer_Module
{
    public function onPreInstall()
    {
        $this->_addSurveyViewPage();
        $this->_mySurveyPage();
        $this->_addSurveyCreatePage();
        parent::onPreInstall();

        $db = $this->getDb();
        $db->query("CREATE TABLE IF NOT EXISTS `engine4_survey_answers` (
  `answer_id` int(11) NOT NULL auto_increment,
  `question_id` int(11) NOT NULL,
  `result_id` int(11) NOT NULL,
  `label` text NOT NULL,
  PRIMARY KEY  (`answer_id`),
  KEY `question_id` (`question_id`),
  KEY `result_id` (`result_id`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
        
        $db->query("CREATE TABLE IF NOT EXISTS `engine4_survey_categories` (
  `category_id` int(11) NOT NULL auto_increment,
  `category_name` varchar(255) NOT NULL,
  PRIMARY KEY  (`category_id`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
        
        $db->query("CREATE TABLE IF NOT EXISTS `engine4_survey_takes` (
  `take_id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `survey_id` int(11) NOT NULL,
  `result_id` int(11) NOT NULL,
  `answers` text NOT NULL,
  `took_date` datetime NOT NULL,
  PRIMARY KEY  (`take_id`),
  KEY `user_id` (`user_id`),
  KEY `survey_id` (`survey_id`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
        
        $db->query("CREATE TABLE IF NOT EXISTS `engine4_survey_questions` (
  `question_id` int(11) NOT NULL auto_increment,
  `survey_id` int(11) NOT NULL,
  `text` text NOT NULL,
  `photo_id` int(11) default NULL,
  PRIMARY KEY  (`question_id`),
  KEY `survey_id` (`survey_id`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
        
        $db->query("CREATE TABLE IF NOT EXISTS `engine4_survey_surveys` (
  `survey_id` int(11) NOT NULL auto_increment,
  `category_id` int(11) NOT NULL default '0',
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL default '',
  `description` text,
  `photo_id` int(11) default NULL,
  `published` tinyint(1) NOT NULL default '0',
  `approved` tinyint(1) NOT NULL default '1',
  `creation_date` datetime NOT NULL,
  `modified_date` datetime default NULL,
  `comment_count` int(11) NOT NULL default '0',
  `view_count` int(11) NOT NULL default '0',
  `take_count` int(11) NOT NULL default '0',
  PRIMARY KEY  (`survey_id`),
  KEY `user_id` (`user_id`),
  KEY `category_id` (`category_id`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
        
        $db->query("CREATE TABLE IF NOT EXISTS `engine4_survey_results` (
  `result_id` int(11) NOT NULL auto_increment,
  `survey_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL default '',
  `description` text,
  `photo_id` int(11) default NULL,
  PRIMARY KEY  (`result_id`),
  KEY `survey_id` (`survey_id`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
        
        
        $db->query("CREATE TABLE IF NOT EXISTS `engine4_survey_choices` (
  `choice_id` int(11) NOT NULL auto_increment,
  `survey_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `answer_id` int(11) NOT NULL,
  PRIMARY KEY  (`choice_id`),
  KEY `survey_id` (`survey_id`,`user_id`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
        
        
  $db->query("INSERT IGNORE INTO `engine4_survey_categories` (`category_id`, `category_name`) VALUES
  (1, 'Arts & Culture'),
  (2, 'Business'),
  (3, 'Entertainment'),
  (5, 'Family & Home'),
  (6, 'Health'),
  (7, 'Recreation'),
  (8, 'Personal'),
  (9, 'Shopping'),
  (10, 'Society'),
  (11, 'Sports'),
  (12, 'Technology'),
  (13, 'Other');");
        
        $db->query("INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `order`) VALUES
  ('core_main_survey', 'survey', 'Surveys', '', '{\"route\":\"survey_browse\"}', 'core_main', '', 4),
  ('core_sitemap_survey', 'survey', 'Surveys', '', '{\"route\":\"survey_browse\"}', 'core_sitemap', '', 4),
  ('core_main_survey', 'survey', 'Surveys', '', '{\"route\":\"default\",\"module\":\"survey\"}', 'core_main', '', 3),
  ('core_admin_main_plugins_survey', 'survey', 'HE - Surveys', '', '{\"route\":\"admin_default\",\"module\":\"survey\",\"controller\":\"settings\"}', 'core_admin_main_plugins', '', 888),
  ('survey_admin_main_surveyzes', 'survey', 'View Surveys', '', '{\"route\":\"admin_default\",\"module\":\"survey\",\"controller\":\"surveyzes\"}', 'survey_admin_main', '', 1),
  ('survey_admin_main_settings', 'survey', 'Survey Settings', '', '{\"route\":\"admin_default\",\"module\":\"survey\",\"controller\":\"settings\"}', 'survey_admin_main', '', 2),
  ('survey_admin_main_level', 'survey', 'Survey Level Settings', '', '{\"route\":\"admin_default\",\"module\":\"survey\",\"controller\":\"level\"}', 'survey_admin_main', '', 3),
  ('survey_admin_main_categories', 'survey', 'Categories', '', '{\"route\":\"admin_default\",\"module\":\"survey\",\"controller\":\"categories\"}', 'survey_admin_main', '', 4);");
        
  $db->query("INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES
('survey_main_index', 'survey', 'Browse Survey', NULL, '{\"route\":\"survey_browse\",\"module\":\"survey\",\"controller\":\"index\"}', 'survey_main', NULL, 1, 0, 1),
('survey_main_manage', 'survey', 'My Surveys', NULL, '{\"route\":\"survey_manage\",\"module\":\"survey\",\"action\":\"manage\"}', 'survey_main', NULL, 1, 0, 999),
('survey_main_create', 'survey', 'Create new survey', NULL, '{\"route\":\"survey_create\",\"module\":\"survey\",\"action\":\"create\"}', 'survey_main', NULL, 1, 0, 999);");


  $db->query("INSERT IGNORE INTO `engine4_activity_actiontypes` (`type`, `module`, `body`, `enabled`, `displayable`, `attachable`, `commentable`, `shareable`, `is_generated`) VALUES
  ('survey_new', 'survey', '{item:$subject} created a new survey:', 1, 5, 1, 3, 1, 1),
  ('survey_take', 'survey', '{item:$subject} took a survey: {item:$object:survey}', 1, 1, 1, 1, 0, 0),
  ('comment_survey', 'survey', '{item:$subject} commented on {item:$owner}''s {item:$object:survey}', 1, 1, 1, 1, 1, 0);");
        
        $db->query("INSERT IGNORE INTO `engine4_authorization_permissions` (`level_id`, `type`, `name`, `value`, `params`) VALUES
  (1, 'survey', 'create', 1, NULL),
  (1, 'survey', 'edit', 1, NULL),
  (1, 'survey', 'delete', 1, NULL),
  (1, 'survey', 'view', 1, NULL),
  (1, 'survey', 'comment', 1, NULL),
  (1, 'survey', 'take', 1, NULL),
  (1, 'survey', 'auth_comment', 5, '[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),
  (1, 'survey', 'auth_html', 3, 'strong, b, em, i, u, strike, sub, sup, p, div, pre, address, h1, h2, h3, h4, h5, h6, span, ol, li, ul, a, img, embed, br, hr'),
  (1, 'survey', 'auth_view', 5, '[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),
            
  (2, 'survey', 'create', 1, NULL),
  (2, 'survey', 'edit', 1, NULL),
  (2, 'survey', 'delete', 1, NULL),
  (2, 'survey', 'view', 1, NULL),
  (2, 'survey', 'comment', 1, NULL),
  (2, 'survey', 'take', 1, NULL),
  (2, 'survey', 'auth_comment', 5, '[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),
  (2, 'survey', 'auth_html', 3, 'strong, b, em, i, u, strike, sub, sup, p, div, pre, address, h1, h2, h3, h4, h5, h6, span, ol, li, ul, a, img, embed, br, hr'),
  (2, 'survey', 'auth_view', 5, '[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),
            
  (3, 'survey', 'create', 1, NULL),
  (3, 'survey', 'edit', 1, NULL),
  (3, 'survey', 'delete', 1, NULL),
  (3, 'survey', 'view', 1, NULL),
  (3, 'survey', 'comment', 1, NULL),
  (3, 'survey', 'take', 1, NULL),
  (3, 'survey', 'auth_comment', 5, '[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),
  (3, 'survey', 'auth_html', 3, 'strong, b, em, i, u, strike, sub, sup, p, div, pre, address, h1, h2, h3, h4, h5, h6, span, ol, li, ul, a, img, embed, br, hr'),
  (3, 'survey', 'auth_view', 5, '[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),
            
  (4, 'survey', 'create', 1, NULL),
  (4, 'survey', 'delete', 1, NULL),
  (4, 'survey', 'view', 1, NULL),
  (4, 'survey', 'comment', 1, NULL),
  (4, 'survey', 'take', 1, NULL),
  (4, 'survey', 'auth_comment', 5, '[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),
  (4, 'survey', 'auth_html', 3, 'strong, b, em, i, u, strike, sub, sup, p, div, pre, address, h1, h2, h3, h4, h5, h6, span, ol, li, ul, a, img, embed, br, hr'),
  (4, 'survey', 'auth_view', 5, '[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),
            
  (5, 'survey', 'view', 1, NULL),
  (5, 'survey', 'auth_comment', 5, '[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),
  (5, 'survey', 'auth_html', 3, 'strong, b, em, i, u, strike, sub, sup, p, div, pre, address, h1, h2, h3, h4, h5, h6, span, ol, li, ul, a, img, embed, br, hr'),
  (5, 'survey', 'auth_view', 5, '[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]');");
    
    }
  protected function _addSurveyViewPage()
    {
        $db     = $this->getDb();
        $select = new Zend_Db_Select($db);

        // Check if it's already been placed
        $select = new Zend_Db_Select($db);
        $select
            ->from('engine4_core_pages')
            ->where('name = ?', 'survey_index_index')
            ->limit(1);
        ;
        $info = $select->query()->fetch();

        if( empty($info) ) {
            $db->insert('engine4_core_pages', array(
                'name' => 'survey_index_index',
                'displayname' => 'Survey Browse page',
                'title' => 'Survey Browse page',
                'description' => 'This is the view page for a survey.',
                'custom' => 0,
            ));
            $pageId = $db->lastInsertId('engine4_core_pages');

            // Insert top
            $db->insert('engine4_core_content', array(
                'type' => 'container',
                'name' => 'top',
                'page_id' => $pageId,
                'order' => 1,
            ));
            $topId = $db->lastInsertId();

            // Insert main
            $db->insert('engine4_core_content', array(
                'type' => 'container',
                'name' => 'main',
                'page_id' => $pageId,
                'order' => 2,
            ));
            $mainId = $db->lastInsertId();

            // Insert top-middle
            $db->insert('engine4_core_content', array(
                'type' => 'container',
                'name' => 'middle',
                'page_id' => $pageId,
                'parent_content_id' => $topId,
            ));
            $topMiddleId = $db->lastInsertId();

            // Insert main-middle
            $db->insert('engine4_core_content', array(
                'type' => 'container',
                'name' => 'middle',
                'page_id' => $pageId,
                'parent_content_id' => $mainId,
                'order' => 2,
            ));
            $mainMiddleId = $db->lastInsertId();

            // Insert main-right
            $db->insert('engine4_core_content', array(
                'type' => 'container',
                'name' => 'right',
                'page_id' => $pageId,
                'parent_content_id' => $mainId,
                'order' => 1,
            ));
            $mainRightId = $db->lastInsertId();


            // Insert menu
            $db->insert('engine4_core_content', array(
                'type' => 'widget',
                'name' => 'survey.browse-menu',
                'page_id' => $pageId,
                'parent_content_id' => $topMiddleId,
                'order' => 1,
            ));

            // Insert content
            $db->insert('engine4_core_content', array(
                'type' => 'widget',
                'name' => 'core.content',
                'page_id' => $pageId,
                'parent_content_id' => $mainMiddleId,
                'order' => 1,
            ));

            // Insert search
            $db->insert('engine4_core_content', array(
                'type' => 'widget',
                'name' => 'survey.most-recent',
                'page_id' => $pageId,
                'parent_content_id' => $mainRightId,
                'order' => 1,
            ));

            // Insert gutter menu
            $db->insert('engine4_core_content', array(
                'type' => 'widget',
                'name' => 'survey.most-popular',
                'page_id' => $pageId,
                'parent_content_id' => $mainRightId,
                'order' => 2,
            ));
        }
    }
  protected function _mySurveyPage()
    {
        $db     = $this->getDb();
        $select = new Zend_Db_Select($db);

        // Check if it's already been placed
        $select = new Zend_Db_Select($db);
        $select
            ->from('engine4_core_pages')
            ->where('name = ?', 'survey_index_manage')
            ->limit(1);
        ;
        $info = $select->query()->fetch();

        if( empty($info) ) {
            $db->insert('engine4_core_pages', array(
                'name' => 'survey_index_manage',
                'displayname' => 'Survey Manage page',
                'title' => 'Survey Manage page',
                'description' => 'This is the view page for a survey.',
                'custom' => 0,
            ));
            $pageId = $db->lastInsertId('engine4_core_pages');

            // Insert top
            $db->insert('engine4_core_content', array(
                'type' => 'container',
                'name' => 'top',
                'page_id' => $pageId,
                'order' => 1,
            ));
            $topId = $db->lastInsertId();

            // Insert main
            $db->insert('engine4_core_content', array(
                'type' => 'container',
                'name' => 'main',
                'page_id' => $pageId,
                'order' => 2,
            ));
            $mainId = $db->lastInsertId();

            // Insert top-middle
            $db->insert('engine4_core_content', array(
                'type' => 'container',
                'name' => 'middle',
                'page_id' => $pageId,
                'parent_content_id' => $topId,
            ));
            $topMiddleId = $db->lastInsertId();

            // Insert main-middle
            $db->insert('engine4_core_content', array(
                'type' => 'container',
                'name' => 'middle',
                'page_id' => $pageId,
                'parent_content_id' => $mainId,
                'order' => 2,
            ));
            $mainMiddleId = $db->lastInsertId();

            // Insert main-right
            $db->insert('engine4_core_content', array(
                'type' => 'container',
                'name' => 'right',
                'page_id' => $pageId,
                'parent_content_id' => $mainId,
                'order' => 1,
            ));
            $mainRightId = $db->lastInsertId();


            // Insert menu
            $db->insert('engine4_core_content', array(
                'type' => 'widget',
                'name' => 'survey.browse-menu',
                'page_id' => $pageId,
                'parent_content_id' => $topMiddleId,
                'order' => 1,
            ));

            // Insert content
            $db->insert('engine4_core_content', array(
                'type' => 'widget',
                'name' => 'core.content',
                'page_id' => $pageId,
                'parent_content_id' => $mainMiddleId,
                'order' => 1,
            ));

            // Insert search
            $db->insert('engine4_core_content', array(
                'type' => 'widget',
                'name' => 'survey.search',
                'page_id' => $pageId,
                'parent_content_id' => $mainRightId,
                'order' => 1,
            ));

        }
    }
 protected function _addSurveyCreatePage()
  {
    $db = $this->getDb();

    // profile page
    $pageId = $db->select()
      ->from('engine4_core_pages', 'page_id')
      ->where('name = ?', 'survey_index_create')
      ->limit(1)
      ->query()
      ->fetchColumn();

    if( !$pageId ) {

      // Insert page
      $db->insert('engine4_core_pages', array(
        'name' => 'survey_index_create',
        'displayname' => 'Survey Create Page',
        'title' => 'Survey Create',
        'description' => 'This page is the Survey create page.',
        'custom' => 0,
      ));
      $pageId = $db->lastInsertId();

      // Insert top
      $db->insert('engine4_core_content', array(
        'type' => 'container',
        'name' => 'top',
        'page_id' => $pageId,
        'order' => 1,
      ));
      $topId = $db->lastInsertId();

      // Insert main
      $db->insert('engine4_core_content', array(
        'type' => 'container',
        'name' => 'main',
        'page_id' => $pageId,
        'order' => 2,
      ));
      $mainId = $db->lastInsertId();

      // Insert top-middle
      $db->insert('engine4_core_content', array(
        'type' => 'container',
        'name' => 'middle',
        'page_id' => $pageId,
        'parent_content_id' => $topId,
      ));
      $topMiddleId = $db->lastInsertId();

      // Insert main-middle
      $db->insert('engine4_core_content', array(
        'type' => 'container',
        'name' => 'middle',
        'page_id' => $pageId,
        'parent_content_id' => $mainId,
        'order' => 2,
      ));
      $mainMiddleId = $db->lastInsertId();


      // Insert menu
      $db->insert('engine4_core_content', array(
        'type' => 'widget',
        'name' => 'survey.browse-menu',
        'page_id' => $pageId,
        'parent_content_id' => $topMiddleId,
        'order' => 1,
      ));

      // Insert content
      $db->insert('engine4_core_content', array(
        'type' => 'widget',
        'name' => 'core.content',
        'page_id' => $pageId,
        'parent_content_id' => $mainMiddleId,
        'order' => 1,
      ));
    }
  }
}