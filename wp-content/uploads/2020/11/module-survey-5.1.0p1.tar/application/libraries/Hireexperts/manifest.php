<?php return array(
  'package' => array(
    'type' => 'library',
    'name' => 'hireexperts',
    'version' => '4.0.0',
    'revision' => '$Revision: 1568 $',
    'path' => 'application/libraries/Hireexperts',
    'repository' => 'socialengine.com',
    'title' => 'Hire-Experts Lib',
    'author' => 'Hire-Experts Team',
    'directories' => array(
      'application/libraries/Hireexperts/externals',
      'application/libraries/Hireexperts/moules',
      'application/libraries/Hireexperts/views',
      'application/libraries/Hireexperts/Api.php'
    )
  )
) ?>
