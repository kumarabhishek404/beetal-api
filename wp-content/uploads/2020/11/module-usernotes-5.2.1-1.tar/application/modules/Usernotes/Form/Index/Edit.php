<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Usernotes
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: Create.php 2010-07-30 18:00 vadim $
 * @author     Vadim
 */

/**
 * @category   Application_Extensions
 * @package    Usernotes
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Usernotes_Form_Index_Edit extends Engine_Form
{
  public function init()
  {
    $this
      ->setTitle('Update your user note')
      //->setDescription('Save your note about this user below:')
      ->setAttrib('id', 'user-notes')
      ->setMethod('post');

    $this->addElement('Textarea', 'note', array(
      'label' => 'Note',
      'filters' => array('StripTags'),
    ));

    $this->addElement('Button', 'submit', array(
            'label' => 'Save',
            'type' => 'submit',
            'ignore' => true
        )); 
  }
}