<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Usernotes
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: install.php 2010-07-30 18:00 ermek $
 * @author     Ermek
 */

/**
 * @category   Application_Extensions
 * @package    Usernotes
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Usernotes_Installer extends Engine_Package_Installer_Module
{
  public function onPreInstall()
  {
    $this->_myNotesPage();
    parent::onPreInstall();

    $db = $this->getDb();
    
    $db->query("CREATE TABLE IF NOT EXISTS `engine4_usernotes_usernote` (
    `usernote_id` int(11) NOT NULL auto_increment,
    `owner_id` int(11) NOT NULL,
    `user_id` int(11) NOT NULL,
    `note` text NOT NULL,
    `creation_date` datetime NOT NULL,
    `last_update` datetime NOT NULL,
    PRIMARY KEY  (`usernote_id`),
    KEY `owner` (`owner_id`, `user_id`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_unicode_ci;");
    
    $db->query("INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `order`) VALUES
  ('core_main_usernotes', 'usernotes', 'User Notes', 'Usernotes_Plugin_Menus', '{\"route\":\"default\",\"module\":\"usernotes\"}', 'core_main', '', 10),
        
  ('core_admin_main_plugins_usernotes', 'usernotes', 'HE - Usernotes', '', '{\"route\":\"admin_default\",\"module\":\"usernotes\",\"controller\":\"manage\"}', 'core_admin_main_plugins', '', 888),
        
  ('usernotes_admin_main_manage', 'usernotes', 'Admin Usernotes', '', '{\"route\":\"admin_default\",\"module\":\"usernotes\",\"controller\":\"manage\"}', 'usernotes_admin_main', '', 1),
  ('usernotes_admin_main_level', 'usernotes', 'Member Level Settings', '', '{\"route\":\"admin_default\",\"module\":\"usernotes\",\"controller\":\"level\"}', 'usernotes_admin_main', '', 2)
  ");
    
    $db->query("INSERT IGNORE INTO `engine4_authorization_permissions` (`level_id`, `type`, `name`, `value`, `params`) VALUES
  (1, 'usernotes', 'enabled', 1, NULL),
  (2, 'usernotes', 'enabled', 1, NULL),
  (3, 'usernotes', 'enabled', 1, NULL),
  (4, 'usernotes', 'enabled', 1, NULL),
  (5, 'usernotes', 'enabled', 0, NULL)");
    
    $db->query("DELETE FROM `engine4_core_content` WHERE `name` = 'usernotes.profile-usernotes'");
    
    $db->query("INSERT INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`) VALUES (5,'widget','usernotes.profile-usernotes',510,7,'{\"title\":\"User Notes\",\"titleCount\":\"true\"}');");
    }
public function _myNotesPage(){
      $db = $this->getDb();

    // profile page
    $pageId = $db->select()
      ->from('engine4_core_pages', 'page_id')
      ->where('name = ?', 'usernotes_index_index')
      ->limit(1)
      ->query()
      ->fetchColumn();

    if( !$pageId ) {

      // Insert page
      $db->insert('engine4_core_pages', array(
        'name' => 'usernotes_index_index',
        'displayname' => 'Usernotes listing page',
        'title' => 'Usernotes listing page',
        'description' => 'This page is the to display all usernotes listing.',
        'custom' => 0,
      ));
      $pageId = $db->lastInsertId();

      // Insert top
      $db->insert('engine4_core_content', array(
        'type' => 'container',
        'name' => 'top',
        'page_id' => $pageId,
        'order' => 1,
      ));
      $topId = $db->lastInsertId();

      // Insert main
      $db->insert('engine4_core_content', array(
        'type' => 'container',
        'name' => 'main',
        'page_id' => $pageId,
        'order' => 2,
      ));
      $mainId = $db->lastInsertId();

      // Insert top-middle
      $db->insert('engine4_core_content', array(
        'type' => 'container',
        'name' => 'middle',
        'page_id' => $pageId,
        'parent_content_id' => $topId,
      ));
      $topMiddleId = $db->lastInsertId();

      // Insert main-middle
      $db->insert('engine4_core_content', array(
        'type' => 'container',
        'name' => 'middle',
        'page_id' => $pageId,
        'parent_content_id' => $mainId,
        'order' => 2,
      ));
      $mainMiddleId = $db->lastInsertId();


      // Insert menu
      $db->insert('engine4_core_content', array(
        'type' => 'widget',
        'name' => 'user.browse-menu',
        'page_id' => $pageId,
        'parent_content_id' => $topMiddleId,
        'order' => 1,
      ));

      // Insert content
      $db->insert('engine4_core_content', array(
        'type' => 'widget',
        'name' => 'core.content',
        'page_id' => $pageId,
        'parent_content_id' => $mainMiddleId,
        'order' => 1,
      ));
    }
}
}