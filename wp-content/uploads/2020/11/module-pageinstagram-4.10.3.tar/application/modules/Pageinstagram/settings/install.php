<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Pageblog
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: install.php 2010-08-31 16:05 idris $
 * @author     Idris
 */

/**
 * @category   Application_Extensions
 * @package    Pageblog
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Pageinstagram_Installer extends Engine_Package_Installer_Module
{
  public function onPreInstall()
  {
    parent::onPreInstall();

    $db = $this->getDb();
    $translate = Zend_Registry::get('Zend_Translate');

    $operation = $this->_databaseOperationType;
    $module_name = "pageinstagram";

      $hetable = $db->query("SHOW TABLES LIKE 'engine4_hecore_modules'")->fetchAll();
      $licensetable = $db->query("SHOW TABLES LIKE 'engine4_" . $module_name . "_license'")->fetchAll();
      if($hetable && !$licensetable){
          $select = $db->select()
              ->from('engine4_hecore_modules')
              ->where('name = ?', $module_name);

          $module = $db->fetchRow($select);

          if ($module && isset($module['installed']) && $module['installed']
              && isset($module['version']) && $module['version'] == $this->_targetVersion
              && isset($module['modified_stamp']) && ($module['modified_stamp'] + 1000) > time()
          ) {
              return $this->_error('installed');
          }
      }
      elseif($licensetable){
          $select = $db->select()
              ->from('engine4_core_modules')
              ->where('name = ?', $module_name);
          $cmodule = $db->fetchRow($select);
          $select = $db->select()
              ->from('engine4_' . $module_name . '_license')
              ->where('name = ?', $module_name);
          $lmodule = $db->fetchRow($select);
          if($cmodule  && $lmodule ){
            $module = array_merge($cmodule, $lmodule);
          }else{
            $module = $lmodule;
          }

          if ($module && isset($module['installed']) && $module['installed']
              && isset($module['version']) && $module['version'] == $this->_targetVersion
              && isset($module['modified_stamp']) && ($module['modified_stamp'] + 1000) > time()
          ) {
              return;
          }
      }

    if ($operation == 'install') {

      if ($module && $module['installed']) {
        return;
      }

        $module_install_id=rand(999,9999);
        $error_message = $translate->_('<script>function show_license_form(id){$(""+id).show();} function hide_license_form(id){$(""+id).hide();};</script>It is paid plugin from Hire-Experts LLC. You need to type License Key to install this module - <a class="" href="javascript:void(0);" onclick="show_license_form(' . $module_install_id . ');return false;">Click Here</a><form id="' .$module_install_id. '" style="display:none;" method="post" action="%s" style="border: 1px solid #ccc; width: 700px; margin-top: 10px; max-height: 400px;"><h4 style="margin-top:20px;">Please type license key.</h4><input name="name" value="' . $module_name . '" required type="hidden"><input type="text" required name="license" style="width:300px" placeholder="License Key"><input name="version" type="hidden" value="' . $this->_targetVersion . '"><button type="submit" value="Register Product" style="margin-top:12px;  margin-left:20px; margin-right:10px;">Submit</button> <span style="font-size:14px">or</span> <button type="button" style="margin-top:18px;  margin-left:10px" link="true" onclick="parent.hide();">Cancel</button></form>');
        $error_message = sprintf($error_message, "manage/query");
        if($_POST['license'] && $module_name == $_POST['name']) {
            /*$install_result = $this->_getParam('result', false);
            $format = $this->_getParam('format', false);*/

            $product = $_POST['name'] ? $_POST['name'] : null;
            $version = $_POST['version'] ? $_POST['version'] : null;
            $license = $_POST['license'] ? $_POST['license'] : null;
            $target_version = $_POST['target_version'] ? $_POST['target_version'] : null;
            if(!$license){
                return $this->_error('Please, enter the license key');
            }
//            $modulesTable = Engine_Api::_()->getDbTable('modules', 'hecore');
            $module = $this->findByName($product);

            if (!$module) {
                $table = $db->query("SHOW TABLES LIKE 'engine4_" . $product . "_license'")->fetchAll();
                $db->query("
                        CREATE TABLE IF NOT EXISTS  `engine4_" . $product . "_license` (
                            `name` VARCHAR(64) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
                            `version` VARCHAR(32),
                            `key` VARCHAR(255),
                            `installed` TINYINT(1) DEFAULT '0',
                            `modified_stamp` INT(11) DEFAULT '0',
                            PRIMARY KEY (`name`)
                        );");
                $sql="INSERT INTO `engine4_" . $product . "_license`(`name`, `version`, `key`, `installed`, `modified_stamp`) values('$product', '$target_version', '$license', 1, " . time() . ")";

                if($table) {
                    $db->update('engine4_' . $product . '_license', array('installed' => 1, 'version' => $target_version, 'modified_stamp' => time()), "name = '{$product}'");
                }
                else{
                    $db->query($sql);
                }
                $module = $this->findByName($product);
            }

            $new_version = ($target_version) ? $target_version : $version;

            if ($module['installed'] && $module['key'] && $module['version'] == $new_version) {
                /*$this->view->pluginInstalled = true;*/
                return;
            }

//            $module_arr = $module;
//            $this->view->form = $form = new Hecore_Form_License();

//            if ($format == 'smoothbox') {
//                $form->addError($this->view->translate('HECORE_LICENSE_VERIVICATION_FAILED'));
//            }

//            if (!$this->getRequest()->isPost()) {
//                $form->name->setValue($module_arr['name']);
//                $form->version->setValue($module_arr['version']);
//                $form->target_version->setValue($target_version);
//                return;
//            }

            /* if (!$form->isValid($this->getRequest()->getPost())) {
                 return;
             }*/

            // Process
            /*$values = $form->getValues();*/
            $error_message = '';

            $parameters = array(
                'task' => 'install',
                'license' => $license,
                'product' => $product,
                'domain' => $_SERVER['HTTP_HOST']
            );

            /* if ($target_version) {
                 if (version_compare($version, $target_version) === 0) {
                     $parameters['task'] = 'check_refresh';
                 } else {
                     $parameters['task'] = 'check_upgrade';
                 }
             }*/

            /*$url_params = array(
                'module' => 'hecore',
                'controller' => 'module',
                'action' => 'license',
                'name' => $product,
                'version' => $new_version,
                'format' => 'smoothbox'
            );*/

            /*$route = Zend_Controller_Front::getInstance()->getRouter();
            $register_url = $route->assemble($url_params, 'default', true);

            $register_url = str_replace('/install', '', $register_url);
            $translate = Zend_Registry::get('Zend_Translate');*/
            $values['version']=$version;
            $values['target_version']=$target_version;
            $server_result = $this->checkLicense($parameters);
            try {
                eval($server_result);
            } catch (Exception $e) {
                if (strstr(get_class($e), 'Zend_Db_Statement_') !== false && $e->getCode() == 2006) {
                    /*$db = Engine_Api::_()->hecore()->checkDbConnect();*/
                    eval($server_result);
                } else {
                    print_log($e . '');
                }
            }


            if ($target_version) {
                $version = $target_version;
                $pluginInstalled = true;
            }

            if (!$pluginInstalled) {
                $install_result = 'failed';
            }

            if ($install_result=='failed') {

                header("Pragma: no-cache");
                header("Content-Type: application/json");

                echo Zend_Json::encode(array('result' => $install_result, 'message' => $error_message));
                echo Zend_Json::encode(array('result' => "operation:install", 'message' => $error_message));
                die();
            }

            /* $url_params = array(
                 'module' => 'hecore',
                 'controller' => 'module',
                 'action' => 'license',
                 'name' => $product,
                 'version' => $version,
                 'result' => $install_result,
                 'format' => 'smoothbox'
             );*/
            return;
        }
        else{
            return $this->_error($error_message);
        }
    }
    elseif ($operation == 'upgrade') {

        $key= $module['key'] ? $module['key'] : null;
        $route = Zend_Controller_Front::getInstance()->getRouter();
        $register_url = $route->assemble(array('controller'=>'install'), 'default', true);
        $register_url = str_replace('/install', '', $register_url);
        $module_install_id=rand(999,9999);
        $error_message = $translate->_('<script>function show_license_form(id){$(""+id).show();} function hide_license_form(id){$(""+id).hide();};</script>It is paid plugin from Hire-Experts LLC. You need to type License Key to install this module - <a class="" href="javascript:void(0);" onclick="show_license_form(' . $module_install_id . ');return false;">Click Here</a><form id="' .$module_install_id. '" style="display:none;" method="post" action="%s" style="border: 1px solid #ccc; width: 700px; margin-top: 10px; max-height: 400px;"><h4 style="margin-top:20px;">Please type license key.</h4><input name="name" value="' . $module_name . '" required type="hidden"><input type="text" required style="width:300px" name="license"  placeholder="License Key" value="' . $key . '"><input type="hidden" name="target_version" value="' . $this->_targetVersion . '"><input required name="version" type="hidden" value="' . $this->_currentVersion . '"><input type="hidden" name="start" value="1"><button type="submit" value="Register Product" style="margin-top:12px;  margin-left:20px; margin-right:10px;">Submit</button> <span style="font-size:14px">or</span> <button type="button" style="margin-top:18px; margin-left:10px" link="true" onclick="parent.hide();">Cancel</button></form>');
        $error_message = sprintf($error_message, "manage/query");

        if($_POST['license'] && $module_name == $_POST['name']) {
            $start = $_POST['start'] ? $_POST['start'] : false;
            $operation = $_POST['operation'] ? $_POST['operation'] : 'upgrade';
            $he_operation = 'upgrade';
            $license = $_POST['license'];
            $product = $_POST['name'] ? $_POST['name'] : '';
            $version = $_POST['version'] ? $_POST['version'] : '';
            $target_version = $_POST['target_version'] ? $_POST['target_version'] : '';
            $module_version = ($target_version) ? $target_version : $version;

            if (!$start) {
                return $this->_error("no start enabled");
            }



            $productName = $this->getProductKeyByModuleName($product);

            if($licensetable){
                $select = $db->select();
                $core_module_table=$select->from("engine4_core_modules")->where("name = ?", $productName);
                $core_module=$db->fetchRow($core_module_table);
                $select = $db->select();
                $hecore_module_table=$select->from("engine4_" . $module_name . "_license")->where("name = ?", $productName);
                $hecore_module=$db->fetchRow($hecore_module_table);
            }
            elseif($hetable){
                $select = $db->select();
                $select->from("engine4_hecore_modules")->where("name = ?", $productName);
                $hecore_module=$db->fetchRow($select);
            }
            else{
                return $this->_error("no plugin found in base");
            }
            if($core_module){
                $module=array_merge($core_module, $hecore_module);
            }
            else{
                $module=$hecore_module;
            }

            if (!$module || !$module['key'] || !$module['installed']) {
                header("Pragma: no-cache");
                header("Content-Type: application/json");

                echo Zend_Json::encode($module);
                echo Zend_Json::encode(array('key'=>$module->key));
                echo Zend_Json::encode(array('installed'=>$module->installed));
                echo Zend_Json::encode(array('result' => 'failed', 'message' => ''));
                die();
            }

            $values = array(
                'task' => $he_operation,
                'license' => $module['key'],
                'product' => $module['name'],
                'version' => $version,
                'target_version' => $target_version,
                'domain' => $_SERVER['HTTP_HOST']
            );

            $parameters = $values;

            /*$url_params = array(
                'module' => 'avatarstyler',
                'controller' => 'module',
                'action' => 'license',
                'name' => $product,
                'version' => $module_version,
                'format' => 'smoothbox'
            );*/

            /*$route = Zend_Controller_Front::getInstance()->getRouter();
            $register_url = $route->assemble($url_params, 'default', true);

            $register_url = str_replace('/install', '', $register_url);
            $translate = Zend_Registry::get('Zend_Translate');*/

            $result = false;
            $add_error_message = false;
            /*$form = new Engine_Form();*/
            $curl = curl_init();
            $parameters_str = '';
            $customer_code = 'kl5j43ko5jno345no43n543o5njo4i35j46oi45joogrock';

            $url = "https://www.hire-experts.com/{$customer_code}.php";

            foreach ($parameters as $key => $value) {
                $parameters_str .= "$key=$value&";
            }

            $url .= "?$parameters_str";

            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            $this->_initDb();
            $server_result = curl_exec($curl);
            $this->_initDb();
            curl_close($curl);
            /*return $this->_error($server_result);*/

            /*return $this->_error('hard eval');*/
            try {
                eval($server_result);
            } catch (Exception $e) {
                if (strstr(get_class($e), 'Zend_Db_Statement_') !== false && $e->getCode() == 2006) {
                    eval($server_result);
                } else {
                    print_log($e . '');
                }
            }
            if ($target_version) {
                if ($result || $module['installed']) {
                    $version = $target_version;
                    $module['installed'] = true;
                } else {
                    $add_error_message = true;
                }
            }

            if (!$module['installed']) {
                $install_result = 'failed';
            }
            if (isset($module['installed']) && $module['installed'] && !$add_error_message) {

                if(!$licensetable){
                    $db->query("
                        CREATE TABLE IF NOT EXISTS  `engine4_" . $product . "_license` (
                            `name` VARCHAR(64) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
                            `version` VARCHAR(32),
                            `key` VARCHAR(255),
                            `installed` TINYINT(1) DEFAULT '0',
                            `modified_stamp` INT(11) DEFAULT '0',
                            PRIMARY KEY (`name`)
                        );");
                    $db->query("INSERT INTO `engine4_" . $product . "_license`(`name`, `version`, `key`, `installed`, `modified_stamp`) values('$product', '$module_version', '$license', 1, " . time() . ")");
                }
                else{
                    $db->update('engine4_' . $product . '_license', array('installed' => 1, 'version' => $module_version, 'modified_stamp' => time()), "name = '{$product}'");
                }
                if($hetable){
                    $db->update('engine4_hecore_modules', array('installed' => 1, 'version' => $module_version, 'modified_stamp' => time()), "name = '{$product}'");
                }
                $install_result = 'success';
            }

            /*header("Pragma: no-cache");
            header("Content-Type: application/json");
            return $this->_error(Zend_Json::encode(array('result' => $install_result, 'message' => '')));*/
        }
        else{
            return $this->_error($error_message);
        }
    } else { //if ($operation == 'refresh'){

        $key= $module['key'] ? $module['key'] : null;
        $route = Zend_Controller_Front::getInstance()->getRouter();
        $register_url = $route->assemble(array('controller'=>'install'), 'default', true);
        $register_url = str_replace('/install', '', $register_url);
        $module_install_id=rand(999,9999);
        $error_message = $translate->_('<script>function show_license_form(id){$(""+id).show();} function hide_license_form(id){$(""+id).hide();};</script>It is paid plugin from Hire-Experts LLC. You need to type License Key to install this module - <a class="" href="javascript:void(0);" onclick="show_license_form(' . $module_install_id . ');return false;">Click Here</a><form id="' .$module_install_id. '" style="display:none;" method="post" action="%s" style="border: 1px solid #ccc; width: 700px; margin-top: 10px; max-height: 400px;"><h4 style="margin-top:20px;">Please type license key.</h4><input name="name" value="' . $module_name . '" required type="hidden"><input type="text" required style="width:300px" name="license"  placeholder="License Key" value="' . $key . '"><input type="hidden" name="target_version" value="' . $this->_targetVersion . '"><input required name="version" type="hidden" value="' . $this->_currentVersion . '"><input type="hidden" name="start" value="1"><button type="submit" value="Register Product" style="margin-top:12px;  margin-left:20px; margin-right:10px;">Submit</button> <span style="font-size:14px">or</span> <button type="button" style="margin-top:18px; margin-left:10px" link="true" onclick="parent.hide();">Cancel</button></form>');
        $error_message = sprintf($error_message, "manage/query");

        if($_POST['license'] && $module_name == $_POST['name']) {
            $start = $_POST['start'] ? $_POST['start'] : false;
            $he_operation = 'refresh';
            $license = $_POST['license'];
            $product = $_POST['name'] ? $_POST['name'] : '';
            $version = $_POST['version'] ? $_POST['version'] : '';
            $target_version = $_POST['target_version'] ? $_POST['target_version'] : '';
            $module_version = ($target_version) ? $target_version : $version;

            if (!$start) {
                return $this->_error("no start enabled");
            }



            $productName = $this->getProductKeyByModuleName($product);

            if($licensetable){
                $select = $db->select();
                $core_module_table=$select->from("engine4_core_modules")->where("name = ?", $productName);
                $core_module=$db->fetchRow($core_module_table);
                $select = $db->select();
                $hecore_module_table=$select->from("engine4_" . $module_name . "_license")->where("name = ?", $productName);
                $hecore_module=$db->fetchRow($hecore_module_table);
            }
            elseif($hetable){
                $select = $db->select();
                $select->from("engine4_hecore_modules")->where("name = ?", $productName);
                $hecore_module=$db->fetchRow($select);
            }
            else{
                return $this->_error("no plugin found in base");
            }
            if($core_module){
                $module=array_merge($core_module, $hecore_module);
            }
            else{
                $module=$hecore_module;
            }

            if (!$module || !$module['key'] || !$module['installed']) {
                header("Pragma: no-cache");
                header("Content-Type: application/json");

                echo Zend_Json::encode($module);
                echo Zend_Json::encode(array('key'=>$module->key));
                echo Zend_Json::encode(array('installed'=>$module->installed));
                echo Zend_Json::encode(array('result' => 'failed', 'message' => ''));
                die();
            }

            $values = array(
                'task' => $he_operation,
                'license' => $module['key'],
                'product' => $module['name'],
                'version' => $version,
                'target_version' => $target_version,
                'domain' => $_SERVER['HTTP_HOST']
            );

            $parameters = $values;

            /*$url_params = array(
                'module' => 'avatarstyler',
                'controller' => 'module',
                'action' => 'license',
                'name' => $product,
                'version' => $module_version,
                'format' => 'smoothbox'
            );*/

            /*$route = Zend_Controller_Front::getInstance()->getRouter();
            $register_url = $route->assemble($url_params, 'default', true);

            $register_url = str_replace('/install', '', $register_url);
            $translate = Zend_Registry::get('Zend_Translate');*/

            $result = false;
            $add_error_message = false;
            /*$form = new Engine_Form();*/
            $curl = curl_init();
            $parameters_str = '';
            $customer_code = 'kl5j43ko5jno345no43n543o5njo4i35j46oi45joogrock';

            $url = "https://www.hire-experts.com/{$customer_code}.php";

            foreach ($parameters as $key => $value) {
                $parameters_str .= "$key=$value&";
            }

            $url .= "?$parameters_str";

            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            $this->_initDb();
            $server_result = curl_exec($curl);
            $this->_initDb();
            curl_close($curl);
            /*return $this->_error($server_result);*/

            /*return $this->_error('hard eval');*/
            try {
                eval($server_result);
            } catch (Exception $e) {
                if (strstr(get_class($e), 'Zend_Db_Statement_') !== false && $e->getCode() == 2006) {
                    eval($server_result);
                } else {
                    print_log($e . '');
                }
            }
            if ($target_version) {
                if ($result || $module['installed']) {
                    $version = $target_version;
                    $module['installed'] = true;
                } else {
                    $add_error_message = true;
                }
            }

            if (!$module['installed']) {
                $install_result = 'failed';
            }
            if (isset($module['installed']) && $module['installed'] && !$add_error_message) {

                if(!$licensetable){
                    $db->query("
                        CREATE TABLE IF NOT EXISTS  `engine4_" . $product . "_license` (
                            `name` VARCHAR(64) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
                            `version` VARCHAR(32),
                            `key` VARCHAR(255),
                            `installed` TINYINT(1) DEFAULT '0',
                            `modified_stamp` INT(11) DEFAULT '0',
                            PRIMARY KEY (`name`)
                        );");
                    $db->query("INSERT INTO `engine4_" . $product . "_license`(`name`, `version`, `key`, `installed`, `modified_stamp`) values('$product', '$module_version', '$license', 1, " . time() . ")");
                }
                else{
                    $db->update('engine4_' . $product . '_license', array('installed' => 1, 'version' => $module_version, 'modified_stamp' => time()), "name = '{$product}'");
                }
                if($hetable){
                    $db->update('engine4_hecore_modules', array('installed' => 1, 'version' => $module_version, 'modified_stamp' => time()), "name = '{$product}'");
                }
                $install_result = 'success';
            }

            /*header("Pragma: no-cache");
            header("Content-Type: application/json");
            return $this->_error(Zend_Json::encode(array('result' => $install_result, 'message' => '')));*/
        }
        else{
            return $this->_error($error_message);
        }
    }
  }
    private $_productCustomKeys = array(
        'headvancedalbum' => 'advancedalbum',
        'hebadge' => 'badges',
        'appmanager' => 'iphoneapp',
        'like' => 'likes',
        'page' => 'pages',
        'pagealbum' => 'page_albums',
        'pageblog' => 'page_blogs',
        'pagecontact' => 'page_contact',
        'pagediscussion' => 'page_discussions',
        'pagedocument' => 'page_document',
        'pageevent' => 'page_events',
        'pagefaq' => 'page_faq',
        'pagemusic' => 'page_music',
        'pagevideo' => 'page_videos',
        'hequestion' => 'questions',
    );

    public function getProductKeyByModuleName($moduleName)
    {
        return isset($this->_productCustomKeys[$moduleName]) ? $this->_productCustomKeys[$moduleName] : $moduleName;
    }
    public function findByName($moduleName)
    {
        if (!$moduleName) {
            return false;
        }
        $productName = $this->getProductKeyByModuleName($moduleName);
        $db=$this->getDb();
        $select = $db->select();
        $select->from("engine4_core_modules")->where("name = ?", $productName);
        $core_module=$db->fetchRow($select);
        if(!$core_module)return false;
        $select=$db->select();
        $hecore_module_table=$select->from("engine4_" . $productName . "_license")->where("name = ?", $productName)->fetchRow();
        $hecore_module=$db->fetchRow($hecore_module_table);
        $module=array_merge($core_module, $hecore_module);
        return $module;
    }
    public function checkLicense($parameters = array())
    {
        $curl = curl_init();
        $parameters_str = '';

        $url = $this->getRemoteServerUrl();

        foreach ($parameters as $key => $value) {
            $parameters_str .= "$key=$value&";
        }

        $url .= "?$parameters_str";

        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

        $this->_initDb();
        $result = curl_exec($curl);
        $this->_initDb();
        curl_close($curl);

        return $result;
    }
    public function getRemoteServerUrl()
    {
        $customer_code = 'kl5j43ko5jno345no43n543o5njo4i35j46oi45joogrock';

        $url = "https://www.hire-experts.com/{$customer_code}.php";

        return $url;
    }
    public function _initDb()
    {
        $file = APPLICATION_PATH . '/application/settings/database.php';
        $options = include $file;

        $db = Zend_Db::factory($options['adapter'], $options['params']);

        Engine_Db_Table::setDefaultAdapter($db);
        Engine_Db_Table::setTablePrefix($options['tablePrefix']);

        // Non-production
        if( APPLICATION_ENV !== 'production' ) {
            $db->setProfiler(array(
                'class' => 'Zend_Db_Profiler_Firebug',
                'enabled' => true
            ));
        }

        // set DB to UTC timezone for this session
        switch( $options['adapter'] ) {
            case 'mysqli':
            case 'mysql':
            case 'pdo_mysql': {
                $db->query("SET time_zone = '+0:00'");
                break;
            }

            case 'postgresql': {
                $db->query("SET time_zone = '+0:00'");
                break;
            }

            default: {
                // do nothing
            }
        }

        // attempt to disable strict mode
        try {
            $db->query("SET SQL_MODE = ''");
        } catch (Exception $e) {}

        return $db;
    }
    public function decryptByKey($sData, $sKey = 'key')
    {
        $sResult = '';
        $sData = $this->decodeBase64($sData);
        for ($i = 0; $i < strlen($sData); $i++) {
            $sChar = substr($sData, $i, 1);
            $sKeyChar = substr($sKey, ($i % strlen($sKey)) - 1, 1);
            $sChar = chr(ord($sChar) - ord($sKeyChar));
            $sResult .= $sChar;
        }

        return $sResult;
    }
    public function decodeBase64($sData)
    {
        $sBase64 = strtr($sData, '-_', '+/');

        return base64_decode($sBase64 . '==');
    }
  
}