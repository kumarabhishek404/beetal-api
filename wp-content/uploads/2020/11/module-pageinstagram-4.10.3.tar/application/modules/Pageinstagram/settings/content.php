<?php

return array(
    array(
        'title' => 'Page Instagram random',
        'description' => 'Page Instagram random',
        'category' => 'Page Instagram',
        'type' => 'widget',
        'name' => 'pageinstagram.random-instagram',
        'defaultParams' => array(
            'title' => 'Page Instagram random',
        )
    ),
);