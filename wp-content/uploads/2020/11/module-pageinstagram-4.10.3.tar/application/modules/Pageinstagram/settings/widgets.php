<?php

return     array(
    'title' => 'Instagram',
    'description' => 'Instagram.',
    'category' => 'Tabs',
    'type' => 'widget',
    'name' => 'pageinstagram.profile-instagram',
    'defaultParams' => array(
        'title' => 'Instagram',
        'titleCount' => true
    )
);