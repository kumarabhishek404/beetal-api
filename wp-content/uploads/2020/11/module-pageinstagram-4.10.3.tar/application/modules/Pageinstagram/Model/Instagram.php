<?php

class Pageinstagram_Model_Instagram extends Core_Model_Item_Abstract
{

}
