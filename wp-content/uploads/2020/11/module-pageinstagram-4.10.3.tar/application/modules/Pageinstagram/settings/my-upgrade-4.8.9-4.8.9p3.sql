--
-- Update module Hecore
--

UPDATE `engine4_core_modules` SET `version` = '4.8.9p3'  WHERE `name` = 'pageinstagram';