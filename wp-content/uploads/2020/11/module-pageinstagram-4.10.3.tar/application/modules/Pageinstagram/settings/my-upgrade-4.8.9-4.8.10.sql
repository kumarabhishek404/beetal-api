--
-- Update module Hecore
--

UPDATE `engine4_core_modules` SET `version` = '4.8.10'  WHERE `name` = 'pageinstagram';