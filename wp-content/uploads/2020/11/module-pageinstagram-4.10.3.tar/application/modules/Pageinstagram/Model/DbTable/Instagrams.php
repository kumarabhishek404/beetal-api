<?php

class Pageinstagram_Model_DbTable_Instagrams extends Engine_Db_Table
{
	protected $_rowClass = 'Pageinstagram_Model_Instagram';

}