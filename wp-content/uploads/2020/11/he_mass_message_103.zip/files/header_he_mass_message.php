<?php

defined('SE_PAGE') or exit();

include_once "./header_he_core.php";
include_once "./include/class_he_mass_message.php";

he_mass_message::cron();
?>