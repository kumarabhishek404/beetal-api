<?php

$page = "admin_mass_message_tool";
include_once "admin_header.php";

include_once "./admin_header_he_core.php";
include_once "../include/class_he_mass_message.php";


$task = $_POST['task'] ? $_POST['task'] : $_GET['task'];
$tab = $_POST['tab'] ? $_POST['tab'] : ( $_GET['tab'] ? $_GET['tab'] : 'settings');
$message = array();

//handle requests
if($task == "mass_message")
{
	if( he_mass_message::create_campaign($_POST["subject"], $_POST["message"], $_POST["levels"], $_POST["subnets"], $_POST['cats']) )
		$message['info'] = SE_Language::_get(690690023);
	else
		$message["error"] = SE_Language::_get(690690011);
}

elseif ($task=='save_settings')
{
	if( he_mass_message::update_settings(array('setting_mass_message_from_user'=>$_POST['setting_mass_message_from_user'], 'setting_mass_message_per_minute'=>$_POST['setting_mass_message_per_minute'], 'setting_mass_email_per_minute'=>$_POST['setting_mass_email_per_minute'])) )
	{
		$message['info'] = SE_Language::_get(690690010);
	}
	else
	{
		$message["error"] = SE_Language::_get(690690011);
	}
}

elseif ($task=='get_users')
{
	header("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); // Date in the past
	header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); // always modified
	header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
	header("Pragma: no-cache"); // HTTP/1.0
	header("Content-Type: application/json");
	$result = array( 'results' => he_mass_message::get_users($_GET["username"]) );
	echo json_encode($result);
	exit();
}




$admin_user = new se_user(array($setting['setting_id_by_admin_login']));

$smarty->assign('tab', $tab);
$smarty->assign("message", $message);
$smarty->assign("levels", he_mass_message::get_user_levels());
$smarty->assign("subnets", he_mass_message::get_subnets());
$smarty->assign("cats", he_mass_message::get_profile_categories());
$smarty->assign("campaigns", he_mass_message::get_campaigns());
$smarty->assign_by_ref("admin_login",$admin_user);
$smarty->assign('se_version', intval(str_replace('.', '', $version)));

include "admin_footer.php";
?>