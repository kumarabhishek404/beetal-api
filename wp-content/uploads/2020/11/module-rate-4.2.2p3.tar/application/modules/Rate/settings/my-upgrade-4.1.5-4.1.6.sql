
UPDATE `engine4_core_modules` SET `version` = '4.1.6' WHERE `name` = 'rate';