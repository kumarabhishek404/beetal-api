INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES
('rate', 'Rates', 'Rates', '4.2.2p3', 1, 'extra');