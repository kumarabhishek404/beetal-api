
UPDATE `engine4_core_modules` SET `version` = '4.1.9' WHERE `name` = 'rate';