UPDATE `engine4_core_modules` SET `version` = '4.5.3p2' WHERE `name` = 'pinfeed';
