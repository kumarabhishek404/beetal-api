UPDATE `engine4_core_modules` SET `version` = '4.5.0p3' WHERE `name` = 'pinfeed';
