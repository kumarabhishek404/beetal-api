UPDATE `engine4_core_modules` SET `version` = '4.5.2p3' WHERE `name` = 'pinfeed';
