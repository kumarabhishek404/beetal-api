INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES  ('pinfeed', 'Pinfeed', 'Pinfeed', '4.5.0p1', 1, 'extra') ;
