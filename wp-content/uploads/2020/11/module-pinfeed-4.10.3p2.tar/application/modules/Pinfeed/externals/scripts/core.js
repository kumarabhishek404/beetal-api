function pinfeed(options) {

    if ($('activity-feed')) {
        column_count = Math.floor(($('activity-feed').getComputedSize().width - 20) / 270);
    }
    else {
        column_count = 3;
    }
    if (column_count == 0) column_count = 1;

    if (column_count == 2 && options.w == 1) {

        if ($$('.generic_layout_container.layout_right')[0]) {
            $$('.generic_layout_container.layout_right')[0].setStyle('margin-left', '0px');
        }
    }

    if ($('global_wrapper') && $('global_wrapper').getStyle('width').toInt() > 1000) {
        if ($$('.generic_layout_container.layout_right')[0]) $$('.generic_layout_container.layout_right')[0].setStyle('padding-right', '66px');
    }

    if (options.bottom == 1) {
        if (typeof options.item != 'undefined' && options.item && options.item.length) {
            options.item[0].inject($('pinfeed1'), 'top');
        }
    } else {
        var block_arr = [];

        /* Generate Columns if not exists. */

        // <div class="pinfeed" id="pinfeed3" style="width: 270px; float: left;margin-top: 0; "></div>

        var col_count = column_count;

        if (column_count > 2) {

            col_count = (options.item.length > column_count) ? column_count : options.item.length;

            for (var i = 3; i <= col_count; i++) {

                if (!$("pinfeed" + i)) {
                    var col = new Element('div',
                        {
                            'class': 'pinfeed',
                            'id': 'pinfeed' + i,
                            'style': 'width: 270px; float: left;margin-top: 0;'

                        });

                    col.inject($("pinfeedGenerated"), 'bottom');
                }
            }
        }


        for (var m = 0; m < col_count; m++)
            block_arr[m] = $('pinfeed' + (m + 1));

        if (window.clear_pinfeed_counts == 1) {
            start = 1;
        }

        options.item.sort(function (a, b) {

            var length = a.get('rev').length;
            if (a.get('rev').substr(5, length))
                return parseInt(a.get('rev').substr(5, length)) < parseInt(b.get('rev').substr(5, length));
        });

        for (var k = start; k < options.item.length; k++) {

            var min = array[0], min_col = 0;

            for (var j = 1; j < col_count; j++) {
                if (min > array[j]) {
                    min = array[j];
                    min_col = j;
                }
            }
            options.item[k].inject(block_arr[min_col], 'bottom');
            array[min_col] += parseInt(options.item[k].getComputedSize().height) + 30;
        }

        start = options.item.length;
    }

    $$('.wall-items-pinfeed').addEvents({
        'mouseout': function () {
            this.getElement('.wall-menu-expand-link').setStyle('display', 'none');
        },
        'mouseover': function () {
            this.getElement('.wall-menu-expand-link').setStyle('display', 'block');
        }

    });
}

if (!ImageLayout)
    var ImageLayout = {
        HEIGHTS: [],
        getheight: function (images, width) {
            width -= images.length * 5;
            var h = 0;
            for (var i = 0; i < images.length; ++i) {
                h += images[i].width / images[i].height;
            }
            if (width <= 0) {
                width = 1;
            }
            return (width / h);
        },
        setheight: function (images, height) {
            this.HEIGHTS.push(height);
            var set_i = 0;
            for (var i = 0; i < images.length; ++i) {
                if ((height * images[i].width / images[i].height) <= 0) {
                    return;
                }
                var width = (height * images[i].width / images[i].height);
                if (document.getElementsByClassName('layout_pinfeed_pint_feed').length > 0) {
                    images[i].style.width = (width + 2) + "px";
                } else {
                    images[i].style.width = width + "px";
                }

                images[i].style.height = height + "px";
                images[i].style.maxHeight = "none";
                images[i].style.maxWidth = "none";
                if (images[i].getStyle('width').toInt() == 0) {
                    images[i].setStyle('width', '48%');
                    images[i].style.height = "auto";
                    images[i].style.maxHeight = "none";
                    images[i].style.maxWidth = "none";
                }
            }
        },
        CheckWidth: function (images, height) {
            this.HEIGHTS.push(height);
            for (var i = 0; i < images.length; ++i) {
                if (images[i].getStyle('width').toInt() == 0) {
                    images[i].setStyle('width', '48%');
                    images[i].style.height = "auto";
                    images[i].style.maxHeight = "none";
                    images[i].style.maxWidth = "none";
                }
            }
        },
        collectionToArray: function (collection) {
            var ary = [];
            for (var i = 0, len = collection.length; i < len; i++) {
                ary.push(collection[i]);
            }
            return ary;
        },
        run: function () {

            if (window.layoutRunning) {
                return;
            }
            this.HEIGHTS = [];
            window.layoutRunning = 1;
            var n = 0, max_height = 0;

            var imageCollection = document.querySelectorAll('.feed_item_attachments:not(.laid_out)');


            if (imageCollection.length >= 1) {
                for (var j = 0; j < imageCollection.length; j++) {

                    var images = imageCollection[j].querySelectorAll('[class^=feed_attachment] img');
                    if (images.length > 1) {
                        if (images[images.length - 1].height > 0 && images[images.length - 1].width > 0) {

                            var size = imageCollection[j].offsetWidth;

                            size -= 2 * parseFloat(window.getComputedStyle(imageCollection[j], null).getPropertyValue('padding-left'));
                            if (size > 1) {


                                images = this.collectionToArray(images);
                                max_height = 0;
                                for (var m = 0; m < images.length; m++) {
                                    max_height += images[m].height;
                                }
//                          max_height *= .5;
                                if (max_height > 0) {
                                    var _height = 200;
                                    if (document.getElementsByClassName('layout_pinfeed_pint_feed').length > 0) {
                                        _height = 150;
                                    }
                                    w: while (images.length > 1) {
                                        for (var i = 1; i < images.length + 1; ++i) {
                                            var slice = images.slice(0, i);
                                            var h = this.getheight(slice, size);
                                            if (h < _height) {
                                                this.setheight(slice, h);
                                                n++;
                                                images = images.slice(i);
                                                continue w;
                                            }
                                        }

                                        this.setheight(slice, Math.min(_height, h));
                                        n++;
                                        break;
                                    }

                                    imageCollection[j].className = imageCollection[j].className + " laid_out";
                                }
                            }
                        }
                    }
                    if (images.length == 1 && document.getElementsByClassName('layout_pinfeed_pint_feed').length > 0) {
                        images[0].setStyle('width', '100%');
                        images[0].setStyle('height', 'auto');
                        images[0].style.maxHeight = "none";
                        images[0].style.maxWidth = "none";
                    }

                }
            }
            var self = this;
            if ($$('.comments')[0]) {
                $$('.comments').each(function (item) {
                    if (item.getElements('ul') && window.Wall_smiles) {
                        var ul_elements = item.getElements('ul');
                        ul_elements.each(function (elements) {
                            var elements = elements.getChildren('li:not(.smile_chenge)');
                            if (elements.length) {
                                var elem = elements;
                                var html = '';
                                for (var j = 0; j < elem.length; j++) {
                                    if (elem[j].get('id')) var comment_id = elem[j].get('id').split('-').pop(); else var comment_id = null;

                                    html = elem[j].getChildren('.comments_info').get('html');
                                    if (html[0]) {
                                        for (var i = window.Wall_smiles.length - 1; i >= 0; i--) {
                                            for (var m = 0; m < html[0].toString().length; m++)
                                                html[0] = html[0].toString().replace(window.Wall_smiles[i].index_tag.toString(), window.Wall_smiles[i].html.toString());
                                        }
                                        elem[j].getChildren('.comments_info').set('html', html[0]);
                                        elem[j].className = elem[j].className + ' smile_chenge';
                                    }

                                }
                            }
                        })
                    }

                });
            }
            window.layoutRunning = 0;

        },
        secon_run: function (w) {

            if (window.layoutRunning) {
                return;
            }
            this.HEIGHTS = [];
            window.layoutRunning = 1;
            var n = 0, max_height = 0;

            var imageCollection = document.querySelectorAll('.feed_item_attachments');


            if (imageCollection.length > 1) {
                for (var j = 0; j < imageCollection.length; j++) {

                    var images = imageCollection[j].querySelectorAll('[class^=feed_attachment] img');
                    if (images.length > 1) {
                        if (images[images.length - 1].height > 0 && images[images.length - 1].width > 0) {

                            var size = imageCollection[j].offsetWidth;

                            size -= 2 * parseFloat(window.getComputedStyle(imageCollection[j], null).getPropertyValue('padding-left'));
                            if (size > 1) {


                                images = this.collectionToArray(images);
                                max_height = 0;
                                for (var m = 0; m < images.length; m++) {
                                    max_height += images[m].height;
                                }
//                          max_height *= .5;
                                if (max_height > 0) {
                                    var _height = w;
                                    if (document.getElementsByClassName('layout_pinfeed_pint_feed').length > 0) {
                                        _height = w;
                                    }
                                    w: while (images.length > 1) {
                                        for (var i = 1; i < images.length + 1; ++i) {
                                            var slice = images.slice(0, i);
                                            var h = this.getheight(slice, size);
                                            if ($$('.feed_item_attachments')[0]) {
                                                var h2 = $$('.feed_item_attachments')[0].getSize().y;
                                                if (h2 > h) {
                                                    h = h2;
                                                }
                                            }
                                            if (h < _height) {
                                                this.setheight(slice, h);
                                                n++;
                                                images = images.slice(i);
                                                continue w;
                                            }
                                        }

                                        this.setheight(slice, Math.min(_height, h));
                                        n++;
                                        break;
                                    }

                                    imageCollection[j].className = imageCollection[j].className + " laid_out_three";
                                }
                            }
                        }
                    }
                }
            }


            window.layoutRunning = 0;

        }
    };

function he_show_message(message, type, delay) {
    var text = '';
    var duration = 400;
    var delay = (delay == undefined) ? 3000 : delay;

    text = message;

    if (window.$message_container == undefined) {
        window.$message_container = new Element('div', {'class': 'he_message_container'});
        $(document.body).adopt(window.$message_container);
    }

    var className = 'he_msg_text';
    if (type == 'error') {
        className = 'he_msg_error';
    } else if (type == 'notice') {
        className = 'he_msg_notice';
    } else {
        className = 'he_msg_text';
    }

    var $message = new Element('div', {
        'class': className,
        'styles': {
            'opacity': 0
        }
    });
    var $close_btn = new Element('a', {
        'class': 'he_close',
        'href': 'javascript://',
        'events': {
            'click': function () {
                $message.fade('out');
                $message.removeClass('visible');

                window.setTimeout(function () {
                    $message.dispose();
                    if (window.$message_container.getElements('.visible').length == 0) {
                        window.$message_container.empty();
                    }
                    ;
                }, duration);
            }
        }
    });

    $message.addClass('visible');
    $message.adopt($close_btn);
    $message.adopt('html', new Element('span', {'html': message}));
    window.$message_container.adopt($message);

    $message.set('tween', {duration: duration});
    $message.fade('in');

    window.setTimeout(function () {
        $message.fade('out');
        $message.removeClass('visible');
        window.setTimeout(function () {
            if (window.$message_container.getElements('.visible').length == 0) {
                window.$message_container.empty();
            }
        }, duration);
    }, delay);
}
function he_show_confirm(title, message, callback, options) {
    if (window.$he_confirm_container == undefined) {
        window.$he_confirm_container = new Element('div', {'class': 'he_confirm_container'});
        var $link = window.$he_confirm_container;

        var $title = new Element('div', {'class': 'he_confirm_title'});
        var $description = new Element('div', {'class': 'he_confirm_desc'});

        if (typeof(en4.core.language.translate) == 'undefined') {
            var confirm_label = language.translate('Confirm');
            var or_label = language.translate('or');
            var cancel_label = language.translate('Cancel');
        } else {
            var confirm_label = en4.core.language.translate('Confirm');
            var or_label = en4.core.language.translate('or');
            var cancel_label = en4.core.language.translate('Cancel');
        }

        var $tools = new Element('div', {'class': 'he_confirm_tools'});
        var $confirm_btn = new Element('button', {'class': 'confirm_btn', 'html': confirm_label});
        var $or_text = new Element('span', {'class': 'or_btn', 'html': or_label});
        var $cancel_btn = new Element('a', {'class': 'cancel_btn', 'href': 'javascript://', 'html': cancel_label});

        $tools.adopt($confirm_btn, $or_text, $cancel_btn);
        $link.adopt($title, $description, $tools);

        var $hidden_cont = new Element('div', {'class': 'display_none'});
        $hidden_cont.adopt($link);
        $(document.body).adopt($hidden_cont);
    }

    var $link = window.$he_confirm_container;

    if (title && title.length > 0) {
        $link.getElement('.he_confirm_title').removeClass('display_none').set('html', title);
    } else {
        $link.getElement('.he_confirm_title').addClass('display_none');
    }

    if (message && message.length > 0) {
        $link.getElement('.he_confirm_desc').removeClass('display_none').set('html', message);
    } else {
        $link.getElement('.he_confirm_desc').addClass('display_none');
    }

    if (options && options.confirm_label != undefined)
        $link.getElement('.he_confirm_tools .confirm_btn').set('html', options.confirm_label);
    if (options && options.cancel_label != undefined)
        $link.getElement('.he_confirm_tools .cancel_btn').set('html', options.cancel_label);
    if (options && options.or_label != undefined)
        $link.getElement('.he_confirm_tools .or_btn').set('html', options.or_label);

    var width = (options && options.width) ? options.width : 500;
    var height = (options && options.height) ? options.height : 100;

    Smoothbox.open($link, {mode: 'Inline', width: width, height: height});

    $('TB_ajaxContent').getElement('.he_confirm_tools .cancel_btn').addEvent('click', function () {
        Smoothbox.close();
    });

    if (callback && typeof(callback) == 'function') {
        $('TB_ajaxContent').getElement('.he_confirm_tools .confirm_btn').addEvent('click', function () {
            Smoothbox.close();
            callback();
        });
    }
}


window.addEvent('domready', function () {
    setTimeout(function () {
        if ($('activity-feed')) {
            column_count = Math.floor($('activity-feed').getComputedSize().width / 270);
        }
        else {
            column_count = 3;
        }
        if (column_count < 3) {
            column_count = Math.floor($('activity-feed').getComputedSize().width / 270);
            if (column_count < 3) {
                column_count = 3;
            }
        }
        if ($('global_wrapper') && $('global_wrapper').getStyle('width').toInt() > 1000) {
            if ($$('.generic_layout_container.layout_right')[0]) $$('.generic_layout_container.layout_right')[0].setStyle('padding-right', '66px');
        }

        pinfeed_page = 1;
        start = 0;
        array = [];
        for (var i = 0; i < column_count; array[i++] = 0);
        //options.container.setStyle('width', column_count * 1);

        var options = {
            autoResize: true, // This will auto-update the layout when the browser window is resized.
            container: $('pinfeed'),
            item: $$('.wall-items-pinfeed'),
            offset: 2,
            itemWidth: 255,
            bottom: 0,
            w: 1
        };
        var handler = $$('.wall-action-item');

        pinfeed(options);
    }, 3000);
});


function respondPinFeed() {
    if (window.getSize().x < 620 && $$('.wall-items-pinfeed')) {
        $$('.pins_xount_2').setStyle('float', 'none');
        $$('.pinfeed').setStyle('width', '100%');
        $$('.wall-items-pinfeed').setStyle('width', '100%');
    } else if (window.getSize().x > 620 && $$('.wall-items-pinfeed')) {
        $$('.pins_xount_2').setStyle('float', 'left');
        $$('.pinfeed').setStyle('width', '270px');
        $$('.wall-items-pinfeed').setStyle('width', '265px');
    }
}

window.addEvent('resize', function () {
    if (window.width_res == 1) {
        new_size = window.getSize().y;

        respondPinFeed();

        column_count_new = Math.floor($('activity-feed').getComputedSize().width / 275);
        if (column_count && column_count_new == column_count) {
            return;
        }
        start = 0;
        array = [];
        for (var i = 0; i < column_count_new; array[i++] = 0);
        var options = {
            autoResize: true, // This will auto-update the layout when the browser window is resized.
            container: $('pinfeed'),
            item: $$('.wall-items-pinfeed'),
            offset: 2,
            itemWidth: 255,
            bottom: 0
        };
        pinfeed(options);

        old_size = new_size;


    }
});

function videoViewer(video_id) {
    $('videoViewer').setStyle('display', 'block');
    $('videoViewer').setStyle('width', '700px');
    $we = $('global_wrapper').getComputedSize().width;
    $he = window.getSize().y;
    var $width = ($we - 700) / 2;
    $('videoViewer').setStyle('left', $width + 'px');

    $('videoViewer').set('html', '<div class="wpContainerVideo">' +
        '<a href="javascript: void(0)" onclick="clsoe_video()" class="close-video-contaner"></a>' +
        $('video_object_' + video_id).get('html') +
        '</div>');

    $he_contaner = $('videoViewer').getComputedSize().height;
    var $top = (($he - $he_contaner) / 2);

    $('videoViewer').setStyle('top', $top + 'px');
    $('videoViewer').setStyle('z-index', '502');
    $$('.video_background').setStyle('display', 'block');


}

function clsoe_video() {
    $('videoViewer').set('html', '');
    $('videoViewer').setStyle('display', 'none');
    $$('.video_background').setStyle('display', 'none');
}

window.addEvent('domready', function () {
    if ($$('.layout_active_theme_transformer')[0] && window.width_res == 1) {
        $interval_check = setInterval(function () {
            if (Math.floor($('activity-feed').getComputedSize().width / 275) < 3) {

            } else {
                column_count = Math.floor($('activity-feed').getComputedSize().width / 275);
                pinfeed_page = 1;
                start = 0;
                array = [];
                for (var i = 0; i < column_count; array[i++] = 0);
                var options = {
                    autoResize: true, // This will auto-update the layout when the browser window is resized.
                    container: $('pinfeed'),
                    item: $$('.wall-items-pinfeed'),
                    offset: 2,
                    itemWidth: 255,
                    bottom: 0
                };
                var handler = $$('.wall-action-item');

                pinfeed(options);
                clearInterval($interval_check);
            }
        }, 2000)
    }

    if (window.width_res == 1) {
        if ($$('.pinfeeds')) var wi = $$('.pinfeeds')[0].getComputedSize().width - column_count * (275);
        else  var wi = $$('.pinfeeds')[0].getComputedSize().width - column_count * (275);
        var ml = $$('.layout_left').getStyle("margin-left")[0].toInt();
        if (!$$('.layout_active_theme_transformer')[0] && !$$('.layout_active_theme_minimal')[0] && !$$('.layout_active_theme_minimal-blue')[0]) {
            $$('.layout_left').setStyle('margin-left', ml + ((wi / 2) - 3) + 'px');
        }
        var wi = $$('.pinfeeds')[0].getComputedSize().width - column_count * (275);
        var ml = $$('.layout_left').getStyle("margin-left")[0].toInt();
//$$('.layout_left').setStyle('margin-left', ml + (wi/2)+'px');
        if (!$$('.layout_active_theme_transformer')[0]) {
            $$('.fake-lists').setStyle('right', (ml - wi) - 34 + 'px')
        }
    }
    if ($$('.pinfeeds')[0].getComputedSize().width <= 950) {
        var elements_div = $$('.generic_layout_container .layout_left').getChildren('div');
        elements_div.each(function (el, i) {
            el.setStyle('width', '170px');
            if ($$('.layout_active_theme_modern')) {
                el.setStyle('margin-right', '17px');
            } else if ($$('.layout_active_theme_slipstream')) {
                el.setStyle('margin-right', '10px');
            } else {
                el.setStyle('margin-right', '0px');
            }

        });
        $$('.generic_layout_container .layout_left').setStyle('margin-right', '0px')
    }


});
