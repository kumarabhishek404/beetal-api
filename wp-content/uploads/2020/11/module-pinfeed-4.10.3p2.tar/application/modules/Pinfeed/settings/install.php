<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Headvancedalbum
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: install.php 17.08.12 06:04 michael $
 * @author     Michael
 */

/**
 * @category   Application_Extensions
 * @package    Pinfeed
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */
class Pinfeed_Installer extends Engine_Package_Installer_Module
{
    public function onPreInstall()
    {
        parent::onPreInstall();

        $db = $this->getDb();
        $db->query("INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`)
VALUES ( 'core_admin_main_plugins_pinfeed', 'pinfeed', 'HE - Pin-Feed', NULL, '{\"route\":\"admin_default\",\"module\":\"pinfeed\",\"controller\":\"index\"}', 'core_admin_main_plugins', NULL, 1, 0, 888);
");
        
        
        $db->query("
INSERT IGNORE INTO `engine4_core_pages` ( `name`, `displayname`, `url`, `title`, `description`, `keywords`, `custom`, `fragment`, `layout`, `levels`, `provides`, `view_count`)
VALUES ( 'pinfeed_index_index', 'Pin-Feed page', '', 'Member Home Page', 'This is pint version of member home page', '', 1, 0, '', '', NULL, 0 );
");
        
        $page_id = $db->lastInsertId();
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (  `page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`)
VALUES ('$page_id', 'container', 'main', NULL, 2, '[\"[\'Member Home Page\']\"]', NULL);
");
        
        $content_id = $db->lastInsertId();
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (  `page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`)
VALUES  ( '$page_id', 'container', 'left', '$content_id', 4, '[\"[]\"]', NULL);
");
        
        $content_id2 = $db->lastInsertId();
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (  `page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`)
VALUES( '$page_id', 'widget', 'user.home-photo', '$content_id2', 3, '[\"[]\"]', NULL);
");
        
        
        
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (  `page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`)
VALUES ( '$page_id', 'widget', 'user.home-links', '$content_id2', 4, '[\"[]\"]', NULL);
");
        
        
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (  `page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`)
VALUES ( '$page_id', 'widget', 'activity.list-requests', '$content_id2', 5, '[\"[]\"]', NULL);
");
        
        
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (  `page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`)
VALUES ( '$page_id', 'container', 'middle', '$content_id', 6, '[\"[]\"]', NULL);
");
        
        $content_id3 = $db->lastInsertId();
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (  `page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`)
VALUES ( '$page_id', 'widget', 'event.home-upcoming', '$content_id2', 7, '[\"[]\"]', NULL);
");
        
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (  `page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`)
VALUES ( '$page_id', 'widget', 'pinfeed.pint-feed', '$content_id3', 11, '[\"[]\"]', NULL);
");
        
        
        
        /***************Profile page layout grid start****************/
        
        $db->query("
INSERT IGNORE INTO `engine4_core_pages` ( `name`, `displayname`, `url`, `title`, `description`, `keywords`, `custom`, `fragment`, `layout`, `levels`, `provides`, `view_count`)
VALUES ( 'pinfeed_index_profile', 'Pinfeed profile Member', NULL, 'Member Profile Page', 'This is pint version of member Profile page', '', 1, 0, '', '', NULL, 0 );
");
        
        $page_id = $db->lastInsertId();
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (  `page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`)
VALUES ('$page_id', 'container', 'main', NULL, 2, '[\"[\'Member Profile Page\']\"]', NULL);
");
        
        $content_id = $db->lastInsertId();
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (  `page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`)
VALUES  ( '$page_id', 'container', 'left', '$content_id', 4, '[\"[]\"]', NULL);
");
        
        $content_id2 = $db->lastInsertId();
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (  `page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`)
VALUES( '$page_id', 'widget', 'user.home-photo', '$content_id2', 1, '[\"[]\"]', NULL);
");
        
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (  `page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`)
VALUES( '$page_id', 'widget', 'user.profile-options', '$content_id2', 3, '[\"[]\"]', NULL);
");
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (  `page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`)
VALUES( '$page_id', 'widget', 'user.profile-fields', '$content_id2', 3, '{\"title\":\"Info\"}', NULL);
");
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (  `page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`)
VALUES( '$page_id', 'widget', 'user.profile-friends', '$content_id2', 3, '{\"title\":\"Friends\",\"titleCount\":true}', NULL);
");
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (  `page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`)
VALUES ( '$page_id', 'container', 'middle', '$content_id', 6, '[\"[]\"]', NULL);
");
        
        $content_id3 = $db->lastInsertId();
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (  `page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`)
VALUES ( '$page_id', 'widget', 'event.home-upcoming', '$content_id2', 7, '[\"[]\"]', NULL);
");
        
        
        $db->query("INSERT IGNORE INTO `engine4_core_content` (  `page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`)
VALUES ( '$page_id', 'widget', 'pinfeed.pint-feed', '$content_id3', 11, '[\"[]\"]', NULL);
");
    }

}
