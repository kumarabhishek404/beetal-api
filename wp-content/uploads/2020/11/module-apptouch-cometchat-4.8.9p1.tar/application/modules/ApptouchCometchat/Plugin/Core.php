<?php
/**
 * Created by PhpStorm.
 * User: azama_000
 * Date: 10.09.15
 * Time: 9:41
 */


class ApptouchCometchat_Plugin_Core extends Zend_Controller_Plugin_Abstract {

} 