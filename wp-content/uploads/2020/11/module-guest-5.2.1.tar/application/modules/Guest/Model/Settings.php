<?php

class Guest_Model_Settings extends Core_Model_Item_Abstract
{

}
