<?php

class Guest_Model_DbTable_Settings extends Engine_Db_Table
{
    protected $_rowClass = 'Guest_Model_Settings';


}