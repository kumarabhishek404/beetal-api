var GuestStorage = {
    focus: true,
    visibility_change: function () {
        var _this = this;
        var hidden, visibilityState, visibilityChange;

        if (typeof document.hidden !== "undefined") {
            hidden = "hidden", visibilityChange = "visibilitychange", visibilityState = "visibilityState";
        } else if (typeof document.msHidden !== "undefined") {
            hidden = "msHidden", visibilityChange = "msvisibilitychange", visibilityState = "msVisibilityState";
        }

        var document_hidden = document[hidden];

        document.addEventListener(visibilityChange, function() {
            if(document_hidden != document[hidden]) {
                _this.focus = document[hidden] ? false : true;
                document_hidden = document[hidden];
            }
        });
    },
    show_guest: function (responseText, json) {
        var _this = this;
        var guest_el = $('guest-notification');

        if (guest_el == null || typeof guest_el == 'undefined') {
            // desktop notification
            if (json) {
                var desk_not = new Request.JSON({
                    url: 'guest/index/guests',
                    onSuccess: function(guest) {
                        if (!Notification) {
                            alert('Desktop notifications not available in your browser. Try Chromium.');
                            return;
                        } else {
                            window.Notification.requestPermission();
                        }

                        if (Notification.permission !== "granted") {
                            Notification.requestPermission(function (permission) {
                                if (permission == 'granted') {
                                    var notification = new Notification('New guest', {
                                        icon: guest.image,
                                        body: guest.name + "\n" + guest.time
                                    });

                                    notification.onclick = function () {
                                        window.open(guest.link);
                                    };
                                }
                            });
                        }
                        else {
                            if (!_this.focus) {
                                var notification = new Notification('New guest', {
                                    icon: guest.image,
                                    body: guest.name + "\n" + guest.time
                                });

                                notification.onclick = function () {
                                    window.open(guest.link);
                                };
                            }
                        }
                    },
                    onFailure: function () { console.log('JSON request is failed'); }
                });
                desk_not.send();
            }

            var temp = new Element('div#guest-notification', {'html': responseText});
            var body = document.getElement('body');
            temp.inject(body, 'bottom');

            var check = $$('div.guest-info')[0];
            if (check !== null && typeof check !== 'undefined') {
                var timerId = setTimeout(function () {
                    var guest_id = check.get("id");
                    var add_req = new Request.HTML({
                        url: 'guest/index/add/guest_id/' + guest_id.substring(6) + '?format=html',
                        method: 'get',
                        onSuccess: function (var1, var2, responseText) {
                            var temp = new Element('li.'+guest_id, {'html': responseText});
                            var element = $$('div.layout_guest_profile_guests')[0];
                            if (element !== null && typeof element !== 'undefined') {
                                element = element.getElements('ul.generic_list_widget')[0];
                                if (element !== null && typeof element !== 'undefined') {
                                    temp.inject(element, 'top');
                                }
                            }
                        }
                    });
                    add_req.send();

                    var del_request = new Request.HTML({
                        url: 'guest/index/viewed/guest_id/' + guest_id.substring(6) + '?format=html',
                        method: 'get'
                    });
                    del_request.send();

                    var el = $('guest-notification');
                    if (el !== null && typeof el !== 'undefined') {
                        el.destroy();
                    }
                }, 5000);

                var close = $('guest-close-btn');
                if (close !== null) {
                    close.addEvent('click', function () {
                        var guest_id = $$('.guest-info')[0].get("id");
                        var add_req = new Request.HTML({
                            url: 'guest/index/add/guest_id/' + guest_id.substring(6) + '?format=html',
                            method: 'get',
                            onSuccess: function (var1, var2, responseText) {
                                var temp = new Element('li.'+guest_id, {'html': responseText});
                                var element = $$('.layout_guest_profile_guests')[0];
                                if (element !== null && typeof element !== 'undefined') {
                                    element = $$('div.layout_guest_profile_guests')[0].getElements('ul.generic_list_widget')[0];
                                    if (element !== null && typeof element !== 'undefined') {
                                        temp.inject(element, 'top');
                                    }
                                }
                            }
                        });
                        add_req.send();

                        var re_request = new Request.HTML({
                            url: 'guest/index/viewed/guest_id/' + guest_id.substring(6) + '?format=html',
                            method: 'get'
                        });
                        re_request.send();

                        var el = $('guest-notification');
                        el.destroy();
                    });
                }

                var guest_not = $('guest-notification');
                if (guest_not !== null && typeof guest_not !== 'undefined') {
                    guest_not.addEvent('mouseenter', function () {
                        clearTimeout(timerId);
                    });
                }
            }
        }
    }
};

window.onload = function () {
    // get the interval of notifications
    var interval = new Request({
        url: 'guest/index/interval',
        method: 'get',
        onSuccess: function (responseText) {
            var inter_val = responseText.toInt();

            // get settings of notifications
            var note_set = new Request({
                url: 'guest/index/notification',
                method: 'get',
                onSuccess: function (responseText) {
                    var type = responseText.toInt();

                    switch(type) {
                        case 1:
                            setInterval(function () {
                                var request = new Request.HTML({
                                    url: 'guest/index/guests?format=html',
                                    method: 'get',
                                    onRequest: function () {},
                                    onSuccess: function (var1, var2, responseText) {
                                        GuestStorage.show_guest(responseText, false);
                                    },
                                    onFailure: function () {}
                                });
                                request.send();
                            }, (1000 * inter_val));
                            break;
                        case 2:
                            setInterval(function () {
                                var request = new Request.HTML({
                                    url: 'guest/index/guests?format=html',
                                    method: 'get',
                                    onRequest: function () {},
                                    onSuccess: function (var1, var2, responseText) {
                                        GuestStorage.visibility_change();
                                        GuestStorage.show_guest(responseText, true);
                                    },
                                    onFailure: function () {}
                                });
                                request.send();
                            }, (1000 * inter_val));
                            break;
                    }
                }
            });
            note_set.send();
        }
    });

    interval.send();
    window.Notification.requestPermission();
};