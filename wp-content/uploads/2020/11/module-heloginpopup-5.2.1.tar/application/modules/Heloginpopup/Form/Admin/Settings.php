<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Heloginpopup
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    Id: Settings.php 24.09.13 14:26 Ulan T $
 * @author     Ulan T
 */

/**
 * @category   Application_Extensions
 * @package    Heloginpopup
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Heloginpopup_Form_Admin_Settings extends Engine_Form
{
  public function init()
  {
    $this->setTitle('Login with Phone no services.')
      ->setDescription('');

      $description = $this->getTranslator()->translate('HELOGIN_ADMIN_SETTINGS_TWILIO_DESCRIPTION');
    $moreinfo = $this->getTranslator()->translate('');
      $description = vsprintf($description.$moreinfo, array(
        'https://www.twilio.com/login'
      ));
      $this->setDescription($description);

      $this->loadDefaultDecorators();
      $this->getDecorator('Description')->setOption('escape', false);

    $settings = Engine_Api::_()->getDbTable('settings', 'core');

        $this->addElement('Text', 'accountsid', array(
      'label' => 'Account SID',
      'filters' => array(
        'StringTrim',
      ),
    ));
    $this->addElement('Text', 'apikey', array(
      'label' => 'Authorization Token',
      'filters' => array(
        'StringTrim',
      ),
    ));
    $this->addElement('Text', 'phoneno', array(
      'label' => 'Phone Number',
      'placeholder' => 'Phone Number',
      'allowEmpty' => false,
      'required' => true,
      'description' => 'Please enter the phone number you have purchased in your Twilio account. [Note: It should include country code with no space or any other character in between the phone number. Example: +84XXXXXXXX. ]',
      'filters' => array(
        'StringTrim',
      ),
      'validators' => array(
        array('NotEmpty', true),
        array('Regex', true, "/^(\+[1-9]{1}[0-9]{3,15})+$/"),
      ),
    ));

    $this->addElement('Radio', 'enable', array(
      'label' => 'Enabled?',
      'multiOptions' => array(
        1 => 'Yes',
        0 => 'No',
      ),
      'value' => 0
    ));

    $this->addElement('Button', 'submit', array(
      'label' => 'Save',
      'type' => 'submit'
    ));
  }
}
