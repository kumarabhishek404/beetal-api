/* Id: core.js 20.09.13 12:26 TeaJay $ */
var loginPopup = {
    formUrl: '',
    forgotUrl: '',
    signupUrl: '',
    facebookUrl: '',
    twitterUrl: '',
    dateLimit: 30,
    content: '',
    modalView: '',
    return_url: '',

    init: function () {
        var self = this;
        self.content.inject($$('body')[0]);
        self.modalView.inject($$('body')[0]);

        // var lastdate = localStorage.getItem('en4_heloginpopup_lastdate');
        // var currentdate = new Date();

        // if( !lastdate ) {
        //     self.showPopup();
        //     localStorage.setItem('en4_heloginpopup_lastdate',currentdate);
        //     return;
        // }

        // lastdate = new Date(lastdate);

        // var dateDiff = parseInt((currentdate.getTime()-lastdate.getTime())/(24*3600*1000));

        // if( dateDiff >= self.dateLimit ) {
            //self.showPopup();
        //     localStorage.setItem('en4_heloginpopup_lastdate',currentdate);
        // }
    },

    showPopup: function () {
        this.content.setStyle('display', 'block');
        this.modalView.setStyle('display', 'block');

        this.content.addClass('heloginpopup_in');
        this.modalView.addClass('heloginpopup_in');
    },

    hidePopup: function () {
        var self = this;
        this.content.removeClass('heloginpopup_in');
        this.modalView.removeClass('heloginpopup_in');
        (function () {
            self.modalView.setStyle('display', 'none');
            self.content.setStyle('display', 'none');
        }).delay(200);
    },
    otpForm: function() {
        $$('.otp-form').setStyle('display', 'block');
        $$('.left').setStyle('display', 'none');
        $$('#message_error_id').setStyle('display', 'none');
    },
    sendcode: function ()
     {
        var recipient = document.getElementById("mobile_number").value;
        var recipientCode = document.getElementById("countryCode").value;  
        var onlyPhone = recipient;      
        var phoneno = /^(0|[0-9]\d*)$/;
        if(recipient.match(phoneno))  
         {      recipient = recipientCode+''+recipient;
                $$('.code_error_message').setStyle('display', 'none');
                $$('.ajax_loader').setStyle('display', 'block');
                loginPopup.sendcodeTwilio(recipient, onlyPhone);       
         }  
       else  
         {  
            $$('.code_error_message').setStyle('display', 'block');
         }  
     },
     verifycode: function (){
        $$('.ajax_loader').setStyle('display', 'block');
        var otpcode = document.getElementById("confirm_code_widget").value;
        var recipient = document.getElementById("mobile_number").value;
        var recipientCode = document.getElementById("countryCode").value;
        var finalphone = recipientCode+''+recipient;
        var onlyPhone = recipient;
            var param = {};
            param.otp= otpcode;
            param.recipient= finalphone;
            param.onlyphone= onlyPhone;
            var request= new Request.JSON({
                    url: en4.core.baseUrl+'heloginpopup/index/otp-verify',
                    method: 'post',
                    data: param,
                    onSuccess: function( response ) 
                    {
                       //console.log(response.error);
                       console.log(response);
                       $$('.ajax_loader, #code_message').setStyle('display', 'none');
                       if(response.error == 1){
                        //display error
                        document.getElementById("message_error_id").innerHTML = 'Your OTP is not valid.';
                        document.getElementById("confirm_code_button").innerHTML = 'Verify';
                        $$('.code_error_message').setStyle('display', 'block');
                       }else{
                        document.getElementById("confirm_code_button").innerHTML = 'Verified';
                        document.getElementById("code_message").innerHTML = 'OTP is verified';
                        $$('.code_error_message, #resend_code_button-wrapper').setStyle('display', 'none');
                        window.location.href = response.return_url;
                       }                   
                    }, 
                    onFailure: function(){
                         console.log('failed');
                    }
                   });
                    request.send();

     }, 
     sendcodeTwilio: function (recipient, onlyPhone)
     {
            var param = {};
            param.number= recipient;
            param.onlyphone= onlyPhone;
            var request= new Request.JSON({
                    url: en4.core.baseUrl+'heloginpopup/index/verification',
                    method: 'post',
                    data: param,
                    onSuccess: function( response ) 
                    {
                       console.log(response);
                        $$('.ajax_loader').setStyle('display', 'none');
                       if(response.error != 0)
                       {
                            document.getElementById("send_code_button").innerHTML = 'Send';
                            if(response.message=="Authenticate"){
                                document.getElementById("message_error_id").innerHTML = 'Twilio Authentication Error';
                            }
                            else
                            {
                                document.getElementById("message_error_id").innerHTML = response.message;
                            }
                            $$('.code_error_message').setStyle('display', 'block');
                        }
                        else
                        {
                           $$('#mobile_number-wrapper').setStyle('display', 'none');
                           $$('#send_code_button-wrapper').setStyle('display', 'none');
                           $$('#confirm_code_widget-wrapper').setStyle('display', 'block');
                           $$('#confirm_code_button-wrapper').setStyle('display', 'inline-block');
                           $$('#code_message').setStyle('display', 'block');
                           $$('#resend_code_button-wrapper').setStyle('display', 'inline-block');
                           //$$('#mobile_hidden').setProperty('value', response.phone);
                        }                  
                    }, 
                    onFailure: function(){
                         console.log('failed');
                    }
                   });
                    request.send();
        },
        resendcode: function (){
            $$('#code_message, #confirm_code_widget-wrapper, #confirm_code_button-wrapper').setStyle('display', 'none');
            $$('#mobile_number-wrapper, #send_code_button-wrapper, .ajax_loader').setStyle('display', 'block');
            document.getElementById("confirm_code_widget").value = '';
            loginPopup.sendcode();

        }
}

en4.core.runonce.add(function () {
    $$('.user_auth_link').addEvent('click', function (e) {
        e.preventDefault();
        loginPopup.showPopup();
        $$('.left').setStyle('display', 'block');
        $$('.otp-form, .ajax_loader, #resend_code_button-wrapper').setStyle('display', 'none');

    });
});

