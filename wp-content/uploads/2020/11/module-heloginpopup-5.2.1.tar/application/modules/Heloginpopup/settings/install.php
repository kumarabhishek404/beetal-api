<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Heloginpopup
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    Id: install.php 24.09.13 14:26 Ulan T $
 * @author     Ulan T
 */

/**
 * @category   Application_Extensions
 * @package    Heloginpopup
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Heloginpopup_Installer extends Engine_Package_Installer_Module
{
  public function onPreInstall()
  {
    parent::onPreInstall();

    $db = $this->getDb();
		$db->query("CREATE TABLE IF NOT EXISTS `engine4_heloginpopup_twilios` (
		`twilio_id` int(10) NOT NULL AUTO_INCREMENT,
		`account_sid` varchar(100) NOT NULL,
		`account_token` varchar(100) NOT NULL,
		`twilio_number` varchar(100) NOT NULL,
		`services` varchar(200) DEFAULT NULL,
		`enable` int(11) DEFAULT '0',
		PRIMARY KEY (`twilio_id`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8");
}
}
