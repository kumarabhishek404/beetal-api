<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Heloginpopup
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    Id: AdminIndexController.php 24.09.13 14:26 Ulan T $
 * @author     Ulan T
 */

/**
 * @category   Application_Extensions
 * @package    Heloginpopup
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Heloginpopup_AdminIndexController extends Core_Controller_Action_Admin
{
  public function indexAction()
  {
    $this->view->form = $form = new Heloginpopup_Form_Admin_Settings();
    $twiliosTable = Engine_Api::_()->getDbtable('twilios', 'heloginpopup');
    $select = $twiliosTable->select()
      ->where('services = ?', 'twilio');   
      // If post exists
    $twiliosRows = $twiliosTable->fetchRow($select);
    $Setvalues = array(
            'accountsid' => $twiliosRows->account_sid,
            'apikey' => $twiliosRows->account_token,
            'phoneno' => $twiliosRows->twilio_number,
            'enable' => $twiliosRows->enable,
          );
    $form->populate($Setvalues);
    if( !$this->getRequest()->isPost() ) {
      return;
    }

    if( !$form->isValid($this->getRequest()->getPost()) ) {
      return;
    }

    $values = $form->getValues();
          if($twiliosRows){
            $twiliosRows->account_sid = $values['accountsid'];
            $twiliosRows->account_token = $values['apikey'];
            $twiliosRows->twilio_number = $values['phoneno'];
            $twiliosRows->enable = $values['enable'];
          $twiliosRows->save();
          }else{
          $twiliosTable->createRow();
          $twiliosTable->account_sid = $values['accountsid'];
          $twiliosTable->account_token = $values['apikey'];
          $twiliosTable->twilio_number = $values['phoneno'];
          $twiliosTable->enable = $values['enable'];
          $twiliosTable->save();
          }
          $form->addNotice('Your changes have been saved.');
  }
}