<?php

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version Styler 1.01
 */

define('SE_PAGE_AJAX', TRUE);
$page = "he_styler_uploader";

include "header.php";

$task = isset($_POST['task']) ? $_POST['task'] : false;
$task = ( !$task && isset($_GET['task']) ) ? $_GET['task'] : $task;

$styler_page = isset($_POST['styler_page']) ? $_POST['styler_page'] : false;
$styler_page = ( !$styler_page && isset($_GET['styler_page']) ) ? $_GET['styler_page'] : $styler_page;

$styler_page_id = isset($_POST['styler_page_id']) ? $_POST['styler_page_id'] : false;
$styler_page_id = ( !$styler_page_id && isset($_GET['styler_page_id']) ) ? $_GET['styler_page_id'] : $styler_page_id;

$skin_id = isset($_POST['skin_id']) ? $_POST['skin_id'] : false;
$skin_id = ( !$skin_id && isset($_GET['skin_id']) ) ? $_GET['skin_id'] : $skin_id;

$group_id = isset($_POST['group_id']) ? $_POST['group_id'] : false;
$group_id = ( !$group_id && isset($_GET['group_id']) ) ? $_GET['group_id'] : $group_id;

$header_sent = false;

$he_styler = new he_styler($styler_page, $styler_page_id);

if ( !$user->user_exists && !in_array($task, array('get_skin')) )
{
    $result = array( 'result' => 0, 'message' => SE_Language::get(690702065) );
}
elseif ( !$skin_id && !in_array($task, array('get_skin_count', 'get_skins', 'make_skin')) )
{
    $result = array( 'result' => 0, 'message' => 'Undefined skin_id' );
}
elseif ( $task == 'upload_image' && $group_id )
{
    $header_sent = true;

    $new_upload = new se_upload();
    
    $max_filesize = 2*1024*1024;
    $file_exts = array('jpg', 'jpeg', 'gif', 'png');
    $file_types = array('image/jpeg', 'image/jpg', 'image/jpe', 'image/pjpeg', 'image/pjpg', 'image/x-jpeg', 'x-jpg', 
        'image/gif', 'image/x-gif', 'image/png', 'image/x-png');
    
    $new_upload->new_upload('bg_image', $max_filesize, $file_exts, $file_types);
    
    if ( $new_upload->is_error )
    {
        $result = array( 'result' => 0, 'message' => SE_Language::get($new_upload->is_error) );
    }
    else
    {
        $file_name = "bg_image_{$skin_id}_{$group_id}.{$new_upload->file_ext}";
        
        $new_upload->upload_file("./uploads_styler/$file_name");
        
        $he_styler->save_bg_image($skin_id, $group_id, $file_name);
        
        $result = array( 'result' => 1, 'src' => $file_name );
    }
}
elseif ( $task == 'delete_image' && $group_id )
{
    $file_name = "bg_image_{$skin_id}_{$group_id}";
    $bg_image = isset($_POST['bg_image']) ? trim($_POST['bg_image']) : '';
    
    if ( strstr($bg_image, $file_name)===false )
    {
        $result = array( 'result' => 0, 'message' => 'File not found' );
    }
    else
    {
        @unlink("./uploads_styler/$bg_image");
        
        $he_styler->delete_bg_image($skin_id, $group_id);
        
        $result = array( 'result' => 1, 'message' => SE_Language::get(690702066) );
    }
}
elseif ( $task == 'save_skin' )
{
    $name = $_POST['name'];
    $values = $_POST['values'];
    
    if ( $he_styler->save_skin($skin_id, $name, $values, 1) )
    {
        $result = array( 'result' => 1, 'message' => SE_Language::get(690702067) );
    }
    else
    {
        $result = array( 'result' => 0, 'message' => SE_Language::get(690702068) );
    }
}
elseif ( $task == 'make_skin' )
{
    $default_skin = $he_styler->default_skin();
    $skin_info = $he_styler->make_skin($default_skin);

    $result = array( 'skin_info' => $skin_info, 'values' => $he_styler->get_skin_value($skin_info['id']) );
}
elseif ( $task == 'get_skin' )
{
    $header_sent = true;
    $output_json = false;
    
    $result = $he_styler->get_skin_css($skin_id);
    
    // CONSTRUCT AND OUTPUT CSS
    header("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); // Date in the past
    header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); // always modified
    header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
    header("Pragma: no-cache"); // HTTP/1.0
    header("Content-Type: text/css");
    
    echo $result;
    
    exit();
}
elseif ( $task == 'get_skin_values' )
{
    $skin_info = $he_styler->find_skin($skin_id);
    $values = $he_styler->get_skin_value($skin_id);
    
    if ( $values && $skin_info )
    {
        $result = array( 'result' => 1, 'values' => $values, 'skin_info' => $skin_info );
    }
    else
    {
        $result = array( 'result' => 0, 'message' => SE_Language::get(690702069) );
    }
}
elseif ( $task == 'get_skins' )
{
    $page = isset($_POST['page']) ? (int)$_POST['page'] : 1;
    $type = isset($_POST['type']) ? trim($_POST['type']) : 'shared_skins';

    $first = ($page - 1)*7;

    if ( $type == 'shared_skins' )
    {
        $skins = $he_styler->get_shared_skins($first);        
    }
    else
    {
        $skins = $he_styler->get_page_skin_history($first);
    }

    if ( $skins['count'] != 0 )
    {
        $result = array( 'result' => 1, 'skins' => $skins['skins'] );
    }
    else
    {
        $result = array( 'result' => 0, 'message' => 'Error' );
    }
}
elseif ( $task == 'select_skin' )
{
    $new_skin_id = $he_styler->select_skin($user->user_info['user_id'], $skin_id);

    if ( $new_skin_id )
    {
        $result = array( 'result' => 1, 'skin_id' => $new_skin_id, 'message' => SE_Language::get(690702077) );
    }
    else
    {
        $result = array( 'result' => 0, 'message' => 'Error' );
    }    
}
elseif ( $task == 'share_skin' )
{
    $header_sent = true;

    $skin_info = $he_styler->find_skin($skin_id);

    if ( $user->user_info['user_id'] != $skin_info['user_id'] )
    {
        $result = array( 'result' => 0, 'message' => 'Error' );
        echo json_encode($result);
        exit();
    }


    $new_upload = new se_upload();

    $max_filesize = 2*1024*1024;
    $file_exts = array('jpg', 'jpeg', 'gif', 'png');
    $file_types = array('image/jpeg', 'image/jpg', 'image/jpe', 'image/pjpeg', 'image/pjpg', 'image/x-jpeg', 'x-jpg',
        'image/gif', 'image/x-gif', 'image/png', 'image/x-png');

    $new_upload->new_upload('photo', $max_filesize, $file_exts, $file_types);

    if ( $new_upload->is_error )
    {
        $result = array( 'result' => 0, 'message' => SE_Language::get($new_upload->is_error) );
    }
    else
    {
        $name = trim($_POST['name']);
        $file_name = "skin_photo_{$skin_id}.{$new_upload->file_ext}";

        $new_upload->upload_photo("./uploads_styler/$file_name", "80", "80");

        
        $skin_info = $he_styler->share_skin($skin_id, $name, $file_name);

        $result = array( 'result' => 1, 'skin_info' => $skin_info, 'message' => SE_Language::get(690702081) );
    }
}
elseif ( $task == 'delete_skin' )
{
    $skin_info = $he_styler->find_skin($skin_id);

    if ( !$skin_info || $skin_info['shared'] || $user->user_info['user_id']!=$skin_info['user_id'] )
    {
        $result = array( 'result' => 0, 'message' => 'Undefined skin_id' );        
    }
    else
    {
        $he_styler->delete_skin($skin_id);
        $result = array( 'result' => 1, 'message' => SE_Language::get(690702070) );
    }
}
elseif ( $task == 'get_skin_count' )
{
    $type = trim($_POST['type']);
    $count = 0;

    if ( $type == 'shared_skins' )
    {
        $count = $he_styler->find_shared_skin_count();
    }
    elseif( $type == 'history_skins' )
    {
        $count = $he_styler->find_page_history_skin_count();
    }

    $result = array( 'count' => $count );
}

if ( !$header_sent )
{
    // CONSTRUCT AND OUTPUT JSON
    header("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); // Date in the past
    header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); // always modified
    header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
    header("Pragma: no-cache"); // HTTP/1.0
    header("Content-Type: application/json");
    
    
}

echo json_encode($result);

exit();

?>