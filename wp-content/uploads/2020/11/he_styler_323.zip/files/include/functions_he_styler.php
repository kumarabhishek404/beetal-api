<?php

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version Styler 3.2
 */

function he_styler_prepare_page()
{
    global $page, $user, $owner, $smarty, $admin, $pages, $group;

    if (in_array($page, array('profile', 'group', 'pages'))) {
        $styler_css_files = array(
            'destruct' => true,
            'custom_destruct' => false,
        );

        $smarty->assign('styler_css_files', $styler_css_files);
    }
    else {
        return false;
    }

    if (isset($_GET['task']) && $_GET['task'] == 'view_skin' && $admin->admin_exists) {
        $skin_id = (int)$_GET['skin_id'];

        switch ($page) {
            case 'profile':
                $he_page = 'profile';
                $he_page_id = $owner->user_info['user_id'];
            break;
            case 'group':
                $he_page = 'group';
                $he_page_id = isset($_GET['group_id']) ? (int)$_GET['group_id'] : 0;
            break;
            case 'pages':
                $he_page = 'page';
                $he_page_id = isset($_GET['pages_id']) ? (int)$_GET['pages_id'] : 0;
            break;
            default:
                $he_page = 'profile';
                $he_page_id = $owner->user_info['user_id'];
            break;
        }
        
        $he_styler = new he_styler($he_page, $he_page_id);
        $skin_info = $he_styler->find_skin($skin_id);

        $smarty->assign('styler_page', $he_styler->page);
        $smarty->assign('styler_page_id', $he_styler->page_id);
        $smarty->assign('styler_default_skin_id', $he_styler->default_skin_id);

        $smarty->assign('skin_info', $skin_info);
        $smarty->assign('rand_code', time());

        $smarty->assign_hook('footer', 'he_styler_footer.tpl');

        return true;
    }
    
    $he_styler_allowed = false;
    $he_owner_mode = false;
    
    switch ($page) {
        case 'profile':
            $he_page = 'profile';
            $he_page_id = $owner->user_info['user_id'];
            $he_page_owner_id = $owner->user_info['user_id'];
            
            $he_styler_allowed = $owner->level_info['level_styler_allowed'];
            $he_owner_mode = ($user->user_exists && $user->user_info['user_id'] == $owner->user_info['user_id']);
        break;
        case 'group':
            $he_page = 'group';
            $he_page_id = $group->group_info['group_id'];
            $he_page_owner_id = $group->group_info['group_user_id'];
            
            $he_styler_allowed = $group->groupowner_level_info['level_styler_allowed'];
            $he_owner_mode = ($user->user_exists && $group->group_exists && $group->user_rank == 2);
        break;
        case 'pages':
            $he_page = 'page';
            $he_page_id = $pages->page_info['pages_id'];
            $he_page_owner_id = $pages->page_owner->user_info['user_id'];
            
            $he_styler_allowed = $pages->page_owner->level_info['level_styler_allowed'];
            $he_owner_mode = ($user->user_exists && $pages->page_exists && $pages->is_owner);
        break;
        default:
        break;
    }
    
    if (!$he_styler_allowed) {
        return false;
    }
    
    $he_styler = new he_styler($he_page, $he_page_id, $he_page_owner_id);

    if ($he_owner_mode) {
        $he_styler->prepare_page();
    }
    else {
        $skin_info = $he_styler->get_page_skin();
        
        $smarty->assign('styler_page', $he_styler->page);
        $smarty->assign('styler_page_id', $he_styler->page_id);
        $smarty->assign('styler_default_skin_id', $he_styler->default_skin_id);

        $smarty->assign('skin_info', $skin_info);
        $smarty->assign('rand_code', time());

        $smarty->assign_hook('footer', 'he_styler_footer.tpl');
    }
}

function he_styler_page_group_hash($page = 'profile')
{
    $sql = he_database::placeholder("SELECT `se_he_styler_group`.* FROM `se_he_styler_group` "
        . "INNER JOIN `se_he_styler_section` ON (`se_he_styler_group`.`section_id`=`se_he_styler_section`.`id`) "
        . "WHERE `se_he_styler_section`.`page`='?'", $page);
        
    $group_list = he_database::fetch_array($sql);
    $group_list_str = json_encode($group_list);
    
    return md5($group_list_str);
}

function he_styler_page_group_rule_hash($page = 'profile')
{
    $sql = he_database::placeholder("SELECT `se_he_styler_group_rule`.* FROM `se_he_styler_group_rule` "
        . "INNER JOIN `se_he_styler_group` ON (`se_he_styler_group_rule`.`group_id`=`se_he_styler_group`.`id`) "
        . "INNER JOIN `se_he_styler_section` ON (`se_he_styler_group`.`section_id`=`se_he_styler_section`.`id`) "
        . "WHERE `se_he_styler_section`.`page`='?'", $page);

    $group_rules = he_database::fetch_array($sql);
    $group_rules_str = json_encode($group_rules);
    
    return md5($group_rules_str);
}

function he_styler_get_hash()
{
    $hash = array();
    
    $profile_hash = array();
    $group_hash = array();
    $page_hash = array();

    //Profile page
    $profile_hash['group'] = array(
        'cdb3641b648e561979ed296a314cce14',
        '151b2a4aee8f4c34027b2733985989a1',
        'f94ade1d89018693bfc4df6192e7df17',
    );
    
    $profile_hash['group_rule'] = array(
        '280cab97b3a8160317e5ba0cbbde85b1',
        '734e430a1df58fb8d64551a3a53aab0c',
    );
    
    //Group page
    $group_hash['group'] = array(
        'd751713988987e9331980363e24189ce',
        '5de9132f7662ef970767c5a499dc014d',
        'eaa00a5448a162eec27fd9928de0e265',
    );
    
    $group_hash['group_rule'] = array(
        'd751713988987e9331980363e24189ce',
        '94d395aa736a4f56b788876af5711804',
        '024e9f4e3bcf9e5560b5185cd2706fa3',
    );
    
    //Pages page
    $page_hash['group'] = array(
        'd751713988987e9331980363e24189ce',
        '28e872cadbff31288eabb171a4a41437',
        '8370f62e5b6c13f49ff108008e7f1c42',
    );
    
    $page_hash['group_rule'] = array(
        'd751713988987e9331980363e24189ce',
        '2ed71f4ac468129c28ead44284b6de8f',
        'edbf2974cc4b1e318fc3d291083a915a',
    );
    
    $hash = array('profile' => $profile_hash, 'group' => $group_hash, 'page' => $page_hash);
    
    return $hash;
}