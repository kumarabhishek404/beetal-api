<?php

class he_styler_import
{
    var $PACKAGE_ROOT_DIR = '../uploads_skin/';
    var $STYLER_ROOT_DIR = '../uploads_styler/';

    var $error = 0;
    var $package_dir = '';
    var $package_info = array();
     
    function setup()
    {
        $sql = "SHOW COLUMNS FROM `se_settings` LIKE 'setting_he_styler_skin_packages'";
        $resource = he_database::query($sql);
        
        if (!he_database::num_rows($resource)) {
            $sql = "ALTER TABLE `se_settings` ADD COLUMN `setting_he_styler_skin_packages` TEXT";
            he_database::query($sql);
        }
    }
    
    function get_installed_packages()
    {
        global $setting;
        
        if (!$setting['setting_he_styler_skin_packages']) {
            
            return array();
        }
        
        $installed_packages = explode(',', $setting['setting_he_styler_skin_packages']);
        $installed_packages = array_map('trim', $installed_packages);        
        
        return $installed_packages;
    }
    
    function get_uploaded_packages()
    {
        $packages = array();
        
        if ($dh = opendir($this->PACKAGE_ROOT_DIR)) {
            while (($file = readdir($dh)) !== false) {
                if ($file == '.' || $file == '..') {
                    continue;
                }
                
                $file_ext = array_pop(explode('.', $file));
                
                if ($file_ext == 'zip') {
                    $packages[] = $file;
                }
            }
        }
    
        closedir($dh);
        
        return $packages;
    }
    
    function import_package($filename)
    {        
        $this->validate_file($filename);
        
        if ($this->error) {
            
            return false;
        }
        
        $this->create_package_dir();

        if ($this->package_dir == '') {
            $this->error = 690702145;
            
            return false;
        }
        
        $this->extract_package($_FILES[$filename]['tmp_name']);
        
        if ($this->error) {
            
            return false;
        }
        
        $this->fetch_package_info();
        
        if ($this->error) {
            $this->delete_directory($this->package_dir);
            
            return false;
        }
        
        $this->install_package();

        $this->delete_directory($this->package_dir);
    }
    
    function import_uploaded_package($package)
    {
        $this->create_package_dir();

        if ($this->package_dir == '') {
            $this->error = 690702145;
            
            return false;
        }
        
        $this->extract_package($this->PACKAGE_ROOT_DIR . $package);
        
        if ($this->error) {
            
            return false;
        }
        
        $this->fetch_package_info();
        
        if ($this->error) {
            $this->delete_directory($this->package_dir);
            
            return false;
        }
        
        $this->install_package();

        $this->delete_directory($this->package_dir);
        
        @unlink($this->PACKAGE_ROOT_DIR . $package);
    }

    function validate_file($filename)
    {
        $file_info = $_FILES[$filename];
        
        if (!isset($file_info) || !is_uploaded_file($file_info['tmp_name'])) {
            $this->error = 690702155;
                 
            return false;
        }
        
        $file_name = explode('.', $file_info['name']);
        $file_extension = array_pop($file_name);

        if ($file_extension != 'zip') {
            $this->error = 690702146;
                    
            return false;
        }
    }
    
    function create_package_dir()
    {    
        //create package folder 
        $first_dir = $this->PACKAGE_ROOT_DIR . 'package';
        $package_dir = $first_dir . '_0';

        $index = 1;
        while ( is_dir($package_dir) )
        {
            $package_dir = $first_dir . '_' . $index++;
        }
        
        if (!@mkdir($package_dir, 0777)) {
            
            return '';
        }
        
        $this->package_dir = $package_dir;        
        @chmod($this->package_dir, 0777);
    }
    
    function extract_package($archive_path)
    {
        if (!extension_loaded('zlib')) {
            $this->error = 690702147;
        }
        
        $zip = new PclZip($archive_path);
        $result = $zip->extract(PCLZIP_OPT_PATH, $this->package_dir);
        
        if ($result == 0) {
            $this->error = 690702148;
            
            $this->delete_directory($this->package_dir);
        }
    }
    
	function delete_directory($dir)
	{
		if (!file_exists($dir)) {
		    return true;
		}
		
		if (!is_dir($dir) || is_link($dir)) {
		    return @unlink($dir);
		}

		if ($res = @opendir($dir)) {
			while (($item = readdir($res)) !== false) {
				if ($item == '.' || $item == '..') {
				    continue;
				}
				
				if (!$this->delete_directory($dir . "/" . $item)) {
					@chmod($dir . "/" . $item, 0777);
					if (!$this->delete_directory($dir . "/" . $item)) {
					    return false;
					}
				}
			}
			
			closedir($res);
		}

		return @rmdir($dir);
	}
	
	function fetch_package_info()
	{
        $package_info_file = $this->package_dir . '/skins_info.txt';
	    
        if (!@file_exists($package_info_file) ) {
            $this->error = 690702149;
            
            return false;
        }
    
        $file_res = @fopen($package_info_file, 'r');
        $skin_info_str = @fread($file_res, filesize($package_info_file));
        
        @fclose($file_res);
        
        if (!$skin_info_str) {
            $this->error = 690702149;
            
            return false;
        }

        $skin_info = json_decode($skin_info_str, true);
                    
        if (!$skin_info) {
            $this->error = 690702149;
            
            return false;
        }
        
        $this->package_info = $skin_info;
	}
	
	function install_package()
	{
        global $setting;

        $package_uid = $this->package_info['info']['uid'];
        
        $package_dir = $this->package_dir . DIRECTORY_SEPARATOR;
        $styler_dir = $this->STYLER_ROOT_DIR;
        
	    $installed_packages = $this->get_installed_packages();

        if (in_array($package_uid, $installed_packages)) {
            $this->error = 690702150;
            
            return false;
        }
        
        $new_skin_ids = $this->import_skins($package_dir, $styler_dir);
        
        if (!$new_skin_ids) {
        	$this->error = 690702149;
        	
        	return false;
        }
        
        $this->import_skin_values($package_dir, $styler_dir, $new_skin_ids);
        
        $setting['setting_he_styler_skin_packages'] .= ',' . $package_uid;
        $query = he_database::placeholder( "UPDATE `se_settings` SET `setting_he_styler_skin_packages`='?'",
            $setting['setting_he_styler_skin_packages'] );
        
        he_database::query($query);
	}
	
	function import_skins($package_dir, $styler_dir)
	{
        $skins = $this->package_info['skins'];
        
        $new_skin_ids = array();

        foreach ($skins as $skin_id => $skin_info) {

            $skin_info['page'] = ( $skin_info['page'] ) ? $skin_info['page'] : 'profile';
            $query = he_database::placeholder( "INSERT INTO `se_he_styler_skin` (`user_id`, `name`,
                `create_stamp`, `shared`, `ready`, `changed`, `approved`, `page`)
                VALUES (0, '?', ?, 1, 1, 1, 1, '?')", $skin_info['name'], $skin_info['create_stamp'], $skin_info['page'] );
    
            he_database::query($query);
   
            $new_skin_id = he_database::insert_id();
            $new_skin_ids[$skin_id] = $new_skin_id;
    
            if ($skin_info['photo'] && file_exists($package_dir . $skin_info['photo'])) {
                $new_skin_photo = str_replace("skin_photo_{$skin_id}.", "skin_photo_{$new_skin_id}.", $skin_info['photo']);
                
                copy($package_dir . $skin_info['photo'], $styler_dir . $new_skin_photo);
    
                $skin_info['photo'] = $new_skin_photo;
            } else {
                $skin_info['photo'] = '';
            }
    
            if ($skin_info['css']) {
                $skin_info['css'] = str_replace("bg_image_{$skin_id}_", "bg_image_{$new_skin_id}_", $skin_info['css']);
            }
    
            $query = he_database::placeholder( "UPDATE `se_he_styler_skin` SET `photo`='?', `css`='?'
                WHERE `id`=?", $skin_info['photo'], $skin_info['css'], $new_skin_id );
    
            he_database::query($query);
        }
        
        return $new_skin_ids;
	}
	
	function import_skin_values($package_dir, $styler_dir, $new_skin_ids)
	{
	    $skin_values = $this->package_info['values'];
        $skin_values_sql = '';

        foreach ($skin_values as $value_info ) {
            $skin_id = $value_info['skin_id'];
            $new_skin_id = $new_skin_ids[$value_info['skin_id']];
            $background_image = ($value_info['background_image'] && $value_info['background_image']!='none'); 

            if ($background_image && file_exists($package_dir . $value_info['background_image'])) {
                $new_filename = str_replace("bg_image_{$skin_id}_", "bg_image_{$new_skin_id}_", $value_info['background_image']);
                
                copy($package_dir . $value_info['background_image'], $styler_dir . $new_filename);
            
                $value_info['background_image'] = $new_filename;
            } else {
                $value_info['background_image'] = '';
            }
            
            $skin_values_sql .= he_database::placeholder( "(?, ?, '?', '?', '?', '?', '?', '?', '?', '?', '?', '?'),",
                $new_skin_id, $value_info['group_id'], $value_info['background_color'], $value_info['background_image'],
                $value_info['background_position'], $value_info['background_repeat'], $value_info['font_color'],
                $value_info['font_family'], $value_info['font_size'], $value_info['border_color'],
                $value_info['border_style'], $value_info['border_width'] );
        }

        if ($skin_values_sql) {
            $skin_values_sql = substr($skin_values_sql, 0, -1);

            $query = "INSERT INTO `se_he_styler_value` (`skin_id`, `group_id`, `background_color`,
                `background_image`, `background_position`, `background_repeat`, `font_color`, `font_family`, `font_size`,
                `border_color`, `border_style`, `border_width`) VALUES $skin_values_sql";
            
            he_database::query($query);
        }
	}
}
