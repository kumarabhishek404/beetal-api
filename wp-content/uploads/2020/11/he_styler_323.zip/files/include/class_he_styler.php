<?php

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version Styler 3.1
 */

class he_styler
{
    var $page = 'profile';
    var $page_id = 0;
    var $page_owner_id = 0;
    var $default_skin_id = 1;

    function he_styler( $page = 'profile', $page_id = 0, $page_owner_id = 0)
    {
        $this->page = $page;
        $this->page_id = $page_id;
        $this->page_owner_id = $page_owner_id;

        if ($this->page_owner_id == 0) {
            $this->set_styler_owner_id();
        }

            $this->default_skin_id = $this->find_default_skin_id();
        }

    function find_sections()
    {
        $query = he_database::placeholder( "SELECT * FROM `se_he_styler_section` 
            WHERE `page`='?' ORDER BY `order`", $this->page );

        return he_database::fetch_array($query, 'id');
    }

    function find_groups()
    {
        $query = he_database::placeholder( "SELECT `g`.* FROM `se_he_styler_group` AS `g` 
            INNER JOIN `se_he_styler_section` AS `s` ON (`g`.`section_id`=`s`.`id`)
            WHERE `s`.`page`='?' ORDER BY `order`", $this->page );

        return he_database::fetch_array($query, 'id');
    }

    function default_skin()
    {
        $query = he_database::placeholder( "SELECT * FROM `se_he_styler_skin` 
            WHERE `default`=1 AND `page`='?' LIMIT 1", $this->page );
        
        $skin_info = he_database::fetch_row($query);

        return $skin_info;
    }

    function make_skin( $skin_info, $force_create = false )
    {
        global $user;

        if ( !$skin_info || !$user->user_exists )
        {
            return false;
        }
        
        $query = he_database::placeholder( "SELECT `id`, `name` FROM `se_he_styler_skin`
            WHERE " . $this->page_where() . " AND `changed`=0 AND `parent_id`=?", $skin_info['id'] );
        $skin_exists = he_database::fetch_row($query);
        
        if ( $skin_exists && !$force_create )
        {
            return $skin_exists;
        }
 
        $new_skin_id = $this->new_skin();

        $skin_values = $this->get_skin_value($skin_info['id']);

        foreach ( $skin_values as $key => $value_info )
        {
            if ( !$value_info['group_id'] )
            {
                continue;
            }

            //copy image
            if ( $value_info['background_image'] && $value_info['background_image'] != 'none' )
            {
                $background_image = explode('.', $value_info['background_image']);
                $new_filename = "bg_image_{$new_skin_id}_{$value_info['group_id']}.{$background_image[1]}";

                $file_src = './uploads_styler/'.$value_info['background_image'];
                $new_file_src = './uploads_styler/'.$new_filename;

                $file_exists = file_exists($file_src);

                if ( $file_exists && copy($file_src, $new_file_src) )
                {
                    $value_info['background_image'] = $new_filename;
                }
            }
            else
            {
                $value_info['background_image'] = 'none';    
            }

            $skin_values[$key] = $value_info;
        }

        $this->save_skin($new_skin_id, $skin_info['name'], $skin_values);

        $new_skin_info = array();
        $new_skin_info['id'] = $new_skin_id;
        $new_skin_info['name'] = $skin_info['name'];

        return $new_skin_info;
    }

    function get_group_rules()
    {
        $query = he_database::placeholder( "SELECT `r`.* FROM `se_he_styler_group_rule` AS `r`
            INNER JOIN `se_he_styler_group` AS `g` ON(`r`.`group_id`=`g`.`id`)
            INNER JOIN `se_he_styler_section` AS `s` ON(`g`.`section_id`=`s`.`id`)  
            WHERE `s`.`page`=?", $this->page );

        $res = he_database::query($query);

        $rules = array();
        while ( $row = he_database::fetch_row_from_resource($res) )
        {
            $rules[$row['group_id']][$row['tool_key']] = array(
                'js_selector' => $row['js_selector'],
                'css_selector' => $row['css_selector']
            );
        }

        return $rules;
    }

    function get_section_list()
    {
        $section_list = $this->find_sections();

        if ( !$section_list )
        {
            return array();
        }
        
        $group_list = $this->find_groups();

        if ( !$group_list )
        {
            return array();
        }

        foreach ($group_list as $group)
        {
            $section_list[$group['section_id']]['groups'][] = $group;
        }

        return $section_list;
    }

    function get_page_skin()
    {        
        $query = "SELECT COUNT(*) FROM `se_he_styler_skin` WHERE " . $this->page_where() . " AND `active`=1";

        if ( he_database::fetch_field($query)==0 )
        {
            $this->new_skin();
        }

        $query = "SELECT * FROM `se_he_styler_skin` WHERE " . $this->page_where() . " AND `active`=1";

        return he_database::fetch_row($query);
    }

    function new_skin()
    {
        global $setting, $user;
        
        $query = "UPDATE `se_he_styler_skin` SET `active`=0 WHERE " . $this->page_where() . " AND `active`=1";

        he_database::query($query);

        $query = he_database::placeholder( "INSERT INTO `se_he_styler_skin` 
            (`user_id`, `page`, `page_id`, `create_stamp`, `active`, `parent_id`, `approved`)
            VALUES(?, '?', ?, ?, ?, ?, ?)", $this->page_owner_id, $this->page,
            $this->page_id, time(), 1, $this->default_skin_id, $setting['setting_he_styler_approval_status'] );

        he_database::query($query);

        return he_database::insert_id();
    }

    function get_skin_value( $skin_id )
    {
        if ( !$skin_id )
        {
            return array();
        }

        $query = he_database::placeholder( "SELECT g.`id`, v.* FROM `se_he_styler_group` AS g
            LEFT JOIN (
                SELECT * FROM `se_he_styler_value` WHERE `skin_id`=? OR `skin_id` IS NULL
            ) AS `v`
            ON (g.`id`=`v`.`group_id`)
            INNER JOIN `se_he_styler_section` AS s
            ON (g.`section_id`=s.`id` AND s.`page`='?')", $skin_id, $this->page );

        $res = he_database::query($query);

        $group_values = array();
        while ( $row = he_database::fetch_row_from_resource($res) )
        {
            $row['group_id'] = ($row['group_id']) ? $row['group_id'] : $row['id'];
            $row['skin_id'] = ($row['skin_id']) ? $row['skin_id'] : $skin_id;

            $group_values[$row['group_id']] = $row;
        }

        return $group_values;
    }

    function delete_bg_image( $skin_id, $group_id )
    {
        if ( !$skin_id || !$group_id )
        {
            return false;
        }

        $query = he_database::placeholder( "UPDATE `se_he_styler_value` SET `background_image`='none'
            WHERE `skin_id`=? AND `group_id`=?", $skin_id, $group_id );

        he_database::query($query);
    }

    function save_bg_image( $skin_id, $group_id, $file_name )
    {
        if ( !$skin_id || !$group_id || !$file_name )
        {
            return false;
        }

        $query = he_database::placeholder( "SELECT COUNT(*) FROM `se_he_styler_value` 
            WHERE `skin_id`=? AND `group_id`=?", $skin_id, $group_id );

        if ( he_database::fetch_field($query) )
        {
            $query = he_database::placeholder( "UPDATE `se_he_styler_value` SET `background_image`='?'
                WHERE `skin_id`=? AND `group_id`=?", $file_name, $skin_id, $group_id );
        }
        else
        {
            $query = he_database::placeholder( "INSERT INTO `se_he_styler_value` (`skin_id`, `group_id`, `background_image`)
                VALUES (?, ?, '?')", $skin_id, $group_id, $file_name );
        }

        he_database::query($query);
    }

    function find_skin( $skin_id )
    {
        if ( !$skin_id )
        {
            return array();
        }

        $query = he_database::placeholder( "SELECT * FROM `se_he_styler_skin`
            WHERE `id`=? AND `page`='?'", $skin_id, $this->page );

        return he_database::fetch_row($query);
    }
    
    function find_admin_shared_skins( $first = 0, $count = 15 )
    {
        $query = he_database::placeholder( "SELECT `s`.*, `u`.`user_username` FROM `se_he_styler_skin` AS `s`
            LEFT JOIN `se_users` AS `u` ON (`s`.`user_id`=`u`.`user_id`)
            WHERE `shared`=1 and `s`.`user_id`!=0 
            LIMIT ?, ?", $first, $count );
        
        return he_database::fetch_array($query);
    }

    function find_admin_default_skins( $first = 0, $count = 15 ) 
    {
        $query = he_database::placeholder( "SELECT * FROM `se_he_styler_skin`
            WHERE `default` !=  1 and `user_id`=0 
            LIMIT ?, ?", $first, $count );
        
        return he_database::fetch_array($query);
    }

    function get_page_skin_history( $first = 0, $count = 7 )
    {
        $query = he_database::placeholder( "SELECT `id`, `name`, `photo`, IF((`parent_id`=? AND `changed`=0), 1, 0) AS `default_skin`
            FROM `se_he_styler_skin` 
            WHERE " . $this->page_where() . " AND `ready`=1 AND `shared`=0
            ORDER BY `id`
            LIMIT ?, ?", $this->default_skin_id, $first, $count );

        $res = he_database::query($query);
        $skins = array();
        while( $row = he_database::fetch_row_from_resource($res) )
        {
            $row['css_href'] = './he_styler_uploader.php?task=get_skin&skin_id=' . $row['id'] . '&no_cache=' . rand();
            $skins[$row['id']] = $row;    
        }

        $query = "SELECT COUNT(*) FROM `se_he_styler_skin` 
            WHERE " . $this->page_where() . " AND `ready`=1 AND `shared`=0";

        $total_count = he_database::fetch_field($query);

        return array( 'count' => $total_count, 'skins' => $skins ); 
    }

    function get_shared_skins( $first = 0, $count = 7 )
    {
        $query = he_database::placeholder( "SELECT `id`, `name`, `photo`, `approved`, `user_id` FROM `se_he_styler_skin`
            WHERE `page`='?' AND `shared`=1 AND `ready`=1 AND `approved`=1
            ORDER BY `id`
            LIMIT ?, ?", $this->page, $first, $count );

        $res = he_database::query($query);
        $skins = array();
        while( $row = he_database::fetch_row_from_resource($res) )
        {
            $row['css_href'] = './he_styler_uploader.php?task=get_skin&skin_id=' . $row['id'] . '&no_cache=' . rand();
            $skins[$row['id']] = $row;
        }

        $query = he_database::placeholder( "SELECT COUNT(*) FROM `se_he_styler_skin` 
            WHERE `page`='?' AND `shared`=1 AND `ready`=1 AND `approved`=1", $this->page );

        $total_count = he_database::fetch_field($query);

        return array( 'count' => $total_count, 'skins' => $skins );
    }

    function save_skin( $skin_id, $name, $values, $changed = 0 )
    {
        global $user;
        
        if ( !$skin_id || !$name || !$values )
        {
            return false;
        }
        
        $skin_info = $this->find_skin($skin_id);
        
        if ( !$skin_info || $skin_info['user_id']!=$user->user_info['user_id'] )
        {
            return false;
        }

        $values_str = '';

        foreach ( $values as $value )
        {
            if ( !$value['group_id'] )
            {
                continue;
            }

            $values_str .= he_database::placeholder( "(?, ?, '?', '?', '?', '?', '?', '?', '?', '?', '?', '?'),",
                $skin_id,
                isset($value['group_id']) ? $value['group_id'] : '',
                isset($value['background_color']) ? $value['background_color'] : '',
                isset($value['background_image']) ? $value['background_image'] : 'none',
                isset($value['background_position']) ? $value['background_position'] : '',
                isset($value['background_repeat']) ? $value['background_repeat'] : '',
                isset($value['font_color']) ? $value['font_color'] : '',
                isset($value['font_family']) ? $value['font_family'] : '',
                isset($value['font_size']) ? $value['font_size'] : '',
                isset($value['border_color']) ? $value['border_color'] : '',
                isset($value['border_style']) ? $value['border_style'] : '',
                isset($value['border_width']) ? $value['border_width'] : ''
            );
        }

        $query = he_database::placeholder( "DELETE FROM `se_he_styler_value` WHERE `skin_id`=?", $skin_id );
        he_database::query($query);

        if ( strlen($values_str)==0 )
        {
            return true;
        }

        $values_str = substr($values_str, 0, -1);

        $query = "INSERT INTO `se_he_styler_value` (
            `skin_id`,
            `group_id`,
            `background_color`,
            `background_image`,
            `background_position`,
            `background_repeat`,
            `font_color`,
            `font_family`,
            `font_size`,
            `border_color`,
            `border_style`,
            `border_width` ) VALUES $values_str";

        he_database::query($query);

        $skin_css = $this->generate_css($skin_id);

        $query = he_database::placeholder( "UPDATE `se_he_styler_skin` SET `name`='?', `css`='?', `changed`=?, `ready`=1
            WHERE `id`=?", $name, $skin_css, $changed, $skin_id );

        he_database::query($query);

        return true;
    }

    function get_skin_css( $skin_id )
    {
        if ( !$skin_id )
        {
            return '';
        }

        $query = he_database::placeholder( "SELECT `css` FROM `se_he_styler_skin` WHERE `id`=?", $skin_id );

        return he_database::fetch_field($query);
    }

    function generate_css( $skin_id )
    {
        if ( !$skin_id )
        {
            return false;
        }

        $groups = $this->find_groups();
        $group_rules = $this->get_group_rules();
        $skin_values = $this->get_skin_value($skin_id);

        $output_css = '';
        foreach ( $groups as $group_id => $group )
        {
            $group_css = '';
            $group_custom_css = '';
            $value = ( $skin_values[$group_id] ) ? $skin_values[$group_id] : array();
            $rule = ( $group_rules[$group_id] ) ? $group_rules[$group_id] : array();
            
            if ( !$value )
            {
                continue;
            }

            $styles = array( 
                'background_color' => 'background-color',
                'background_position' => 'background-position',
                'background_repeat' => 'background-repeat',
                'font_color' => 'color',
                'font_family' => 'font-family',
                'font_size' => 'font-size',
                'border_color' => 'border-color',
                'border_style' => 'border-style',
                'border_width'  => 'border-width' );

            foreach ( $styles as $key => $style )
            {
                if ( $group[$key] &&  $value[$key] && $rule[$key] )
                {
                    $group_custom_css .= "{$rule[$key]['css_selector']} { $style: {$value[$key]}; }\n\r";
                }
                elseif ( $group[$key] &&  $value[$key] )
                {
                    $group_css .= "$style: {$value[$key]};";
                }
            }

            if ( $group['background_image'] && $value['background_image'] && $rule['background_image'] )
            {
                $bg_image_value = ( $value['background_image']!='none' )
                    ? "url('./uploads_styler/{$value['background_image']}')"
                    : 'none';
                $group_custom_css .= "{$rule['background_image']['css_selector']} { background-image: $bg_image_value; }\n\r";
            }
            elseif ( $group['background_image'] && $value['background_image'] )
            {
                $bg_image_value = ( $value['background_image']!='none' )
                    ? "url('./uploads_styler/{$value['background_image']}')"
                    : 'none';
                $group_css .= "background-image: $bg_image_value;";
            }

            $group_css = ( $group_css ) ? "{$group['css_selector']} { $group_css }\n\r" : '';
            $output_css .= $group_css . $group_custom_css;
        }

        return $output_css;
    }

    function select_skin( $user_id, $skin_id )
    {
        if ( !$skin_id )
        {
            return false;
        }

        $query = "UPDATE `se_he_styler_skin` SET `active`=0 WHERE " . $this->page_where();

        he_database::query($query);

        //check if page owner
        $query = he_database::placeholder( "SELECT 1 FROM `se_he_styler_skin`
            WHERE `id`=? AND " . $this->page_where() . " AND `shared`=0", $skin_id );

        $is_owner = he_database::fetch_field($query);

        if ( $is_owner )
        {
            $query = he_database::placeholder( "UPDATE `se_he_styler_skin` SET `active`=1
                WHERE `id`=? AND " . $this->page_where(), $skin_id );

            he_database::query($query);

            return $skin_id;
        }

        $query = he_database::placeholder( "SELECT `id` FROM `se_he_styler_skin`
            WHERE " . $this->page_where() . " AND `parent_id`=? AND `changed`=0", $skin_id );

        $old_skin_id = he_database::fetch_field($query);
        $this->delete_skin($old_skin_id);

        $skin_info = $this->find_skin($skin_id);
        
        $new_skin = $this->make_skin($skin_info);

        $skin_photo = '';
        
        //copy skin photo
        if ( $skin_info['photo'] )
        {
            $files_dir = './uploads_styler/';
            $skin_photo = str_replace('skin_photo_' . $skin_id, 'skin_photo_' . $new_skin['id'], $skin_info['photo']);
            @copy($files_dir . $skin_info['photo'], $files_dir . $skin_photo );
        }

        $query = he_database::placeholder( "UPDATE `se_he_styler_skin` SET `parent_id`=?, `photo`='?', `active`=1
            WHERE `id`=? AND " . $this->page_where(), $skin_id, $skin_photo, $new_skin['id'] );

        he_database::query($query);

        return $new_skin['id'];
    }

    function delete_skin( $skin_id )
    {
        if ( !$skin_id )
        {
            return false;
        }

        $skin_info = $this->find_skin($skin_id);

        //delete files
        $files_dir = './uploads_styler/';

        $query = he_database::placeholder( "SELECT `background_image` FROM `se_he_styler_value`
            WHERE `skin_id`=?", $skin_id );
        $res = he_database::query($query);
        while( $filename = he_database::fetch_row_from_resource($res) )
        {
            if ( strstr($filename, "bg_image_{$skin_id}_")===false )
            {
                continue;
            }

            @unlink($files_dir . $filename);
        }

        //delete skin photo
        if ( $skin_info['photo'] )
        {
            @unlink($files_dir . $skin_info['photo']);   
        }

        $query = he_database::placeholder( "DELETE FROM `se_he_styler_value`
            WHERE `skin_id`=?", $skin_id );

        he_database::query($query);

        $query = he_database::placeholder( "DELETE FROM `se_he_styler_skin`
            WHERE `id`=?", $skin_id );

        he_database::query($query);
    }

    function share_skin( $skin_id, $name, $filename )
    {
        if ( !$skin_id || !$name || !$filename )
        {
            return false;
        }

        $skin_info = $this->find_skin($skin_id);

        $query = he_database::placeholder( "UPDATE `se_he_styler_skin` SET `name`='?', `photo`='?', `posted_stamp`=?,
            `shared`=1, `active`=0 WHERE `id`=?", $name, $filename, time(), $skin_id );
        he_database::query($query);

        $new_skin_info = $this->make_skin($skin_info, true);

        $query = he_database::placeholder( "UPDATE `se_he_styler_skin` SET `create_stamp`=?, `active`=?,
            `ready`=?, `changed`=? WHERE `id`=?", $skin_info['create_stamp'], $skin_info['active'], $skin_info['ready'],
            $skin_info['changed'], $new_skin_info['id'] );

        he_database::query($query);

        return $this->find_skin($new_skin_info['id']);
    }

    function find_shared_skin_count()
    {
        $query = he_database::placeholder( "SELECT COUNT(*) FROM `se_he_styler_skin` 
            WHERE `page`='?' AND `shared`=1 AND `ready`=1 AND `approved`=1", $this->page );

        return he_database::fetch_field($query);
    }
    
    function find_admin_shared_skin_count()
    {
        $query = "SELECT COUNT(*) FROM `se_he_styler_skin` WHERE `shared`=1 AND `ready`=1 AND `user_id`!=0";

        return he_database::fetch_field($query);
    }

    function find_admin_default_skin_count()
    {
        $query = "SELECT COUNT(*) FROM `se_he_styler_skin` WHERE `user_id`=0 AND `default`!=1";

        return he_database::fetch_field($query);
    }

    function find_page_history_skin_count()
    {
        global $user;
        
        $query = "SELECT COUNT(*) FROM `se_he_styler_skin` WHERE " . $this->page_where() . " AND `ready`=1 AND `shared`=0";

        return he_database::fetch_field($query);
    }
    
    function set_approved( $approved, $skin_id )
    {
        $query = he_database::placeholder("UPDATE `se_he_styler_skin` SET `approved`=? WHERE `id`=?", $approved, $skin_id);
        
        he_database::query($query);
    }
    
    function find_default_skin_id()
    {
        $query = he_database::placeholder( "SELECT `id` FROM `se_he_styler_skin`
           WHERE `shared`=1 AND `default`=1 AND `page`='?' LIMIT 1", $this->page );
        
        return he_database::fetch_field($query);
    }
    
    function prepare_page()
    {        
        global $smarty;
        
        $section_list = $this->get_section_list();
        $group_list = $this->find_groups();
        $group_rules = $this->get_group_rules();
        
        $skin_info = $this->get_page_skin();
        $group_values = $this->get_skin_value($skin_info['id']);
        
        $history_skins = $this->get_page_skin_history();
        $shared_skins = $this->get_shared_skins();
    
        $smarty->assign('styler_page', $this->page);
        $smarty->assign('styler_page_id', $this->page_id);
        $smarty->assign('styler_default_skin_id', $this->default_skin_id);
        
        $smarty->assign('shared_skins', $shared_skins);
        $smarty->assign('shared_skins_js', json_encode($shared_skins));

        $smarty->assign('history_skins', $history_skins);
        $smarty->assign('history_skins_js', json_encode($history_skins));
    
        $smarty->assign('skin_info', $skin_info);
        $smarty->assign('section_list', $section_list);
    
        $smarty->assign('group_list_js', json_encode($group_list));
        $smarty->assign('group_values_js', json_encode($group_values));
        $smarty->assign('group_rules_js', json_encode($group_rules));
        
        $smarty->assign('rand_code', time());
        $smarty->assign('he_styler_enable', true);

        $smarty->assign_hook('footer', 'he_styler_footer.tpl');
    }
    
    function page_where( $alias = '' )
    {
        return he_database::placeholder( "$alias`page`='?' AND $alias`page_id`=?", $this->page, $this->page_id );
    }
    
    function set_styler_owner_id()
    {
        if (!$this->page || !$this->page_id) {
            return 0;
        }
        
        switch ($this->page) {
            case 'profile':
                $this->page_owner_id = $this->page_id;
            break;
            
            case 'group':
                $sql = he_database::placeholder("SELECT `group_user_id` FROM `se_groups` WHERE `group_id`=?", $this->page_id);
                $this->page_owner_id = (int)he_database::fetch_field($sql);
            break;

            case 'page':
                $sql = he_database::placeholder("SELECT `pages_owner_id` FROM `se_he_pages` WHERE `pages_id`=?", $this->page_id);
                $this->page_owner_id = (int)he_database::fetch_field($sql);
            break;
                
            default:
            break;
        }
    }
}
