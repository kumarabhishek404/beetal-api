<?php

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version Styler 1.01
 */

defined('SE_PAGE') or exit();

include_once "./header_he_core.php";
include_once "./include/class_he_styler.php";
include_once "./include/functions_he_styler.php";


if ( $user->user_exists && $user->user_info['user_id']==$owner->user_info['user_id'] 
    && $page=="profile" && $user->level_info['level_styler_allowed'] )
{
    $plugin_vars['menu_profile_side'] = array( 
        'file' => 'profile_he_styler.tpl', 
        'title' => 690690038, 
        'name' => 'he_styler');
}

// Use new template hooks
if ( is_a($smarty, 'SESmarty') )
{
    if( !empty($plugin_vars['menu_profile_side']) )
    {
        $smarty->assign_hook('profile_side', $plugin_vars['menu_profile_side']);
    }
}

SE_Hook::register('se_footer', 'he_styler_prepare_page');

?>