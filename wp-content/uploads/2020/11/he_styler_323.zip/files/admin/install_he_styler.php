<?php

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version Styler 3.22
 */

if (!class_exists('he_database')) {
    include_once '../include/class_he_database.php';
}
if (!function_exists('he_styler_page_group_hash')) {
    include_once '../include/functions_he_styler.php';
}

$plugin_name = "Professional Styler Plugin";
$plugin_version = "3.23";
$req_core_version = "3.01";
$plugin_type = "he_styler";
$plugin_desc = "Professional Profile Styler is a powerful and the same time user-friendly plugin. It allows your users to easily customize profile page on the fly(like on Tagged) and create profile skins and share them to community. It is a paid plugin from Hire-Experts LLC.";
$plugin_icon = "he_styler_icon.png";
$plugin_menu_title = "690702071";
$plugin_pages_main = "690702071<!>he_styler_icon.png<!>admin_viewskins.php<~!~>690702102<!>he_styler_icon.png<!>admin_styler_import.php<~!~>";
$plugin_pages_level = "690702092<!>admin_levels_stylersettings.php<~!~>";
$plugin_db_charset = 'utf8';
$plugin_db_collation = 'utf8_unicode_ci';
$plugin_reindex_totals = TRUE;


if( $install=="he_styler" )
{
    //check core library
    $sql = "SELECT `plugin_version` FROM `se_plugins` WHERE plugin_type='he_core' AND `plugin_disabled`=0 LIMIT 1";
    $resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
    $core_version = $database->database_fetch_array($resource);
    if ( floatval($core_version[0]) < floatval($req_core_version) ) {
        die ('This plugin requires Hire-Experts Core Library. Please install latest version of Hire-Experts Core Library plugin. You can download it from My Plugins section in Hire-Experts.com for FREE.');
    }
    //######### GET CURRENT PLUGIN INFORMATION
    $sql = "SELECT * FROM se_plugins WHERE plugin_type='{$plugin_type}' LIMIT 1";
    $resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");

    $plugin_info = array();
    if( $database->database_num_rows($resource) )
        $plugin_info = $database->database_fetch_assoc($resource);


    //######### INSERT ROW INTO se_plugins
    $sql = "SELECT NULL FROM se_plugins WHERE plugin_type='$plugin_type'";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);

    if( !$database->database_num_rows($resource) )
    {
        $sql = "
      INSERT INTO se_plugins (
        plugin_name,
        plugin_version,
        plugin_type,
        plugin_desc,
        plugin_icon,
        plugin_menu_title,
        plugin_pages_main,
        plugin_pages_level,
        plugin_url_htaccess
      ) VALUES (
        '$plugin_name',
        '$plugin_version',
        '$plugin_type',
        '".str_replace("'", "\'", $plugin_desc)."',
        '$plugin_icon',
        '$plugin_menu_title',
        '$plugin_pages_main',
        '$plugin_pages_level',
        ''
      )
    ";

        $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    }

    //######### UPDATE PLUGIN VERSION IN se_plugins
    else
    {
        $sql = "
        UPDATE
            se_plugins
        SET
            plugin_name='$plugin_name',
            plugin_version='$plugin_version',
            plugin_desc='".str_replace("'", "\'", $plugin_desc)."',
            plugin_icon='$plugin_icon',
            plugin_menu_title='$plugin_menu_title',
            plugin_pages_main='$plugin_pages_main',
            plugin_pages_level='$plugin_pages_level',
            plugin_url_htaccess=''
        WHERE
            plugin_type='$plugin_type'
    ";

        $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    }

    //######### CREATE se_he_styler_section
    $sql = "SHOW TABLES FROM `$database_name` LIKE 'se_he_styler_section'";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);

    if( !$database->database_num_rows($resource) )
    {
        $sql = "
        CREATE TABLE `se_he_styler_section` (
          `id` int(11) NOT NULL auto_increment,
          `label` int(11) unsigned NOT NULL,
          `order` int(11) NOT NULL default '1',
          `page` varchar(255) NOT NULL default 'profile',
          PRIMARY KEY  (`id`)
        ) ENGINE=MyISAM DEFAULT CHARSET=utf8;
    ";

        $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    }

    //######### ADD COLUMNS/VALUES TO se_he_styler_section
    $sql = "SHOW COLUMNS FROM `$database_name`.`se_he_styler_section` LIKE 'page'";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    
    if( !$database->database_num_rows($resource) )
    {
        $sql = "ALTER TABLE `se_he_styler_section` ADD COLUMN `page` VARCHAR(255) NOT NULL DEFAULT 'profile'";
        $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    }
    
    
    //######### CREATE se_he_styler_group
    $sql = "SHOW TABLES FROM `$database_name` LIKE 'se_he_styler_group'";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);

    if( !$database->database_num_rows($resource) )
    {
        $sql = "
        CREATE TABLE `se_he_styler_group` (
          `id` int(11) NOT NULL auto_increment,
          `section_id` int(11) unsigned NOT NULL,
          `label` int(11) unsigned NOT NULL,
          `js_selector` text NOT NULL,
          `css_selector` text NOT NULL,
          `background_color` tinyint(1) NOT NULL default '0',
          `background_image` tinyint(1) NOT NULL default '0',
          `background_position` tinyint(1) NOT NULL default '0',
          `background_repeat` tinyint(1) NOT NULL default '0',
          `font_color` tinyint(1) NOT NULL default '0',
          `font_family` tinyint(1) NOT NULL default '0',
          `font_size` tinyint(1) NOT NULL default '0',
          `font_size_tool` tinyint(4) NOT NULL default '1',
          `border_color` tinyint(1) NOT NULL default '0',
          `border_style` tinyint(1) NOT NULL default '0',
          `border_width` tinyint(1) NOT NULL default '0',
          `order` int(11) NOT NULL default '1',
          PRIMARY KEY  (`id`)
        ) ENGINE=MyISAM DEFAULT CHARSET=utf8;
        ";

        $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);    
    }
   

    //######### CREATE se_he_styler_group_rule
    $sql = "SHOW TABLES FROM `$database_name` LIKE 'se_he_styler_group_rule'";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);

    if( !$database->database_num_rows($resource) )
    {
        $sql = "
        CREATE TABLE `se_he_styler_group_rule` (
          `group_id` int(11) unsigned NOT NULL,
          `tool_key` varchar(255) NOT NULL,
          `js_selector` text NOT NULL,
          `css_selector` text NOT NULL,
          UNIQUE KEY `group_id` (`group_id`,`tool_key`)
        ) ENGINE=MyISAM DEFAULT CHARSET=utf8
        ";

        $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    }

    $sql = "ALTER TABLE `se_he_styler_group_rule` MODIFY COLUMN `js_selector` TEXT COLLATE utf8_general_ci NOT NULL";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    
    $sql = "ALTER TABLE `se_he_styler_group_rule` MODIFY COLUMN `css_selector` TEXT COLLATE utf8_general_ci NOT NULL";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);

    //######### CREATE se_he_styler_skin
    $sql = "SHOW TABLES FROM `$database_name` LIKE 'se_he_styler_skin'";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);

    if( !$database->database_num_rows($resource) )
    {
        $sql = "
        CREATE TABLE `se_he_styler_skin` (
          `id` int(11) NOT NULL auto_increment,
          `user_id` int(11) unsigned NOT NULL,
          `parent_id` int(11) default NULL,
          `page` varchar(255) NOT NULL default 'profile',
          `page_id` int(11) NOT NULL default '0',
          `name` varchar(255) default NULL,
          `photo` varchar(255) default NULL,
          `css` text,
          `create_stamp` int(11) unsigned NOT NULL,
          `posted_stamp` int(11) unsigned NOT NULL default '0',
          `shared` tinyint(1) NOT NULL default '0',
          `active` tinyint(1) NOT NULL default '0',
          `ready` tinyint(1) NOT NULL default '0',
          `default` tinyint(1) NOT NULL default '0',
          `changed` tinyint(4) NOT NULL default '0',
          `approved` tinyint(1) NOT NULL default '0',
          PRIMARY KEY  (`id`)
        ) ENGINE=MyISAM DEFAULT CHARSET=utf8;
    ";

        $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    }
    
    
    //######### ADD COLUMNS/VALUES TO se_he_styler_skin
    $sql = "SHOW COLUMNS FROM `$database_name`.`se_he_styler_skin` LIKE 'approved'";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    
    if( !$database->database_num_rows($resource) )
    {
        $sql = "ALTER TABLE `se_he_styler_skin` ADD COLUMN `approved` TINYINT(1) NOT NULL DEFAULT '1'";
        $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    }
    
    //######### ADD COLUMNS/VALUES TO se_he_styler_skin
    $sql = "SHOW COLUMNS FROM `$database_name`.`se_he_styler_skin` LIKE 'page'";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    
    if( !$database->database_num_rows($resource) )
    {
        $sql = "ALTER TABLE `se_he_styler_skin` ADD COLUMN `page` VARCHAR(255) NOT NULL DEFAULT 'profile'";
        $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    }
    
    //######### ADD COLUMNS/VALUES TO se_he_styler_skin
    $sql = "SHOW COLUMNS FROM `$database_name`.`se_he_styler_skin` LIKE 'page_id'";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    
    if( !$database->database_num_rows($resource) )
    {
        $sql = "ALTER TABLE `se_he_styler_skin` ADD COLUMN `page_id` int(11) NOT NULL DEFAULT '0'";
        $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);

        $sql = "UPDATE `se_he_styler_skin` SET `page_id`=`user_id` WHERE 1";
        $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    }
    
    //######## ADDD COLUMNS/VALUES TO se_levels
    $sql = "SHOW COLUMNS FROM `".$database_name."`.`se_levels` LIKE 'level_styler_allowed'";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
     
    if ( !$database->database_num_rows($resource) )
    {
        $sql = "ALTER TABLE `se_levels` ADD COLUMN `level_styler_allowed` TINYINT(1) NOT NULL DEFAULT '1'";
          $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql); 
    }

    //######### CREATE se_he_styler_value
    $sql = "SHOW TABLES FROM `$database_name` LIKE 'se_he_styler_value'";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);

    if( !$database->database_num_rows($resource) )
    {
        $sql = "
        CREATE TABLE `se_he_styler_value` (
          `skin_id` int(11) unsigned NOT NULL,
          `group_id` int(11) unsigned NOT NULL,
          `background_color` varchar(255) NOT NULL default '',
          `background_image` varchar(255) NOT NULL default '',
          `background_position` varchar(255) NOT NULL default '',
          `background_repeat` varchar(255) NOT NULL default '',
          `font_color` varchar(255) NOT NULL default '',
          `font_family` varchar(255) NOT NULL default '',
          `font_size` varchar(255) NOT NULL default '',
          `border_color` varchar(255) NOT NULL default '',
          `border_style` varchar(255) NOT NULL default '',
          `border_width` varchar(255) NOT NULL default '',
          UNIQUE KEY `skin_id` (`skin_id`,`group_id`)
        ) ENGINE=MyISAM DEFAULT CHARSET=utf8
    ";

        $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    }
    
    //######### ADD COLUMNS/VALUES TO SETTINGS TABLE
    $sql = "SHOW COLUMNS FROM `$database_name`.`se_settings` LIKE 'setting_he_styler_approval_status'";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    
    if( !$database->database_num_rows($resource) )
    {
        $sql = "ALTER TABLE `se_settings` ADD COLUMN `setting_he_styler_approval_status` TINYINT(1) NOT NULL DEFAULT '1'";
        $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    }
    
    
    //################ ADD/UPDATE STYLER
    $styler_hash = he_styler_get_hash();
    
    
    //######### ADD PROFILE STYLER SECTIONS
    $sql = "SELECT * FROM `se_he_styler_section` WHERE `page`='profile'";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    
    if ( $database->database_num_rows($resource) == 0 )
    {
        //######### INSERT DATA INTO se_he_styler_section
        $sql = "INSERT INTO `se_he_styler_section` (`id`, `label`, `order`, `page`) VALUES
            (1, 690702000, 1, 'profile'),
            (2, 690702001, 2, 'profile'),
            (3, 690702073, 3, 'profile')
        ";
        
        $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
        
        //######### INSERT DATA INTO se_he_styler_group
        $sql = "INSERT INTO `se_he_styler_group` (`id`, `section_id`, `label`, `js_selector`, `css_selector`, `background_color`, `background_image`, `background_position`, `background_repeat`, `font_color`, `font_family`, `font_size`, `font_size_tool`, `border_color`, `border_style`, `border_width`, `order`) VALUES
          (1, 1, 690702002, 'body', 'body', 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1),
          (2, 2, 690702003, 'td.top_menu,td.top_menu2', 'td.top_menu,td.top_menu2', 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1),
          (3, 2, 690702004, 'td.menu_user,div.copyright,div.menu_item_dropdown a', 'td.menu_user,div.copyright,div.menu_item_dropdown a', 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 2),
          (6, 3, 690702074, 'td.header,div.header,td.profile_rightside td.profile_tab a', 'td.header,div.header,td.profile_rightside td.profile_tab a', 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 3),
            (7, 3, 690702075, 'td.profile,div.portal_content,td.profile_photo,div.profile_content,td.profile_rightside td.profile_tab2 a,div.profile_content td,div.profile_content #profile_friends div,.wall_actions .wall_action,.profile_menu td.profile_menu1 a', 'td.profile,div.portal_content,td.profile_photo,div.profile_content,td.profile_rightside td.profile_tab2 a,div.profile_content td,div.profile_content #profile_friends div,.wall_actions .wall_action,.profile_menu td.profile_menu1 a', 1, 1, 1, 1, 1, 1, 1, 2, 0, 0, 0, 4),
          (8, 3, 690702076, 'div.page_header', 'div.page_header', 1, 0, 0, 0, 1, 1, 1, 3, 0, 0, 0, 1),
          (10, 3, 690702080, 'div.profile_content a, td.profile a, div.portal_content a', 'div.profile_content a, td.profile a, div.portal_content a', 0, 0, 0, 0, 1, 1, 1, 2, 0, 0, 0, 5),
            (11, 1, 690702084, 'div.profile_content,td.profile_rightside td.profile_tab a,td.profile_rightside td.profile_tab2 a,td.profile_tab_end,#profile_tabs_profile,td.header,div.header,td.profile,div.portal_content,td.profile_photo,div.copyright,td.top_menu,td.top_menu2,div.top_menu_link_container, div.top_menu_link_container_end,td.menu_user,table.profile_menu,td.profile_menu1 a', 'div.profile_content,td.profile_rightside td.profile_tab a,td.profile_rightside td.profile_tab2 a,td.profile_tab_end,#profile_tabs_profile,td.header,div.header,td.profile,div.portal_content,td.profile_photo,div.copyright,td.top_menu,td.top_menu2,div.top_menu_link_container, div.top_menu_link_container_end,td.menu_user,table.profile_menu,td.profile_menu1 a', 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 2)
        ";
    
        $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);

        //######### INSERT DATA INTO se_he_styler_group_rule
        $sql = "INSERT INTO `se_he_styler_group_rule` (`group_id`, `tool_key`, `js_selector`, `css_selector`) VALUES
          (2, 'font_family', '.top_menu a.top_menu_item, .top_menu2 div, .top_menu2 a.top_menu_item', '.top_menu a.top_menu_item, .top_menu2 div, .top_menu2 a.top_menu_item'),
          (2, 'font_size', '.top_menu a.top_menu_item, .top_menu2 div, .top_menu2 a.top_menu_item', '.top_menu a.top_menu_item, .top_menu2 div, .top_menu2 a.top_menu_item'),
          (2, 'font_color', '.top_menu a.top_menu_item, .top_menu2 div, .top_menu2 a.top_menu_item', '.top_menu a.top_menu_item, .top_menu2 div, .top_menu2 a.top_menu_item'),
          (7, 'font_family', 'td.profile,div.portal_content,td.profile td,td.profile div,div.profile_content div, div.profile_content td, td.profile_tab2 a, td.profile_tab a', 'td.profile,div.portal_content,td.profile td,td.profile div,div.profile_content div, div.profile_content td, td.profile_tab2 a, td.profile_tab a,td.profile_menu1 a'),
          (7, 'font_color', 'td.profile,div.portal_content,td.profile td,td.profile div,div.profile_content div, div.profile_content td, td.profile_tab2 a, td.profile_tab a', 'td.profile,div.portal_content,td.profile td,td.profile div,div.profile_content div, div.profile_content td, td.profile_tab2 a, td.profile_tab a,td.profile_menu1 a'),
          (3, 'font_color', '.menu_item a.menu_item,div.copyright,div.copyright a.copyright,div.menu_item_dropdown a', '.menu_item a.menu_item,div.copyright,div.copyright a.copyright,div.menu_item_dropdown a'),
          (3, 'font_family', '.menu_item a.menu_item,div.copyright,div.copyright a.copyright,div.menu_item_dropdown a', '.menu_item a.menu_item,div.copyright,div.copyright a.copyright,div.menu_item_dropdown a'),
          (3, 'font_size', '.menu_item a.menu_item,div.copyright,div.copyright a.copyright,div.menu_item_dropdown a', '.menu_item a.menu_item,div.copyright,div.copyright a.copyright,div.menu_item_dropdown a'),
            (7, 'font_size', 'td.profile,div.portal_content,td.profile td,td.profile div,div.profile_content div, div.profile_content td, td.profile_tab2 a, td.profile_tab a', 'td.profile,div.portal_content,td.profile td,td.profile div,div.profile_content div, div.profile_content td, td.profile_tab2 a, td.profile_tab a,td.profile_menu1 a'),
            (11, 'border_color', 'div.profile_content,td.profile_rightside td.profile_tab a,td.profile_rightside td.profile_tab2 a,td.profile_tab_end,#profile_tabs_profile,td.header,div.header,td.profile,div.portal_content,td.profile_photo,div.copyright,td.top_menu,td.top_menu2,div.top_menu_link_container, div.top_menu_link_container_end,td.menu_user,.wall_container .wall_post_action,.wall_container .wall_action,.wall_container .wall_show_more,.wall_container .wall_action .photo_cont,.profile_menu td.profile_menu1 a,table.profile_menu', 'div.profile_content,td.profile_rightside td.profile_tab a,td.profile_rightside td.profile_tab2 a,td.profile_tab_end,#profile_tabs_profile,td.header,div.header,td.profile,div.portal_content,td.profile_photo,div.copyright,td.top_menu,td.top_menu2,div.top_menu_link_container, div.top_menu_link_container_end,td.menu_user,table.profile_menu,td.profile_menu1 a,.wall_container .wall_post_action,.wall_container .wall_action,.wall_container .wall_show_more,.wall_container .wall_action .photo_cont,.profile_menu td.profile_menu1 a,table.profile_menu');
        ";
    
        $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    }    
    else {
        
        $group_hash = he_styler_page_group_hash('profile');
        $rule_hash = he_styler_page_group_rule_hash('profile');
        
        if (in_array($group_hash, $styler_hash['profile']['group'])) {
            
            $sql = "DELETE `se_he_styler_group` FROM `se_he_styler_group` "
                . "INNER JOIN `se_he_styler_section` ON (`se_he_styler_group`.`section_id`=`se_he_styler_section`.`id`) "
                . "WHERE `se_he_styler_section`.`page`='profile'";
                  
            $resource = $database->database_query($sql) or die("<b>Error: </b>" . $database->database_error() 
                . "<br /><b>File: </b>" . __FILE__ . "<br /><b>Line: </b>" . __LINE__ . "<br /><b>Query: </b>" . $sql);
                
            //######### INSERT DATA INTO se_he_styler_group
            $sql = "INSERT INTO `se_he_styler_group` (`id`, `section_id`, `label`, `js_selector`, `css_selector`, `background_color`, `background_image`, `background_position`, `background_repeat`, `font_color`, `font_family`, `font_size`, `font_size_tool`, `border_color`, `border_style`, `border_width`, `order`) VALUES
              (1, 1, 690702002, 'body', 'body', 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1),
              (2, 2, 690702003, 'td.top_menu,td.top_menu2', 'td.top_menu,td.top_menu2', 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1),
              (3, 2, 690702004, 'td.menu_user,div.copyright,div.menu_item_dropdown a', 'td.menu_user,div.copyright,div.menu_item_dropdown a', 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 2),
              (6, 3, 690702074, 'td.header,div.header,td.profile_rightside td.profile_tab a', 'td.header,div.header,td.profile_rightside td.profile_tab a', 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 3),
                (7, 3, 690702075, 'td.profile,div.portal_content,td.profile_photo,div.profile_content,td.profile_rightside td.profile_tab2 a,div.profile_content td,div.profile_content #profile_friends div,.wall_actions .wall_action,.profile_menu td.profile_menu1 a', 'td.profile,div.portal_content,td.profile_photo,div.profile_content,td.profile_rightside td.profile_tab2 a,div.profile_content td,div.profile_content #profile_friends div,.wall_actions .wall_action,.profile_menu td.profile_menu1 a', 1, 1, 1, 1, 1, 1, 1, 2, 0, 0, 0, 4),
              (8, 3, 690702076, 'div.page_header', 'div.page_header', 1, 0, 0, 0, 1, 1, 1, 3, 0, 0, 0, 1),
              (10, 3, 690702080, 'div.profile_content a, td.profile a, div.portal_content a', 'div.profile_content a, td.profile a, div.portal_content a', 0, 0, 0, 0, 1, 1, 1, 2, 0, 0, 0, 5),
                (11, 1, 690702084, 'div.profile_content,td.profile_rightside td.profile_tab a,td.profile_rightside td.profile_tab2 a,td.profile_tab_end,#profile_tabs_profile,td.header,div.header,td.profile,div.portal_content,td.profile_photo,div.copyright,td.top_menu,td.top_menu2,div.top_menu_link_container, div.top_menu_link_container_end,td.menu_user,table.profile_menu,td.profile_menu1 a', 'div.profile_content,td.profile_rightside td.profile_tab a,td.profile_rightside td.profile_tab2 a,td.profile_tab_end,#profile_tabs_profile,td.header,div.header,td.profile,div.portal_content,td.profile_photo,div.copyright,td.top_menu,td.top_menu2,div.top_menu_link_container, div.top_menu_link_container_end,td.menu_user,table.profile_menu,td.profile_menu1 a', 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 2)
            ";
            
            $resource = $database->database_query($sql) or die("<b>Error: </b>" . $database->database_error() 
                . "<br /><b>File: </b>" . __FILE__ . "<br /><b>Line: </b>" . __LINE__ . "<br /><b>Query: </b>" . $sql);
        }
        
        if (in_array($rule_hash, $styler_hash['profile']['group_rule'])) {
            
            $sql = "DELETE `se_he_styler_group_rule` FROM `se_he_styler_group_rule` "
                . "INNER JOIN `se_he_styler_group` ON (`se_he_styler_group_rule`.`group_id`=`se_he_styler_group`.`id`) "
                . "INNER JOIN `se_he_styler_section` ON (`se_he_styler_group`.`section_id`=`se_he_styler_section`.`id`) "
                . "WHERE `se_he_styler_section`.`page`='profile'";

            $resource = $database->database_query($sql) or die("<b>Error: </b>" . $database->database_error() 
                . "<br /><b>File: </b>" . __FILE__ . "<br /><b>Line: </b>" . __LINE__ . "<br /><b>Query: </b>" . $sql);        

            //######### INSERT DATA INTO se_he_styler_group_rule
            $sql = "INSERT INTO `se_he_styler_group_rule` (`group_id`, `tool_key`, `js_selector`, `css_selector`) VALUES
              (2, 'font_family', '.top_menu a.top_menu_item, .top_menu2 div, .top_menu2 a.top_menu_item', '.top_menu a.top_menu_item, .top_menu2 div, .top_menu2 a.top_menu_item'),
              (2, 'font_size', '.top_menu a.top_menu_item, .top_menu2 div, .top_menu2 a.top_menu_item', '.top_menu a.top_menu_item, .top_menu2 div, .top_menu2 a.top_menu_item'),
              (2, 'font_color', '.top_menu a.top_menu_item, .top_menu2 div, .top_menu2 a.top_menu_item', '.top_menu a.top_menu_item, .top_menu2 div, .top_menu2 a.top_menu_item'),
              (7, 'font_family', 'td.profile,div.portal_content,td.profile td,td.profile div,div.profile_content div, div.profile_content td, td.profile_tab2 a, td.profile_tab a', 'td.profile,div.portal_content,td.profile td,td.profile div,div.profile_content div, div.profile_content td, td.profile_tab2 a, td.profile_tab a,td.profile_menu1 a'),
              (7, 'font_color', 'td.profile,div.portal_content,td.profile td,td.profile div,div.profile_content div, div.profile_content td, td.profile_tab2 a, td.profile_tab a', 'td.profile,div.portal_content,td.profile td,td.profile div,div.profile_content div, div.profile_content td, td.profile_tab2 a, td.profile_tab a,td.profile_menu1 a'),
              (3, 'font_color', '.menu_item a.menu_item,div.copyright,div.copyright a.copyright,div.menu_item_dropdown a', '.menu_item a.menu_item,div.copyright,div.copyright a.copyright,div.menu_item_dropdown a'),
              (3, 'font_family', '.menu_item a.menu_item,div.copyright,div.copyright a.copyright,div.menu_item_dropdown a', '.menu_item a.menu_item,div.copyright,div.copyright a.copyright,div.menu_item_dropdown a'),
              (3, 'font_size', '.menu_item a.menu_item,div.copyright,div.copyright a.copyright,div.menu_item_dropdown a', '.menu_item a.menu_item,div.copyright,div.copyright a.copyright,div.menu_item_dropdown a'),
                (7, 'font_size', 'td.profile,div.portal_content,td.profile td,td.profile div,div.profile_content div, div.profile_content td, td.profile_tab2 a, td.profile_tab a', 'td.profile,div.portal_content,td.profile td,td.profile div,div.profile_content div, div.profile_content td, td.profile_tab2 a, td.profile_tab a,td.profile_menu1 a'),
                (11, 'border_color', 'div.profile_content,td.profile_rightside td.profile_tab a,td.profile_rightside td.profile_tab2 a,td.profile_tab_end,#profile_tabs_profile,td.header,div.header,td.profile,div.portal_content,td.profile_photo,div.copyright,td.top_menu,td.top_menu2,div.top_menu_link_container, div.top_menu_link_container_end,td.menu_user,.wall_container .wall_post_action,.wall_container .wall_action,.wall_container .wall_show_more,.wall_container .wall_action .photo_cont,.profile_menu td.profile_menu1 a,table.profile_menu', 'div.profile_content,td.profile_rightside td.profile_tab a,td.profile_rightside td.profile_tab2 a,td.profile_tab_end,#profile_tabs_profile,td.header,div.header,td.profile,div.portal_content,td.profile_photo,div.copyright,td.top_menu,td.top_menu2,div.top_menu_link_container, div.top_menu_link_container_end,td.menu_user,table.profile_menu,td.profile_menu1 a,.wall_container .wall_post_action,.wall_container .wall_action,.wall_container .wall_show_more,.wall_container .wall_action .photo_cont,.profile_menu td.profile_menu1 a,table.profile_menu');
            ";
                
            $resource = $database->database_query($sql) or die("<b>Error: </b>" . $database->database_error() 
                . "<br /><b>File: </b>" . __FILE__ . "<br /><b>Line: </b>" . __LINE__ . "<br /><b>Query: </b>" . $sql);        
        }
        
    }
    
    
    //######### ADD GROUP STYLER SECTIONS
    $sql = "SELECT * FROM `se_he_styler_section` WHERE `page`='group'";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    
    if ( $database->database_num_rows($resource) == 0 )
    {
        //######### INSERT DATA INTO se_he_styler_section
        $sql = "INSERT INTO `se_he_styler_section` (`id`, `label`, `order`, `page`) VALUES
            (10, 690702114, 1, 'group'),
            (11, 690702115, 2, 'group'),
            (12, 690702116, 3, 'group')";
        
        $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
        
        //######### INSERT DATA INTO se_he_styler_group
        $sql = "INSERT INTO `se_he_styler_group` (`id`, `section_id`, `label`, `js_selector`, `css_selector`, `background_color`, `background_image`, `background_position`, `background_repeat`, `font_color`, `font_family`, `font_size`, `font_size_tool`, `border_color`, `border_style`, `border_width`, `order`) VALUES
            (100, 10, 690702117, 'body', 'body', 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1),
            (101, 10, 690702118, 'div.group_content,td.profile_rightside td.group_tab a,td.profile_rightside td.group_tab2 a,td.group_tab_end,#group_tabs_group,td.header,div.header,td.profile,div.portal_content,td.profile_photo,div.copyright,td.top_menu,td.top_menu2,div.top_menu_link_container, div.top_menu_link_container_end,td.menu_user,table.profile_menu,td.profile_menu1 a', 'div.group_content,td.profile_rightside td.group_tab a,td.profile_rightside td.group_tab2 a,td.group_tab_end,#group_tabs_group,td.header,div.header,td.profile,div.portal_content,td.profile_photo,div.copyright,td.top_menu,td.top_menu2,div.top_menu_link_container, div.top_menu_link_container_end,td.menu_user,table.profile_menu,td.profile_menu1 a', 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 2),
            (102, 11, 690702119, 'td.top_menu,td.top_menu2', 'td.top_menu,td.top_menu2', 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1),
            (103, 11, 690702120, 'td.menu_user,div.copyright,div.menu_item_dropdown a', 'td.menu_user,div.copyright,div.menu_item_dropdown a', 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 2),
            (104, 12, 690702122, 'td.header,div.header,td.profile_rightside td.group_tab a', 'td.header,div.header,td.profile_rightside td.group_tab a', 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 3),
            (105, 12, 690702123, 'td.profile,div.portal_content,td.profile_photo,div.group_content,td.profile_rightside td.group_tab2 a,div.group_content td,.profile_menu td.profile_menu1 a,.wall_actions .wall_action', 'td.profile,div.portal_content,td.profile_photo,div.group_content,td.profile_rightside td.group_tab2 a,div.group_content td,.profile_menu td.profile_menu1 a,.wall_actions .wall_action', 1, 1, 1, 1, 1, 1, 1, 2, 0, 0, 0, 4),
            (106, 12, 690702121, 'div.page_header', 'div.page_header', 1, 0, 0, 0, 1, 1, 1, 3, 0, 0, 0, 1),
            (107, 12, 690702124, 'div.group_content a, td.profile a, div.group_content a', 'div.group_content a, td.profile a, div.group_content a', 0, 0, 0, 0, 1, 1, 1, 2, 0, 0, 0, 5);
        ";
    
        $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    
        //######### INSERT DATA INTO se_he_styler_group_rule
        $sql = "INSERT INTO `se_he_styler_group_rule` (`group_id`, `tool_key`, `js_selector`, `css_selector`) VALUES
            (101, 'border_color', 'div.group_content,td.profile_rightside td.group_tab a,td.profile_rightside td.group_tab2 a,td.group_tab_end,#group_tabs_group,td.header,div.header,td.profile,div.portal_content,td.profile_photo,div.copyright,td.top_menu,td.top_menu2,div.top_menu_link_container, div.top_menu_link_container_end,td.menu_user,table.profile_menu,td.profile_menu1 a,.wall_container .wall_post_action,.wall_container .wall_action,.wall_container .wall_show_more,.wall_container .wall_action .photo_cont', 'div.group_content,td.profile_rightside td.group_tab a,td.profile_rightside td.group_tab2 a,td.group_tab_end,#group_tabs_group,td.header,div.header,td.profile,div.portal_content,td.profile_photo,div.copyright,td.top_menu,td.top_menu2,div.top_menu_link_container, div.top_menu_link_container_end,td.menu_user,table.profile_menu,td.profile_menu1 a,.wall_container .wall_post_action,.wall_container .wall_action,.wall_container .wall_show_more,.wall_container .wall_action .photo_cont'),
          (102, 'font_family', '.top_menu a.top_menu_item, .top_menu2 div, .top_menu2 a.top_menu_item', '.top_menu a.top_menu_item, .top_menu2 div, .top_menu2 a.top_menu_item'),
          (102, 'font_size', '.top_menu a.top_menu_item, .top_menu2 div, .top_menu2 a.top_menu_item', '.top_menu a.top_menu_item, .top_menu2 div, .top_menu2 a.top_menu_item'),
          (102, 'font_color', '.top_menu a.top_menu_item, .top_menu2 div, .top_menu2 a.top_menu_item', '.top_menu a.top_menu_item, .top_menu2 div, .top_menu2 a.top_menu_item'),
          (105, 'font_family', 'td.profile,div.portal_content,td.profile td,td.profile div,div.profile_content div, div.profile_content td, td.profile_tab2 a, td.profile_tab a', 'td.profile,div.portal_content,td.profile td,td.profile div,div.profile_content div, div.profile_content td, td.profile_tab2 a, td.profile_tab a,td.profile_menu1 a'),
          (105, 'font_color', 'td.profile,div.portal_content,td.profile td,td.profile div,div.group_content div, div.group_content td, td.group_tab2 a, td.group_tab a', 'td.profile,div.portal_content,td.profile td,td.profile div,div.group_content div, div.group_content td, td.group_tab2 a, td.group_tab a,td.profile_menu1 a'),
          (103, 'font_color', '.menu_item a.menu_item,div.copyright,div.copyright a.copyright,div.menu_item_dropdown a', '.menu_item a.menu_item,div.copyright,div.copyright a.copyright,div.menu_item_dropdown a'),
          (103, 'font_family', '.menu_item a.menu_item,div.copyright,div.copyright a.copyright,div.menu_item_dropdown a', '.menu_item a.menu_item,div.copyright,div.copyright a.copyright,div.menu_item_dropdown a'),
          (103, 'font_size', '.menu_item a.menu_item,div.copyright,div.copyright a.copyright,div.menu_item_dropdown a', '.menu_item a.menu_item,div.copyright,div.copyright a.copyright,div.menu_item_dropdown a'),
            (105, 'font_size', 'td.profile,div.portal_content,td.profile td,td.profile div,div.profile_content div, div.profile_content td, td.profile_tab2 a, td.profile_tab a', 'td.profile,div.portal_content,td.profile td,td.profile div,div.profile_content div, div.profile_content td, td.profile_tab2 a, td.profile_tab a,td.profile_menu1 a')
        ";
    
        $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    }
    else {
        
        $group_hash = he_styler_page_group_hash('group');
        $rule_hash = he_styler_page_group_rule_hash('group');
        
        if (in_array($group_hash, $styler_hash['group']['group'])) {
            
            $sql = "DELETE `se_he_styler_group` FROM `se_he_styler_group` "
                . "INNER JOIN `se_he_styler_section` ON (`se_he_styler_group`.`section_id`=`se_he_styler_section`.`id`) "
                . "WHERE `se_he_styler_section`.`page`='group'";
                  
            $resource = $database->database_query($sql) or die("<b>Error: </b>" . $database->database_error() 
                . "<br /><b>File: </b>" . __FILE__ . "<br /><b>Line: </b>" . __LINE__ . "<br /><b>Query: </b>" . $sql);
                
            //######### INSERT DATA INTO se_he_styler_group
            $sql = "INSERT INTO `se_he_styler_group` (`id`, `section_id`, `label`, `js_selector`, `css_selector`, `background_color`, `background_image`, `background_position`, `background_repeat`, `font_color`, `font_family`, `font_size`, `font_size_tool`, `border_color`, `border_style`, `border_width`, `order`) VALUES
                (100, 10, 690702117, 'body', 'body', 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1),
                (101, 10, 690702118, 'div.group_content,td.profile_rightside td.group_tab a,td.profile_rightside td.group_tab2 a,td.group_tab_end,#group_tabs_group,td.header,div.header,td.profile,div.portal_content,td.profile_photo,div.copyright,td.top_menu,td.top_menu2,div.top_menu_link_container, div.top_menu_link_container_end,td.menu_user,table.profile_menu,td.profile_menu1 a', 'div.group_content,td.profile_rightside td.group_tab a,td.profile_rightside td.group_tab2 a,td.group_tab_end,#group_tabs_group,td.header,div.header,td.profile,div.portal_content,td.profile_photo,div.copyright,td.top_menu,td.top_menu2,div.top_menu_link_container, div.top_menu_link_container_end,td.menu_user,table.profile_menu,td.profile_menu1 a', 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 2),
                (102, 11, 690702119, 'td.top_menu,td.top_menu2', 'td.top_menu,td.top_menu2', 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1),
                (103, 11, 690702120, 'td.menu_user,div.copyright,div.menu_item_dropdown a', 'td.menu_user,div.copyright,div.menu_item_dropdown a', 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 2),
                (104, 12, 690702122, 'td.header,div.header,td.profile_rightside td.group_tab a', 'td.header,div.header,td.profile_rightside td.group_tab a', 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 3),
                (105, 12, 690702123, 'td.profile,div.portal_content,td.profile_photo,div.group_content,td.profile_rightside td.group_tab2 a,div.group_content td,.profile_menu td.profile_menu1 a,.wall_actions .wall_action', 'td.profile,div.portal_content,td.profile_photo,div.group_content,td.profile_rightside td.group_tab2 a,div.group_content td,.profile_menu td.profile_menu1 a,.wall_actions .wall_action', 1, 1, 1, 1, 1, 1, 1, 2, 0, 0, 0, 4),
                (106, 12, 690702121, 'div.page_header', 'div.page_header', 1, 0, 0, 0, 1, 1, 1, 3, 0, 0, 0, 1),
                (107, 12, 690702124, 'div.group_content a, td.profile a, div.group_content a', 'div.group_content a, td.profile a, div.group_content a', 0, 0, 0, 0, 1, 1, 1, 2, 0, 0, 0, 5);
            ";
            
            $resource = $database->database_query($sql) or die("<b>Error: </b>" . $database->database_error() 
                . "<br /><b>File: </b>" . __FILE__ . "<br /><b>Line: </b>" . __LINE__ . "<br /><b>Query: </b>" . $sql);
        }
        
        if (in_array($rule_hash, $styler_hash['group']['group_rule'])) {
            
            $sql = "DELETE `se_he_styler_group_rule` FROM `se_he_styler_group_rule` "
                . "INNER JOIN `se_he_styler_group` ON (`se_he_styler_group_rule`.`group_id`=`se_he_styler_group`.`id`) "
                . "INNER JOIN `se_he_styler_section` ON (`se_he_styler_group`.`section_id`=`se_he_styler_section`.`id`) "
                . "WHERE `se_he_styler_section`.`page`='group'";

            $resource = $database->database_query($sql) or die("<b>Error: </b>" . $database->database_error() 
                . "<br /><b>File: </b>" . __FILE__ . "<br /><b>Line: </b>" . __LINE__ . "<br /><b>Query: </b>" . $sql);        

            //######### INSERT DATA INTO se_he_styler_group_rule
            $sql = "INSERT INTO `se_he_styler_group_rule` (`group_id`, `tool_key`, `js_selector`, `css_selector`) VALUES
                (101, 'border_color', 'div.group_content,td.profile_rightside td.group_tab a,td.profile_rightside td.group_tab2 a,td.group_tab_end,#group_tabs_group,td.header,div.header,td.profile,div.portal_content,td.profile_photo,div.copyright,td.top_menu,td.top_menu2,div.top_menu_link_container, div.top_menu_link_container_end,td.menu_user,table.profile_menu,td.profile_menu1 a,.wall_container .wall_post_action,.wall_container .wall_action,.wall_container .wall_show_more,.wall_container .wall_action .photo_cont', 'div.group_content,td.profile_rightside td.group_tab a,td.profile_rightside td.group_tab2 a,td.group_tab_end,#group_tabs_group,td.header,div.header,td.profile,div.portal_content,td.profile_photo,div.copyright,td.top_menu,td.top_menu2,div.top_menu_link_container, div.top_menu_link_container_end,td.menu_user,table.profile_menu,td.profile_menu1 a,.wall_container .wall_post_action,.wall_container .wall_action,.wall_container .wall_show_more,.wall_container .wall_action .photo_cont'),
              (102, 'font_family', '.top_menu a.top_menu_item, .top_menu2 div, .top_menu2 a.top_menu_item', '.top_menu a.top_menu_item, .top_menu2 div, .top_menu2 a.top_menu_item'),
              (102, 'font_size', '.top_menu a.top_menu_item, .top_menu2 div, .top_menu2 a.top_menu_item', '.top_menu a.top_menu_item, .top_menu2 div, .top_menu2 a.top_menu_item'),
              (102, 'font_color', '.top_menu a.top_menu_item, .top_menu2 div, .top_menu2 a.top_menu_item', '.top_menu a.top_menu_item, .top_menu2 div, .top_menu2 a.top_menu_item'),
              (105, 'font_family', 'td.profile,div.portal_content,td.profile td,td.profile div,div.profile_content div, div.profile_content td, td.profile_tab2 a, td.profile_tab a', 'td.profile,div.portal_content,td.profile td,td.profile div,div.profile_content div, div.profile_content td, td.profile_tab2 a, td.profile_tab a,td.profile_menu1 a'),
              (105, 'font_color', 'td.profile,div.portal_content,td.profile td,td.profile div,div.group_content div, div.group_content td, td.group_tab2 a, td.group_tab a', 'td.profile,div.portal_content,td.profile td,td.profile div,div.group_content div, div.group_content td, td.group_tab2 a, td.group_tab a,td.profile_menu1 a'),
              (103, 'font_color', '.menu_item a.menu_item,div.copyright,div.copyright a.copyright,div.menu_item_dropdown a', '.menu_item a.menu_item,div.copyright,div.copyright a.copyright,div.menu_item_dropdown a'),
              (103, 'font_family', '.menu_item a.menu_item,div.copyright,div.copyright a.copyright,div.menu_item_dropdown a', '.menu_item a.menu_item,div.copyright,div.copyright a.copyright,div.menu_item_dropdown a'),
              (103, 'font_size', '.menu_item a.menu_item,div.copyright,div.copyright a.copyright,div.menu_item_dropdown a', '.menu_item a.menu_item,div.copyright,div.copyright a.copyright,div.menu_item_dropdown a'),
                (105, 'font_size', 'td.profile,div.portal_content,td.profile td,td.profile div,div.profile_content div, div.profile_content td, td.profile_tab2 a, td.profile_tab a', 'td.profile,div.portal_content,td.profile td,td.profile div,div.profile_content div, div.profile_content td, td.profile_tab2 a, td.profile_tab a,td.profile_menu1 a')
            ";
                
            $resource = $database->database_query($sql) or die("<b>Error: </b>" . $database->database_error() 
                . "<br /><b>File: </b>" . __FILE__ . "<br /><b>Line: </b>" . __LINE__ . "<br /><b>Query: </b>" . $sql);        
        }
        
    }
    
    //######### ADD DEFAULT PROFILE SKIN
    $sql = "SELECT * FROM `se_he_styler_skin` WHERE `page`='profile' AND `shared`=1 AND `default`=1";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    
    if ( $database->database_num_rows($resource) == 0 )
    {    
        //######### INSERT DATA INTO se_he_styler_skin
        $sql = "
        INSERT INTO `se_he_styler_skin` (`user_id`, `parent_id`, `page`, `page_id`, `name`, `photo`, `css`, `create_stamp`, `posted_stamp`, `shared`, `active`, `ready`, `default`, `changed`, `approved`)
        VALUES(0, NULL, 'profile', 0, 'Default', NULL, NULL, 0, 0, 1, 0, 1, 1, 1, 1)";
        
        $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    }
    
    //######### ADD DEFAULT GROUP SKIN
    $sql = "SELECT * FROM `se_he_styler_skin` WHERE `page`='group' AND `shared`=1 AND `default`=1";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    
    if ( $database->database_num_rows($resource) == 0 )
    {    
        //######### INSERT DATA INTO se_he_styler_skin
        $sql = "
        INSERT INTO `se_he_styler_skin` (`user_id`, `parent_id`, `page`, `page_id`, `name`, `photo`, `css`, `create_stamp`, `posted_stamp`, `shared`, `active`, `ready`, `default`, `changed`, `approved`)
        VALUES(0, NULL, 'group', 0, 'Default', NULL, NULL, 0, 0, 1, 0, 1, 1, 1, 1)";
        
        $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    }

    //######### ADD VALUES TO LANGS TABLE
    $he_languagevars = array
    (
        '690702000' => 'Page',
        '690702001' => 'Menu',
        '690702002' => 'Background',
        '690702003' => 'Main Menu',
        '690702004' => 'Sub Menu',
        '690702006' => 'Select a skin',
        '690702007' => 'Make a skin',
        '690702008' => 'My skins history',
        '690702009' => 'Previous',
        '690702010' => 'Next',
        '690702011' => 'There are no skins',
        '690702012' => 'Choose skin',
        '690702013' => 'Background Color',
        '690702014' => 'Clear',
        '690702015' => 'Background Image',
        '690702016' => 'Upload',
        '690702017' => 'Image Position',
        '690702018' => 'Image Repeat',
        '690702019' => 'Across & Down',
        '690702020' => 'Across',
        '690702021' => 'Down',
        '690702022' => 'None',
        '690702023' => 'Border Color',
        '690702024' => 'Border Style',
        '690702025' => 'none',
        '690702026' => 'solid',
        '690702027' => 'dashed',
        '690702028' => 'dotted',
        '690702029' => 'double',
        '690702030' => 'groove',
        '690702031' => 'ridge',
        '690702032' => 'inset',
        '690702033' => 'outset',
        '690702034' => 'Border Size',
        '690702035' => '1px',
        '690702036' => '2px',
        '690702037' => '3px',
        '690702038' => '4px',
        '690702039' => '5px',
        '690702040' => 'Font Styles',
        '690702041' => 'Arial',
        '690702042' => 'Arial Black',
        '690702043' => 'Comic Sans',
        '690702044' => 'Courier New',
        '690702045' => 'Georgia',
        '690702046' => 'Impact',
        '690702047' => 'Lucida Console',
        '690702048' => 'Tahoma',
        '690702049' => 'Times',
        '690702050' => 'Trebuchet',
        '690702051' => 'Verdana',
        '690702052' => 'tiny',
        '690702053' => 'small',
        '690702054' => 'medium',
        '690702055' => 'large',
        '690702056' => 'huge',
        '690702057' => 'type skin name',
        '690702058' => 'Edit',
        '690702059' => 'Delete',
        '690702060' => 'Share',
        '690702061' => 'Choose skin',
        '690702062' => 'Share',
        '690702063' => 'a',
        '690702064' => 'Save skin',
        '690702065' => 'Please log in',
        '690702066' => 'File was deleted',
        '690702067' => 'Skin was successfully saved',
        '690702068' => 'Please give your skin a name.',
        '690702069' => 'Skin styles not defined',
        '690702070' => 'Skin was deleted',
        '690702071' => 'Styler Plugin',
        '690702072' => 'Footer',
        '690702073' => 'Boxes',
        '690702074' => 'Header',
        '690702075' => 'Body',
        '690702076' => 'Title',
        '690702077' => 'Selected skin saved',
        '690702078' => 'Please upload skin photo',
        '690702080' => 'Links',
        '690702081' => 'Your skin has been succesfully shared',
        '690702082' => 'Are you sure you want to delete this skin?',
        '690702083' => 'Change your profile skin',
        '690702084' => 'Borders',
        '690702085' => 'Close',

        //UPDATED LANGVARS
        '690702005' => 'View Skins',
        '690702079' => 'Use this page to approve/disapprove or delete shared skins. Also you can forbid/permit using of Styler plugin by user level, please visit the <a href="admin_levels.php">User Levels</a> page.',
    
        //NEW LANGVARS 
        '690702086' => 'Created date',
        '690702087' => 'Approved',
        '690702088' => 'approve',
        '690702089' => '%1\$d Skins Found',
        '690702090' => 'disapprove',
        '690702091' => 'Automatically approve new shared skins',
        '690702092' => 'Styler settings',
        '690702093' => 'Owner',
        '690702103' => 'Are you sure you want to delete this skin?',
        '690702104' => 'No skins',

        '690702094' => 'Uploaded skin packages(from ftp)',
        '690702095' => 'Here you can import and manage imported skins. Hire-Experts provides FREE skin packages for Profile page, please go to <a href="http://www.hire-experts.com/social-engine-skins.php">http://www.hire-experts.com/social-engine-skins.php</a> to browse and download free skins packages.',
        '690702096' => 'Name',
        '690702097' => 'Description',
        '690702098' => 'Status',
        '690702099' => 'Installed',
        '690702100' => 'Install',
        '690702101' => 'No packages to install',
        '690702102' => 'Styler Skins Import',
       
        // New version 3.2
        '690702109' => 'This page contains "Styler" plugin settings. Here you can define if users of this user level are allowed to use "Styler" plugin',
        '690702110' => 'Can users use "Styler" plugin?', 
        '690702111' => 'If set to "Yes" users can use "Styler" plugin.',
        '690702112' => 'Yes, users can use "Styler" plugin.',
        '690702113' => 'No, users cannot use "Styler" plugin',
        '690702114' => 'Page',
        '690702115' => 'Menu',
        '690702116' => 'Boxes',
        '690702117' => 'Background',
        '690702118' => 'Borders',
        '690702119' => 'Main Menu',
        '690702120' => 'Sub Menu',
        '690702121' => 'Title',
        '690702122' => 'Header',
        '690702123' => 'Body',
        '690702124' => 'Links',
        '690702125' => 'Change your group skin',
        '690702126' => 'Page',
        '690702127' => 'view',

        // Page Styler
        '690702128' => 'Page',
        '690702129' => 'Menu',
        '690702130' => 'Boxes',
        '690702131' => 'Background',
        '690702132' => 'Borders',
        '690702133' => 'Main Menu',
        '690702134' => 'Sub Menu',
        '690702135' => 'Title',
        '690702136' => 'Header',
        '690702137' => 'Body',
        '690702138' => 'Links',
        '690702139' => 'Change your page skin',

        // New version 3.21
        '690702140' => 'List of default skins',
        '690702141' => 'Below you can see list of imported skins. You view or disable skin.',
        '690702142' => 'disable',
        '690702143' => 'enable',
        '690702144' => 'Status',
        '690702145' => 'Please set perissions to folder 0777 permission for folder "uploads_skin"',
        '690702146' => 'Please upload zip file',
        '690702147' => 'Zlib is required. Please contact you hosting provider to intall zlib library for your server.',
        '690702148' => 'File damaged. Please re-upload skin package zip file.',
        '690702149' => 'Not valid package uploaded',
        '690702150' => 'You have installed this package',
        '690702151' => 'Skins package has been succesfully imported',
        '690702152' => 'Upload skin package',
        '690702153' => 'Package:',
        '690702154' => 'Upload',
        '690702155' => 'Please increase "upload_max_filesize" value. File uploading stopped by filesize limit.'
    );
    
    foreach ($he_languagevars as $langvar_id => $langvar_value)
    {
        $sql = "SELECT `languagevar_id` FROM `se_languagevars`
           WHERE `languagevar_id`=$langvar_id AND `languagevar_language_id`=1";
        
        if ( $database->database_num_rows($database->database_query($sql)) == 0 )
        {
            $sql = "INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`)
                VALUES('$langvar_id', '1', '$langvar_value', 'styler')";
        }
        else
        {
            $sql = "UPDATE `se_languagevars` SET `languagevar_value`='$langvar_value', `languagevar_default`='styler'
                WHERE `languagevar_id`=$langvar_id AND `languagevar_language_id`=1";
        }
        
        $resource = $database->database_query($sql) or die("<b>Error: </b>" . $database->database_error() . "<br /><b>File: </b>" . __FILE__ . "<br /><b>Line: </b>" . __LINE__ . "<br /><b>Query: </b>" . $sql);
    }
}