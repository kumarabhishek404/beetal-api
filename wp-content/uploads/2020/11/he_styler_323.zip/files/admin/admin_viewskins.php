<?php

/**
 * @author Mirlan
 * @copyright Hire-Experts LLC
 * @version Styler 3.1
 */

$page = "admin_viewskins";
include "admin_header.php";

//APPROVAL STATUS FOR NEW SKINS
$task = ( isset($_POST['task']) || $_POST['task'] ) ? $_POST['task'] : '';

$he_styler = new he_styler();

if($task == 'save_settings')
{
    $setting['setting_he_styler_approval_status'] = (int)isset($_POST['setting_he_skins_approval_status']);
    
    $query = he_database::placeholder("UPDATE `se_settings` 
        SET `setting_he_styler_approval_status` = ?", $setting['setting_he_styler_approval_status']);
    he_database::query($query);
}

//APPROVAL SETTINGS FOR EXISTING SKINS
$p = isset($_GET['p']) ? (int)$_GET['p'] : 1;

if(isset($_GET['skin_id']) and isset($_GET['delete']))
{
    $skin_id = (int)$_GET['skin_id'];
    $he_styler->delete_skin($skin_id);
} 

if(isset($_GET['skin_id']) and isset($_GET['approved']))
{
    $skin_id = (int)$_GET['skin_id'];
    $approve = (int)$_GET['approved'];

    $he_styler->set_approved($approve, $skin_id);
}


$count = 20;
$first = ($p - 1)*$count;

$total_skins = $he_styler->find_admin_shared_skin_count();
$skins = $he_styler->find_admin_shared_skins($first, $count);

// MAKE SKIN'S PAGES
$page_vars = make_page($total_skins, $count, $p);

$page_array = array();
for( $x = 0; $x <= $page_vars[2] - 1; $x++ )
{
    if( $x+1 == $page_vars[1] )
    {
        $link = "1";
    }
    else
    {
        $link = "0";
    }
    
    $page_array[$x] = array( 'page' => $x+1, 'link' => $link );
}

//ASSIGN VARIABLES AND SHOW VIEW USERS PAGE
$smarty->assign('def_approval_status',$setting['setting_he_styler_approval_status']);
$smarty->assign('on_page',$p);
$smarty->assign('pages', $page_array);
$smarty->assign('total_skins', $total_skins);
$smarty->assign('skins', $skins);
include "admin_footer.php";
?>