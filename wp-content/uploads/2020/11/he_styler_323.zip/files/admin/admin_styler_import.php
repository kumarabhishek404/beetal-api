<?php

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version Styler 1.01
 */

$page = "admin_styler_import";
include "admin_header.php";


$task = ( isset($_POST['task']) || $_POST['task'] ) ? $_POST['task'] : false;
$task = ( !$task && isset($_GET['task']) ) ? $_GET['task'] : $task;
$p = isset($_GET['p']) ? (int)$_GET['p'] : 1;
$package = isset($_GET['package']) ? $_GET['package'] : false;

$styler = new he_styler();

$styler_import = new he_styler_import();
$styler_import->setup();

$result = false;

if (isset($_SESSION['styler_import']['result'])) {
    $result = $_SESSION['styler_import']['result'];
    unset($_SESSION['styler_import']['result']);
}

if ($task == 'import_skin') {
    $styler_import->import_package('skin_package');
    
    if ($styler_import->error) {
        $result = array('result' => 0, 'message' => $styler_import->error);
    } else {
        $result = array('result' => 1, 'message' => 690702151);
    }
} elseif ($task == 'install' && $package) {
    if (!file_exists($styler_import->PACKAGE_ROOT_DIR . $package)
      || 'zip' != array_pop(explode('.', $package))) {
        $result = array('result' => 0, 'message' => 690702149);
    } else {
        $styler_import->import_uploaded_package($package);

        if ($styler_import->error) {
            $result = array('result' => 0, 'message' => $styler_import->error);
        } else {
            $result = array('result' => 1, 'message' => 690702151);
        }
    }

    $_SESSION['styler_import']['result'] = $result;
    cheader('admin_styler_import.php');
}

if (isset($_GET['skin_id']) && isset($_GET['approved'])) {
    $skin_id = (int)$_GET['skin_id'];
    $approved = (int)$_GET['approved'];

    $styler->set_approved($approved, $skin_id);
}


$count = 20;
$first = ($p - 1)*$count;

$total_skins = $styler->find_admin_default_skin_count();
$skins = $styler->find_admin_default_skins($first, $count);

// MAKE SKIN'S PAGES
$page_vars = make_page($total_skins, $count, $p);

$page_array = array();
for( $x = 0; $x <= $page_vars[2] - 1; $x++ )
{
    if( $x+1 == $page_vars[1] )
    {
        $link = "1";
    }
    else
    {
        $link = "0";
    }
    
    $page_array[$x] = array( 'page' => $x+1, 'link' => $link );
}

// DEFAULT USERS IN VIEW
$default_user = he_database::fetch_field("SELECT `user_username` FROM `se_users` "
    . "ORDER BY `user_enabled` DESC, `user_verified` DESC LIMIT 1");

// GET UPLOADED PACKAGES
$packages = $styler_import->get_uploaded_packages();
    
//ASSIGN VARIABLES AND SHOW VIEW USERS PAGE
$smarty->assign('on_page',$p);
$smarty->assign('pages', $page_array);
$smarty->assign('total_skins', $total_skins);
$smarty->assign('skins', $skins);
$smarty->assign('default_user',$default_user);
$smarty->assign_by_ref('result', $result);
$smarty->assign_by_ref('packages', $packages);

include "admin_footer.php";

?>