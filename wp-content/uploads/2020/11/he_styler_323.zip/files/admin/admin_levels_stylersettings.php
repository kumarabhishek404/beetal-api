<?php

/**
 * @author Mirlan
 * @copyright Hire-Experts LLC
 * @version Styler 3.2
 */

$page = "admin_levels_stylersettings";
include "admin_header.php";

$task = 'main';
$level_id = 0;

if( isset($_POST['task']) )
{
    $task = $_POST['task']; 
}
elseif( isset($_GET['task']) )
{
    $task = $_GET['task'];
}

if( isset($_POST['level_id']) )
{
    $level_id = $_POST['level_id'];
}
elseif( isset($_GET['level_id']) )
{
    $level_id = $_GET['level_id'];
}

if( isset($_POST['level_styler_allowed']) )
{
    $level_styler_allowed = $_POST['level_styler_allowed'];
}
elseif( isset($_GET['level_styler_allowed']) )
{
    $level_styler_allowed = $_GET['level_styler_allowed'];
}

// SET ERROR VARIABLES
$result = 0;

if ($task == "dosave")
{
    $sql = "UPDATE se_levels SET level_styler_allowed=$level_styler_allowed WHERE level_id = $level_id";
    $database->database_query($sql);

    $result = 1;
}

// VALIDATE LEVEL ID
$level = $database->database_query("SELECT * FROM se_levels WHERE level_id='$level_id'");

if( $database->database_num_rows($level) != 1 )
{
    header("Location: admin_levels.php");
    exit();
}

$level_info = $database->database_fetch_assoc($level);

// ASSIGN VARIABLES AND SHOW ADMIN ADD USER LEVEL PAGE
$smarty->assign('result', $result);
$smarty->assign('level_info', $level_info);

include "admin_footer.php";
?>