INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`)
 VALUES  ('hashtag', 'Hashtag', 'Hashtag', '4.10.3', 1, 'extra') ;

CREATE TABLE `engine4_hashtag_forbiddentags` (
	`forbiddentag_id` INT(100) NOT NULL AUTO_INCREMENT,
	`hashtag` VARCHAR(250) NULL DEFAULT NULL,
	PRIMARY KEY (`forbiddentag_id`)
)
COLLATE='utf8_general_ci'
ENGINE=InnoDB
AUTO_INCREMENT=1
;


INSERT INTO `engine4_core_menus` (`id`, `name`, `type`, `title`, `order`) VALUES (NULL , 'hashtag_admin_main', 'standard', 'Hashtag Admin Navigation Menu', 999);
INSERT INTO `engine4_core_menuitems` (`id`, `name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES (NULL , 'hashtag_admin_settings', 'hashtag', 'Settings', NULL, '{"route":"admin_default","module":"hashtag","controller":"index","action":"index"}', 'hashtag_admin_main', NULL, 1, 0, 1);
INSERT INTO `engine4_core_menuitems` (`id`, `name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES (693, 'hashtag_admin_blacklist', 'hashtag', 'Black List', NULL, '{"route":"admin_default","module":"hashtag","controller":"index","action":"blacklist"}', 'hashtag_admin_main', NULL, 1, 0, 2);
