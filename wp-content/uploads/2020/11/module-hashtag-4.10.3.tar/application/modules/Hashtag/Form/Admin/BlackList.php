<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Bolot
 * Date: 03.05.13
 * Time: 12:57
 * To change this template use File | Settings | File Templates.
 */

class Hashtag_Form_Admin_BlackList extends Engine_Form {
  public function init()
  {
    // My stuff
    $this
      ->setTitle("Black List");


    $view = Zend_Registry::get('Zend_View');
    $this->addElement('Text', 'blacktag', array(
        'placeholder' => $view->translate("Enter hashtags comma separated"),
        'style' => 'margin-bottom: 10px; width:300px;',
      'allowEmpty' => false,
      'required' => true,
      'filters' => array(
        new Engine_Filter_Censor(),
        'StripTags',
        new Engine_Filter_StringLength(array('max' => '100'))
      ),
        'Description' =>'<button type="submit">Add</button>',

    ));


    $element = $this->getElement('blacktag');
    $element->setDecorators(
        array(
            'ViewHelper',
            array('Label', array('escape'=>false,'tag'=>' span')),
            array('Description',array('escape'=>false,'tag'=>' span')), //escape false because I want html output
        )
    );

  }


}