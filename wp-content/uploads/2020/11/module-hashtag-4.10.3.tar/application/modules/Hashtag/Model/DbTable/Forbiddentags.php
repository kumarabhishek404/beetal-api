<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Bolot
 * Date: 16.05.13
 * Time: 14:38
 * To change this template use File | Settings | File Templates.
 */
class Hashtag_Model_DbTable_Forbiddentags extends Engine_Db_Table
{
  protected $_rowClass = 'Hashtag_Model_Forbiddentag';

}