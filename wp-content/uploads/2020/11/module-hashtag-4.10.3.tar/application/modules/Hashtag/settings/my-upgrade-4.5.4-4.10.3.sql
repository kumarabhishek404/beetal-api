UPDATE `engine4_core_modules` SET `version` = '4.10.3' WHERE `name` = 'hashtag';
