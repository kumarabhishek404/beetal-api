<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Kalyskin
 * Date: 28.09.16
 * Time: 12:52
 * To change this template use File | Settings | File Templates.
 */

class Hashtag_AdminIndexController  extends Core_Controller_Action_Admin
{
  public function indexAction()
  {
    $this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
        ->getNavigation('hashtag_admin_main', array(), 'hashtag_admin_settings');

    $settings = Engine_Api::_()->getApi('settings', 'core');
    $this->view->form = $form = new Hashtag_Form_Admin_Settings_Date();

    if ($this->_request->isPost()) {

      // Check license
    /*  $hecoreApi = new Hireexperts_Api();
      $product_result = $hecoreApi->checkProduct('hashtag');

      if (isset($product_result['result']) && !$product_result['result']) {
        $form->addError($product_result['message']);
        $this->view->headScript()->appendScript($product_result['script']);

        return;
      }*/
      $form->isValid($this->_getAllParams());
      $values = $form->getValues();
      if (preg_match("|^[\d]*$|", $values['period']) && preg_match("|^[\d]*$|", $values['count'])) {
        Engine_Api::_()->getApi('settings', 'core')->setSetting('hashtag.count', $values['count']);
        Engine_Api::_()->getApi('settings', 'core')->setSetting('hashtag.period', $values['period']);
        $form->addNotice('Your changes have been saved.');
      }else{
        return $form->addError('ERROR_HASHTAG_SETTINGS_SAVE');;
      }
    }

    $form->period->setValue($settings->getSetting('hashtag.period', 5));
    $form->count->setValue($settings->getSetting('hashtag.count', 5));



  }
  public function blacklistAction()
  {
    $this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
        ->getNavigation('hashtag_admin_main', array(), 'hashtag_admin_blacklist');

    $page = $this->_getParam('page',1);
    $table = Engine_Api::_()->getDbTable('forbiddentags', 'hashtag');
    $select = $table->select();

    $this->view->form = $form = new Hashtag_Form_Admin_BlackList();

    if ($this->_request->isPost()) {
      $form->isValid($this->_getAllParams());
      $values = $form->getValues();

        foreach($this->check_hash($values['blacktag']) as $item) {
          $sel = $table->select()->where('hashtag=?',$item);
          $tag = $table->fetchRow($sel);
          if($tag == null){
            $table = Engine_Api::_()->getDbTable('forbiddentags', 'hashtag');
            $row = $table->createRow();
            $row->hashtag = $item;
            $row->save();
            $form->addNotice('Hashtag "'.$item.'"  added !');
          }else{
            $form->addNotice('"'.$item.'" already exists');
          }
        }


    }

    $this->view->paginator = $paginator = Zend_Paginator::factory($select);
    $paginator->setItemCountPerPage(30);
    $this->view->paginator = $paginator->setCurrentPageNumber($page);
    //$this->view->totalUsers = $paginator->getTotalItemCount();
    //$this->view->userCount = $paginator->getCurrentItemCount();



  }
  public function deleteAction()
  {
    $id = (int) $this->_getParam('tag_id',0);
    if($id){
      $table = Engine_Api::_()->getDbTable('forbiddentags', 'hashtag');
      $select = $table->select()
          ->where('forbiddentag_id=?', $id);
      $tag = $table->fetchRow($select);
      $tag->delete();
    }
    return $this->_helper->redirector->gotoRoute(array('action' => 'blacklist'));
  }

  public function check_hash($body)
  {
    $vowels = array(".", ",", ";", "!", "?", ":", "*", "#", "'"," ");
    $arr = array_filter(array_unique(explode('^&',str_replace($vowels,'^&',$body))));
    return $arr;
  }


}