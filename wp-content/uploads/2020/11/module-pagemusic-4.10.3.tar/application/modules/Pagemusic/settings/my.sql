INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES
('pagemusic', 'Page Music', 'Page Music', '4.2.0', 1, 'extra');