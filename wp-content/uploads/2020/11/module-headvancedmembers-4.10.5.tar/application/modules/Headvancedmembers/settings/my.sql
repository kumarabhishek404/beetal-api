INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES  ('headvancedmembers', 'Advanced Members', 'Advanced Members', '4.10.5', 1, 'extra') ;
