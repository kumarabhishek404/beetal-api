<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Headvancedmembers
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: Instal.php 2015-10-06 16:58:20  $
 * @author     Bolot
 */

/**
 * @category   Application_Extensions
 * @package    Headvancedmembers
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Headvancedmembers_Installer extends Engine_Package_Installer_Module
{
  public function onPreInstall()
  {
    parent::onPreInstall();

    $db = $this->getDb();
    
    $db->query("INSERT IGNORE  INTO `engine4_core_pages` (`name`, `displayname`, `title`, `description`, `levels`, `provides`)
VALUES ('headvancedmembers_index_browse', 'Headvancedmembers  list', 'Advanced members', 'Advanced members', NULL, NULL);");
    $page_id = $db->lastInsertId();
    
    $db->query("INSERT IGNORE  INTO `engine4_core_content` (`page_id`, `type`, `name`, `params`, `attribs`) VALUES ($page_id, 'container', 'main', NULL, NULL);");
    $container = $db->lastInsertId();
    
    $db->query("INSERT IGNORE  INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `params`, `attribs`) VALUES ($page_id, 'container', 'middle', $container, NULL, NULL);");
    $container1 = $db->lastInsertId();
    $db->query("INSERT IGNORE  INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ($page_id, 'widget', 'core.content', $container1, 3, '[]', NULL);");
    
    $db->query("INSERT IGNORE  INTO `engine4_core_menus` (`name`, `title`) VALUES ('headvancedmembers_admin_main', 'Headvancedmembers Admin Navigation Menu');");
    
    $db->query("INSERT IGNORE  INTO `engine4_core_menuitems` (`name`, `module`, `label`, `params`, `menu`, `order`)
VALUES ('headvancedmembers_admin_general', 'headvancedmembers', 'General', '{\"route\":\"admin_default\",\"module\":\"headvancedmembers\",\"controller\":\"index\",\"action\":\"index\"}', 'headvancedmembers_admin_main', 1);");
    
    $db->query("INSERT IGNORE  INTO `engine4_core_menuitems` (`name`, `module`, `label`, `params`, `menu`, `order`)
VALUES ('headvancedmembers_admin_members', 'headvancedmembers', 'Members', '{\"route\":\"admin_default\",\"module\":\"headvancedmembers\",\"controller\":\"index\",\"action\":\"members\"}', 'headvancedmembers_admin_main', 1);");
    
    $db->query("CREATE TABLE IF NOT EXISTS `engine4_headvancedmembers_verification` (
`verification_id` INT(11) NOT NULL AUTO_INCREMENT,
`user_id` INT(11) NOT NULL DEFAULT '0',
`verified_id` INT(11) NOT NULL DEFAULT '0',
`date` DATETIME NULL,
PRIMARY KEY (`verification_id`)
);");
    $db->query("CREATE TABLE IF NOT EXISTS `engine4_headvancedmembers_status` (
`user_id` INT(10) NULL DEFAULT NULL,
`status` INT(10) NULL DEFAULT NULL,
`status_id` INT(10) NOT NULL AUTO_INCREMENT,
PRIMARY KEY (`status_id`)
);");
    
    $db->query("INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `params`,`menu`,`enabled`,`custom`,`order`)
VALUES ('core_admin_main_plugins_headvancedmembers','headvancedmembers', 'HE - Advanced Members','{\"route\":\"admin_default\",\"module\":\"headvancedmembers\",\"controller\":\"index\",\"action\":\"index\"}','core_admin_main_plugins',1,0,888);");
    
    $page_id = $db->query("select * from engine4_core_pages where name = 'timeline_profile_index'")->fetchColumn('page_id');
    if($page_id){
        $sql = "select * from engine4_core_content where page_id=$page_id and name = 'timeline.new-feed'";
        
        $content_id = $db->query($sql)->fetchColumn('content_id');
        if($content_id){
            $sql ="INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ($page_id, 'widget', 'headvancedmembers.verify', $content_id, 1, '[]', NULL)";
            $db->query($sql);
        }
    }
    
    $page_id = $db->query("select * from engine4_core_pages where name = 'user_profile_index'")->fetchColumn('page_id');
    if($page_id){
        $sql ="select * from engine4_core_content where page_id=$page_id and name = 'left'";        
        $content_id = $db->query($sql)->fetchColumn('content_id');
        if($content_id){
            $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES ($page_id, 'widget', 'headvancedmembers.verify', $content_id, 1, '[]', NULL)";
            $db->query($sql);
        }
    }
    
    $db->query("CREATE TABLE IF NOT EXISTS `engine4_headvancedmembers_markers` (
`marker_id` INT(11) NOT NULL AUTO_INCREMENT,
`adres` VARCHAR(100) NOT NULL,
`user_id` INT(11) NOT NULL,
`latitude` FLOAT(10,6) NULL DEFAULT NULL,
`longitude` FLOAT(10,6) NULL DEFAULT NULL,
PRIMARY KEY (`marker_id`)
)
COLLATE='utf8_general_ci'
ENGINE=InnoDB;");
    
    $db->query("INSERT IGNORE INTO `engine4_core_menuitems` ( `name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES ( 'headvancedmembers_settings', 'headvancedmembers', 'My location', '', '{\"route\":\"headvancedmembers_settings\"}', 'user_settings', '', 1, 0, 2);");
    
    $db->query("INSERT IGNORE INTO `engine4_core_settings` (`name`, `value`) VALUES ('headvancedmembers.gmapkey', '');");
    
    
  }
}