--
-- Update module Pageblog
--

UPDATE `engine4_core_modules` SET `version` = '4.1.2'  WHERE `name` = 'pageevent';