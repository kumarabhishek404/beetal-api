<?php 

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version Tags 1.03
 */

function he_tag_supported_plugin()
{
	static $plugins;

	if ( $plugins === null )
	{	
		$plugins = array(
			'album' => array( 
				'content' => 'album', 
				'entity_type' => 1, 
				'entity_url' => 'album_tags.php',
				'label' => 690690046,
				'tab' => 690690089,
				'user_level' => he_tag_check_user_level('album')
			),
			'video' => array( 
				'content' => 'video',
				'entity_type' => 2,
				'entity_url' => 'video_tags.php',
				'label' => 690690047,
				'tab' => 690690090,
				'user_level' => he_tag_check_user_level('video')
			),		
			'blog' => array( 
				'content' => 'blog',
				'entity_type' => 3,
				'entity_url' => 'blog_tags.php',
				'label' => 690690048,
				'tab' => 690690092,
				'user_level' => he_tag_check_user_level('blog')
			),		
			'event' => array( 
				'content' => 'event',
				'entity_type' => 4,
				'entity_url' => 'event_tags.php',
				'label' => 690690049,
				'tab' => 690690093,
				'user_level' => he_tag_check_user_level('event')
			),		
			'group' => array( 
				'content' => 'group',
				'entity_type' => 5,
				'entity_url' => 'group_tags.php',
				'label' => 690690081,
				'tab' => 690690091,
				'user_level' => he_tag_check_user_level('group')
			),		
			'he_quiz' => array( 
				'content' => 'he_quiz',
				'entity_type' => 6,
				'entity_url' => 'quiz_tags.php',
				'label' => 690690085,
				'tab' => 690690088,
				'user_level' => he_tag_check_user_level('he_quiz')
            ),
            'music' => array( 
                'content' => 'music',
                'entity_type' => 7,
                'entity_url' => 'music_tags.php',
                'label' => 690690097,
                'tab' => 690690098,
                'user_level' => he_tag_check_user_level('music')
			)
		);
	}

	return $plugins;
}

function he_tag_available_plugin( $plugin_name = false )
{
	static $plugins;
	
	if ( $plugins === null )
	{
		global $global_plugins;
		
		global $admin;

		$supported_plugins = he_tag_supported_plugin();

		$plugins = array();

		$plugin_names = array_keys($global_plugins);

		foreach ( $plugin_names as $name )
		{
			if ( isset($supported_plugins[$name]) && ( $supported_plugins[$name]['user_level'] || $admin->admin_exists ) )
			{
				$plugins[$name] = $supported_plugins[$name]; 
			}
		}
	}
	
	if ( $plugin_name )
	{
		return isset($plugins[$plugin_name]);
	}
	
	return $plugins;
}

function he_tag_plugin_info( $name )
{
	static $plugins;
	
	if ( $plugins === null )
	{
		$plugins = he_tag_supported_plugin();
	}
	
	return $plugins[$name];
}

function he_tag_check_user_level( $name )
{
    global $user, $admin, $setting;
	
	if ( $admin->admin_exists )
	{
		return 1;
	}
			   
	switch ( $name ) 
	{
		case 'album':
			$level = ($user->user_exists && $user->level_info['level_album_allow']) 
					+ (!$user->user_exists && $setting['setting_permission_album']);
		break;

		case 'video':
			$level = ($user->user_exists && ($user->level_info['level_video_allow'] || $user->level_info['level_youtube_allow'])) 
					+ (!$user->user_exists && $setting['setting_permission_video']);
		break;
		
		case 'blog':
			$level = (!$user->user_exists && $setting['setting_permission_blog']) 
					+ ($user->user_exists && $user->level_info['level_blog_view']);
		break;
					
		case 'event':
			$level = ($user->user_exists && ($user->level_info['level_event_allow'] & 1)) 
					+ (!$user->user_exists && $setting['setting_permission_event']);
		break;	
		
		case 'group':
			$level = ($user->user_exists && ($user->level_info['level_event_allow'] & 1)) 
					+ (!$user->user_exists && $setting['setting_permission_event']);
		break;	
		
		case 'he_quiz':
			$level = 1;
        break;

        case 'music':
			$level = 1;
		break;
		
		default:
			$level = 0;
		break;
	}
	
	return $level;		
}

function he_frontend_tag_navigator( $params = array() )
{

	$entity = trim($params['type']);
		
	$count = isset($params['count']) ? (int)$params['count'] : 50;	
	
	$font_styles = array();	
	$font_styles['min_font_size'] = isset($params['min_font_size']) ? (int)$params['min_font_size'] : 10;
	$font_styles['max_font_size'] = isset($params['max_font_size']) ? (int)$params['max_font_size'] : 30;
	
	$width = isset($params['width']) ? (int)$params['width'] : 500;
	
	if ( !isset($params['tags']) )
	{
		$tag_service = new he_tag_service($entity);
		$tags = $tag_service->get_browse_list($count, $font_styles);
	}
	else
	{
		$tags = $params['tags'];
	}

	$lang_var = SE_Language::get(690690076);
	$not_tag_var = SE_Language::get(690690086);
	
	$tag_str = '';
	foreach ($tags as $tag)
	{
		$tag_str .= '<a href="' . $tag['url'] . '" style="font-size:' . 
		$tag['size'] . 'px;line-height:' . 
		$tag['line_height'] . 'px;">' . 
		$tag['label'] . '</a> ';
	}

	$tag_str = ( strlen($tag_str) ) ? $tag_str : '<center>' . $not_tag_var . '</center>';
	
	return <<<OUTPUT
<div class="tag_cont" style="width: {$width}px;">
<div class="block">
	<h1>$lang_var</h1>
	<div class="inner">
		$tag_str
	</div>
</div>
</div>
OUTPUT;
}

function he_frontend_tag_clouds( $params = array() )
{
    $active_tab = isset($params['active_tab']) ? trim($params['active_tab']) : '';        
	$count = isset($params['count']) ? (int)$params['count'] : 50;	
	
	$font_styles = array();	
	$font_styles['min_font_size'] = isset($params['min_font_size']) ? (int)$params['min_font_size'] : 10;
	$font_styles['max_font_size'] = isset($params['max_font_size']) ? (int)$params['max_font_size'] : 30;
	
	$width = isset($params['width']) ? (int)$params['width'] 
									 : (isset($params['tags']) ? 500 : 0);
	
	$not_tag_var = SE_Language::get(690690086);
	$tag_plugins = he_tag_available_plugin();
	
	$rand_prefix = rand(0, 100);
	
	$tag_tabs = '';
	$tag_clouds = '';

	foreach ( $tag_plugins as $plugin )
	{
		$node_id = 'he_tag_' . $rand_prefix . $plugin['entity_type'];
		$active_tab_class = ( $active_tab==$plugin['content'] ) ? ' active_tab' : '';
		
		if ( $params['tags'] )
		{
			$tags = $params['tags'];
		}
		else
		{
			$tag_service = new he_tag_service($plugin['content']);
			$tags = $tag_service->get_browse_list($count, $font_styles);
		}
		
		$tag_tabs .= '<div class="he_tag_tab he_tag_ ' . $active_tab_class .
			'" onmouseup="this.blur()" onmousedown="tag_service.switch_cloud_tab(this, \'' . $node_id . '\')"><label>' . 
			SE_Language::get($plugin['tab']) . '</label></div>';
		
		$tag_clouds .= '<div class="he_tag_cloud' . $active_tab_class . '" id="' . $node_id . '">';
		$tag_str = '';
		foreach ( $tags as $tag )
		{
			$tag_str .= '<a href="' . $tag['url'] . '" style="font-size:' . 
			$tag['size'] . 'px; line-height:' . 
			$tag['line_height'] . 'px;">' . 
			$tag['label'] . '</a> ';
		}
		
		if ( !strlen($tag_str) )
		{
			$tag_str = '<center>' . $not_tag_var . '</center>';
		}
		
		$tag_clouds .= $tag_str . '</div>'; 
	}
	
	$lang_var = SE_Language::get(690690076);
	
	$width_str = ( $width ) ? 'style="width: ' . $width . 'px;"' : '';
	
	return <<<TAG_CLOUD
<script src="./include/js/he_tag_service.js" type="text/javascript"></script>
<div class="tag_cont" $width_str>
<div class="block_cap">
	<div class="he_tag_tab_label">$lang_var</div>
	$tag_tabs
	<div class="clr"></div>
</div>
<div class="block">
	<div class="inner">
		$tag_clouds
	</div>
</div>
</div>
TAG_CLOUD;
}

?>