<?php

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version Tags 1.03
 */
 
class he_user_content
{
	var $user_id;
	
	var $username;

	var $content_type;
	
	/**
	 * @var he_tag_service
	 */
	var $tag_service;
	
	function he_user_content( $content_type )
	{
		global $user;
		
		$this->user_id = $user->user_info['user_id'];
		$this->username = $user->user_info['user_username'];
		
		$this->content_type = $content_type;
		$this->tag_service = new he_tag_service($this->content_type);
	}
	
	function get_user_content( $start, $count )
	{	
		$user_content = array( 'list' => array(), 'tags' => array(), 'total' => array() );
			
		switch ($this->content_type)
		{
			case 'album':
				$user_content = $this->get_user_albums($start, $count);
				
				break;
			
			case 'video':
				$user_content = $this->get_user_videos($start, $count);
				
				break;
				
			case 'blog':
				$user_content = $this->get_user_blog($start, $count);
				
				break;
				
			case 'event':
				$user_content = $this->get_user_events($start, $count);
				
				break;
				
			case 'group':
				$user_content = $this->get_user_group($start, $count);

				break;
				
			case 'he_quiz':
				$user_content = $this->get_user_quiz($start, $count);
				
				break;
				
			case 'music':
				$user_content = $this->get_user_musics($start, $count);
				
				break;
				
			default:
				
				break;
		}
		
		return $user_content;
	}
		
	function get_user_albums( $start, $count )
	{
		global $url;
	
		$albums = array();
		global $url;

		$albums_ids = array();
		
		$class_album = new se_album($this->user_id);

		//get user albums
		$album_info = $class_album->album_list($start, $count);
		
		foreach ($album_info as $album) {
			$item = array();

			$albums_ids[] = $album['album_id'];

			$item['id'] = $album['album_id'];
			$item['label'] = $album['album_title'];
			$item['description'] = $album['album_desc'];
			$item['url'] = $url->url_create('album', $this->username, $album['album_id']);
			if ( $album['album_cover_id']===0 ) {
				$item['thumb'] = './images/icons/folder_big.gif';
			} 
			else { 
				$item['thumb'] = $url->url_userdir($this->user_id) . $album['album_cover_id'] . '_thumb.jpg';
			}

			$albums[$album['album_id']] = $item;
		}

		
		
		//get albums tags
		$tags = $this->tag_service->find_by_entity_id_list($albums_ids);
		$total = $class_album->album_total();

		return array( 'list' => $albums, 'tags' => $tags, 'total' => $total );
	}
	
	function get_user_videos( $start, $count )
	{
		global $url;
		
		//get user videos
		$class_video = new se_video($this->user_id);	
		$videos = $class_video->video_list($start, $count);
		
		$video_list = array();
		$video_ids = array();
		
		foreach ($videos as $video)
		{
			$item = array();
			$video_id = $video['video_id'];
			
			$item['id'] = $video_id;
			$item['label'] = $video['video_title'];
			$item['description'] = $video['video_desc'];
			
			$item['url'] = $url->url_create('video', $this->username, $video_id);
			
			$item['thumb'] = ( $video['video_thumb'] ) 
				? $video['video_dir'] . $video_id . '_thumb.jpg' 
				: './images/video_placeholder.gif';
			
			$video_list[$video_id] = $item;
			$video_ids[] = $video_id;
		}
		
		$tags = $this->tag_service->find_by_entity_id_list($video_ids);
		$total = $class_video->video_total();
		
		return array( 'list' => $video_list, 'tags' => $tags, 'total' => $total );
	}
		
	
	function get_user_blog( $start, $count )
	{
		global $url;
		
		//get user videos
		$class_blog = new se_blog($this->user_id);
		$blog = $class_blog->blog_entries_list($start, $count);
		
		$blog_list = array();
		$blog_ids = array();
		
		foreach ($blog as $entity)
		{
			$item = array();
			$entity_id = $entity['blogentry_id'];
			
			$item['id'] = $entity_id;
			$item['label'] = $entity['blogentry_title'];
			$item['description'] = $entity['blogentry_body'];
			
			$item['url'] = $url->url_create('blog', $this->username, $entity_id);
			
			$blog_list[$entity_id] = $item;
			$blog_ids[] = $entity_id;
		}
		
		$tags = $this->tag_service->find_by_entity_id_list($blog_ids);
		$total = $class_blog->blog_entries_total();
		
		return array( 'list' => $blog_list, 'tags' => $tags, 'total' => $total );
	}
		
	
	function get_user_events( $start, $count )
	{
		global $url;

		//get user videos
		$class_events = new se_event($this->user_id);
		$events = $class_events->event_list($start, $count, "event_id DESC", "(se_eventmembers.eventmember_rank = 3)");

		$events_list = array();
		$events_ids = array();

		foreach ($events as $entity)
		{
			$item = array();
			$event_info = $entity['event']->event_info;
			
			$entity_id = $event_info['event_id'];
			
			$item['id'] = $entity_id;
			$item['label'] = $event_info['event_title'];
			$item['description'] = $event_info['event_desc'];
			$item['url'] = $url->url_create('event', $this->username, $entity_id);
			
			$item['thumb'] = $entity['event']->event_photo("./images/nophoto.gif");
			
			$events_list[$entity_id] = $item;
			$events_ids[] = $entity_id;
		}
		
		$tags = $this->tag_service->find_by_entity_id_list($events_ids);
		$total = $class_events->event_total();
		
		return array( 'list' => $events_list, 'tags' => $tags, 'total' => $total );
	}
		
	
	function get_user_group( $start, $count )
	{
		global $url;

		//get user group
		$class_group = new se_group($this->user_id);
		$groups = $class_group->group_list($start, $count, "group_id DESC", " (se_groupmembers.groupmember_rank = 2) ");

		$group_list = array();
		$group_ids = array();

		foreach ($groups as $group)
		{
			$item = array();
			$group_info = $group['group']->group_info;
			$group_id = $group_info['group_id'];
			
			$item['id'] = $group_id;
			$item['label'] = $group_info['group_title'];
			$item['description'] = $group_info['group_desc'];
			$item['url'] = $url->url_create('group', $this->username, $group_id);
			
			$item['thumb'] = $group['group']->group_photo("./images/nophoto.gif");
			
			$group_list[$group_id] = $item;
			$group_ids[] = $group_id;
		}
		
		$tags = $this->tag_service->find_by_entity_id_list($group_ids);
		$total = $class_group->group_total();

		return array( 'list' => $group_list, 'tags' => $tags, 'total' => $total );
	}
		
	function get_user_quiz( $start, $count )
	{
		global $url;
		
		$quizzes = he_quiz::user_quiz_list($this->user_id, $start, $count);
		
		$quiz_list = array();		
		foreach ($quizzes as $quiz)
		{
			$item = array();
			
			$item['id'] = $quiz['id'];
			$item['label'] = $quiz['name'];
			$item['description'] = $quiz['description'];
			$item['url'] = $url->url_base .  'quiz_general.php?quiz_id=' . $quiz['id'];
			
			$item['thumb'] = ( $quiz['photo_url'] ) ? $quiz['photo_url'] : './images/he_quiz_thumb.jpg';
			
			$quiz_list[$quiz['id']] = $item;
		}
		
		$quiz_ids = array_keys($quizzes);
		
		$tags = $this->tag_service->find_by_entity_id_list($quiz_ids);
		$total = he_quiz::user_quiz_total($this->user_id);

		return array( 'list' => $quiz_list, 'tags' => $tags, 'total' => $total );
	}

	function get_user_musics($start, $count)
	{
		global $url;
		
		$musics = array();
		
		$class_music = new se_music($this->user_id);
		$music_info = $class_music->music_list($start, $count);
				
		foreach ($music_info as $music)
		{
			$music_user = new se_user($music['music_user_id']);
			$item = array();
			$musics_ids[] = $music['music_id'];
			$item['id'] = $music['music_id'];
			$item['label'] = $music['music_title'];
			$item['url'] = $url->url_create("profile", $music_user->user_info['user_username']);
			$musics[$music['music_id']] = $item;
		}
		
		$tags = $this->tag_service->find_by_entity_id_list($musics_ids);
		$total = $class_music->music_total();
		
		return array('list' => $musics, 'tags' => $tags, 'total' => $total);
	}	
}

?>