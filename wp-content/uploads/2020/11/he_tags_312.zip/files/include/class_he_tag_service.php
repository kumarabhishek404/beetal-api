<?php

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version Tags 1.03
 */

class he_tag_service
{
	var $TBL_TAG = 'se_he_tag', 
		$TBL_ENTITY_TAG = 'se_he_entity_tag';
	
	var $entity,
		$entity_type,
		$entity_url,
		$entity_cond;
	
	function he_tag_service( $entity )
	{
		$plugin_info = he_tag_plugin_info($entity);

		$this->entity = $entity;
		$this->entity_type = $plugin_info['entity_type'];
		$this->entity_url = $plugin_info['entity_url'];
	}
	
	function add_tag( $entity_id, $tag_label )
	{
		if ( !$entity_id || !$tag_label )
		{
			return false;
		}
		
		$tag_id = $this->get_id_by_label($tag_label);
		
		$query = he_database::placeholder( "INSERT INTO `" . $this->TBL_ENTITY_TAG . "` 
			(`entity_type`, `entity_id`, `tag_id`) VALUES(?, ?, ?)", $this->entity_type, $entity_id, $tag_id );
		
		he_database::query($query);
		
		return he_database::insert_id();
	}
	
	function get_id_by_label( $label )
	{
		$query = he_database::placeholder( "SELECT `id` FROM `" . $this->TBL_TAG . "` 
			WHERE `label`='?'", $label );
		
		$tag_id = he_database::fetch_field($query);
		
		if ( !$tag_id )
		{
			$query = he_database::placeholder( "INSERT INTO `" . $this->TBL_TAG . "` 
				(`label`) VALUES('?')", $label );
			
			he_database::query($query);
			
			$tag_id = he_database::insert_id();
		}
		
		return $tag_id;
	}
	
	function find_by_entity_id_list( $entity_ids = array() )
	{
		if ( !$entity_ids )
		{
			return array();
		}
		
		global $database;
		
		$entity_str = implode(',', $entity_ids);
		
		$query = he_database::placeholder( "SELECT `entity`.`entity_id`, `tag`.`label` FROM `" . $this->TBL_ENTITY_TAG . "` AS `entity`
			LEFT JOIN `" . $this->TBL_TAG . "` AS `tag` ON (`entity`.`tag_id`=`tag`.`id`)
			WHERE `entity`.`entity_type`=? AND `entity`.`entity_id` IN ( $entity_str )", $this->entity_type );

		$tag_arr = array();
		$res = he_database::query($query);
		while ($row = $database->database_fetch_assoc($res))
		{
			$tag_arr[$row['entity_id']] = isset($tag_arr[$row['entity_id']]) 
				? $tag_arr[$row['entity_id']] 
				: array();
			$tag_arr[$row['entity_id']][] = $row['label'];
		}
		
		$entity_arr = array();
		foreach ($tag_arr as $entity_id => $tags)
		{
			$entity_arr[$entity_id] = implode(', ', $tags);
		}

		return $entity_arr;
	}
	
	function find_by_tag_id( $tag_id )
	{
		if ( $tag_id===0 )
		{
			return false;
		}

		$query = he_database::placeholder( "SELECT `label` FROM `". $this->TBL_TAG ."` 
			WHERE `id`=? ", $tag_id );

		return he_database::fetch_field($query);
	}
	
	function find_entity_id_list( $tag_id )
	{
		if ( !$tag_id )
		{
			return array();
		}
		
		$query = he_database::placeholder( "SELECT `entity_id` FROM `" . $this->TBL_ENTITY_TAG . "` AS `entity`
			LEFT JOIN `" . $this->TBL_TAG . "` AS `tag` ON (`entity`.`tag_id`=`tag`.`id`)
			WHERE `entity`.`entity_type`=? AND `tag`.`id`=?", $this->entity_type, $tag_id );

		return he_database::fetch_column($query);
	}

	function add_entity_tag( $entity_id, $tag_str )
	{
		if ( !$entity_id || !$tag_str )
		{
			return false;
		}
		
		$tags = explode(',', $tag_str);
		$tags = array_map('trim', $tags);
		$tags = array_unique($tags);
		
		foreach ($tags as $tag)
		{
			if ( !$tag ) 
			{
				continue;
			}
			
			$this->add_tag($entity_id, $tag);
		}
	}
	
	function update_entity_tag( $entity_id, $tag_str )
	{
		if ( !$entity_id )
		{
			return false;
		}
		//delete old tags
		$query = he_database::placeholder( "DELETE FROM `" . $this->TBL_ENTITY_TAG . "` 
			WHERE `entity_type`=? AND `entity_id`=?", $this->entity_type, $entity_id );

		he_database::query($query);

		//add new tags
		$this->add_entity_tag($entity_id, $tag_str);
		
		return $this->get_entity_tag($entity_id);
	}
	
	function get_entity_tag( $entity_id )
	{
		$query = he_database::placeholder( "SELECT `tag`.`label` FROM `" . $this->TBL_ENTITY_TAG . "` AS `entity`
			LEFT JOIN `" . $this->TBL_TAG . "` AS `tag` ON (`entity`.`tag_id`=`tag`.`id`)
			WHERE `entity`.`entity_type`=? AND `entity`.`entity_id`=?", $this->entity_type, $entity_id );
		$tag_arr = he_database::fetch_column($query);

		return implode(', ', $tag_arr);
	}
	
	function get_browse_list( $count, $font_styles )
	{
		$this->set_entity_condition();
				
		switch ( $this->entity )
		{
			case 'album':
				$tags = $this->get_tag_list('se_albums', 'album_id', $this->entity_cond, $count);
				break;
				
			case 'video':
				$tags = $this->get_tag_list('se_videos', 'video_id', $this->entity_cond, $count);
				break;
				
			case 'blog':
				$tags = $this->get_tag_list('se_blogentries', 'blogentry_id', $this->entity_cond, $count);
				break;
				
			case 'event':
				$tags = $this->get_tag_list('se_events', 'event_id', $this->entity_cond, $count);
				break;
				
			case 'group':
				$tags = $this->get_tag_list('se_groups', 'group_id', $this->entity_cond, $count);
				break;
				
			case 'he_quiz':
				$tags = $this->get_tag_list('se_he_quiz', 'id', $this->entity_cond, $count);
				break;
				
			case 'music':
				$tags = $this->get_tag_list('se_music', 'music_id', $this->entity_cond, $count);
				break;
				
			default:
				return false;
				break;
		}
		
		return $this->prepare_tags($tags, $font_styles);						
	}
	
	function get_tag_list( $TBL_MAIN, $id_name, $where_cond = '', $count = false )
	{
		$limit = ( $count ) ? 'LIMIT ' . $count : '';
		
		if ( $where_cond)
		{
			$query = he_database::placeholder( "SELECT `t`.`id` AS `tag_id`, `t`.`label`, COUNT(`e`.`tag_id`) AS `count` 
				FROM `" . $this->TBL_ENTITY_TAG . "` AS `e`
				LEFT JOIN  `" . $this->TBL_TAG . "` AS `t` ON (`e`.`tag_id`=`t`.`id`)
				INNER JOIN `" . $TBL_MAIN . "` ON (`e`.`entity_id`=`" . $TBL_MAIN . "`.`" . $id_name . "`)
				WHERE `e`.`entity_type`=? AND $where_cond
				GROUP BY `e`.`tag_id`
				$limit", $this->entity_type );			
		}
		else
		{
			$query = he_database::placeholder( "SELECT `t`.`id` AS `tag_id`, `t`.`label`, COUNT(`e`.`tag_id`) AS `count` 
				FROM `" . $this->TBL_ENTITY_TAG . "` AS `e`
				LEFT JOIN  `" . $this->TBL_TAG . "` AS `t` ON (`e`.`tag_id`=`t`.`id`)
				INNER JOIN `" . $TBL_MAIN . "` ON (`e`.`entity_id`=`" . $TBL_MAIN . "`.`" . $id_name . "`)
				WHERE `e`.`entity_type`=?
				GROUP BY `e`.`tag_id`
				$limit", $this->entity_type );
		}

		return he_database::fetch_array($query);
	}
	
	function set_entity_condition()
	{
		if ( isset($this->entity_cond) )
		{
			return true;	
		}
		
		global $user;
		
		switch ( $this->entity )
		{
			case 'video':
				$this->entity_cond = "`se_videos`.`video_search`='1' AND `se_videos`.`video_is_converted`='1' AND
					(CASE
					    WHEN `se_videos`.`video_user_id`='{$user->user_info['user_id']}'
					      THEN TRUE
					    WHEN ((`se_videos`.`video_privacy` & @SE_PRIVACY_REGISTERED) AND '{$user->user_exists}'<>0)
					      THEN TRUE
					    WHEN ((`se_videos`.`video_privacy` & @SE_PRIVACY_ANONYMOUS) AND '{$user->user_exists}'=0)
					      THEN TRUE
					    WHEN ((`se_videos`.`video_privacy` & @SE_PRIVACY_FRIEND) AND (SELECT TRUE FROM `se_friends` WHERE `friend_user_id1`=`se_videos`.`video_user_id` AND `friend_user_id2`='{$user->user_info['user_id']}' AND `friend_status`='1' LIMIT 1))
					      THEN TRUE
					    WHEN ((`se_videos`.`video_privacy` & @SE_PRIVACY_SUBNET) AND '{$user->user_exists}'<>0 AND (SELECT TRUE FROM `se_users` WHERE `user_id`=`se_videos`.`video_user_id` AND `user_subnet_id`='{$user->user_info['user_subnet_id']}' LIMIT 1))
					      THEN TRUE
					    WHEN ((`se_videos`.`video_privacy` & @SE_PRIVACY_FRIEND2) AND (SELECT TRUE FROM `se_friends` AS `friends_primary` LEFT JOIN `se_users` ON `friends_primary`.`friend_user_id1`=`se_users`.`user_id` LEFT JOIN `se_friends` AS `friends_secondary` ON `friends_primary`.`friend_user_id2`=`friends_secondary`.`friend_user_id1` WHERE `friends_primary`.`friend_user_id1`=`se_videos`.`video_user_id` AND `friends_secondary`.`friend_user_id2`='{$user->user_info['user_id']}' AND `se_users`.`user_subnet_id`='{$user->user_info['user_subnet_id']}' LIMIT 1))
					      THEN TRUE
					    ELSE FALSE
					END)";
			break;
			
			case 'event':
				$this->entity_cond = "CASE
				    WHEN `se_events`.`event_user_id`='{$user->user_info['user_id']}'
				      THEN TRUE
				    WHEN ((`se_events`.`event_privacy` & 32) AND '{$user->user_exists}'<>0)
				      THEN TRUE
				    WHEN ((`se_events`.`event_privacy` & 64) AND '{$user->user_exists}'=0)
				      THEN TRUE
				    WHEN ((`se_events`.`event_privacy` & 2) AND (SELECT TRUE FROM `se_eventmembers` WHERE `eventmember_user_id`='{$user->user_info['user_id']}' AND `eventmember_event_id`=`se_events`.`event_id` AND `eventmember_status`=1 LIMIT 1))
				      THEN TRUE
				    WHEN ((`se_events`.`event_privacy` & 4) AND '{$user->user_exists}'<>0 AND (SELECT TRUE FROM `se_friends` WHERE `friend_user_id1`=`se_events`.`event_user_id` AND `friend_user_id2`='{$user->user_info['user_id']}' AND `friend_status`=1 LIMIT 1))
				      THEN TRUE
				    WHEN ((`se_events`.`event_privacy` & 8) AND '{$user->user_exists}'<>0 AND (SELECT TRUE FROM `se_eventmembers` LEFT JOIN `se_friends` ON `se_eventmembers`.`eventmember_user_id`=`se_friends`.`friend_user_id1` WHERE `se_eventmembers`.`eventmember_event_id`=`se_events`.`event_id` AND `se_friends`.`friend_user_id2`='{$user->user_info['user_id']}' AND `se_eventmembers`.`eventmember_status`=1 AND `se_friends`.`friend_status`=1 LIMIT 1))
				      THEN TRUE
				    WHEN ((`se_events`.`event_privacy` & 16) AND '{$user->user_exists}'<>0 AND (SELECT TRUE FROM `se_eventmembers` LEFT JOIN `se_friends` AS `friends_primary` ON `se_eventmembers`.`eventmember_user_id`=`friends_primary`.`friend_user_id1` LEFT JOIN `se_friends` AS `friends_secondary` ON `friends_primary`.`friend_user_id2`=`friends_secondary`.`friend_user_id1` WHERE `se_eventmembers`.`eventmember_event_id`=`se_events`.`event_id` AND `se_eventmembers`.`eventmember_status`=1 AND `friends_secondary`.`friend_user_id2`='{$user->user_info['user_id']}' AND `friends_primary`.`friend_status`=1 AND `friends_secondary`.`friend_status`=1 LIMIT 1))
				      THEN TRUE
				    ELSE FALSE
					END";
			break;
				
			case 'album':
				$this->entity_cond = "CASE
					WHEN se_albums.album_user_id='{$user->user_info['user_id']}'
					  THEN TRUE
					WHEN ((se_albums.album_privacy & @SE_PRIVACY_REGISTERED) AND '{$user->user_exists}'<>0)
					  THEN TRUE
					WHEN ((se_albums.album_privacy & @SE_PRIVACY_ANONYMOUS) AND '{$user->user_exists}'=0)
					  THEN TRUE
					WHEN ((se_albums.album_privacy & @SE_PRIVACY_FRIEND) AND (SELECT TRUE FROM se_friends WHERE friend_user_id1=se_albums.album_user_id AND friend_user_id2='{$user->user_info['user_id']}' AND friend_status='1' LIMIT 1))
					  THEN TRUE
					WHEN ((se_albums.album_privacy & @SE_PRIVACY_SUBNET) AND '{$user->user_exists}'<>0 AND (SELECT TRUE FROM se_users WHERE user_id=se_albums.album_user_id AND user_subnet_id='{$user->user_info['user_subnet_id']}' LIMIT 1))
					  THEN TRUE
					WHEN ((se_albums.album_privacy & @SE_PRIVACY_FRIEND2) AND (SELECT TRUE FROM se_friends AS friends_primary LEFT JOIN se_users ON friends_primary.friend_user_id1=se_users.user_id LEFT JOIN se_friends AS friends_secondary ON friends_primary.friend_user_id2=friends_secondary.friend_user_id1 WHERE friends_primary.friend_user_id1=se_albums.album_user_id AND friends_secondary.friend_user_id2='{$user->user_info['user_id']}' AND se_users.user_subnet_id='{$user->user_info['user_subnet_id']}' LIMIT 1))
					  THEN TRUE
					ELSE FALSE
					END";
			break;
			
			case 'blog':
				$this->entity_cond = "CASE
					WHEN se_blogentries.blogentry_user_id='{$user->user_info['user_id']}'
					  THEN TRUE
					WHEN ((se_blogentries.blogentry_privacy & @SE_PRIVACY_REGISTERED) AND '{$user->user_exists}'<>0)
					  THEN TRUE
					WHEN ((se_blogentries.blogentry_privacy & @SE_PRIVACY_ANONYMOUS) AND '{$user->user_exists}'=0)
					  THEN TRUE
					WHEN ((se_blogentries.blogentry_privacy & @SE_PRIVACY_FRIEND) AND (SELECT TRUE FROM se_friends WHERE friend_user_id1=se_blogentries.blogentry_user_id AND friend_user_id2='{$user->user_info['user_id']}' AND friend_status='1' LIMIT 1))
					  THEN TRUE
					WHEN ((se_blogentries.blogentry_privacy & @SE_PRIVACY_SUBNET) AND '{$user->user_exists}'<>0 AND (SELECT TRUE FROM se_users WHERE user_id=se_blogentries.blogentry_user_id AND user_subnet_id='{$user->user_info['user_subnet_id']}' LIMIT 1))
					  THEN TRUE
					WHEN ((se_blogentries.blogentry_privacy & @SE_PRIVACY_FRIEND2) AND (SELECT TRUE FROM se_friends AS friends_primary LEFT JOIN se_users ON friends_primary.friend_user_id1=se_users.user_id LEFT JOIN se_friends AS friends_secondary ON friends_primary.friend_user_id2=friends_secondary.friend_user_id1 WHERE friends_primary.friend_user_id1=se_blogentries.blogentry_user_id AND friends_secondary.friend_user_id2='{$user->user_info['user_id']}' AND se_users.user_subnet_id='{$user->user_info['user_subnet_id']}' LIMIT 1))
					  THEN TRUE
					ELSE FALSE
					END";
			break;
			
			case 'group':
				$this->entity_cond = "CASE
					WHEN se_groups.group_user_id='{$user->user_info['user_id']}'
					  THEN TRUE
					WHEN ((se_groups.group_privacy & 32) AND '{$user->user_exists}'<>0)
					  THEN TRUE
					WHEN ((se_groups.group_privacy & 64) AND '{$user->user_exists}'=0)
					  THEN TRUE
					WHEN ((se_groups.group_privacy & 2) AND (SELECT TRUE FROM se_groupmembers WHERE groupmember_user_id='{$user->user_info['user_id']}' AND groupmember_group_id=se_groups.group_id AND groupmember_status=1 LIMIT 1))
					  THEN TRUE
					WHEN ((se_groups.group_privacy & 4) AND '{$user->user_exists}'<>0 AND (SELECT TRUE FROM se_friends WHERE friend_user_id1=se_groups.group_user_id AND friend_user_id2='{$user->user_info['user_id']}' AND friend_status=1 LIMIT 1))
					  THEN TRUE
					WHEN ((se_groups.group_privacy & 8) AND '{$user->user_exists}'<>0 AND (SELECT TRUE FROM se_groupmembers LEFT JOIN se_friends ON se_groupmembers.groupmember_user_id=se_friends.friend_user_id1 WHERE se_groupmembers.groupmember_group_id=se_groups.group_id AND se_friends.friend_user_id2='{$user->user_info['user_id']}' AND se_groupmembers.groupmember_status=1 AND se_friends.friend_status=1 LIMIT 1))
					  THEN TRUE
					WHEN ((se_groups.group_privacy & 16) AND '{$user->user_exists}'<>0 AND (SELECT TRUE FROM se_groupmembers LEFT JOIN se_friends AS friends_primary ON se_groupmembers.groupmember_user_id=friends_primary.friend_user_id1 LEFT JOIN se_friends AS friends_secondary ON friends_primary.friend_user_id2=friends_secondary.friend_user_id1 WHERE se_groupmembers.groupmember_group_id=se_groups.group_id AND se_groupmembers.groupmember_status=1 AND friends_secondary.friend_user_id2='{$user->user_info['user_id']}' AND friends_primary.friend_status=1 AND friends_secondary.friend_status=1 LIMIT 1))
					  THEN TRUE
					ELSE FALSE
					END";
			break;			
			
			case 'he_quiz':
				$this->entity_cond = "se_he_quiz.status=1";
			
			default:
				$this->entity_cond = '';
			break;
		}
		
	}
	
	function prepare_tags( $tags, $font_styles )
	{
		global $url;
		
		$min_font_size = $font_styles['min_font_size'];
		$max_font_size = $font_styles['max_font_size'];
		
		foreach ( $tags as $value )
		{
			if( !isset( $max_value ) )
			{
				$min_value = $value['count'];
				$max_value = $value['count'];
				continue;
			}
			
			if( $min_value > $value['count'] )
				$min_value = $value['count'];
				
			if( $max_value < $value['count'] )
				$max_value = $value['count'];
		}
		
		foreach ( $tags as $key => $value )
		{
			$tags[$key]['url'] = $url->url_base . $this->entity_url . '?tag=' . $value['tag_id'];
			$font_size = ( $max_value == $min_value ? 15 : 
			floor( ($value['count'] - $min_value)/( $max_value - $min_value ) * ( $max_font_size - $min_font_size ) + $min_font_size) );
			$tags[$key]['size'] = $font_size;
			$tags[$key]['line_height'] = $font_size + 4;
		}

		return $tags;
	}
}

?>