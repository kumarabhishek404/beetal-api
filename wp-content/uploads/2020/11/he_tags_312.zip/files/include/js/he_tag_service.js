
/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version Tags 1.02
 */

var tag_service = {
	save_tag: function(save_button, content_id, content)
	{
		var tag_input = $('tag_' + content_id);
		if ( tag_input === null ) {
			return false;
		}
		
		tag_input.className = 'textbox';
		var tag_value = tag_input.getProperty('value');
		
		$(save_button).disabled = true;
		new Request.JSON({
			method : 'get',
			url : 'user_tags.php',
			data : { 'task' : 'save_content_tag', 'type' : content, 'content_id' : content_id, 'tag': tag_value, 'no_cache': Math.random() },
			onSuccess : function(result) {
				if ( result )
				{
					tag_input.defaultValue = result;
					tag_input.value = result;
				}
				$(save_button).disabled = false;
			}
		}).send();
	},
	
	switch_tab: function(node, id)
	{
		var $node = $(node);
		$$('a.active').removeClass('active');
		$node.addClass('active');
		
		$('type').defaultValue = id;
		$('type').value = id;
	
		$('he_tad_header').set('text', $node.get('text'));
		$('he_code_type').set('text', $node.get('id'));
	},
	
	switch_cloud_tab: function(node, id)
	{
		var $node = $(node);
		var $parent = $node.getParent('.tag_cont');

		$parent.getElements('.he_tag_tab').removeClass('active_tab');
		$node.addClass('active_tab');
		
		$parent.getElements('.he_tag_cloud').set('tween', {duration: 500});
		$parent.getElements('.he_tag_cloud').fade('out');
		
		window.setTimeout(function(){
			$parent.getElements('.he_tag_cloud').removeClass('active_tab');
			$(id).set('tween', {duration: 500});
			$(id).fade('in');
			$(id).addClass('active_tab');
		}, 500);
	}
}
