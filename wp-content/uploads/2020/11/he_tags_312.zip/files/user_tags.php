<?php

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version Tags 1.02
 */

$task = (isset($_GET['task']) && $_GET['task']) ? $_GET['task'] : ''; 

if ( $task == 'save_content_tag' )
{
	define('SE_PAGE_AJAX', TRUE);
}

$page = "user_tags";
include "header.php";

if($user->user_exists == 0)
{
  $page = "error";
  $smarty->assign('error_header', 639);
  $smarty->assign('error_message', 656);
  $smarty->assign('error_submit', 641);
  include "footer.php";
}

$tag_plugins = he_tag_available_plugin();
$default_plugin = array_keys($tag_plugins);

$cur_page = (isset($_GET['page']) && $_GET['page']) ? (int)$_GET['page'] : 1;
$content = (isset($_GET['type']) && $_GET['type']) ? $_GET['type'] : @$default_plugin[0];

if( !$content || !isset($tag_plugins[$content]) )
{
  $page = "error";
  $smarty->assign('error_header', 639);
  $smarty->assign('error_message', 690690078);
  $smarty->assign('error_submit', 641);
  include "footer.php";
}

$count_on_page = 20;
$start = ($cur_page-1)*$count_on_page;

if ( $task == 'save_content_tag' )
{
	header("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); // Date in the past
	header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); // always modified
	header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
	header("Pragma: no-cache"); // HTTP/1.0
	header("Content-Type: application/json");
	
	$content_id = (int)$_GET['content_id'];
	$tag_str = $_GET['tag'];
	
	$tag_service = new he_tag_service($content);
	$new_tags = $tag_service->update_entity_tag($content_id, $tag_str);
	echo json_encode($new_tags);
	
	exit();
}

$user_content = new he_user_content($content);
$content_list = $user_content->get_user_content($start, $count_on_page);


$smarty->assign('cur_page', $cur_page);
$smarty->assign('content', $content);
$smarty->assign('content_list', $content_list);
$smarty->assign('tag_plugins', $tag_plugins);
include "footer.php";
?>