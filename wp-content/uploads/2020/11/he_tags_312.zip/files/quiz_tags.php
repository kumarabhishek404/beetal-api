<?php

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version Quiz 1.02
 */

$page = "quiz_tags";
include "header.php";


$current_page = ( isset($_GET['page']) && $_GET['page'] ) ? (int)$_GET['page'] : 1;
$mode = ( isset($_GET['mode']) && $_GET['mode'] ) ? trim($_GET['mode']) : 'popular';

// DISPLAY ERROR PAGE IF USER IS NOT LOGGED IN AND ADMIN SETTING REQUIRES REGISTRATION
if ( !$user->user_exists )
{
	$page = "error";
	$smarty->assign('error_header', 639);
	$smarty->assign('error_message', 656);
	$smarty->assign('error_submit', 641);
	include "footer.php";
}

$content = 'he_quiz';
$tag_plugins = he_tag_available_plugin();

if ( !isset($tag_plugins[$content]) )
{
  $page = "error";
  $smarty->assign('error_header', 639);
  $smarty->assign('error_message', 690690078);
  $smarty->assign('error_submit', 641);
  include "footer.php";
}

$tag_id = (isset($_GET['tag']) && $_GET['tag']) ? $_GET['tag'] : false;

//TODO get from configs
$on_page = 10;
$pages = 5;

$first = ( $current_page - 1 ) * $on_page;

// CREATE TAG OBJECT
$tag_service = new he_tag_service('he_quiz');

$quiz_ids = $tag_service->find_entity_id_list($tag_id);

$quiz_str = implode(',', $quiz_ids);
$quiz_str = ( $quiz_str ) ? $quiz_str : 0;
$where = " AND `quiz`.`id` IN ( $quiz_str )";


$chosed_tag = $tag_service->find_by_tag_id($tag_id);
$tags_array = $tag_service->find_by_entity_id_list($quiz_ids);

$quiz_arr = he_quiz::quiz_list($first, $on_page, $mode, $where);

$quiz_total = he_quiz::quiz_total($where);

//DISPLAY TABS
$smarty->assign('content', $content);
$smarty->assign('tag_plugins', $tag_plugins);

$smarty->assign('tags_array', $tags_array);
$smarty->assign('chosed_tag', $chosed_tag);

$smarty->assign('mode', $mode);
$smarty->assign('current_page', $current_page);
$smarty->assign('quiz_arr', $quiz_arr);

$smarty->assign('paging', array( 'total' => $quiz_total, 'on_page' => $on_page, 'pages' => $pages ));

include "footer.php";
?>