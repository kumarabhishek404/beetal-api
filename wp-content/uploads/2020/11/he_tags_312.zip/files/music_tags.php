<?php

$page = "music_tags";
include "header.php";

$content = 'music';
$tag_plugins = he_tag_available_plugin();

$tag_id = (isset($_GET['tag']) && $_GET['tag']) ? $_GET['tag'] : false;
$p = (isset($_GET['p']) && $_GET['p']) ? $_GET['p'] : 1;

if ( !isset($tag_plugins[$content]) )
{
  $page = "error";
  $smarty->assign('error_header', 639);
  $smarty->assign('error_message', 690690078);
  $smarty->assign('error_submit', 641);
  include "footer.php";
}

$tag_service = new he_tag_service('music');

$chosed_tag = $tag_service->find_by_tag_id($tag_id);
$music_ids = $tag_service->find_entity_id_list($tag_id);
$tags_array = $tag_service->find_by_entity_id_list($music_ids);

$where = "";

if (!empty($music_ids)) 
{	
	$temp = implode(', ', $music_ids);
	$where = "se_music.music_id IN ($temp) ";
}

$music = new se_music();

$total_music = $music->music_total($where);
$musics_per_page = 22;

$page_vars = make_page($total_music, $musics_per_page, $p);
$music_array = $music->music_list($page_vars[0], $musics_per_page, "", $where);


$smarty->assign('tags_array', $tags_array);
$smarty->assign('tag_plugins', $tag_plugins);
$smarty->assign('content', $content);
$smarty->assign('total_music', $total_music);
$smarty->assign('musics', $music_array);
$smarty->assign('chosed_tag', $chosed_tag);

$smarty->assign('tag_id', $tag_id);
$smarty->assign('p', $page_vars[1]);
$smarty->assign('maxpage', $page_vars[2]);
$smarty->assign('p_start', $page_vars[0]+1);
$smarty->assign('p_end', $page_vars[0]+count($music_array));

include "footer.php";

?>