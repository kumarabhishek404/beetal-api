<?php

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version Tags 1.02
 */

defined('SE_PAGE') or exit();

include_once "./header_he_core.php";
include_once "./include/class_he_tag_service.php";
include_once "./include/class_he_user_content.php";

include_once "./include/functions_he_tags.php";


// PRELOAD LANGUAGE
SE_Language::_preload(690690070);
SE_Language::_preload(690690071);

$tag_plugins = he_tag_available_plugin();

$default_plugin = array_keys($tag_plugins);
$dplugin_info = ( $tag_plugins ) ? $tag_plugins[$default_plugin[0]] : array();


if( $dplugin_info )
{
	// SET MENU VARS
	$plugin_vars['menu_main'] = array(
		'file' => $dplugin_info['entity_url'], 
		'title' => 690690070
	);
	
	//USER APPS MENU
	$plugin_vars['menu_user'] = array(
		'file' => 'user_tags.php', 
		'icon' => 'he_tags.png', 
		'title' => 690690071
	);
}



// Use new template hooks
if ( is_a($smarty, 'SESmarty') )
{
	$plugin_vars['uses_tpl_hooks'] = TRUE;
	
	if ( !empty($plugin_vars['menu_main']) )
	{
		$smarty->assign_hook('menu_main', $plugin_vars['menu_main']);
	}
	
	if ( !empty($plugin_vars['menu_user']) )
	{
		$smarty->assign_hook('menu_user_apps', $plugin_vars['menu_user']);
	}
	
	$smarty->assign_hook('styles', './templates/styles_he_tags.css');
}

$smarty->register_function('tag_navigator', 'he_frontend_tag_navigator');
$smarty->register_function('tag_clouds', 'he_frontend_tag_clouds');

?>