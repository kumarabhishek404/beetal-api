<?php

/*
@author Vadim
@copyright Hire-Experts LLC
@version Tags 3.11
 */

$plugin_name = "Tags Plugin";
$plugin_version = "3.12";
$req_core_version = "3.01";
$plugin_type = "he_tags";
$plugin_desc = "This plugin lets your users to tag videos, photo albums, music, events, blogs and groups. Also it allows users to browse using tag clouds.";
$plugin_icon = "he_tags_icon.gif";
$plugin_menu_title = "690690080";
$plugin_pages_main = "690690080<!>he_tags_icon.gif<!>admin_tag_clouds.php<~!~>";
$plugin_db_charset = 'utf8';
$plugin_db_collation = 'utf8_unicode_ci';
$plugin_reindex_totals = TRUE;




if( $install=="he_tags" )
{
	//check core library
	$sql = "SELECT `plugin_version` FROM `se_plugins` WHERE plugin_type='he_core' AND `plugin_disabled`=0 LIMIT 1";
	$resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
	$core_version = $database->database_fetch_array($resource);
	if ( floatval($core_version[0]) < floatval($req_core_version) ) {
		die ('This plugin requires Hire-Experts Core Library. Please install latest version of Hire-Experts Core Library plugin. You can download it from My Plugins section in Hire-Experts.com for FREE.');
	}

  //######### GET CURRENT PLUGIN INFORMATION
  $sql = "SELECT * FROM se_plugins WHERE plugin_type='{$plugin_type}' LIMIT 1";
  $resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
  
  $plugin_info = array();
  if( $database->database_num_rows($resource) )
    $plugin_info = $database->database_fetch_assoc($resource);
   
  
  //######### INSERT ROW INTO se_plugins
  $sql = "SELECT NULL FROM se_plugins WHERE plugin_type='$plugin_type'";
  $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
  
  if( !$database->database_num_rows($resource) )
  {
    $sql = "
      INSERT INTO se_plugins (
        plugin_name,
        plugin_version,
        plugin_type,
        plugin_desc,
        plugin_icon,
        plugin_menu_title,
        plugin_pages_main,
        plugin_pages_level,
        plugin_url_htaccess
      ) VALUES (
        '$plugin_name',
        '$plugin_version',
        '$plugin_type',
        '".str_replace("'", "\'", $plugin_desc)."',
        '$plugin_icon',
        '$plugin_menu_title',
        '$plugin_pages_main',
        '',
        ''
      )
    ";
    
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
  }
  
  //######### UPDATE PLUGIN VERSION IN se_plugins
  else
  {
    $sql = "
      UPDATE
        se_plugins
      SET
        plugin_name='$plugin_name',
        plugin_version='$plugin_version',
        plugin_desc='".str_replace("'", "\'", $plugin_desc)."',
        plugin_icon='$plugin_icon',
        plugin_menu_title='$plugin_menu_title',
        plugin_pages_main='$plugin_pages_main',
        plugin_pages_level='',
        plugin_url_htaccess=''
      WHERE
        plugin_type='$plugin_type'
    ";
    
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
  }



  //######### CREATE se_eventalbums
  $sql = "SHOW TABLES FROM `$database_name` LIKE 'se_he_entity_tag'";
  $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
  
  if( !$database->database_num_rows($resource) )
  {
    $sql = "
		CREATE TABLE `se_he_entity_tag` (
		  `entity_type` tinyint(20) unsigned NOT NULL,
		  `entity_id` int(11) unsigned NOT NULL,
		  `tag_id` int(11) unsigned NOT NULL,
		  UNIQUE KEY `entity_type` (`entity_type`,`entity_id`,`tag_id`)
		) ENGINE=MyISAM DEFAULT CHARSET=utf8;
    ";
    
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
  }
  
  if( !$database->database_num_rows($resource) )
  {
    $sql = "
		CREATE TABLE `se_he_tag` (
		  `id` int(11) NOT NULL auto_increment,
		  `label` varchar(255) NOT NULL,
		  PRIMARY KEY  (`id`)
		) ENGINE=MyISAM DEFAULT CHARSET=utf8;
    ";
    
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
  }
  
    //######### ADD VALUES TO LANGS TABLE
    $he_languagevars = array (
        '690690046' => 'Photo Album Tags',
        '690690047' => 'Video Tags',
        '690690048' => 'Blog Tags',
        '690690049' => 'Event Tags',
        '690690050' => 'Browse Blogs By Tag',
        '690690051' => 'Category',
        '690690052' => 'Tags',
        '690690053' => 'No blogs were found matching your criteria',
        '690690054' => 'Browse Events By Tag',
        '690690055' => 'Browse Photo Albums By Tag',
        '690690056' => 'No photo albums were found matching your criteria',
        '690690057' => 'Browse Videos By Tag',
        '690690058' => 'No videos were found matching your criteria',
        '690690059' => 'You have not installed any supported plugins',
        '690690060' => 'Tag clouds',
        '690690061' => 'Please go to <a href="http://www.hire-experts.com/">Hire-Experts.com</a> to get this plugin latest version.',
        '690690062' => 'Here you can generate code shippet for tag clouds box and put on any wished page in SE. Just choose the box settings(like width, tags count, etc), then click Generate Code button and it will show ready for use code below. Copy this code and paste in a wished page\'s template file(*.tpl). It generates code snippet for',
        '690690063' => 'Cloud Width',
        '690690064' => 'Font size',
        '690690065' => 'Minimal',
        '690690066' => 'Maximal',
        '690690067' => 'Tags Count',
        '690690068' => 'Tags Cloud',
        '690690069' => 'Save',
        '690690070' => 'Tags',
        '690690071' => 'User Tags',
        '690690072' => 'Photo Album Tags',
        '690690073' => 'Vidoes Tags',
        '690690074' => 'Blog Tags',
        '690690075' => 'Event Tags',
        '690690076' => 'Popular Tags',
        '690690077' => 'Preview',
        '690690078' => 'This plugin is unavaible',
        '690690079' => 'Your have no content',
        '690690080' => 'Tags Plugin',
        '690690081' => 'Group Tags',
        '690690082' => 'No groups were found matching your criteria',
        '690690083' => 'Browse Groups By Tag',
        '690690084' => 'Generate Code',
        '690690085' => 'Quiz Tags',
        '690690086' => 'no tags',
        '690690087' => 'Tags cloud with tabs',
        '690690088' => 'Quizzes',
        '690690089' => 'Photo Albums',
        '690690090' => 'Videos',
        '690690091' => 'Groups',
        '690690092' => 'Blogs',
        '690690093' => 'Events',
        '690690094' => 'No quizzes were found matching your criteria',
        '690690095' => 'No musics were found matching your criteria',
        '690690096' => 'Browse Musics By Tag',
        '690690097' => 'Music Tags',
        '690690098' => 'Music',
    );

    foreach ($he_languagevars as $langvar_id => $langvar_value)
    {
        $sql = "SELECT `languagevar_id` FROM `se_languagevars`
           WHERE `languagevar_id`=$langvar_id AND `languagevar_language_id`=1";

		$langvar_value = $database->database_real_escape_string($langvar_value);
        if ( $database->database_num_rows($database->database_query($sql)) == 0 )
        {
            $sql = "INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`)
                VALUES('$langvar_id', '1', '$langvar_value', 'tags')";
        }
        else
        {
            $sql = "UPDATE `se_languagevars` SET `languagevar_value`='$langvar_value', `languagevar_default`='tags'
                WHERE `languagevar_id`=$langvar_id AND `languagevar_language_id`=1";
        }

        $resource = $database->database_query($sql) or die("<b>Error: </b>" . $database->database_error() . "<br /><b>File: </b>" . __FILE__ . "<br /><b>Line: </b>" . __LINE__ . "<br /><b>Query: </b>" . $sql);
    }

}

?>