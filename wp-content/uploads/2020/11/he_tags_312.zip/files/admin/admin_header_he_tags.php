<?php

/*
@author Vadim
@copyright Hire-Experts LLC
@version Tags 1.02
 */

// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
defined('SE_PAGE') or exit();

include_once "./admin_header_he_core.php";
include_once "../include/class_he_tag_service.php";
include_once "../include/functions_he_tags.php";

$smarty->register_function('tag_navigator', 'he_frontend_tag_navigator');
$smarty->register_function('tag_clouds', 'he_frontend_tag_clouds');

?>