<?php

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version Tags 1.02
 */

$page = "admin_tag_clouds";
include "admin_header.php";


$task = (isset($_POST['task']) && $_POST['task']) ? $_POST['task'] : '';

$tag_plugins = he_tag_available_plugin();

if (!$tag_plugins) {
	$message['error'] = SE_Language::get(690690059);
	$smarty->assign('message', $message);
	include "admin_footer.php";
	exit();
}

if ($task == 'save_settings') {
	$settings = $_POST;
} else {
	$plugins = array_keys($tag_plugins);
	
	$settings['type'] = $plugins[0];
	$settings['width'] = 500;
	$settings['min_font_size'] = 10;
	$settings['max_font_size'] = 30;
	$settings['count'] = 50;
}


$tags = array();

for ($i=1; $i<=$settings['count']; $i++){
	$tags[] = array('label'=>'tag'.$i, 'count'=>rand(1, 20));
}

$min_font_size = $settings['min_font_size'];
$max_font_size = $settings['max_font_size'];

foreach ( $tags as $value )
{
	if( !isset( $max_value ) )
	{
		$min_value = $value['count'];
		$max_value = $value['count'];
		continue;
	}
		
	if( $min_value > $value['count'] )
		$min_value = $value['count'];
		
	if( $max_value < $value['count'] )
		$max_value = $value['count'];
}

foreach ( $tags as $key => $value ) {
	$tags[$key]['url'] = '#';
	$font_size = ( $max_value == $min_value ? 15 : 
	floor( ($value['count'] - $min_value)/( $max_value - $min_value ) * ( $max_font_size - $min_font_size ) + $min_font_size) );
	$tags[$key]['size'] = $font_size;
	$tags[$key]['line_height'] = $font_size + 4;
}

$smarty->assign('tag_preview', $tags);
$smarty->assign('tag_plugins', $tag_plugins);
$smarty->assign('settings', $settings);


include "admin_footer.php";
?>