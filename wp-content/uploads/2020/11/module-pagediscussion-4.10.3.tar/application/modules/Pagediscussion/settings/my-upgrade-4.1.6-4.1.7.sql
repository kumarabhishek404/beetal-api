
UPDATE `engine4_core_modules` SET `version` = '4.1.7'  WHERE `name` = 'pagediscussion';