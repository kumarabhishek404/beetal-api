
UPDATE `engine4_core_modules` SET `version` = '4.1.9p1'  WHERE `name` = 'mobile';

UPDATE `engine4_core_menuitems` SET `label`='HE - Mobile', `order` = '888' WHERE `name`='core_admin_main_plugins_mobile';