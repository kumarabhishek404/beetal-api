<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Welcome
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: install.php 2010-08-02 16:05 idris $
 * @author     Idris
 */

/**
 * @category   Application_Extensions
 * @package    Welcome
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Welcome_Installer extends Engine_Package_Installer_Module
{

    protected function _addContentPage(){
      $db = $this->getDb();

      $he_query = "CREATE TABLE IF NOT EXISTS `engine4_welcome_slideshows` (
        `slideshow_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
        `title` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
        `effect` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
        `width` int(10) unsigned NOT NULL DEFAULT '0',
        `height` int(10) unsigned NOT NULL DEFAULT '0',
        PRIMARY KEY (`slideshow_id`),
        KEY `title` (`title`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
      $db->query($he_query);

      $he_query_1 = "CREATE TABLE IF NOT EXISTS `engine4_welcome_steps` (
        `step_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
        `slideshow_id` int(10) unsigned NOT NULL DEFAULT '1',
        `photo_id` int(11) NOT NULL,
        `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
        `body` text COLLATE utf8_unicode_ci NOT NULL,
        `link` text COLLATE utf8_unicode_ci DEFAULT NULL,
        `creation_date` datetime NOT NULL,
        PRIMARY KEY (`step_id`)
      ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
      $db->query($he_query_1);

      $he_query_2 = "CREATE TABLE IF NOT EXISTS `engine4_welcome_effects` (
        `effect_id` INTEGER(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `value` VARCHAR(128) COLLATE utf8_unicode_ci NOT NULL,
        `label` VARCHAR(128) COLLATE utf8_unicode_ci NOT NULL,
        PRIMARY KEY (`effect_id`)
        )ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_unicode_ci";
      $db->query($he_query_2);

      $db->query("INSERT IGNORE INTO `engine4_welcome_effects` (`effect_id`, `value`, `label`) VALUES
        (1, 'tabs', 'Tabs'),
        (2, 'slider', 'Slider'),
        (3, 'popup', 'Accordeon'),
        (4, 'curtain', 'Curtain'),
        (5, 'carousel', 'Carousel'),
        (6, 'kenburns', 'KenBurns')");

      $he_query_4 = "CREATE TABLE IF NOT EXISTS `engine4_welcome_settings` (
        `setting_id` INTEGER(11) NOT NULL AUTO_INCREMENT,
        `name` VARCHAR(100) COLLATE utf8_unicode_ci DEFAULT NULL,
        `value` VARCHAR(255) COLLATE utf8_unicode_ci DEFAULT NULL,
        `effect` VARCHAR(100) COLLATE utf8_unicode_ci DEFAULT NULL,
        `type` VARCHAR(100) COLLATE utf8_unicode_ci DEFAULT NULL,
        `options` TEXT COLLATE utf8_unicode_ci,
        `label` VARCHAR(255) COLLATE utf8_unicode_ci DEFAULT NULL,
        `description` TEXT COLLATE utf8_unicode_ci,
        PRIMARY KEY (`setting_id`)
        )ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_unicode_ci";
      $db->query($he_query_4);

      $db->query("INSERT IGNORE INTO `engine4_welcome_settings` (`setting_id`, `name`, `value`, `effect`, `type`, `options`, `label`, `description`) VALUES
        (1, 'effect', 'wave', 'curtain', 'select', 'a:3:{s:4:\"wave\";s:4:\"Wave\";s:6:\"zipper\";s:6:\"Zipper\";s:7:\"curtain\";s:7:\"Curtain\";}', 'Type', ''),
        (2, 'strips', '20', 'curtain', 'text', '', 'Strips Count', ''),
        (3, 'titleOpacity', '0.6', 'curtain', 'text', '', 'Title Opacity(0.0-1.0)', ''),
        (4, 'position', 'curtain', 'curtain', 'select', 'a:4:{s:9:\"alternate\";s:9:\"Alternate\";s:3:\"top\";s:3:\"Top\";s:6:\"bottom\";s:6:\"Bottom\";s:7:\"curtain\";s:7:\"Curtain\";}', 'Position', ''),
        (5, 'direction', 'fountainAlternate', 'curtain', 'select', 'a:6:{s:17:\"fountainAlternate\";s:18:\"Fountain Alternate\";s:4:\"left\";s:4:\"Left\";s:5:\"right\";s:5:\"Right\";s:9:\"alternate\";s:9:\"Alternate\";s:6:\"random\";s:6:\"Random\";s:8:\"fountain\";s:8:\"Fountain\";}', 'Direction', ''),
        (6, 'defaultIndex', '1', 'popup', 'text', '', 'Default Index', ''),
        (7, 'expandMode', 'mouseover', 'popup', 'select', 'a:3:{s:9:\"mouseover\";s:13:\"On mouse over\";s:5:\"click\";s:14:\"On mouse click\";s:5:\"false\";s:13:\"Do not expand\";}', 'Expand Mode', ''),
        (8, 'pinMode', 'click', 'popup', 'select', 'a:3:{s:9:\"mouseover\";s:13:\"On mouse over\";s:5:\"click\";s:14:\"On mouse click\";s:5:\"false\";s:18:\"Do not stay opened\";}', 'Pin Mode', ''),
        (9, 'pause', '3000', 'carousel', 'text', '', 'Pause(ms)', ''),
        (10, 'speed', '1000', 'carousel', 'text', '', 'Speed(ms)', ''),
        (11, 'delay', '5000', 'curtain', 'text', '', 'Delay(ms)', ''),
        (12, 'interval', '5000', 'tabs', 'text', NULL, 'Pause(ms)', NULL),
        (13, 'duration', '2000', 'kenburns', 'text', NULL, 'Duration(ms)', NULL)");

      $he_query_5 = "CREATE TABLE IF NOT EXISTS `engine4_welcome_slideshowsettings`(
        `slideshowsetting_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
        `slideshow_id` int(11) unsigned NOT NULL,
        `setting_id` int(11) unsigned NOT NULL,
        `value` varchar(255) NOT NULL,
        PRIMARY KEY (`slideshowsetting_id`),
        KEY `slideshow_id` (`slideshow_id`,`setting_id`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
      $db->query($he_query_5);


      $db->query("INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `order`) VALUES
        ('core_admin_main_plugins_welcome', 'welcome', 'HE - Welcome', '', '{\"route\":\"admin_default\",\"module\":\"welcome\",\"controller\":\"slideshow\"}', 'core_admin_main_plugins', '', 888)");
    }
    public function onInstall()
    {
        $this->_addContentPage();
        parent::onInstall();
    }

    public function onPreInstall()
    {
      // code here
    }

   

    
}
