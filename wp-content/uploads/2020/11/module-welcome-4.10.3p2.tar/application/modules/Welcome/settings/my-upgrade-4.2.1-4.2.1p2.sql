--
-- Update module Welcome
--

UPDATE `engine4_core_modules` SET `version` = '4.2.1p2'  WHERE `name` = 'welcome';
