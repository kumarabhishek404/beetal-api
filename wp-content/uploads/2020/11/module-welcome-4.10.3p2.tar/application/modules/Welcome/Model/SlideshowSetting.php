<?php

class Welcome_Model_SlideshowSetting extends Core_Model_Item_Abstract
{

}

?>