INSERT INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES
('welcome', 'Welcome Slideshow', 'Welcome Slideshow Plugin.', '4.10.3p2', 1, 'extra');
