--
-- Update module Hecore
--

UPDATE `engine4_core_modules` SET `version` = '4.2.0p9'  WHERE `name` = 'hecore';