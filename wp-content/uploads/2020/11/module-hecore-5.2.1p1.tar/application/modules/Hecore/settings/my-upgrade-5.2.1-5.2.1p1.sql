UPDATE `engine4_core_modules` SET `version` = '5.2.1p1' WHERE `name` = 'hecore';
/*Update if exist*/
UPDATE `engine4_core_menuitems`
SET `params` = '{"route":"admin_default","module":"hecore","controller":"settings"}'
WHERE `name` = 'core_admin_main_plugins_hecore';

UPDATE `engine4_core_menuitems`
SET `enabled` = 0
WHERE `name` = 'hecore_admin_main_plugins';