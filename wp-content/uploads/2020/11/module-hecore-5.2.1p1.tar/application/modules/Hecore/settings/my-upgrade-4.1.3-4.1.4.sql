--
-- Update module Hecore
--

UPDATE `engine4_core_modules` SET `version` = '4.1.4'  WHERE `name` = 'hecore';