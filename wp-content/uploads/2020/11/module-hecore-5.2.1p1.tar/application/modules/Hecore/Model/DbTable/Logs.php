<?php
/**
 * Created by PhpStorm.
 * User: Улан Омуркулов
 * Date: 28.10.14
 * Time: 12:52
 */

class Hecore_Model_DbTable_Logs  extends Engine_Db_Table{

  protected $_rowClass = "Hecore_Model_Log";


}