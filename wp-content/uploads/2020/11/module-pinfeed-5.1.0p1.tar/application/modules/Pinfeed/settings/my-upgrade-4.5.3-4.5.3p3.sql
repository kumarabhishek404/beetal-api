UPDATE `engine4_core_modules` SET `version` = '4.5.3p3' WHERE `name` = 'pinfeed';
