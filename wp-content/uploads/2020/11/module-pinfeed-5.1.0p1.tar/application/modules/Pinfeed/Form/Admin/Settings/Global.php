<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Bolot
 * Date: 03.05.13
 * Time: 12:57
 * To change this template use File | Settings | File Templates.
 */

class Pinfeed_Form_Admin_Settings_Global extends Engine_Form {
  public function init()
  {
    // My stuff
    $this
      ->setTitle("Wall Pin Feed setting")->setDescription('BLOCKS_PEN_SETTINGS_DESCRIPTION');

    $this->addElement('Select', 'usage', array(
      'label' => 'Replace standard Home Page to the Pin Feed',
      'description' => 'Replaces standard Home Page on a beautiful new Pin Feed',
      'multiOptions' => array(
        '1' => 'Yes, use Pin Feed Home page',
        '0' => 'No, use default Home page',
      ),
    ));

    // Element: submit
    $this->addElement('Button', 'submit', array(
      'label' => 'Save',
      'type' => 'submit',
    ));

  }


}