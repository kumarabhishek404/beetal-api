INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES
('offers', 'Offers', 'Offers', '4.10.5p1', 1, 'extra') ;