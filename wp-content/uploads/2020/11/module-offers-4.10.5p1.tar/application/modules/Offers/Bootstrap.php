<?php

class Offers_Bootstrap extends Engine_Application_Bootstrap_Abstract
{
  public function __construct($application)
  {
    parent::__construct($application);
    $this->initViewHelperPath();

 	 // Add main user javascript
   $headScript = new Zend_View_Helper_HeadScript();
   $headScript->appendFile('application/modules/Offers/externals/scripts/offers.js');
   $view = Zend_Registry::get('Zend_View');
   if (isset($_SERVER['HTTP_USER_AGENT']) && stripos( $_SERVER['HTTP_USER_AGENT'], 'Safari') !== false && stripos( $_SERVER['HTTP_USER_AGENT'], 'Chrome') === false)
   {
       $baseUrl = $view->layout()->staticBaseUrl;
       $view->headLink()->appendStylesheet($baseUrl . 'application/libraries/Hireexperts/externals/styles/main.css');
       $view->headLink()->appendStylesheet($baseUrl . 'application/modules/Offers/externals/styles/main.css');
   }
   $front =  Zend_Controller_Front::getInstance();
   $plugin =  new Offers_Controller_Helper_OffersHead();
   $front->registerPlugin($plugin);
  }
}