<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Offers
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: install.php 05.10.12 12:05 TeaJay $
 * @author     Taalay
 */

class Offers_Installer extends Engine_Package_Installer_Module
{
  public function onPreInstall()
  {
    parent::onPreInstall();

    $db = $this->getDb();
    $db = Engine_Db_Table::getDefaultAdapter();
    
    $db->query("CREATE TABLE IF NOT EXISTS `engine4_offers_apis` (
`api_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
`page_id` INT(10) UNSIGNED NOT NULL,
`enabled` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
`gateway_id` INT(10) UNSIGNED NULL DEFAULT NULL,
`config` MEDIUMBLOB NULL,
`test_mode` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
PRIMARY KEY (`api_id`),
UNIQUE INDEX `page_id_gateway_id` (`page_id`, `gateway_id`)
) COLLATE='utf8_unicode_ci' ENGINE=InnoDB ROW_FORMAT=DEFAULT;");
    
    $db->query("CREATE TABLE IF NOT EXISTS `engine4_offers_categories` (
`category_id` INT(10) NOT NULL AUTO_INCREMENT,
`title` VARCHAR(64) NOT NULL DEFAULT 'Empty',
PRIMARY KEY (`category_id`)
) COLLATE='utf8_general_ci' ENGINE=InnoDB ROW_FORMAT=DEFAULT;");
    
    $db->query("CREATE TABLE IF NOT EXISTS `engine4_offers_complete` (
`require_id` INT(10) NOT NULL,
`offer_id` INT(10) NOT NULL,
`type` VARCHAR(30) NOT NULL,
`object_type` VARCHAR(30) NOT NULL,
`object_id` INT(10) NOT NULL,
`creation_date` DATETIME NOT NULL,
`page_id` INT(10) NOT NULL DEFAULT '0',
`item_id` INT(10) NOT NULL DEFAULT '0',
PRIMARY KEY (`require_id`, `object_type`, `object_id`)
) COLLATE='utf8_general_ci' ENGINE=InnoDB ROW_FORMAT=DEFAULT;");
    
    $db->query("CREATE TABLE IF NOT EXISTS `engine4_offers_contacts` (
`offer_id` INT(11) NOT NULL,
`country` VARCHAR(255) NOT NULL,
`state` VARCHAR(255) NOT NULL,
`city` VARCHAR(255) NOT NULL,
`address` VARCHAR(255) NOT NULL,
`phone` VARCHAR(255) NOT NULL,
`website` VARCHAR(255) NOT NULL,
`lat` DOUBLE(10,7) NULL DEFAULT NULL,
`lng` DOUBLE(10,7) NULL DEFAULT NULL,
PRIMARY KEY (`offer_id`)
) COLLATE='utf8_general_ci' ENGINE=InnoDB ROW_FORMAT=DEFAULT;");
    
    $db->query("CREATE TABLE IF NOT EXISTS `engine4_offers_follows` (
`user_id` INT(10) UNSIGNED NOT NULL,
`offer_id` INT(10) UNSIGNED NOT NULL,
`follow_status` ENUM('active','finished') NULL DEFAULT NULL,
PRIMARY KEY (`user_id`, `offer_id`)
) COLLATE='utf8_general_ci' ENGINE=InnoDB ROW_FORMAT=DEFAULT;");
    
    $db->query("CREATE TABLE IF NOT EXISTS `engine4_offers_info` (
`user_id` INT(10) NOT NULL,
`friend` INT(10) NOT NULL,
`comment` INT(10) NOT NULL,
`login` INT(10) NOT NULL,
`status` INT(10) NOT NULL,
`photo` INT(10) NOT NULL,
`blog` INT(10) NOT NULL,
`event` INT(10) NOT NULL,
`group` INT(10) NOT NULL,
`forum` INT(10) NOT NULL,
`classified` INT(10) NOT NULL,
`invite` INT(10) NOT NULL,
`referral` INT(10) NOT NULL,
`poll` INT(10) NOT NULL,
`pollpassed` INT(10) NOT NULL,
`music` INT(10) NOT NULL,
`video` INT(10) NOT NULL,
`checkin` INT(10) NOT NULL,
`like` INT(10) NOT NULL,
`likeme` INT(10) NOT NULL,
`quiz` INT(10) NOT NULL,
`quizpassed` INT(10) NOT NULL,
`rate` INT(10) NOT NULL,
`review` INT(10) NOT NULL,
`store` INT(10) NOT NULL,
`storeorder` INT(10) NOT NULL,
`suggest` INT(10) NOT NULL,
PRIMARY KEY (`user_id`)
) COLLATE='utf8_general_ci' ENGINE=InnoDB ROW_FORMAT=DEFAULT;");
    
    $db->query("CREATE TABLE IF NOT EXISTS `engine4_offers_offers` (
`offer_id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
`owner_id` INT(11) UNSIGNED NOT NULL,
`page_id` INT(11) UNSIGNED NOT NULL,
`title` VARCHAR(200) NOT NULL,
`type` ENUM('paid','free','reward','store') NOT NULL DEFAULT 'free',
`price_offer` DOUBLE(16,2) UNSIGNED NULL DEFAULT '0',
`price_item` DOUBLE(16,2) UNSIGNED NULL DEFAULT NULL,
`discount` SMALLINT(6) UNSIGNED NOT NULL DEFAULT '0',
`coupons_count` SMALLINT(6) NULL DEFAULT NULL,
`coupons_code` VARCHAR(50) DEFAULT NULL,
`enable_unique_code` VARCHAR(50) DEFAULT NULL,
`coupons_unlimit` VARCHAR(50) DEFAULT NULL,
`creation_date` DATETIME NOT NULL,
`time_limit` ENUM('limit','unlimit') NOT NULL DEFAULT 'unlimit',
`starttime` DATETIME NOT NULL,
`endtime` DATETIME NOT NULL,
`redeem_starttime` DATETIME NOT NULL,
`redeem_endtime` DATETIME NOT NULL,
`description` TEXT NULL,
`location` TEXT COLLATE utf8_unicode_ci NULL,
`photo_id` INT(10) UNSIGNED NOT NULL,
`category_id` INT(10) UNSIGNED NOT NULL DEFAULT '1',
`featured` TINYINT(1) NOT NULL DEFAULT 0,
`favorite` TINYINT(1) NOT NULL DEFAULT 0,
`enabled` TINYINT(3) UNSIGNED NOT NULL DEFAULT '1',
`discount_type` ENUM('percent','currency') NOT NULL DEFAULT 'percent',
`via_credits` TINYINT(1) NOT NULL DEFAULT '0',
PRIMARY KEY (`offer_id`)
) COLLATE='utf8_general_ci' ENGINE=InnoDB ROW_FORMAT=DEFAULT;");
    
    $db->query("CREATE TABLE IF NOT EXISTS `engine4_offers_orders` (
`order_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
`user_id` INT(10) UNSIGNED NOT NULL,
`gateway_id` INT(10) UNSIGNED NOT NULL,
`gateway_order_id` VARCHAR(128) NULL DEFAULT NULL COLLATE 'latin1_general_ci',
`gateway_transaction_id` VARCHAR(128) NULL DEFAULT NULL COLLATE 'latin1_general_ci',
`state` ENUM('pending','cancelled','failed','incomplete','complete') NOT NULL DEFAULT 'pending' COLLATE 'latin1_general_ci',
`creation_date` DATETIME NOT NULL,
`source_type` VARCHAR(128) NULL DEFAULT NULL COLLATE 'latin1_general_ci',
`source_id` INT(10) UNSIGNED NULL DEFAULT NULL,
PRIMARY KEY (`order_id`),
INDEX `user_id` (`user_id`),
INDEX `gateway_id` (`gateway_id`, `gateway_order_id`),
INDEX `state` (`state`),
INDEX `source_type` (`source_type`, `source_id`)
) COLLATE='utf8_unicode_ci' ENGINE=InnoDB ROW_FORMAT=DEFAULT;");
    
    $db->query("CREATE TABLE IF NOT EXISTS `engine4_offers_photos` (
`photo_id` INT(11) NOT NULL AUTO_INCREMENT,
`title` VARCHAR(100) NULL DEFAULT NULL,
`description` TEXT NULL,
`creation_date` DATETIME NOT NULL,
`modified_date` DATETIME NOT NULL,
`collection_id` INT(11) UNSIGNED NOT NULL,
`owner_id` INT(11) UNSIGNED NOT NULL,
`file_id` INT(11) UNSIGNED NOT NULL,
PRIMARY KEY (`photo_id`)
) COLLATE='utf8_general_ci' ENGINE=InnoDB ROW_FORMAT=DEFAULT;");
    
    $db->query("CREATE TABLE IF NOT EXISTS `engine4_offers_products` (
`product_id` INT(11) NOT NULL,
`offer_id` INT(11) NOT NULL,
`page_id` INT(11) NOT NULL,
PRIMARY KEY (`product_id`, `offer_id`, `page_id`)
) COLLATE='utf8_general_ci' ENGINE=InnoDB ROW_FORMAT=DEFAULT;");
    
    $db->query("CREATE TABLE IF NOT EXISTS `engine4_offers_require` (
`require_id` INT(10) NOT NULL AUTO_INCREMENT,
`offer_id` INT(10) NOT NULL DEFAULT '0',
`type` VARCHAR(30) NOT NULL COLLATE 'utf8_unicode_ci',
`params` TEXT NOT NULL COLLATE 'utf8_unicode_ci',
PRIMARY KEY (`require_id`)
) COLLATE='utf8_general_ci' ENGINE=InnoDB ROW_FORMAT=DEFAULT;");
    
    $db->query("CREATE TABLE IF NOT EXISTS `engine4_offers_subscriptions` (
`subscription_id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
`user_id` INT(11) UNSIGNED NOT NULL,
`offer_id` INT(11) UNSIGNED NOT NULL,
`status` ENUM('initial','trial','pending','active','cancelled','expired','overdue','refunded','used') NOT NULL DEFAULT 'initial' COLLATE 'utf8_unicode_ci',
`active` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
`creation_date` DATETIME NOT NULL,
`modified_date` DATETIME NULL DEFAULT NULL,
`payment_date` DATETIME NULL DEFAULT NULL,
`expiration_date` DATETIME NULL DEFAULT NULL,
`notes` TEXT NULL COLLATE 'utf8_unicode_ci',
`gateway_id` INT(10) UNSIGNED NULL DEFAULT NULL,
`gateway_profile_id` VARCHAR(128) NULL DEFAULT NULL COLLATE 'latin1_general_ci',
`expiration_notified` TINYINT(11) UNSIGNED NOT NULL DEFAULT '0',
`coupon_code` VARCHAR(50) NOT NULL DEFAULT '0',
PRIMARY KEY (`subscription_id`),
UNIQUE INDEX `gateway_id` (`gateway_id`, `gateway_profile_id`),
INDEX `user_id` (`user_id`),
INDEX `offer_id` (`offer_id`),
INDEX `status` (`status`),
INDEX `active` (`active`)
) COLLATE='utf8_unicode_ci' ENGINE=InnoDB ROW_FORMAT=DEFAULT;");
    
    $db->query("CREATE TABLE IF NOT EXISTS `engine4_offers_transactions` (
`transaction_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
`user_id` INT(10) UNSIGNED NOT NULL DEFAULT '0',
`gateway_id` INT(10) UNSIGNED NOT NULL,
`timestamp` DATETIME NOT NULL,
`order_id` INT(10) UNSIGNED NOT NULL DEFAULT '0',
`type` VARCHAR(64) NULL DEFAULT NULL COLLATE 'latin1_general_ci',
`state` VARCHAR(64) NULL DEFAULT NULL COLLATE 'latin1_general_ci',
`gateway_transaction_id` VARCHAR(128) NOT NULL COLLATE 'latin1_general_ci',
`gateway_parent_transaction_id` VARCHAR(128) NULL DEFAULT NULL COLLATE 'latin1_general_ci',
`gateway_order_id` VARCHAR(128) NULL DEFAULT NULL COLLATE 'latin1_general_ci',
`amount` DECIMAL(16,2) NOT NULL,
`currency` CHAR(3) NOT NULL DEFAULT '' COLLATE 'latin1_general_ci',
PRIMARY KEY (`transaction_id`),
INDEX `user_id` (`user_id`),
INDEX `gateway_id` (`gateway_id`),
INDEX `type` (`type`),
INDEX `state` (`state`),
INDEX `gateway_transaction_id` (`gateway_transaction_id`),
INDEX `gateway_parent_transaction_id` (`gateway_parent_transaction_id`)
) COLLATE='utf8_unicode_ci' ENGINE=InnoDB ROW_FORMAT=DEFAULT;");
    
    $db->query("CREATE TABLE IF NOT EXISTS `engine4_offers_infopage` (
`user_id` int(10) NOT NULL,
`page_id` int(10) NOT NULL,
`pageblog` int(10) NOT NULL DEFAULT '0',
`playlist` int(10) NOT NULL DEFAULT '0',
`pagedocument` int(10) NOT NULL DEFAULT '0',
`pagealbum` int(10) NOT NULL DEFAULT '0',
`pagevideo` int(10) NOT NULL DEFAULT '0',
`like` int(10) NOT NULL DEFAULT '0',
`suggest` int(10) NOT NULL DEFAULT '0',
`review` int(10) NOT NULL DEFAULT '0',
PRIMARY KEY (`user_id`,`page_id`)
) COLLATE='utf8_unicode_ci' ENGINE=InnoDB ROW_FORMAT=DEFAULT;");
    
    $db->query("INSERT IGNORE INTO `engine4_activity_actiontypes` (`type`, `module`, `body`, `enabled`, `displayable`, `attachable`, `commentable`, `shareable`, `is_generated`) VALUES
('offers_accept', 'offers', '{item:\\\$subject} accepted offer {item:\\\$object}', 1, 7, 2, 1, 1, 1),
('offers_purchase', 'offers', '{item:\\\$subject} purchased offer {item:\\\$object}', 1, 7, 2, 1, 1, 1),
('page_offers_accept', 'offers', '{actors:\\\$subject:\\\$object} accepted offer {var:\\\$link}', 1, 3, 2, 1, 1, 1),
('page_offers_purchase', 'offers', '{actors:\\\$subject:\\\$object} purchased offer {var:\\\$link}', 1, 3, 2, 1, 1, 1),
('page_offer_new', 'offers', '{actors:\\\$subject:\\\$object} posted new offer: {body:\\\$body}', 1, 3, 1, 1, 1, 1),
('offer_new', 'offers', '{item:\\\$subject} posted new offer: {item:\\\$object}', 1, 7, 1, 1, 1, 1);");
    
    $db->query("INSERT IGNORE INTO `engine4_activity_notificationtypes` (`type`, `module`, `body`, `is_request`, `handler`, `default`) VALUES 
('suggest_offer', 'offers', '{item:\\\$subject} has suggested to you a {item:\\\$object:\\\offer}.', 1, 'suggest.handler.request', 1);");
    
    $db->query("INSERT IGNORE INTO `engine4_core_tasks` (`title`, `module`, `plugin`) VALUES
('Offers Tasks', 'offers', 'Offers_Plugin_Task_Tasks');");
    
    $db->query("INSERT IGNORE INTO `engine4_core_mailtemplates` (`type`, `module`, `vars`) VALUES
('offers_follow_template', 'offers', '[recipient_name][offer_name][link][recipient_link]'),
('offers_expiration_template', 'offers', '[recipient_name][offer_name][link][recipient_link][days][hours]'),
('offers_email_template', 'offers', '[email_content][recipient_email][sender_name][sender_email]'),
('offers_subscription_active', 'offers', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[subscription_title],[subscription_description],[object_link]'),
('offers_subscription_expired', 'offers', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[subscription_title],[subscription_description],[object_link]'),
('offers_subscription_overdue', 'offers', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[subscription_title],[subscription_description],[object_link]'),
('offers_subscription_pending', 'offers', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[subscription_title],[subscription_description],[object_link]'),
('offers_subscription_refunded', 'offers', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[subscription_title],[subscription_description],[object_link]');");
    
    $db->query("INSERT IGNORE INTO `engine4_core_menus` (`name`, `type`, `title`, `order`) VALUES
('offers_main', 'standard', 'Offers Main Navigation Menu', 999),
('offer_profile', 'standard', 'Offer Profile Options Menu', 999);");
    
    $db->query("INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES
('offer_admin_main_categories', 'offers', 'OFFERS_Categories', NULL, '{\"route\":\"admin_default\",\"module\":\"offers\",\"controller\":\"categories\"}', 'offer_admin_main', NULL, 2, 0, 9),
('offers_main_upcoming', 'offers', 'OFFERS_upcoming_offers', NULL, '{\"route\":\"offers_upcoming\"}', 'offers_main', NULL, 1, 0, 1),
('offers_main_manage', 'offers', 'OFFERS_offers_manage', 'Offers_Plugin_Menus', '{\"route\":\"offers_mine\"}', 'offers_main', NULL, 1, 0, 3),
('offer_profile_share', 'offers', '', 'Offers_Plugin_Menus', NULL, 'offer_profile', NULL, 1, 0, 3),
('offer_profile_edit', 'offers', 'OFFERS_Edit', 'Offers_Plugin_Menus', '', 'offer_profile', NULL, 1, 0, 1),
('offer_profile_delete', 'offers', 'OFFERS_delete_offer', 'Offers_Plugin_Menus', '', 'offer_profile', NULL, 1, 0, 2),
('offer_profile_follow', 'offers', 'OFFERS_FOLLOW_Follow_Offer', 'Offers_Plugin_Menus', '', 'offer_profile', NULL, 1, 0, 4),
('offers_main_past', 'offers', 'OFFERS_past_offers', NULL, '{\"route\":\"offers_past\"}', 'offers_main', NULL, 1, 0, 2),
('offers_upcoming', 'offers', 'OFFERS_upcoming_offers', 'Offers_Plugin_Menus', '', 'offer_profile_page', '', 1, 0, 1),
('offers_past', 'offers', 'OFFERS_past_offers', 'Offers_Plugin_Menus', '', 'offer_profile_page', '', 1, 0, 2),
('offers_mine', 'offers', 'OFFERS_mine', 'Offers_Plugin_Menus', '', 'offer_profile_page', NULL, 1, 1, 3),
('offers_create', 'offers', 'OFFERS_Create New Offer', 'Offers_Plugin_Menus', '', 'offer_profile_page', NULL, 1, 0, 4),
('core_admin_main_plugins_offer', 'offers', 'HE_OFFERS', NULL, '{\"route\":\"admin_default\",\"module\":\"offers\",\"controller\":\"manage\"}', 'core_admin_main_plugins', NULL, 1, 0, 888),
('offer_admin_main_manage', 'offers', 'OFFERS_manage_offers', NULL, '{\"route\":\"admin_default\",\"module\":\"offers\",\"controller\":\"manage\"}', 'offer_admin_main', NULL, 1, 0, 1),
('edit_offer', 'offers', 'OFFERS_Edit photos', 'Offers_Plugin_Menus', '', 'offer_edit', NULL, 1, 0, 1),
('offer_manage_photos', 'offers', 'OFFERS_manage_photos', 'Offers_Plugin_Menus', '', 'offer_edit', NULL, 1, 0, 2),
('offer_add_photos', 'offers', 'OFFERS_Add photos', 'Offers_Plugin_Menus', '', 'offer_edit', NULL, 1, 0, 3),
('edit_contacts', 'offers', 'OFFERS_edit_contacts', 'Offers_Plugin_Menus', '', 'offer_edit', NULL, 1, 0, 4),
('view_offer', 'offers', 'View Offer', 'Offers_Plugin_Menus', '', 'offer_edit', NULL, 1, 0, 5),
('core_main_offers', 'offers', 'OFFERS_Offers', NULL, '{\"route\":\"offers_upcoming\"}', 'core_main', NULL, 1, 0, 999),
('offer_profile_suggest', 'offers', 'Suggest To Friends', 'Suggest_Plugin_Menus', '', 'offer_suggest', NULL, 1, 0, 999),
('offer_admin_main_credits', 'offers', 'OFFERS_Credits', 'Offers_Plugin_Menus', '{\"route\":\"admin_default\",\"module\":\"offers\",\"controller\":\"credits\"}', 'offer_admin_main', NULL, 1, 0, 19),
('offer_admin_main_transactions', 'offers', 'OFFERS_Transactions', NULL, '{\"route\":\"admin_default\",\"module\":\"offers\",\"controller\":\"transactions\"}', 'offer_admin_main', NULL, 1, 0, 29),
('offer_profile_favorite', 'offers', 'OFFERS_Make As Favorite', 'Offers_Plugin_Menus', '', 'offer_profile', NULL, 1, 0, 3);");
    
    
    $db->query("INSERT IGNORE INTO `engine4_offers_categories` (`category_id`, `title`) VALUES
(1, 'Uncategorized'),
(2, 'Arts'),
(3, 'Automotive'),
(4, 'Baby & Kids'),
(5, 'Books & Magazines'),
(6, 'Electronics'),
(7, 'Events & Attractions'),
(8, 'Food'),
(9, 'Health & Beauty'),
(10, 'Home & Garden'),
(11, 'Hotels'),
(12, 'Medical'),
(13, 'Pets'),
(14, 'Restaurants'),
(15, 'Services'),
(16, 'Shopping'),
(17, 'Sports & Outdoor'),
(18, 'Travel & Experiences'),
(19, 'Other');");
    
    $sql = "SELECT TRUE FROM `engine4_core_modules` WHERE `name` = 'page' LIMIT 1";
    
    if (null != $db->fetchRow($sql)){
        $db->query("INSERT IGNORE INTO `engine4_page_modules` (`name`, `widget`, `order`, `params`, `informed`) VALUES
('offers', 'offers.profile-offers', 4, '{\"title\":\"Offers\", \"titleCount\":\"true\"}', 1);");
    };
    
    $db->query("INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'offer' as `type`,
    'auth_view' as `name`,
    5 as `value`,
    '[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]' as `params`
  FROM `engine4_authorization_levels` WHERE `type` NOT IN('public');");
    
    $db->query("INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'offer' as `type`,
    'auth_comment' as `name`,
    5 as `value`,
    '[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]' as `params`
  FROM `engine4_authorization_levels` WHERE `type` NOT IN('public');");
    
    $db->query("INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'offer' as `type`,
    'view' as `name`,
    2 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('moderator', 'admin');");
    
    $db->query("INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'offer' as `type`,
    'comment' as `name`,
    2 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('moderator', 'admin');");
    
    $db->query("INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'offer' as `type`,
    'view' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user');");
    
    $db->query("INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'offer' as `type`,
    'comment' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user');");
    
    $db->query("INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'offer' as `type`,
    'view' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('public');");
    
    $db->query("INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'offer' as `type`,
    'edit' as `name`,
    2 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('moderator', 'admin');");
    
    $db->query("INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'offer' as `type`,
    'edit' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user');");
    
    $db->query("INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'offer' as `type`,
    'delete' as `name`,
    2 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('moderator', 'admin');");
    
    $db->query("INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'offer' as `type`,
    'delete' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user');");
    
    $sql = "INSERT IGNORE INTO  `engine4_core_pages` (`name`, `displayname`, `title`, `description`, `provides`, `view_count`) VALUES
('offers_index_browse', 'Offers Browse Page', 'Offers Home', 'This page displays all offers', 'no-subject', 0)";
    $db->query($sql);
    $page_id = $db->lastInsertId();
    
    $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'container', 'top', NULL, 1)";
    $db->query($sql);
    $top_content_id = $db->lastInsertId();
    
    $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'container', 'middle', $top_content_id, 6)";
    $db->query($sql);
    $top_middle_content_id = $db->lastInsertId();
    
    $sql = "
INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'widget', 'offers.navigation-tabs', $top_middle_content_id, 3)";
    $db->query($sql);
    
    $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'container', 'main', NULL, 2)";
    $db->query($sql);
    $main_content_id = $db->lastInsertId();
    
    $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'container', 'right', $main_content_id, 5)";
    $db->query($sql);
    $main_right_content_id = $db->lastInsertId();
    
    $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`) VALUES
($page_id, 'widget', 'offers.offer-search', $main_right_content_id, 8, '[\"[]\"]'),
($page_id, 'widget', 'offers.offer-categories', $main_right_content_id, 9, '{\"title\":\"Categories\"}'),
($page_id, 'widget', 'offers.recent-offers', $main_right_content_id, 10, '{\"title\":\"Recent Offers\"}'),
($page_id, 'widget', 'offers.hot-offers', $main_right_content_id, 11, '{\"title\":\"Hot Offers\"}'),
($page_id, 'widget', 'offers.popular-offers', $main_right_content_id, 12, '{\"title\":\"Most Popular Offers\"}')";
    $db->query($sql);
    
    $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'container', 'middle', $main_content_id, 6)";
    $db->query($sql);
    $main_middle_content_id = $db->lastInsertId();
    
    $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`) VALUES
($page_id, 'widget', 'offers.browse-offers', $main_middle_content_id, 6, '[\"[]\"]')";
    $db->query($sql);
    
    
    $sql = "INSERT IGNORE INTO  `engine4_core_pages` (`name`, `displayname`, `title`, `description`, `provides`, `view_count`) VALUES
('offers_offer_view', 'Offer Profile Page', 'Offer Profile', 'This is the view page for a offer', 'no-subject', 0)";
    $db->query($sql);
    $page_id = $db->lastInsertId();
    
    $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'container', 'main', NULL, 2)";
    $db->query($sql);
    $main_content_id = $db->lastInsertId();
    
    $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'container', 'left', $main_content_id, 4)";
    $db->query($sql);
    $main_left_content_id = $db->lastInsertId();
    
    $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`) VALUES
($page_id, 'widget', 'offers.offer-photo', $main_left_content_id, 3, '[\"[]\"]'),
($page_id, 'widget', 'offers.offer-menu', $main_left_content_id, 4, '[\"[]\"]'),
($page_id, 'widget', 'offers.offer-contacts', $main_left_content_id, 5, '{\"title\":\"Contacts\"}'),
($page_id, 'widget', 'offers.offer-participants', $main_left_content_id, 6, '{\"title\":\"Participants\",\"titleCount\":\"true\"}')";
    $db->query($sql);
    
    $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'container', 'middle', $main_content_id, 6)";
    $db->query($sql);
    $main_middle_content_id = $db->lastInsertId();
    
    $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`) VALUES
($page_id, 'widget', 'core.container-tabs', $main_middle_content_id, 8, '{\"max\":\"6\"}')";
    $db->query($sql);
    $main_middle_tabs_content_id = $db->lastInsertId();
    
    $sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`) VALUES
($page_id, 'widget', 'offers.offer-details', $main_middle_tabs_content_id, 9, '{\"title\":\"Offers Details\",\"titleCount\":false}'),
($page_id, 'widget', 'activity.feed', $main_middle_tabs_content_id, 10, '{\"title\":\"What\'s New\"}')";
    $db->query($sql);
    $db->query("INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES
	('offer_admin_main_levels', 'offers', 'OFFERS_level', NULL, '{\"route\":\"admin_default\",\"module\":\"offers\",\"controller\":\"level\"}', 'offer_admin_main', NULL, 1, 0, 999);");
    $db->query("INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'offer' as `type`,
    'accept' as `name`,
    1 as `value`,
    null as `params`
  FROM `engine4_authorization_levels` WHERE `type` NOT IN('public');");
    
    $db->query("INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `params`, `menu`, `order`)
VALUES ('offer_admin_main_popular', 'offers', 'Popular', '{\"route\":\"admin_default\",\"module\":\"offers\",\"controller\":\"popular\"}', 'offer_admin_main', 1);");
    
  }
}