<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Newsletter Updates
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: Links.php 2017-02-25 10:15 bolot $
 * @author     Bolot
 */

/**
 * @category   Application_Extensions
 * @package    Newsletter Updates
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */
 
class Updates_Model_DbTable_Autoemails extends Engine_Db_Table
{
  protected $_rowClass = "Updates_Model_Autoemail";

  public function getList(){
    $typeTable = Engine_Api::_()->getDbTable('events', 'updates');
    $typeTableName = $typeTable->info('name');
    $thisTablename = $this->info('name');
    $select = $this->select()
      ->setIntegrityCheck(false)
      ->from(array('a'=>$thisTablename))
      ->joinLeft(array('e'=>$typeTableName), "`e`.`event_id` = `a`.`type_id`", array('e.description','e.name as type_name'));
    $data = $this->fetchAll($select);
    return $data;
  }
  public function getAutoemail($id){
    $typeTable = Engine_Api::_()->getDbTable('events', 'updates');
    $typeTableName = $typeTable->info('name');
    $thisTablename = $this->info('name');
    $select = $this->select()
      ->setIntegrityCheck(false)
      ->from(array('a'=>$thisTablename))
      ->joinLeft(array('e'=>$typeTableName), "`e`.`event_id` = `a`.`type_id`", array('e.description','e.name as type_name'))
      ->where('a.autoemail_id = ?',$id);
    $data = $this->fetchRow($select);
    return $data;
  }
  public function saveParams($params){

    $where = array('autoemail_id = ?' => $params['id']);
    $status = 0;
    if(isset($params['status']) && $params['status'] == 1){
      $status = 1;
    }
    $this->update(array('name' => $params['name'], 'email_content' => $params['message'], 'type_id' => $params['type'], 'status' => $status), $where);
    return true;
  }
}
