--
-- Update module Updates
--

UPDATE `engine4_core_modules` SET `version` = '4.2.3'  WHERE `name` = 'updates';