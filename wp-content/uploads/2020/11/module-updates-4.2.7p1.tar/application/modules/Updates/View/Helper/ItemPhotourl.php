<?php
/**
 * SocialEngine
 *
 * @category   Application_Updates
 * @package    Updates
 * @copyright  Copyright 2008-2017 Hire-experts
 * @license    http://www.hire-experts.com/
 * @version    $Id: ItemPhotourl.php 9747 2017-02-20 02:08:08Z bolot $
 * @author     Bolot
 */

/**
 * @category   Application_Updates
 * @package    Updates
 * @copyright  Copyright 2008-2017 Hire-experts
 * @license    http://www.hire-experts.com/
 */
class Updates_View_Helper_ItemPhotourl extends Zend_View_Helper_Abstract
{
  protected $_noPhotos;

  public function itemPhotourl($item, $type = 'thumb.profile', $alt = "", $attribs = array())
  {
    $color = array(
      '#0eea90 ',
      '#133390 ',
      '#096bd0 ',
      '#3794ce ',
      '#6f9bc9 ',
      '#4ee2ae ',
      '#43c524 ',
      '#7076ed ',
      '#fd6ea3 ',
      '#c818bc ',
      '#f55508 ',
      '#f3f365 ',
      '#9efd97 ',
      '#f76d65 ',
      '#cb4be9 ',
      '#ed2e2c '
    );
    $color_code = $color[rand(0,15)];

    $key  = $item->getTitle();
    $key = strtoupper($key[0]);
    $html = '<a href="'.$item->getHref().'" style="vertical-align: bottom;text-decoration:none; color: rgb(255,255,255);line-height: 105px;text-align:center;display: inline-block; width: 110px; height: 110px; overflow: hidden;  border-radius: 50%; box-sizing: border-box; background-color: '.$color_code.';  font-size: 70px;">
    <span style="color:#fff">'.$key.'</span>
  </a>';
    return $html;
  }


}