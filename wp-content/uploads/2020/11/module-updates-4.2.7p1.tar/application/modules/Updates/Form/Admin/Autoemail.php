<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Newsletter Updates
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: Module.php 2010-09-09 10:15 mirlan $
 * @author     Mirlan
 */

/**
 * @category   Application_Extensions
 * @package    Newsletter Updates
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Updates_Form_Admin_Autoemail extends Engine_Form
{
  public function init()
  {
    $this
      ->loadDefaultDecorators();


    $this->setAttribs(array(
      'id' => 'campaign_form',
      'class' => 'global_form_box'
    ));

    $settings = Engine_Api::_()->getApi('settings', 'core');



    $i = 0;




    // OTHER FIELDS
    $this->addElement('text', 'name', array(
      'label' => 'Title:',
      'required'=>true,
      'trim'=>true,
      'style'=>'min-width: 230px',
      'order'=>$i++
    ));

    $modulesTbl = Engine_Api::_()->getDbTable('modules', 'core');
    $coreItem = $modulesTbl->getModule('core')->toArray();

    //Activity

      $editorOptions = array(
        'height'=>'350px',
        'theme_advanced_resizing'=>true,
      );


    $this->addElement('TinyMce', 'message', array(
      'label' => 'Message',
      'editorOptions' => $editorOptions,
      'required'=>true,
      'decorators' => array(
        'ViewHelper',
        array('HtmlTag2', array('tag' => 'div', 'id'=>'message-wrapper', 'class'=>'form-wrapper')),
        'Description',
      ),
      'allowEmpty' => false,
      'order'=>$i++
    ));
    $recievers = array();
    $ObjectEvents  = Engine_Api::_()->updates()->getEvents();
    foreach($ObjectEvents as $event){
      $recievers[$event->event_id] = $event['name'];
    }

    $this->addElement('select', 'type', array(
      'label' => 'Emails Type:',
      'multiOptions' => $recievers,
      'order' => $i++,
      'description' => 'Change type to send correct time',
    ));
    $this->addElement('checkbox', 'status', array(
      'label' => 'Enabled?',
      'value' => 1,
      'order'=>$i++
    ));
    $this->addElement('Button', 'submit', array(
      'label' => 'Save',
      'type' => 'submit',
      'ignore' => true,
      'order'=>$i++,
      'decorators' => array('ViewHelper')
    ));



    $this->addElement('Button', 'test_email', array(
      'type'=>'button',
      'label' => 'UPDATES_Send test email',
      'link'=> true,
      'onclick' => 'testemail()',
      'order'=>$i++,
      'decorators' => array('ViewHelper'),
    ));

    $this->addElement('Cancel', 'cancel', array(
      'type'=>'cancel',
      'label' => 'UPDATES_cancel',
      'link'=> true,
      'prependText' => ' or ',
      'href' => $this->getView()->url(array('module'=>'updates', 'controller'=>'autoemail', 'action'=>'index')),
      'order'=>$i++,
      'decorators' => array('ViewHelper'),
    ));


  }

  public function setHeaders($params){
  }
}