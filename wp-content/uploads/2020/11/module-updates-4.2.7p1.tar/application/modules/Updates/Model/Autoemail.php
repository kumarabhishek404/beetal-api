<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Newsletter Updates
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: Campaign.php 2017-02-25 10:15 bolot $
 * @author     Bolot
 */

/**
 * @category   Application_Extensions
 * @package    Newsletter Updates
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Updates_Model_Autoemail extends Core_Model_Item_Abstract
{
  protected $_type = 'autoemail';
  public function getType(){

    $typeTable = Engine_Api::_()->getDbTable('events', 'updates');
    $select  = $typeTable->select()->where('event_id = ?',$this->type_id);
    $data  = $typeTable->fetchRow($select);
    $type = explode('_',$data->type);
    return $type[0];
  }
}
