<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Admin
 * Date: 08.12.10
 * Time: 10:30
 * To change this template use File | Settings | File Templates.
 */
 
class Updates_Model_Subscriber extends Core_Model_Item_Abstract
{
  protected $_type = "updates_subscriber";
}
