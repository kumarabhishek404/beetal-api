/***
 * MooRainbow
 *
 * @version		1.2b2
 * @license		MIT-style license
 * @author		Djamil Legato - < djamil [at] djamil.it >
 * @infos		http://moorainbow.woolly-sheep.net
 * @copyright	Author
 * 
 *
 */
live_edit = {
	content_id:0,
	upload_url:'',
	bg_url:false,
	init:function(){
		this.initButtons();
		console.log('edit ready');
	},
	initButtons:function(){
		var self = this;
		if($('header_bg_hidden')) {
			this.bg_url = $('header_bg_hidden').get('bg_url');
		}
		$$('.edit_block').addEvent('click',function(){
		$$('.modal-container').show();
		});
		$$('.modal-close').addEvent('click',function(){
		$$('.modal-container').hide();
		});
		$('upload_header_bg').addEvent('change',function(){
			var file = this.files[0];
			self.upload(file)
		});
		if($('enable_bg_status') && parseInt($('enable_bg_status').get('enable_bg')) != 1){
			$('enable_bg').checked = false;
		}
		$('enable_bg').addEvent('change',function(){
			if(!this.checked){
				$$('.header_widget').setStyle('background-image','none');
			}else{
				if(self.bg_url) {
					$$('.header_widget').setStyle('background-image', 'url(' + self.bg_url + ')');
				}
			}
			new Request.JSON({
				'url':en4.core.baseUrl + 'admin/updates/settings/bg',
				'method':'post',
				'data':{'format':'json', 'checked':this.checked}
			}).send();
		});
		$('font_size_header').addEvent('change',function(){
			var font_change_to = this.value;
				$$('.header_widget').getElement('h3').setStyle('font-size',(14+parseInt(font_change_to))+'px');
				$$('.header_widget').getElement('h5').setStyle('font-size',(9+parseInt(font_change_to))+'px');
			$('hfsize').value = font_change_to;
			activate_submit();
		});
		if($('hfsize').value>1){
			$('font_size_header').value = $('hfsize').value;
		}
		this.upload_url = en4.core.baseUrl + 'admin/updates/settings/cover';
	},
	upload:function(file) {
		var self = this;
		$('progress_status').setStyle('width','0');
		$$('.upload_progress_update').show();

	var xhr = new XMLHttpRequest();

	// обработчик для закачки
	xhr.upload.onprogress = function(event) {
		var ttt = (event.loaded*100)/event.total;
		$('progress_status').setStyle('width',ttt+'%');
	}

	// обработчики успеха и ошибки
	// если status == 200, то это успех, иначе ошибка
	xhr.onload = xhr.onerror = function() {
		if (this.status == 200) {
			$$('.upload_progress_update').hide();
			console.log("success");
			var params = JSON.parse(this.response);
			$$('.header_widget').setStyle('background-image','url('+params.photo_url+')');
			self.bg_url = params.photo_url;
			$('header_bg_hidden').set('bg_url',params.photo_url)
			$('enable_bg').checked = true;
			new Request.JSON({
				'url':en4.core.baseUrl + 'admin/updates/settings/bg',
				'method':'post',
				'data':{'format':'json', 'checked':'true'}
			}).send();
			$$('.modal-container').hide();
		} else {
			console.log("error " + this.status);
		}
	};
	xhr.open("POST", this.upload_url, true);
		var formData = new FormData();
		formData.append("myfile", file);
	xhr.send(formData);

}
};
var $savechanges = false;
window.onbeforeunload = function(event) {
	if(!$('submit').disabled && !$savechanges) {
		return en4.core.language.translate('UPDATES_All unsaved changes to content will be lost');
		//return 'I\'m sorry Dave, I can\'t do that.';
	} else {
		true;
	}
 };

function activate_submit(){
			$('submit').disabled = false;
			$('submit').addClass('highlight');
			$('button').disabled = true;
			$('button').setStyle('background', '#878C9C');
}

if(document.styleSheets[0]) {
  document.styleSheets[0].disabled = true;
}
var $color = Array();
en4.core.runonce.add(function()
{
  $('background_box').setStyle('background-color', $('bgcolor').value);
  $('body_box').setStyle('body_box', $('bgcolor').value);
  $('font_box').setStyle('background-color', $('fncolor').value);
  $('titles_box').setStyle('background-color', $('tlcolor').value);
  $('links_box').setStyle('background-color', $('lkcolor').value);
  $('header_box').setStyle('background-color', ($('hdcolor').value!=""?$('hdcolor').value:'#C7DAA6'));
  $('header_font_box').setStyle('background-color', ($('hdfcolor').value!=""?$('hdfcolor').value:'#C7DAA6'));
  //set styles
  $('background').setStyle('background-color',  $('bgcolor').value);
  $$('.fontcolors').setStyle('color', $('fncolor').value);
  $$('.msgtitles').setStyle('color', $('tlcolor').value);
  $$('.msgtitles').setStyle('border-bottom-color', $('tlcolor').value);
  $$('.msgLink').setStyle('color', $('lkcolor').value);
  $$('.header_widget').setStyle('background-color', ($('hdcolor').value!=""?$('hdcolor').value:'#C7DAA6'));
  $$('.header_widget').setStyle('color', ($('hdfcolor').value!=""?$('hdfcolor').value:'#ffffff'));

	var $bg = new MooRainbow('background_color', {
		'id':'backgroundColor',
		'onChange': function(color) {
			$('background_box').setStyle('background-color', color.hex);
			$('background').setStyle('background-color', color.hex);
			$('bgcolor').value = color.hex;
			activate_submit();
		}
	});
	var $bg = new MooRainbow('body_color', {
		'id':'bodyColor',
		'onChange': function(color) {
			$('body_box').setStyle('background-color', color.hex);
			$('body_background').setStyle('background-color', color.hex);
			$('bbcolor').value = color.hex;
			activate_submit();
		}
	});

	var $fn = new MooRainbow('font_color', {
		'id':'fontColor',
		'onChange': function(color) {
			$('font_box').setStyle('background-color', color.hex);
			$$('.fontcolors').setStyle('color', color.hex);
			$('fncolor').value = color.hex;
			activate_submit();
		}
	});

	var $tl = new MooRainbow('titles_color', {
		'id':'titlesColor',
		'onChange': function(color) {
			$('titles_box').setStyle('background-color', color.hex);
			$$('.msgtitles').setStyle('color', color.hex);
			$$('.msgtitles').setStyle('border-bottom-color', color.hex);
			$('tlcolor').value = color.hex;
			activate_submit();
		}
	});
	var $hc = new MooRainbow('header_color', {
		'id':'headerColor',
		'onChange': function(color) {
			$('header_box').setStyle('background-color', color.hex);
			$$('.header_widget').setStyle('background-color', color.hex);
			$('hdcolor').value = color.hex;
			activate_submit();
		}
	});
	var $hcf = new MooRainbow('header_font_color', {
		'id':'headerFontColor',
		'onChange': function(color) {
			$('header_font_box').setStyle('background-color', color.hex);
			$$('.header_widget').setStyle('color', color.hex);
			$('hdfcolor').value = color.hex;
			activate_submit();
		}
	});

	var $lk = new MooRainbow('links_color', {
		'id':'linksColor',
		'onChange': function(color) {
			$('links_box').setStyle('background-color', color.hex);
			$$('.msgLink').setStyle('color', color.hex);
			$('lkcolor').value = color.hex;
			activate_submit();
		}
	});

	$$('.content-conteiner').addEvents({
		'mouseenter':function(){
			$(this).getElement('.content-edit').setStyle('display', 'inline');
		},
		'mouseleave':function(){
		$(this).getElement('.content-edit').setStyle('display', 'none');
		}
	});
});

var content  = {
		id:0,
		name:'',
		blacklist: {},

		editContent:function(content_name, content_id)
    {
			content.id = content_id;
			content.name = content_name;

			var $items =  $(content_name + '_' + content_id).getElements('.item').getProperty('class');

			var displayed = new Array();
			for(var i in $items){
				if ($items[i].substring != undefined){
					var pos = parseInt($items[i].indexOf(' '));
					displayed[i] = $items[i].substring(5, pos);
				}
			}

      he_contacts.width = 600;
      he_contacts.height = 500;

      he_contacts.myCSS = new Asset.css(en4.core.baseUrl + 'application/css.php?request=application/themes/default/theme.css');

      he_contacts.onLoad = function() {
        $('tmp_items').adopt($$('.blacklist_item'));

        $('content_tab_active').addEvent('click', function()
         {
          $('tmp_items').adopt($$('.blacklist_item'));
          $('he_contacts_list').adopt($$('.content_item'));

          $(this).setStyle('display', 'none');
          $('blacklist_tab_disabled').setStyle('display', 'none');
          $('blacklist_tab_active').setStyle('display', '');
          $('content_tab_disabled').setStyle('display', '');

          $('remove_from_blacklist').setStyle('display', 'none');
          $('add_to_blacklist').setStyle('display', '');

          $('select_all_contacs').checked = false;
          he_contacts.choose_all_contacts($('select_all_contacs'));
        });

        $('blacklist_tab_active').addEvent('click', function()
         {
           $('tmp_items').adopt($$('.content_item'));
          $('he_contacts_list').adopt($$('.blacklist_item'));

          $(this).setStyle('display', 'none');

          $('content_tab_disabled').setStyle('display', 'none');
          $('blacklist_tab_disabled').setStyle('display', '');
          $('content_tab_active').setStyle('display', '');

          $('add_to_blacklist').setStyle('display', 'none');
          $('remove_from_blacklist').setStyle('display', '');

          $('select_all_contacs').checked = false;
          he_contacts.choose_all_contacts($('select_all_contacs'));
        });

        Smoothbox.instance.positionWindow();

        // correct styles
        $('global_content_simple').setStyle('display', 'block');
        $$('.admin_home_middle')[0].getChildren('div').setStyle('margin', 'auto');
        $$('.admin_home_middle')[0].getChildren('div').setStyle('text-align', 'center');
      };

      he_contacts.onClose = function() {
        if (he_contacts.myCSS) {
          he_contacts.myCSS.destroy();
        }
      };
			he_contacts.box('updates',
                      'getContentItems',
                      'content.addToBlacklist',
                      en4.core.language.translate('UPDATES_Edit widget content list'),
                      {
												'scriptpath':'application/modules/Updates/views/scripts/',
												'blacklist':(content.blacklist[content_name] != undefined && content.blacklist[content_name].length > 0)?content.blacklist[content_name]:false,
												'content_id':content_id,
												'content_name': content_name,
												'displayed': (displayed.length > 0)?displayed:false,
												'modified':!$('submit').disabled
											},
                    	0);
		},

		addToBlacklist:function(items)
    {
			if (content.blacklist[content.name] == undefined){
				content.blacklist[content.name] = Array();
			}

			var length = content.blacklist[content.name].length;
			var count = 0;
			for (var i in items)
      {
				if (!isNaN(parseInt(items[i])))
        {
          if (content.blacklist[content.name] == '') {
            content.blacklist[content.name] += items[i];
          } else {
					  content.blacklist[content.name] += ","+items[i];
          }

					$elements = $$('.'+content.name).getElement('.item_'+items[i]);

					for(var j in $elements)
          {
						if ($elements[j] != null && $elements[j].setStyle != undefined) {
							$elements[j].setStyle('display', 'none');
						}
					}
					count++;
        }
        else {
				  // nothing...
        }
			}

			content.id = 0;
			content.name = '';

      if (count > 0) {
				$('blacklist').value = json_enc(content.blacklist);
        $('remove').value = false;
				activate_submit();
			}
		},

		removeFromBlacklist:function(items) {
			var count = 0;
      var $contentBlacklist = content.blacklist[content.name].split(',');
      var removeBlacklist = '0';
      for(var i in items){
				var key = in_array_key(items[i], $contentBlacklist);
				if (key != undefined){
					$elements = $$('.'+content.name).getElement('.item_'+items[i]);
          removeBlacklist += ',' + items[i];
					for(var j in $elements) {
						if ($elements[j] != null && $elements[j].setStyle != undefined){
							$elements[j].setStyle('display', '');
						}
					}

					count++;

					content.blacklist[content.name][key] = 0;
				}
			}

      for (var key in content.blacklist) {
        if (key != content.name) {
          delete content.blacklist[key];
        }
      }

      content.blacklist[content.name] = removeBlacklist;
			if (count > 0) {
				$('blacklist').value = json_enc(content.blacklist);
        $('remove').value = true;
				activate_submit();
			}
		}
}

function in_array_key(needle, haystack) {
    var length = haystack.length;
    for(var i = 0; i < length; i++) {
        if(haystack[i] == needle) return i;
    }
    return undefined;
}

function json_enc(list)
{
	var str_str = '{';
	var i=0;
	for (var widget_type in list) {
   if (i != 0) str_str +=',';
    str_str += '"' + widget_type + '":['
    + list[widget_type].toString() + "]";
    i++;
	}

	str_str += '}';

	return str_str;
}