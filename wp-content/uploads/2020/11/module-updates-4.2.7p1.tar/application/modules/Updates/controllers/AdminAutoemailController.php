<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Newsletter Updates
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: AdminGeneralController.php 2010-09-09 10:15 mirlan $
 * @author     Mirlan
 */

/**
 * @category   Application_Extensions
 * @package    Newsletter Updates
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Updates_AdminAutoemailController extends Core_Controller_Action_Admin
{
  public function init(){
    $this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
      ->getNavigation('updates_admin_main', array(), 'updates_admin_main_autoemails');
  }
	public function indexAction()
  {
    /*
     * @var $listCompaings  Updates_Model_DbTable_Autoemails
     */
    $listCompaings  = Engine_Api::_()->getDbTable('autoemails', 'updates')->getList();
    /*print_die($listCompaings);*/
    $this->view->list = $listCompaings;
  }
  public function editAction(){
    $auteid = $this->getParam('id',0);
    $autoemailTable = Engine_Api::_()->getDbTable('autoemails', 'updates');
    $this->view->auteid  = $auteid;

    $this->view->form = $form  = new Updates_Form_Admin_Autoemail();
    if( $this->getRequest()->isPost())
    {
      $autoemailTable->saveParams($this->_getAllParams());
    }
    $compaings  = $autoemailTable->getAutoemail($auteid);
    $form->populate(array('name'=>$compaings->name,'message'=>$compaings->email_content,'type'=>$compaings->type_id,'status'=>$compaings->status));
    }
  public function enableAction()
  {
    $auteid = $this->getParam('id', 0);
    $status = $this->getParam('status', 0);
    $autoemailTable = Engine_Api::_()->getDbTable('autoemails', 'updates');
    $where = array('autoemail_id = ?' => $auteid);
    $autoemailTable->update(array('status' => $status), $where);
    die('success');
  }
  public function checkemailAction()
  {
    Engine_Api::_()->updates()->checkEvents();
    die('success');
  }

  public function testemailAction()
  {
    $this->view->form = $form = new Updates_Form_Admin_Layout_Testemail();
    $id = $this->_getParam('id');
    $autoemailTable = Engine_Api::_()->getDbTable('autoemails', 'updates');
    $compaings  = $autoemailTable->getAutoemail($id);
    $type = $compaings->getType();
    if ($this->getRequest()->isPost() && $form->isValid($this->getRequest()->getPost()))
    {
      $api  = Engine_Api::_()->updates();
      $test_email = $this->_getParam('test_email');
      $api->senEmail(false, $type,$compaings,$test_email);

      $this->_forward('success', 'utility', 'core', array(
        'smoothboxClose' => TRUE,
        'parentRefresh' => FALSE,
        'format'=> 'smoothbox',
        'messages' => array($this->view->translate('UPDATES_Test mail successfully has been sent to ').$test_email),
      ));
    }
  }
 }
