--
-- Update module Updates
--

UPDATE `engine4_core_modules` SET `version` = '4.2.6p1'  WHERE `name` = 'updates';