<?php

/**
 * Created by JetBrains PhpStorm.
 * User: Admin
 * Date: 02.12.10
 * Time: 15:00
 * To change this template use File | Settings | File Templates.
 */
class Updates_Api_Core extends Core_Api_Abstract
{
  public function getContentItems($params)
  {
    $id = $params['content_id'];
    $displayed = explode(',', $params['displayed']);
    $blacklist = explode(',', $params['blacklist']);

    $displayed = array_unique(array_merge($displayed, $blacklist));

    $displayed_tmp = array();
    foreach ($displayed as $key => $value) {
      if (isset($value) && trim($value) != '') {
        $displayed_tmp[] = $value;
      }
    }

    /**
     * @var $contentTb Updates_Model_DbTable_Content
     */

    $displayed = $displayed_tmp;
    $contentTb = Engine_Api::_()->getDbTable('content', 'updates');

    if (null == ($content = $contentTb->getContentWidget($id))) {
      $this->_forward('success', 'utility', 'core', array(
        'smoothboxClose' => TRUE,
        'parentRefresh' => FALSE,
        'format' => 'smoothbox',
        'messages' => Zend_Registry::get('Zend_Translate')->translate('UPDATES_No content found with id') . ' ' . $id,
      ));
    }

    $content = $content->toArray();
    $content['authTb'] = $authorizationTb = Engine_Api::_()->getDbTable('allow', 'authorization')->info('name');
    $content['count'] = $content['params']['count'];
    $content['title'] = $content['params']['title'];
    $content['select'] = $content['params']['select'];
    $content['title'] = $content['params']['title'];
    $content['displayed'] = implode(',', $displayed);
    $content['count'] = count($displayed);
    $content['blacklist'] = null;

    $items = $contentTb->getContentData($content['name'], $content);

    return Zend_Paginator::factory($items);
  }

  public function urlsEncode($message, $id = '', $type = 'updates')
  {
    $view = Zend_Registry::get('Zend_View');
    $host = $_SERVER['HTTP_HOST'] . $view->baseUrl();
    $matches = array();
    $host = str_replace('/', '\/', $host);
    preg_match_all('/href="http:\/\/' . $host . '+[a-zA-Z0-9\/\-\_\s@\.\$\&\?=!\{\}\:\;\,\%\#\*\(\)\+]*"/', $message, $matches);

    $originals = array();
    $encoded = array();

    if (count($matches) <= 0) return $message;

    foreach ($matches[0] as $match) {
      $exploded = explode('"', $match);
      $originals[] = $match;
      $encoded[] = 'target="blank" href="http://' . $host . '/updates/ajax/referred/' . $type . '/' . $id . '/' . str_replace('%', '_enc_', urlencode($exploded[1])) . '"';
    }

    if (isset($originals) && isset($encoded)) {
      $message = str_replace($originals, $encoded, $message);
    }

    return $message;
  }

  public function getTimezone()
  {
    $settings = Engine_Api::_()->getApi('settings', 'core');
    if ($settings->__get('core.locale.timezone')) {
      return $settings->__get('core.locale.timezone');
    } else {
      return Zend_Registry::get('timezone');
    }
  }

  public function getDatetime($datetime = null)
  {
    $dt = new Zend_Date();
    $dt->setTimezone($this->getTimezone());

    if ($datetime != null) {
      $dt->setTime($datetime);
    }

    return $dt->get(Zend_Date::DATETIME);
  }

  public function getTimestamp($datetime = null, $dt = null)
  {
    if (!$dt) {
      $dt = new Zend_Date();
      $dt->setTimezone($this->getTimezone());
    }

    if ($datetime != null) {
      $dt->setTime($datetime);
    }

    $year = $dt->get(Zend_Date::YEAR);
    $month = $dt->get(Zend_Date::MONTH_SHORT);
    $day = $dt->get(Zend_Date::DAY_SHORT);
    $hour = $dt->get(Zend_Date::HOUR_SHORT);
    $minute = $dt->get(Zend_Date::MINUTE_SHORT);
    $second = $dt->get(Zend_Date::SECOND_SHORT);

    $ts = mktime($hour, $minute, $second, $month, $day, $year);

    return $ts;
  }

  public function getEvents($type = 0)
  {
    $table = Engine_Api::_()->getDbTable('events', 'updates');

    $select = $table->select();
    if ($type) {
      $select->where('type = ?', $type);
      return $table->fetchRow($select);
    }
    return $table->fetchAll($select);
  }

  public function getSendedIds($param)
  {
    $table = Engine_Api::_()->getDbTable('autoemaillogs', 'updates');
    $select = $table->select()->where("from_unixtime(`date`,'%Y-%m-%d') = DATE(now())")->where("type_id = ?", $param['event_id']);
    $data = $table->fetchAll($select);
    $ids = array();
    if ($data && count($data) > 0) {
      foreach ($data as $d) {
        $ids[] = $d['user_id'];
      }
    }
    return $ids;
  }

  public function getAutoEmailToSend($type = 0)
  {
    $table = Engine_Api::_()->getDbTable('autoemails', 'updates');

    $select = $table->select();
    if ($type) {
      $select->where('type_id = ?', $type);
      return $table->fetchRow($select);
    }
  }

  public function checkEvents()
  {
       $type = $this->getEvents('birthday_email');
    $autoemail = $this->getAutoEmailToSend($type['event_id']);
    if ($autoemail->status == 1) {
      $ids = $this->getSendedIds($type);
      $users_birthday = $this->isBirthdayToday($ids);
      if ($users_birthday && count($users_birthday) > 0) {
        $params_autoemaillog = array();
        foreach ($users_birthday as $u) {
          $user = Engine_Api::_()->getItem('user', $u['user_id']);
          if($user) {
            $this->senEmail($user, 'birthday', $autoemail);
          }
          $params_autoemaillog[] = array(
            'user_id' => $u['user_id'],
            'type_id' => $type['event_id'],
            'date' => time()
          );
        }
        if(count($params_autoemaillog)>0) {
          $db = Engine_Db_Table::getDefaultAdapter();
          $queryVals = array();
          foreach ($params_autoemaillog as $row) {
            foreach($row as &$col) {
              $col = $db->quote($col);
            }
            $queryVals[] = '(' . implode(',', $row) . ')';
          }
          if(count($queryVals)>0) {
            $sql = "INSERT INTO `getse`.`engine4_updates_autoemaillogs` (`user_id`, `type_id`, `date`) VALUES
          " . implode(',', $queryVals) . ";";
            $db->query($sql);
          }
        }

      }

    }
  }

  public function isBirthdayToday($ids)
  {
    $db = Engine_Db_Table::getDefaultAdapter();
    $where = '';
    if (count($ids) > 0) {
      $where .= ' AND engine4_user_fields_values.item_id not in(' . implode(',', $ids) . ') ';
    }
    $sql = "SELECT engine4_user_fields_values.item_id as `user_id` FROM engine4_user_fields_values LEFT JOIN engine4_user_fields_meta ON engine4_user_fields_values.field_id = engine4_user_fields_meta.field_id WHERE engine4_user_fields_meta.type = 'birthdate' AND MONTH(engine4_user_fields_values.value) = MONTH(NOW()) AND DAY(engine4_user_fields_values.value) = DAY(NOW())" . $where;
    return $db->query($sql)->fetchAll();
  }

  public function senEmail($user, $type,$autoemail,$test_eamil = false)
  {
    $settings = Engine_Api::_()->getApi('settings', 'core');
    $mailService = $settings->__get('updates.mailservice');


    /**
     * @var $table Updates_Model_DbTable_Updates
     * @var $mail Core_Api_Mail
     */
    $tamplate = $autoemail;
    $message = $autoemail->email_content;
    if($user){
      $email_to = $user['email'];
      $title = $user->getTitle();
    }

    if($test_eamil){
      $email_to = $test_eamil;
      $title = $test_eamil;
    }

    $mail = Engine_Api::_()->getApi('mail', 'core');


    $host = (isset($_SERVER['HTTPS']) ? "https" : "http");
    $host_url = $host.'://'.str_ireplace('/updates','',$_SERVER['HTTP_HOST'].Zend_Controller_Front::getInstance()->getRouter()->assemble(array(), 'upadtes'));


    $remove = array("[name]", "[email]", "http://devka.hire-experts.com");
    $replace = array($title, $email_to, $host_url);
    $message = str_replace($remove, $replace, $message);

    $remove = array("\n", "\r\n", "\r");
    $message = str_replace($remove, ' ', $message);
    $remove = array("    ", "   ", "  ");
    $params['message'] = $message = str_replace($remove, ' ', $message);

    $settings = Engine_Api::_()->getApi('settings', 'core');
    $mailService = $settings->__get('updates.mailservice');

    $messageBody = $params['message'];

    if ($mailService == 'socialengine') {
      if ($mail->sendSystemRaw($email_to, $type, $params) instanceof Core_Api_Mail) {
        return true;
      }
    } elseif ($mailService == 'sendgrid') {
      include_once 'application/modules/Updates/Api/SendGrid_loader.php';

      // Login credentials
      $username = $settings->__get('updates.sendgrid.username');
      $password = $settings->__get('updates.sendgrid.password');

      // Get admin info
      $fromAddress = Engine_Api::_()->getApi('settings', 'core')->getSetting('core.mail.from', 'admin@' . $_SERVER['HTTP_HOST']);
      $fromName = Engine_Api::_()->getApi('settings', 'core')->getSetting('core.mail.name', 'Site Admin');

      $sendgrid = new SendGrid($username, $password);
      $sendgridMail = new SendGrid\Mail();

      $sendgridMail->
      addTo($email_to)->
      setFrom($fromAddress)->
      setFromName($fromName)->
      setSubject($tamplate->name)->
      setText(strip_tags($messageBody))->
      setHtml($messageBody);

      $result = $sendgrid->
      web->
      send($sendgridMail);

      // send message
      if ($result) {
        return true;
      } else {
        echo "Something went wrong - " . $result;
        exit;
      }
      unset($sendgridMail);
    } elseif ($mailService == 'mailchimp') {
      if (!class_exists('MCAPI')) {
        include_once 'application/modules/Updates/Api/MCAPI.class.php';
      }
      $apikey = $settings->__get('updates.mailchimp.apikey');
      $api = new MCAPI($apikey);
      $type = 'regular';

      $list_id = $settings->__get('updates.mailchimp.listid');
      $opts['list_id'] = $list_id;
      $opts['subject'] = $settings->__get('updates.mailchimp.subject');
      $opts['from_email'] = $settings->__get('updates.mailchimp.fromemail');
      $opts['from_name'] = $settings->__get('updates.mailchimp.fromname');
      $opts['title'] = $settings->__get('updates.mailchimp.title');
      $opts['tracking'] = array('opens' => true, 'html_clicks' => true, 'text_clicks' => false);
      $opts['authenticate'] = true;

      $messageBody = str_replace('Unsubscribe</a>&nbsp;|', '</a>', $messageBody);

      $content = array('html' => $messageBody,
        'text' => 'text text text *|UNSUB|*'
      );

      $campaign_id = $api->campaignCreate($type, $opts, $content);

      if ($api->errorCode) {
        echo "Unable to Create New Updates!\n";
        echo "\tCode=" . $api->errorCode . "\n";
        echo "\tMsg=" . $api->errorMessage . "\n";
        exit;
      }

      $emails = array($email_to);
      $api->campaignSendTest($campaign_id, $emails);

      if ($api->errorCode) {
        echo "Unable to Send Updates!\n";
        echo "\tCode=" . $api->errorCode . "\n";
        echo "\tMsg=" . $api->errorMessage . "\n";
        exit;
      } else {
        return true;
      }
      unset($campaign_id);
    }


  }
}