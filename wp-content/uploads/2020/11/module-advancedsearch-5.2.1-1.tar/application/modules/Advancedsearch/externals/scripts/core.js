/*
 * New advanced search plugin
 * By Kalyskin
 * 2017-04-18
 * new JS code
 */

var AdvancedSearch = function (params) {
    this.params = params;
    var self = this;
    window.addEvent('domready', function () {
        self.init();
    });
};
AdvancedSearch.prototype.open = function () {
    $(this.params.container_id).removeClass("closed");
    //  this.input_search.focus();
    this.input_search.set("value", "");
    $$("html")[0].setStyle("overflow", "hidden");
};
AdvancedSearch.prototype.close = function () {
    $(this.params.container_id).addClass("closed");
    $$("html")[0].setStyle("overflow", "");
};
AdvancedSearch.prototype.searchGlobal = function () {
    var self = this;
    var query = self.input_search.get('value');
    var type = self.container.getElement('#as_global_type').get('value');
    var global_types_list = self.container.getElement('#advancedsearch_global_types_list');
    var found_items = self.container.getElement('#as_global_found_items');
    var global_loading = self.container.getElement('#as_global_loading');

    if (query != '') {
        global_types_list.setStyle('opacity', '0');
        self.asGlobal.hide();
        global_types_list.setStyle('display', 'none');
        global_types_list.getParent().setStyle('overflow', 'hidden');
        global_loading.setStyle('visibility', 'visible');
        var url = self.params.url;
        new Request.JSON({
            url: url,
            method: 'post',
            data: {
                'query': query,
                'type': type,
                'global': true,
                'format': 'json'
            },
            onSuccess: function (data) {
                if (data && "html" in data && data.html.trim() != '') {
                    var found = data.html;

                    found_items.set('html', data.html);
                    var myFx = new Fx.Tween('as_global_found_items');
                    found_items.setStyle('opacity', 0);
                    found_items.setStyle('max-height', '780px');
                    found_items.setStyle('overflow', 'auto');
                    myFx.start('opacity', 0, 1);
                } else if (typeof data.html !== 'undefined' && data.html.trim() == '') {
                    var check = true;
                    var div = new Element('div');
                    div.addClass('as_global_found_more');
                    new Element('span').set('text', self.params.not_found_text).inject(div);
                    found_items.set('html', '');
                    if (global_types_list.getParent().getStyle('overflow') == 'hidden') {
                        div.inject(found_items);
                    }
                }
                global_loading.setStyle('visibility', 'hidden');
            }
        }).send();

    } else {
        self.asGlobal.show();
        global_types_list.setStyle('opacity', '1').setStyle('display', 'block')
        global_types_list.getParent().setStyle('overflow', 'visible');
        global_loading.setStyle('visibility', 'hidden');
        found_items.set('html', '');
    }
};
AdvancedSearch.prototype.init = function () {
    var self = this;
    self.container = $(this.params.container_id);
    if (!self.container) return;
    self.input_search = self.container.getElement("input#global_search_field_advs");
    var global_types_list = self.container.getElement('#advancedsearch_global_types_list');
    var _asGlobal = new Fx.Slide(global_types_list);
    self.asGlobal = {
        hide: function () {
            _asGlobal.hide();
        },
        show: function () {
            _asGlobal.show();
            _asGlobal.wrapper.setStyle("height", "auto");
        }
    };

    /*Short code Shift+F : to toggle search panel*/
    $(document.body).addEvent('keydown', function (event) {
        if (event.key == 'f' && event.shift && $(event.target).get('tag') == 'body') {
            self.open();
        }
    });

    /* Close if clicked body area*/
    $(document.body).addEvent('click', function (e) {
        if (!$(e.target).hasClass('advsearch_left_toggle_container') && !$(e.target).getParent("#advsearch_left_toggle_container") && !$(e.target).hasClass(".as_global_search") && !$(e.target).getParent("form#global_search_form")
        ) {
            self.close();
        }
    });

    /*Init main search input*/
    if ($(self.params.main_input_id)) {
        $(self.params.main_input_id).addEvent('click', function () {
            self.open();
        });
        $(self.params.main_input_id).addEvent('focus', function () {
            self.open();
        });
    } else if ($(self.params.inject_form_id) && $("core_menu_mini_menu")) {
        /*if not found mini_search than inject input search to core_menu_mini_menu */
        var li = $(self.params.inject_form_id).getElement("li");
        li.getElement("input").set("id", "global_search_field");
        li.inject($("core_menu_mini_menu").getElement("ul"));
        $(self.params.inject_form_id).remove();
        console.log("injected!");
    }

    self.input_search.addEvent('focus', function () {

        if ($(this).get('value').trim() == '') {
            global_types_list.setStyle('display', 'block').setStyle('opacity', '1');
            self.asGlobal.show();
            $('as_global_found_items').set('html', '');
            global_types_list.getParent().setStyle('overflow', 'visible');
        } else if (parseInt($('as_global_found_items').getParent().getStyle('height')) == 0) {
            self.searchGlobal();
        }
    });
    self.container.getElements('.as_type_global_container_search').addEvent('click', function () {

        self.container.getElements('.as_type_global_container_search').removeClass('active');
        $(this).toggleClass('active');
        self.input_search.focus();
        var child_span = $(this).getChildren('span');
        var typeName = child_span.get('text');
        self.input_search.set('placeholder', typeName);
        var type = child_span.getProperty('data-type');
        self.container.getElement('#as_global_type').set('value', type);

    });

    self.input_search.addEvent('keyup', function (event) {

        if (event.key == 'enter') {
            if ($$('div.as_global_search_result.active').length > 0) {
                window.location = $$('div.as_global_search_result.active')[0].getParent('a').get('href');
            } else if ($$('div.as_global_found_more.active').length > 0) {
                window.location = $$('div.as_global_found_more.active')[0].getParent('a').get('href');
            }
        } else if ((event.key == 'up' || event.key == 'down')) {
            if ($('advancedsearch_global_types_list').getParent().getStyle('overflow') == 'visible') {

                var that = $$('.as_type_global_container_search.active');
                var activate = false;
                if (event.key == 'down') {
                    activate = that.getNext();
                } else {
                    activate = that.getPrevious();
                }
                if (activate && activate[0] != null) {
                    $$('.as_type_global_container_search').removeClass('active');
                    activate.toggleClass('active');
                    var icon = activate.getChildren('span i')[0].get('class');
                    var type = activate.getChildren('span')[0].get('data-type');
                    $('as_global_default_icon').getChildren('i').set('class', icon);
                    $('as_global_type').set('value', type);
                }
            } else if (parseInt($('as_global_found_items').getParent().getStyle('height')) > 0) {
                if ($('as_global_found_items').getChildren('.as_global_found_more').length == 0) {
                    if ($$('div.as_global_search_result.active').length > 0 || $$('div.as_global_found_more.active').length > 0) {
                        var changeActive = false;
                        if (event.key == 'up') {
                            if ($$('div.as_global_found_more.active').length > 0) {
                                changeActive = $$('div.as_global_found_more.active')[0].getParent().getPrevious('a');
                            } else if ($$('div.as_global_search_result.active').length > 0) {
                                changeActive = $$('div.as_global_search_result.active')[0].getParent().getPrevious('a');
                            }
                        } else if ($$('div.as_global_search_result.active').length > 0) {
                            changeActive = $$('div.as_global_search_result.active')[0].getParent().getNext('a');
                        }
                        if (changeActive) {
                            $$('div.as_global_search_result').removeClass('active');
                            $$('div.as_global_found_more').removeClass('active');
                            if (changeActive.hasClass('as_global_found_more_link')) {
                                changeActive.getChildren('div.as_global_found_more').addClass('active');
                            } else {
                                changeActive.getChildren('div.as_global_search_result').addClass('active');
                            }
                        }
                    } else {
                        $$('div.as_global_search_result')[0].addClass('active');
                        $$('div.as_global_found_more').removeClass('active');
                    }
                }
            }
        } else if (event.key == 'esc') {
            if ($(this).get('value').length > 0) {
                self.asGlobal.show();
                global_types_list.setStyle('opacity', '1');
                global_types_list.setStyle('display', 'block');
                global_types_list.getParent().setStyle('overflow', 'visible');
                $('as_global_found_items').set('html', '');
                $(this).set('value', '');
            } else {
                global_types_list.setStyle('opacity', '0');
                //self.asGlobal.hide();
                global_types_list.setStyle('display', 'none');
                global_types_list.getParent().setStyle('overflow', 'hidden');
                $(this).blur();
                self.close();
            }
        } else if ($(this).get('value').length > 2) {
            self.searchGlobal();
        } else {
            self.asGlobal.show();
            global_types_list.setStyle('opacity', '1');
            global_types_list.setStyle('display', 'block');
            global_types_list.getParent().setStyle('overflow', 'visible');
            $('as_global_found_items').set('html', '');
        }
    });

};




























