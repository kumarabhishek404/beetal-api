<?php
/***/
return array(
  array(
    'title' => 'Advanced Search',
    'description' => 'Shows the site-wide advanced search.',
    'category' => 'Advanced Search',
    'type' => 'widget',
    'name' => 'advancedsearch.search-mini',
  )
);
