<?php
/******/
class Advancedsearch_Model_DbTable_Title extends Engine_Db_Table {

}