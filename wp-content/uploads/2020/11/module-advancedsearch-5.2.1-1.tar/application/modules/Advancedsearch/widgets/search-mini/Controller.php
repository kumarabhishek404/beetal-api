<?php

/**
 * @author  Kalyskin
 */
class Advancedsearch_Widget_SearchMiniController extends Engine_Content_Widget_Abstract
{
    public function indexAction()
    {
        $requireCheck = Engine_Api::_()->getApi('settings', 'core')->core_general_search;
        if (!$requireCheck && !Zend_Controller_Action_HelperBroker::getStaticHelper('RequireUser')->checkRequire()) {
            $this->setNoRender();
            return;
        }
        $viewer = Engine_Api::_()->user()->getViewer();
        $require_check = Engine_Api::_()->getApi('settings', 'core')->core_general_search;
        if(!$require_check){
            if( $viewer->getIdentity()){
                $this->view->search_check = true;
            }
            else{
                $this->view->search_check = false;
            }
        }
        else $this->view->search_check = true;

        $string_for_array_mini_menu = Engine_Api::_()->getApi('settings', 'core')->getSetting('advancedsearch.typeslist');
        $mini_menu_array = explode(',', $string_for_array_mini_menu);
        $this->view->types = $mini_menu_array;
    }

}

?>
