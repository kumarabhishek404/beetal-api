INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES  ('advancedsearch', 'Advanced Search', 'Advanced Search from Hire-Experts LLC', '5.2.1', 1, 'extra') ;

INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`) VALUES (1, 'widget', 'advancedsearch.search-mini',100);

INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `order`) VALUES
('advancedsearch_admin_main_types', 'advancedsearch', 'AS_Search types', NULL, '{\"route\":\"admin_default\",\"module\":\"advancedsearch\",\"controller\":\"index\"}', 'advancedsearch_admin_main', '', 999),
('core_admin_main_plugins_advancedsearch', 'advancedsearch', 'AS_Advanced Search', NULL, '{\"route\":\"admin_default\",\"module\":\"advancedsearch\",\"controller\":\"index\"}', 'core_admin_main_plugins', '', 888);

INSERT IGNORE INTO `engine4_core_settings` (`name`, `value`) VALUES ('advancedsearch.sort', 'user');
