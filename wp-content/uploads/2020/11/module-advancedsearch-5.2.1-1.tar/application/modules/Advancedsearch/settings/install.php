<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: install.php 16.12.16 05:40 bolot $
 * @author     Bolot
 */

/**
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */
class Advancedsearch_Installer extends Engine_Package_Installer_Module
{

  public function onPreInstall()
  {
    $this->_SearchePage();
    parent::onPreInstall();
    $db = $this->getDb();
    $db = Engine_Db_Table::getDefaultAdapter();

    $db->query("INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES  ('advancedsearch', 'Advanced Search', 'Advanced Search from Hire-Experts LLC', '5.2.1', 1, 'extra') ;");
 
  }
  public function _SearchePage()
    {
        $db = $this->getDb();

        // create page
        $pageId = $db->select()
            ->from('engine4_core_pages', 'page_id')
            ->where('name = ?', 'advancedsearch_index_index')
            ->limit(1)
            ->query()
            ->fetchColumn();

        // insert if it doesn't exist yet
        if( !$pageId ) {
            // Insert page
            $db->insert('engine4_core_pages', array(
                'name' => 'advancedsearch_index_index',
                'displayname' => 'Advance Search Page',
                'title' => 'Advance Search Page',
                'description' => 'This page allows to be display all search results.',
                'custom' => 0,
            ));
            $pageId = $db->lastInsertId();

            // Insert main
            $db->insert('engine4_core_content', array(
                'type' => 'container',
                'name' => 'main',
                'page_id' => $pageId,
                'order' => 2,
            ));
            $mainId = $db->lastInsertId();


            // Insert main-middle
            $db->insert('engine4_core_content', array(
                'type' => 'container',
                'name' => 'middle',
                'page_id' => $pageId,
                'parent_content_id' => $mainId,
                'order' => 2,
            ));
            $mainMiddleId = $db->lastInsertId();

            // Insert content
            $db->insert('engine4_core_content', array(
                'type' => 'widget',
                'name' => 'core.content',
                'page_id' => $pageId,
                'parent_content_id' => $mainMiddleId,
                'order' => 1,
            ));
        }
    }
  function onEnable()
  {
    parent::onEnable();
    

  }

  function onDisable()
  {
    parent::onDisable();
    
  }
  
  
  
}
