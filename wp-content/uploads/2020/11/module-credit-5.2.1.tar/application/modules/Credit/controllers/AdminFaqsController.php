<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Credit
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: AdminPaymentsController.php 18.01.12 13:25 TeaJay $
 * @author     Taalay
 */

/**
 * @category   Application_Extensions
 * @package    Credit
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Credit_AdminFaqsController extends Core_Controller_Action_Admin
{
  public function indexAction()
  {
  	$this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
      ->getNavigation('credit_admin_main', array(), 'credit_admin_main_faqs');
      $faqsTable = Engine_Api::_()->getDbtable('faqs', 'credit');
      $select = $faqsTable->select();
      $this->view->paginator = $paginator = Zend_Paginator::factory($select);
    $this->view->paginator = $paginator->setCurrentPageNumber( $page );

  }
  public function createAction(){
  	$this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
      ->getNavigation('credit_admin_main', array(), 'credit_admin_main_faqs');
      $this->view->formFilter = $formFilter = new Credit_Form_Admin_Faqs();
      if( !$this->getRequest()->isPost() ) {
      return;
    }
    if( !$formFilter->isValid($this->getRequest()->getPost()) ) {
      return;
    }
    $values = $formFilter->getValues();
    $faqsTable = Engine_Api::_()->getDbtable('faqs', 'credit');
    $db = $faqsTable->getAdapter();
    $db->beginTransaction();
    try
      {
          $row = $faqsTable->createRow();
          $row->title = $values['subject'];
          $row->message = $values['message'];
          $row->save();
          $db->commit();
      }
      catch( Exception $e )
      {
      }
      //$form->addNotice('Vendor have been created.');
      return $this->_forward('success', 'utility', 'core', array(
      'smoothboxClose' => true,
      'parentRefresh' => true,
      'format'=> 'smoothbox',
      'messages' => 'Faq has been saved.'
    ));
      return;	

  }
  public function editAction(){
  	$id   = $this->_getParam('id');
  	$credit_faq = Engine_Api::_()->getItem('credit_faq', $id);
  	$this->view->form = $form = new Credit_Form_Admin_Faqs();
  	$values = array(
        'subject' => $credit_faq->title,
        'message' => $credit_faq->message,

      );
      $form->populate($values);
      if( !$this->getRequest()->isPost() ) {
      return;
    }
    if( !$form->isValid($this->getRequest()->getPost()) ) {
      return;
    }
    $values = $form->getValues();
  	$credit_faq->title = $values['subject'];
    $credit_faq->message = $values['message'];
    $credit_faq->save();
    return $this->_forward('success', 'utility', 'core', array(
      'smoothboxClose' => true,
      'parentRefresh' => true,
      'format'=> 'smoothbox',
      'messages' => 'Faq has been saved.'
    ));
      return;
  }
  public function deleteAction(){
  	    $id = $this->_getParam('id');
    // Check post
    if( $this->getRequest()->isPost() )
    {
      $db = Engine_Db_Table::getDefaultAdapter();
      $db->beginTransaction();

      try
      {
        $credit_faq = Engine_Api::_()->getItem('credit_faq', $id);
        $credit_faq->delete();
        $db->commit();
      }

      catch( Exception $e )
      {
        $db->rollBack();
        throw $e;
      }

      $this->_forward('success', 'utility', 'core', array(
          'smoothboxClose' => 10,
          'parentRefresh'=> 10,
          'messages' => array('')
      ));
    }

    // Output
    $this->renderScript('admin-faqs/delete.tpl');
  	
  }
}
