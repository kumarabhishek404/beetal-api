<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Credit
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: Controller.php 02.02.12 11:44 TeaJay $
 * @author     Taalay
 */

/**
 * @category   Application_Extensions
 * @package    Credit
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Credit_Widget_FaqController extends Engine_Content_Widget_Abstract
{
  public function indexAction()
  {
  
    $this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
      ->getNavigation('credit_main', array(), 'credit_main_faq');

    $translate = Zend_Registry::get('Zend_Translate');
    $faqsTable = Engine_Api::_()->getDbtable('faqs', 'credit');
    $gateways = $faqsTable->fetchAll();
    $this->view->faqs = $gateways;

    /**
     * @var $table Credit_Model_DbTable_ActionTypes
     */

    $table = Engine_Api::_()->getDbTable('actionTypes', 'credit');
    $this->view->actionTypes = $table->getActionTypes(array('action_module' => 'ASC', 'credit' => 1));
  }
}
