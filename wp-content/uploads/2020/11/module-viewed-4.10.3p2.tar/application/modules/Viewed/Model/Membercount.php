<?php
class Viewed_Model_Membercount extends Core_Model_Item_Abstract
{


}