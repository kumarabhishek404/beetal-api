<?php
class Viewed_Model_Viewme extends Core_Model_Item_Abstract
{


}