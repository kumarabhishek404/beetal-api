<?php

return array(
 
  array(
    'title' => 'Who Viewed me',
    'description' => 'Displays a list of user who viewed my profile',
    'category' => 'Who Viewed Me',
    'type' => 'widget',
    'name' => 'viewed.whoviewedme',
    'requirements' => array(
      'no-subject',
    ),
  ),
) ?>