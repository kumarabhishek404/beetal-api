<?php

class Checkin_Bootstrap extends Engine_Application_Bootstrap_Abstract
{
    public function __construct($application)
    {
        $view = Zend_Registry::get('Zend_View');
        parent::__construct($application);
        $this->initViewHelperPath();
        $isEventEnabled = Engine_Api::_()->getDbTable('modules', 'core')->isModuleEnabled('heevent');
        if (!$isEventEnabled) {
            $view = Zend_Registry::get('Zend_View');
            $http_protocol = (_ENGINE_SSL ? 'https://' : 'http://');
            $settings = Engine_Api::_()->getApi('settings', 'core');
            $key = trim($settings->getSetting('checkin.google_map_key', ''));
            $view->headScript()
                ->appendFile($http_protocol . 'maps.googleapis.com/maps/api/js?sensor=false&key='.$key.'&libraries=places');
        }

        $view->headTranslate(array(
            'go to post'
        ));
    }
}