
INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES
('checkin', 'Checkin', 'Checkin', '4.1.5p5', 1, 'extra') ;