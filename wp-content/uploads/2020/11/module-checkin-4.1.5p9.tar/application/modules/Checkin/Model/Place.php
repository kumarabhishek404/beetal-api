<?php
/***/
class Checkin_Model_Place extends Core_Model_Item_Abstract
{
  
}