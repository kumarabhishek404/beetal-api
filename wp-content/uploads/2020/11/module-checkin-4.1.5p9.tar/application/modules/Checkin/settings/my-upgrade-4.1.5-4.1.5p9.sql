--
-- Update module Checkin
--

UPDATE `engine4_core_modules` SET `version` = '4.1.5p8'  WHERE `name` = 'checkin';