--
-- Update module Checkin
--

UPDATE `engine4_core_modules` SET `version` = '4.1.4p2'  WHERE `name` = 'checkin';