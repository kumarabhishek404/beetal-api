<?php
  /**
   * SocialEngine
   *
   * @category   Application_Core
   * @package    Pagealbum
   * @version    $Id: changelog.php 9689 2012-04-19 00:22:35Z Ulan T $
   * @author     Ulan T
   */
return array(
  '4.1.6' => array(
    'externals/scripts/jquery-1.4.2.min.js' => 'Removed',
    'externals/scripts/jquery-1.6.2.min.js' => 'Removed',
  )
);