INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES  
('pagealbum', 'Page Album', 'Page Album', '4.2.2', 1, 'extra');