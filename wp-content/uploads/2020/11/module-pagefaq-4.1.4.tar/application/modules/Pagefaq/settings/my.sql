INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES
('pagefaq', 'Page FAQ', 'Page FAQ', '4.1.4', 1, 'extra') ;