<?php
/**
 * @author Vadim
 * @copyright Hire-Experts LLC
 * @version Layouts 1.01
 */

$plugin_name = "Layouts Plugin";
$plugin_version = "1.01";
$req_core_version = "3.01";
$plugin_type = "he_layout";
$plugin_desc = "Layouts allows you easily change look of your site. Please go to <a href=\"http://www.hire-experts.com/\">Hire-Experts.com</a> to get this plugin latest version.";
$plugin_icon = "he_layouts16.gif";
$plugin_menu_title = "";
$plugin_pages_main = "690697001<!>he_layouts16.gif<!>admin_he_layout.php<~!~>";
$plugin_pages_level = "";
$plugin_url_htaccess = "";
$plugin_db_charset = 'utf8';
$plugin_db_collation = 'utf8_unicode_ci';


if($install == "he_layout") {

	//check core library
	$sql = "SELECT `plugin_version` FROM `se_plugins` WHERE plugin_type='he_core' AND `plugin_disabled`=0 LIMIT 1";
	$resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
	$core_version = $database->database_fetch_array($resource);
	if ( floatval($core_version[0]) < floatval($req_core_version) ) {
		die ('This plugin requires Hire-Experts Core Library. Please install latest version of Hire-Experts Core Library plugin. You can download it from My Plugins section in Hire-Experts.com for FREE.');
	}

	//check if plugin was already installed
	$sql = "SELECT * FROM se_plugins WHERE plugin_type='$plugin_type' LIMIT 1";
	$resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
	
	$plugin_info = array();
	if( $database->database_num_rows($resource) )
		$plugin_info = $database->database_fetch_assoc($resource);
	
	
	//install plugin
	if( !$plugin_info ) {
		$database->database_query("INSERT INTO se_plugins (plugin_name,
			plugin_version,
			plugin_type,
			plugin_desc,
			plugin_icon,
			plugin_menu_title,
			plugin_pages_main,
			plugin_pages_level,
			plugin_url_htaccess
			) VALUES (
			'$plugin_name',
			'$plugin_version',
			'$plugin_type',
			'".str_replace("'", "\'", $plugin_desc)."',
			'$plugin_icon',
			'',
			'$plugin_pages_main',
			'',
			'$plugin_url_htaccess')");
	
	
	//update plugin
	} else {
		$database->database_query("UPDATE se_plugins SET plugin_name='$plugin_name',
			plugin_version='$plugin_version',
			plugin_desc='".str_replace("'", "\'", $plugin_desc)."',
			plugin_icon='$plugin_icon',
			plugin_menu_title='',
			plugin_pages_main='$plugin_pages_main',
			plugin_pages_level='',
			plugin_url_htaccess='$plugin_url_htaccess' WHERE plugin_type='$plugin_type'");
	}
	
	$database->database_query("CREATE TABLE IF NOT EXISTS `se_he_layouts` (
  `id` tinyint(6) NOT NULL AUTO_INCREMENT,
  `name` tinytext NOT NULL,
  `style` text NOT NULL,
  `descr` tinytext NOT NULL,
  `active` tinyint(1) NOT NULL default '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;");
	
	$database->database_query("INSERT INTO `se_he_layouts` VALUES(NULL, 'Standard', '', 'Use a standard layout', 1)");


	$database->database_query("INSERT INTO `se_he_layouts` VALUES(NULL, 'colorset_blue', '

#TB_closeAjaxWindow { padding:6px 5px 0 0; }

div.autosuggest div.as_header,
div.autosuggest div.as_footer,
div.autosuggest div.as_header div.as_corner,
div.autosuggest div.as_footer div.as_corner { background-image: url(./he_layouts/colorset_blue/ul_corner.gif); }

div.autosuggest ul li { color: #fff; font-size: 1.2em; }
div.autosuggest ul li a { color: #fff; }
div.autosuggest ul em { text-decoration: underline; }


#eego { background-color: transparent; border: solid 0px;cursor:pointer;padding:0px;margin:0px;height:37px;width:37px }




/* global */

body {
	background: #fff ; /*  url(./he_layouts/colorset_blue/bg.png) repeat-x */
	font-family: arial, verdana, serif;
}

a:link, a:visited { color:#326bdf; outline:none; text-decoration:underline; }				/* Removes ugly firefox dotted borders*/
a:hover { color:#136cff; outline:none; text-decoration:none; }

ul { list-style-image:url(./he_layouts/colorset_blue/ul.gif); }

.body {
	background: #fbfdff !important;
	border: solid 1px #97c9f0;
	width: 900px;
	background: #fff;
	padding:0 10px 10px;
	margin: 0 auto 0;
	border-top: 0px;
}

div, td {
	font-family: arial, serif;
	color:#005999;
}




/* HEADER */

td.top_menu {
	background: url(./he_layouts/colorset_blue/ee.png) repeat-x 0% 75%;
	border:none;
	border-top:1px solid #306599;
}

div.top_menu_link { padding:6px 4px 0; }
div.top_menu_link_container, div.top_menu_link_container_end { border-left: 1px solid #306599; }
div.top_menu_link_container_end { background: url(./he_layouts/colorset_blue/ee.png) no-repeat 0% 100%; padding:0 1px 0 0; border-left: none; }

.top_menu_item { padding:7px 10px 5px; }
.top_menu_item:hover { background: url(./he_layouts/colorset_blue/ee.png) repeat-x 0% 48%; }
.top_menu_link_container:hover { background: url(./he_layouts/colorset_blue/ee.png) repeat-x 0% 50%; }

a.top_menu_item:link, a.top_menu_item:visited, a.top_menu_item:hover { color: #fff; text-decoration: none; }


td.top_menu2 {
	width: 20%; 
	text-align: right; 
	background: url(./he_layouts/colorset_blue/ee.png) repeat-x 0% 75%;
	border:none;
	border-top:1px solid #306599;
	border-right:1px solid #306599;
}

div.top_menu_link_loggedin {
	height: auto;
	padding: 0;
	color:#e1ecf5;
}



td.menu_user {
	background:#e4f2ff url(./he_layouts/colorset_blue/menu_user.png);
	border:#3e71a4 solid 1px;
	border-top:none;
}

a.menu_item:link, a.menu_item:visited { color: #427eb6; text-decoration: none; }
a.menu_item:hover { color: #529de3; text-decoration: none; }

div.menu_dropdown { border-color:#3e71a4; }
div.menu_item_dropdown a { background:#f2f9ff; border-color:#3e71a4; }
div.menu_item_dropdown a:hover { background:#e4f2ff; border-color:#97c9f0; }








/* FOOTER */

div.copyright  {
	background: url(./he_layouts/colorset_blue/ee.png) repeat-x 0% 75%;
	text-align: center; 
	color: #fff;
	font-weight:bold;
	border-top:none;
}
a.copyright:link, a.copyright:visited { color: #fff; text-decoration: none; }
a.copyright:hover { color: #fff; text-decoration: underline; }



/* CONTENT */

div.page_header { font-family: arial, serif; color:#006bc6; }

div.home_whatsnew { background:#fff; border-color:#b0d1eb; }

div.friends_search { border-color:#3e71a4; }

div.newupdates { background-image: url(./he_layouts/colorset_blue/newupdates.png); }



td.tabs {  }
td.tab, td.tab0, td.tab2, td.tab3 { background: transparent; border-color:#97c9f0; }

td.tab2 { background:#f1faff; }
td.tab2 a:link, td.tab2 a:visited  { color:#64a0dd; text-decoration:none; }
td.tab2 a:hover { color:#369; }

td.tab1 { background:#fbfdff; border-color:#3e71a4; }
td.tab1 a:link, td.tab1 a:visited, td.tab1 a:hover { color:#369; text-decoration:none; }


td.button, .recommended_tools a:link, .recommended_tools a:visited { background:#fbfdff; border-color:#3e71a4; }

td.result { border-color:#97c9f0; background:#f2f9ff; }



div.signup_header {
	background:url(./he_layouts/colorset_blue/ee.png) repeat-x 0% 50%;
	color: #fff;
}


td.messages_header {
	background: url(./he_layouts/colorset_blue/ee.png) repeat-x top;
}





/* SIDEBAR BLOCKS */

td.header, div.header {
	border:none;
	background: url(./he_layouts/colorset_blue/ee.png) repeat-x 0% 75%;
	color: #fff;
	text-align:center;
	font-size:1.2em;
}

td.home_box, div.home_updated { border-color:#3e71a4; }






/* inputs */

input.button {
	background:url(./he_layouts/colorset_blue/ee.png) repeat-x 0% 50%;
	font-size: 1.2em;
	color: #fff;
	border-color: #0280e1;
}
*:first-child+html input.button { padding: 0px -2px; } /* IE7 only padding fix */

input.button:hover { background:url(./he_layouts/colorset_blue/ee.png) repeat-x 0% 75%; border-color: #002e4b; }
input.button:active { background:url(./he_layouts/colorset_blue/ee.png) repeat-x 0% 100%; }

input.text, input.text_small, select, select.small, select.event_small, textarea, textarea.comment_area {
	border:1px solid #b0d1eb;
	color:#427eb6;
}





/* profile  */

.profile_content { background:#fff !important; border-color:#97c9f0 !important; }


td.profile_tab a:link, td.profile_tab a:visited { color:#64a0dd; background:#f1faff; border-color:#97c9f0; text-decoration:none; }
td.profile_tab a:hover { color:#369; background:#f9feff; }
td.profile_tab2 a:link, td.profile_tab2 a:visited, td.profile_tab2 a:hover { color:#369; background:#fff; border-color:#97c9f0; text-decoration:none; }


td.profile_tab1 { background:#fbfdff; border-color:#3e71a4; }
td.profile_tab_end { background:#fbfdff; border-color:#97c9f0; }

table.profile_menu { border-color:#3E71A4; }
td.profile_menu1 a, div.nolink {
	background-color:#fff;
	background-image:url(../images/menu_bg1.gif);
	border-bottom:1px solid #3E71A4;
	text-decoration:none;
}
td.profile_menu1 a:hover {  }



td.profile_photo {
	background:#fff;
	border-color:#3e71a4;
}
img.photo, td.editprofile_photo { border-color:#97c9f0; }

td.profile, div.network_content { border-color:#3e71a4; }

div.profile_postcomment { background:#eff7ff; border-color:#97c9f0; }


div.profile_action { border-bottom:1px solid #d1e7f0; }
div.profile_action_date { color:#5b85f0; }



div.comment_headline {
	border-bottom: none !important;
	background: url(./he_layouts/colorset_blue/ee.png) repeat-x 0% 75% !important;
	color:#fff !important;
	padding-left:14px !important;
}

#profile_1_totalcomments { color:#fff }
div.profile_comment_author, div.profile_comment_date, #profile_tabs_profile { background:#f1faff; border-color:#97c9f0; }

div.profile_blogentry, div.recommended_stat {
	border-color:#d1e7f0;
}



/* HOME */

div.portal_signup_container1 { border-color:#3e71a4; }
div.portal_signup_container1:hover { border-color:#4f85f4; }

div.portal_signup a.portal_signup, div.portal_signup a.portal_signup:hover {
	background: url(./he_layouts/colorset_blue/ee.png) repeat-x 0% 75%;
	border: none;
	color:#fff;
	text-decoration:none;
}
div.portal_signup a:hover { background: url(./he_layouts/colorset_blue/ee.png) repeat-x 0% 50%; }


a.portal_signup:link, a.portal_signup:visited { color: #336699; text-decoration: none; }
a.portal_signup:hover { color: #437ab1; text-decoration: none; }



div.portal_spacer { height: 10px; }

div.portal_content { border: 1px solid #3e71a4; }

td.portal_text { vertical-align: top; padding: 10px 20px 10px 10px; }
table.portal_table { margin-bottom: 10px; }



div.portal_whatsnew {
	border: 1px solid #b0d1eb;
	padding: 4px 10px 4px 10px;
}
div.portal_action { border-top:1px solid #d1e7f0; }
div.portal_action_date { color:#5b85f0; }
div.portal_action_top { padding: 6px 6px 6px 6px; }



div.portal_login { border: 1px solid #b0d1eb; }
td.portal_member {  }



/* plugins */

div.poll, div.polls_browse_item, div.browse_fields, div.poll_search, div.album, td.seBlogColumnRight, div.media, td.carousel_item_active, td.carousel_item:hover {
	background:#f1faff;
	border:1px solid #b0d1eb;
}
div.poll_stats, div.album_stats, div.blogs_browse_date, div.seBlogEntryDate, div.album_media_date { color:#003eaf; }
div.poll_title, td.poll_view, div.album_title { color:#336be6; border-color:#b0d1eb; }
div.poll_options, div.album_options, div.album_options2, div.album_photo, div.blogs_browse_item, div.seBlogEntry { border-color:#b0d1eb; }
div.poll_view_title { background:#e0f4ff; }


div.blog_list, div.blog_list2 { border-color:#b0d1eb; }
div.blog_list1 { border-color:#b0d1eb; background:#f1faff; }
div.blog_list1 div, div.blog_list2 div { color:#003eaf !important; }

div.blogs_browse1 { background:#f1faff; }
div.blogs_browse_item {  }


div.poll_headline {
	border-bottom: none !important;
	background: url(./he_layouts/colorset_blue/ee.png) repeat-x 0% 75% !important;
	color:#fff !important;
	padding-left:14px !important;
}
.totalcomments { color:#fff }
div.poll_view_stats { color:#336be6; }


div.seEvent, div.event_members_result { color:#336be6; border-color:#b0d1eb; background:#f1faff; }
div.seEventTitle, div.seEventOptions, div.seEventPhoto { border-color:#b0d1eb; }
div.seEventStats, div.profile_friend_details div { color:#003eaf; }
div.seEventBody { color:#005999; }

td.event_tab_left a:link, td.event_tab_left a:visited, td.event_tab a:link, td.event_tab a:visited { color:#64a0dd; text-decoration:none; background:#f1faff; border-color:#97c9f0; }
td.event_tab_left a:hover, td.event_tab a:hover { color:#369; background:#f9feff; border-color:#97c9f0; }

td.event_tab_active a:link, td.event_tab_active a:visited { color:#369; text-decoration:none; background:#fff; border-color:#97c9f0; border-bottom:none; margin-bottom:1px; }
td.event_tab_active a:hover { color:#39f; }

', 'Blue-colored theme', 0)");


	$database->database_query("INSERT INTO `se_he_layouts` VALUES(NULL, 'colorset_green', '

#TB_closeAjaxWindow { padding:6px 5px 0 0; }

div.autosuggest div.as_header,
div.autosuggest div.as_footer,
div.autosuggest div.as_header div.as_corner,
div.autosuggest div.as_footer div.as_corner { background-image: url(./he_layouts/colorset_green/ul_corner.gif); }

div.autosuggest ul li { color: #fff; font-size: 1.2em; }
div.autosuggest ul li a { color: #fff; }
div.autosuggest ul em { text-decoration: underline; }


#eego { background-color: transparent; border: solid 0px;cursor:pointer;padding:0px;margin:0px;height:37px;width:37px }




/* global */

body {
	background: #fdfffa; /*  url(./he_layouts/colorset_green/bg.png) repeat-x */
	font-family: arial, verdana, serif;
}

a:link, a:visited { color:#328418; outline:none; text-decoration:underline; }				/* Removes ugly firefox dotted borders*/
a:hover { color:#6fb64c; outline:none; text-decoration:none; }

ul { list-style-image:url(./he_layouts/colorset_green/ul.gif); }

.body {
	background: url(./he_layouts/colorset_green/header.png) top no-repeat #fdfffa !important;
	border: none;
	width: 900px;
	padding:50px 10px 10px;
	margin: 0 auto 0;
	border-top: 0px;
	padding-top:0;
}

div, td {
	font-family: arial, serif;
	color:#207804;
}




/* HEADER */

td.top_menu {
	background: url(./he_layouts/colorset_green/block_top.png) repeat-x 0% 75%;
	border:none;
	border-top:1px solid #186a10;
}

div.top_menu_link { padding:6px 4px 0; }
div.top_menu_link_container, div.top_menu_link_container_end { border-left: 1px solid #186a10; }
div.top_menu_link_container_end { padding:0 1px 0 0; }

.top_menu_item { padding:7px 10px 5px; }
.top_menu_item:hover { background: url(./he_layouts/colorset_green/block_top.png) repeat-x 0% 48%; }
.top_menu_link_container:hover { background: url(./he_layouts/colorset_green/block_top.png) repeat-x 0% 50%; }

a.top_menu_item:link, a.top_menu_item:visited, a.top_menu_item:hover { color: #fff; text-decoration: none; }



td.top_menu2 {
	width: 20%; 
	text-align: right; 
	background: url(./he_layouts/colorset_green/block_top.png) repeat-x 0% 75%;
	border:none;
	border-top:1px solid #186a10;
	border-right:1px solid #186a10;
}

div.top_menu_link_loggedin {
	height: auto;
	padding: 0;
	color:#f5ffe4;
}



td.menu_user {
	background:#f2ffdb url(./he_layouts/colorset_green/menu_user.png);
	border:#186a10 solid 1px;
	border-top:none;
}

a.menu_item:link, a.menu_item:visited { color: #398535; text-decoration: none; }
a.menu_item:hover { color: #67be4c; text-decoration: none; }

div.menu_dropdown { border-color:#046804; }
div.menu_item_dropdown a { background:#f2ffdb; border-color:#046804; }
div.menu_item_dropdown a:hover { background:#dfffbc; border-color:#53bf30; }








/* FOOTER */

div.copyright  {
	background: url(./he_layouts/colorset_green/block_top.png) repeat-x 0% 75%;
	text-align: center; 
	color: #fff;
	font-weight:bold;
	border-top:none;
}
a.copyright:link { color: #fff; text-decoration: none; }
a.copyright:visited { color: #fff; text-decoration: none; }
a.copyright:hover { color: #fff; text-decoration: underline; }



/* CONTENT */

div.content { padding-top:18px }


div.page_header { font-family: arial, serif; color:#009d32; padding-left:10px; }

div.home_whatsnew { background:#fff; border-color:#3ea253; }

div.friends_search { border-color:#3ea253; }

div.newupdates { background-image: url(./he_layouts/colorset_green/newupdates.png); }



td.tabs {  }
td.tab, td.tab0, td.tab2, td.tab3 { background: transparent; border-color:#71b74b; }

td.tab2 { background:#eeffda; }
td.tab2 a:link, td.tab2 a:visited  { color:#5a9f34; text-decoration:none; }
td.tab2 a:hover { color:#3eb216; }

td.tab1 { background:#fdfffa; border-color:#3b8500; }
td.tab1 a:link, td.tab1 a:visited, td.tab1 a:hover { color:#52923e; text-decoration:none; }
td.tab1 a:hover { color:#75d23c; text-decoration:none; }


td.button, .recommended_tools a:link, .recommended_tools a:visited { background:#fff; border-color:#3b8500; }

td.result { border-color:#3b8500; background:#f9fff5; }



div.signup_header {
	background:url(./he_layouts/colorset_green/block_top.png) repeat-x 0% 50%;
	color: #fff;
}


td.messages_header {
	background: url(./he_layouts/colorset_green/block_top.png) repeat-x top;
}





/* SIDEBAR BLOCKS */

td.header, div.header {
	border:none;
	background: url(./he_layouts/colorset_green/block_top.png) repeat-x 0% 75%;
	color: #fff;
	text-align:center;
	font-size:1.2em;
}

td.home_box, div.home_updated { border-color:#3ea253; }




















/* inputs */

input.button {
	background:url(./he_layouts/colorset_green/block_top.png) repeat-x 0% 50%;
	font-size: 1.2em;
	color: #fff;
	border-color: #3ea253;
}
*:first-child+html input.button { padding: 0px -2px; } /* IE7 only padding fix */

input.button:hover { background:url(./he_layouts/colorset_green/block_top.png) repeat-x 0% 75%; border-color: #3ea253; }
input.button:active { background:url(./he_layouts/colorset_green/block_top.png) repeat-x 0% 100%; }

input.text, input.text_small, select, select.small, select.event_small, textarea, textarea.comment_area {
	border:1px solid #7fdb83;
	color:#3ea253;
}






/* profile  */

.profile_content { background:#fff !important; border-color:#71b74b !important; }


td.profile_tab a:link, td.profile_tab a:visited { color:#5ec273; background:#f2ffe7; border-color:#71b74b; text-decoration:none; }
td.profile_tab a:hover { color:#3ea253; background:#f2ffe7; }
td.profile_tab2 a:link, td.profile_tab2 a:visited, td.profile_tab2 a:hover { color:#3ea253; background:#fff; border-color:#71b74b; text-decoration:none; }
td.profile_tab2 a:hover { color:#2e6223; background:#fff; border-color:#71b74b; text-decoration:none; }

td.profile_tab1 { background:#f9ffee; border-color:#71b74b; }
td.profile_tab_end { border-color:#71b74b; }

table.profile_menu { border-color:#461; }
td.profile_menu1 a, div.nolink {
	background-color:#fff;
	background-image:url(../images/menu_bg1.gif);
	border-bottom:1px solid #461;
	text-decoration:none;
}
td.profile_menu1 a:hover {  }


td.profile_photo {
	background:#fff;
	border-color:#71b74b;
}
img.photo, td.editprofile_photo { border-color:#c6ea9a; }

td.profile, div.network_content { border-color:#71b74b; }

div.profile_postcomment { background:transparent; border:none; }


div.profile_action { border-bottom:1px solid #c0f092; }
div.profile_action_date { color:#71b224; }



div.comment_headline {
	border-bottom: none !important;
	background: url(./he_layouts/colorset_green/block_top.png) repeat-x 0% 75% !important;
	color:#fff !important;
	padding-left:14px !important;
}

#profile_1_totalcomments { color:#fff }
div.profile_comment_author, div.profile_comment_date, #profile_tabs_profile { background:#e4ffd6; border-color:#86d94f; }

div.profile_blogentry, div.recommended_stat {
	border-color:#c0f092;
}






/* HOME */

div.portal_signup_container1 { border-color:#461; }
div.portal_signup_container1:hover { border-color:#6a3; }

div.portal_signup a.portal_signup, div.portal_signup a.portal_signup:hover {
	background: url(./he_layouts/colorset_green/block_top.png) repeat-x 0% 75%;
	border: none;
	color:#fff;
	text-decoration:none;
}
div.portal_signup a:hover { background: url(./he_layouts/colorset_green/block_top.png) repeat-x 0% 50%; }


a.portal_signup:link, a.portal_signup:visited { color: #669933; text-decoration: none; }
a.portal_signup:hover { color: #7a43b1; text-decoration: none; }



div.portal_spacer { height: 10px; }

div.portal_content { border: 1px solid #71b74b; }

td.portal_text { vertical-align: top; padding: 10px 20px 10px 10px; }
table.portal_table { margin-bottom: 10px; }



div.portal_whatsnew {
	background:#fff;
	border: 1px solid #3ea253;
	padding: 4px 10px 4px 10px;
}
div.portal_action { border-top:1px solid #c0f092; }
div.portal_action_date { color:#71b224; }
div.portal_action_top { padding: 6px 6px 6px 6px; }


div.portal_login { border: 1px solid #6a3; }
td.portal_member {  }





/* plugins */

div.poll, div.polls_browse_item, div.browse_fields, div.poll_search, div.album, td.seBlogColumnRight, div.media, td.carousel_item_active, td.carousel_item:hover {
	background:#eeffda;
	border:1px solid #7fdb83;
}
div.poll_stats, div.album_stats, div.blogs_browse_date, div.seBlogEntryDate, div.album_media_date { color:#84af00; }
div.poll_title, td.poll_view, div.album_title { color:#a6e635; border-color:#3ea253; }
div.poll_options, div.album_options, div.album_options2, div.album_photo, div.blogs_browse_item, div.seBlogEntry { border-color:#3ea253; }
div.poll_view_title { background:#f4ffe0; }


div.blog_list, div.blog_list2 { border-color:#3ea253; }
div.blog_list1 { border-color:#3ea253; background:#eeffda; }
div.blog_list1 div, div.blog_list2 div { color:#84af00 !important; }

div.blogs_browse1 { background:#eeffda; }
div.blogs_browse_item {  }


div.poll_headline {
	border-bottom: none !important;
	background: url(./he_layouts/colorset_blue/ee.png) repeat-x 0% 75% !important;
	color:#fff !important;
	padding-left:14px !important;
}
.totalcomments { color:#fff }
div.poll_view_stats { color:#a6e635; }


div.seEvent, div.event_members_result { color:#a6e635; border-color:#3ea253; background:#fafff1; }
div.seEventTitle, div.seEventOptions, div.seEventPhoto { border-color:#3ea253; }
div.seEventStats, div.profile_friend_details div { color:#84af00; }
div.seEventBody { color:#207804; }

td.event_tab_left a:link, td.event_tab_left a:visited, td.event_tab a:link, td.event_tab a:visited { color:#71b74b; text-decoration:none; background:#f2ffe7; border-color:#71b74b; }
td.event_tab_left a:hover, td.event_tab a:hover { color:#369; background:#f9feff; border-color:#97c9f0; }

td.event_tab_active a:link, td.event_tab_active a:visited { color:#693; text-decoration:none; background:#fff; border-color:#71b74b; border-bottom:none; margin-bottom:1px; }
td.event_tab_active a:hover { color:#7dd12a; }

', 'Green-colored theme', 0)");


	$database->database_query("INSERT INTO `se_he_layouts` VALUES(NULL, 'colorset_pink', '

#TB_closeAjaxWindow { padding:6px 5px 0 0; }

div.autosuggest div.as_header,
div.autosuggest div.as_footer,
div.autosuggest div.as_header div.as_corner,
div.autosuggest div.as_footer div.as_corner { background-image: url(./he_layouts/colorset_pink/ul_corner.gif); }

div.autosuggest ul li { color: #fff; font-size: 1.2em; }
div.autosuggest ul li a { color: #fff; }
div.autosuggest ul em { text-decoration: underline; }


#eego { background-color: transparent; border: solid 0px;cursor:pointer;padding:0px;margin:0px;height:37px;width:37px }




/* global */

body {
	background: #fff ; /*  url(./he_layouts/colorset_pink/bg.png) repeat-x */
	font-family: arial, verdana, serif;
}

a:link, a:visited { color:#5a46f0; outline:none; }				/* Removes ugly firefox dotted borders*/
a:hover { color:#8a00ff; outline:none; }

ul { list-style-image:url(./he_layouts/colorset_pink/ul.gif); }

.body {
	background: #fff !important;
	border: none;
	width: 900px;
	padding:0 10px 10px;
	margin: 0 auto 0;
	border-top: 0px;
}

div, td {
	font-family: arial, serif;
	color:#41004a;
}




/* HEADER */

td.top_menu {
	background: url(./he_layouts/colorset_pink/block_top.png) repeat-x 0% 75%;
	border:none;
	border-top:1px solid #8a4689;
}

div.top_menu_link { padding:6px 4px 0; }
div.top_menu_link_container, div.top_menu_link_container_end { border-left: 1px solid #8a4689; }
div.top_menu_link_container_end {  }

.top_menu_item { padding:7px 10px 5px; }
.top_menu_item:hover { background: url(./he_layouts/colorset_pink/block_top.png) repeat-x 0% 48%; }
.top_menu_link_container:hover { background: url(./he_layouts/colorset_pink/block_top.png) repeat-x 0% 50%; }

a.top_menu_item:link, a.top_menu_item:visited, a.top_menu_item:hover { color: #fff; text-decoration: none; }


td.top_menu2 {
	width: 20%; 
	text-align: right; 
	background: url(./he_layouts/colorset_pink/block_top.png) repeat-x 0% 75%;
	border:none;
	border-top:1px solid #8a4689;
	border-right:1px solid #8a4689;
}

div.top_menu_link_loggedin {
	height: auto;
	padding: 0;
	color:#faecff;
}



td.menu_user {
	background:#f8f2ff url(./he_layouts/colorset_pink/menu_user.png);
	border:#b86bb0 solid 1px;
	border-top:none;
}

a.menu_item:link, a.menu_item:visited { color:#600058; text-decoration:none; }
a.menu_item:hover { color:#c200b2; text-decoration:none; }

div.menu_dropdown { border-color:#b86bb0; }
div.menu_item_dropdown a { background:#f8f2ff; border-color:#b86bb0; }
div.menu_item_dropdown a:hover { background:#f7e4ff; border-color:#e68ce3; }








/* FOOTER */

div.copyright  {
	background: url(./he_layouts/colorset_pink/block_top.png) repeat-x 0% 75%;
	text-align: center; 
	color: #fff;
	font-weight:bold;
	border-top:none;
}
a.copyright:link, a.copyright:visited { color: #fff; text-decoration: none; }
a.copyright:hover { color: #fff; text-decoration: underline; }



/* CONTENT */

div.page_header { font-family: arial, serif; color:#880d87; }

div.home_whatsnew { border-color:#e3ace6; }

div.friends_search { border-color:#e3ace6; }

div.newupdates { background-image: url(./he_layouts/colorset_pink/newupdates.png); }



td.tabs {  }
td.tab, td.tab0, td.tab2, td.tab3 { background: transparent; border-color:#e3ace6; }

td.tab2 { background:#fcf3ff; }
td.tab2 a:link, td.tab2 a:visited  { color:#c200b2; text-decoration:none; }
td.tab2 a:hover { color:#600058; }

td.tab1 { background:#fff; border-color:#b86bb0; }
td.tab1 a:link, td.tab1 a:visited, td.tab1 a:hover { color:#600058; text-decoration:none; }


td.button, .recommended_tools a:link, .recommended_tools a:visited { background:#fcfaff; border-color:#b86bb0; }

td.result { border-color:#e3ace6; background:#fcfaff; }



div.signup_header {
	background:url(./he_layouts/colorset_pink/block_top.png) repeat-x 0% 50%;
	color: #fff;
}


td.messages_header {
	background: url(./he_layouts/colorset_pink/block_top.png) repeat-x top;
}





/* SIDEBAR BLOCKS */

td.header, div.header {
	border:none;
	background: url(./he_layouts/colorset_pink/block_top.png) repeat-x 0% 75%;
	color: #fff;
	text-align:center;
	font-size:1.2em;
}

td.home_box, div.home_updated { border-color:#b86bb0; }






/* inputs */

input.button {
	background:url(./he_layouts/colorset_pink/block_top.png) repeat-x 0% 50%;
	font-size: 1.2em;
	color: #fff;
	border-color: #784ac5;
}
*:first-child+html input.button { padding: 0px -2px; } /* IE7 only padding fix */

input.button:hover { background:url(./he_layouts/colorset_pink/block_top.png) repeat-x 0% 75%; border-color: #3a004b; }
input.button:active { background:url(./he_layouts/colorset_pink/block_top.png) repeat-x 0% 100%; }

input.text, input.text_small, select, select.small, select.event_small, textarea, textarea.comment_area {
	border:1px solid #e3ace6;
	color:#7f45b6;
}





/* profile  */

.profile_content { background:#fff !important; border-color:#e3ace6 !important; }


td.profile_tab a:link, td.profile_tab a:visited { color:#b056c0; background:#fcf3ff; border-color:#e3ace6; text-decoration:none; }
td.profile_tab a:hover { color:#600058; background:#fdfaff; }
td.profile_tab2 a:link, td.profile_tab2 a:visited, td.profile_tab2 a:hover { color:#600058; background:#fff; border-color:#e3ace6; text-decoration:none; }

td.profile_tab1 { background:#fbfdff; border-color:#b86bb0; }
td.profile_tab_end { background:#fbfdff; border-color:#e3ace6; }

table.profile_menu { border-color:#b86bb0; }
td.profile_menu1 a, div.nolink {
	background-color:#fff;
	background-image:url(../images/menu_bg1.gif);
	border-bottom:1px solid #b86bb0;
	text-decoration:none;
}
td.profile_menu1 a:hover { background-color:#f8f2ff; }


td.profile_photo {
	background:#fff;
	border-color:#b86bb0;
}

td.profile, div.network_content { border-color:#b86bb0; }

div.profile_postcomment { background:#fff8ff; border-color:#e3ace6; }
img.photo, td.editprofile_photo { border-color:#e3ace6; }


div.profile_action { border-bottom:1px solid #e4d5f0; }
div.profile_action_date { color:#880d87; }



div.comment_headline {
	border-bottom: none !important;
	background: url(./he_layouts/colorset_pink/block_top.png) repeat-x 0% 75% !important;
	color:#fff !important;
	padding-left:14px !important;
}

#profile_1_totalcomments { color:#fff }
div.profile_comment_author, div.profile_comment_date, #profile_tabs_profile { background:#fff8ff; border-color:#e3ace6; }

div.profile_blogentry, div.recommended_stat {
	border-color:#e9d4f4;
}



/* HOME */

div.portal_signup_container1 { border-color:#b86bb0; }
div.portal_signup_container1:hover { border-color:#f28de7; }

div.portal_signup a.portal_signup, div.portal_signup a.portal_signup:hover {
	background: url(./he_layouts/colorset_pink/block_top.png) repeat-x 0% 75%;
	border: none;
	color:#fff;
	text-decoration:none;
}
div.portal_signup a:hover { background: url(./he_layouts/colorset_pink/block_top.png) repeat-x 0% 50%; }


a.portal_signup:link, a.portal_signup:visited { color: #993799; text-decoration: none; }
a.portal_signup:hover { color: #7e3ac5; text-decoration: none; }



div.portal_spacer { height: 10px; }

div.portal_content { border: 1px solid #b86bb0; }

td.portal_text {
	vertical-align: top; 
	padding: 10px 20px 10px 10px;
}
table.portal_table {
	margin-bottom: 10px;
}



div.portal_whatsnew {
	border: 1px solid #e3ace6;
	padding: 4px 10px 4px 10px;
}
div.portal_action { border-top:1px solid #e4d5f0; }
div.portal_action_date { color:#880d87; }
div.portal_action_top { padding: 6px 6px 6px 6px; }

div.portal_login { border: 1px solid #e3ace6; }
td.portal_member {  }



/* plugins */

div.poll, div.polls_browse_item, div.browse_fields, div.poll_search, div.album, td.seBlogColumnRight, div.media, td.carousel_item_active, td.carousel_item:hover {
	background:#fcf3ff;
	border:1px solid #e3ace6;
}
div.poll_stats, div.album_stats, div.blogs_browse_date, div.seBlogEntryDate, div.album_media_date { color:#7300af; }
div.poll_title, td.poll_view, div.album_title { color:#8b33e6; border-color:#e3ace6; }
div.poll_options, div.album_options, div.album_options2, div.album_photo, div.blogs_browse_item, div.seBlogEntry { border-color:#e3ace6; }
div.poll_view_title { background:#f1e2ff; }


div.blog_list, div.blog_list2 { border-color:#e3ace6; }
div.blog_list1 { border-color:#e3ace6; background:#fcf3ff; }
div.blog_list1 div, div.blog_list2 div { color:#7300af !important; }

div.blogs_browse1 { background:#fcf3ff; }
div.blogs_browse_item {  }


div.poll_headline {
	border-bottom: none !important;
	background: url(./he_layouts/colorset_pink/block_top.png) repeat-x 0% 75% !important;
	color:#fff !important;
	padding-left:14px !important;
}
.totalcomments { color:#fff }
div.poll_view_stats { color:#8b33e6; }


div.seEvent, div.event_members_result { color:#8b33e6; border-color:#e3ace6; background:#fcf3ff; }
div.seEventTitle, div.seEventOptions, div.seEventPhoto { border-color:#e3ace6; }
div.seEventStats, div.profile_friend_details div { color:#7300af; }
div.seEventBody { color:#005999; }

td.event_tab_left a:link, td.event_tab_left a:visited, td.event_tab a:link, td.event_tab a:visited { color:#e3ace6; text-decoration:none; background:#fcf3ff; border-color:#e68ce3; }
td.event_tab_left a:hover, td.event_tab a:hover { color:#969; background:#f9feff; border-color:#e68ce3; }

td.event_tab_active a:link, td.event_tab_active a:visited { color:#969; text-decoration:none; background:#fff; border-color:#e68ce3; border-bottom:none; margin-bottom:1px; }
td.event_tab_active a:hover { color:#f9f; }

', 'Pink-colored theme', 0)");
	



	//insert langs
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697001 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697001', '1', 'Layouts', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Layouts', languagevar_default='he_layouts' WHERE languagevar_id='690697001' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697002 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697002', '1', 'Layouts allows you easily change look of your site. Just choose wished layout from the list below. You can edit/delete layouts, import new layouts from Get New Layout section. We constantly develop new layouts so please tune in. Also you can create a new layout by yourself: put css code into textarea, type name which will be used as a layout folder name and Icon which will be used as preview icon.', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Layouts allows you easily change look of your site. Just choose wished layout from the list below. You can edit/delete layouts, import new layouts from Get New Layout section. We constantly develop new layouts so please tune in. Also you can create a new layout by yourself: put css code into textarea, type name which will be used as a layout folder name and Icon which will be used as preview icon.', languagevar_default='he_layouts' WHERE languagevar_id='690697002' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697003 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697003', '1', 'Layouts Managment', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Layouts Managment', languagevar_default='he_layouts' WHERE languagevar_id='690697003' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697004 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697004', '1', 'Get New Layouts', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Get New Layouts', languagevar_default='he_layouts' WHERE languagevar_id='690697004' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697005 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697005', '1', 'Name/folder', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Name/folder', languagevar_default='he_layouts' WHERE languagevar_id='690697005' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697006 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697006', '1', 'Description', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Description', languagevar_default='he_layouts' WHERE languagevar_id='690697006' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697007 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697007', '1', 'Set Layout', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Set Layout', languagevar_default='he_layouts' WHERE languagevar_id='690697007' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697008 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697008', '1', 'Edit Layout', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Edit Layout', languagevar_default='he_layouts' WHERE languagevar_id='690697008' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697009 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697009', '1', 'Delete Layout', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Delete Layout', languagevar_default='he_layouts' WHERE languagevar_id='690697009' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697010 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697010', '1', 'Edit \"%1\$s\" Layout', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Edit \"%1\$s\" Layout', languagevar_default='he_layouts' WHERE languagevar_id='690697010' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697011 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697011', '1', 'Preview Icon', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Preview Icon', languagevar_default='he_layouts' WHERE languagevar_id='690697011' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697012 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697012', '1', 'Delete Image', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Delete Image', languagevar_default='he_layouts' WHERE languagevar_id='690697012' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697013 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697013', '1', 'Import Layout', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Import Layout', languagevar_default='he_layouts' WHERE languagevar_id='690697013' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697014 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697014', '1', 'Layout ZIP-Archive', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Layout ZIP-Archive', languagevar_default='he_layouts' WHERE languagevar_id='690697014' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697015 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697015', '1', 'Import', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Import', languagevar_default='he_layouts' WHERE languagevar_id='690697015' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697016 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697016', '1', 'Add New Layout', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Add New Layout', languagevar_default='he_layouts' WHERE languagevar_id='690697016' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697017 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697017', '1', 'Add', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Add', languagevar_default='he_layouts' WHERE languagevar_id='690697017' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697018 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697018', '1', 'Price', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Price', languagevar_default='he_layouts' WHERE languagevar_id='690697018' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697019 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697019', '1', 'FREE!!', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='FREE!!', languagevar_default='he_layouts' WHERE languagevar_id='690697019' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697020 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697020', '1', 'Download!', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Download!', languagevar_default='he_layouts' WHERE languagevar_id='690697020' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697021 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697021', '1', 'see more...', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='see more...', languagevar_default='he_layouts' WHERE languagevar_id='690697021' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697022 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697022', '1', 'Layout not found', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Layout not found', languagevar_default='he_layouts' WHERE languagevar_id='690697022' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697023 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697023', '1', 'Not Found a correct ZIP-Archive', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Not Found a correct ZIP-Archive', languagevar_default='he_layouts' WHERE languagevar_id='690697023' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697024 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697024', '1', 'Can`t create a layout directory. Please check write permission for he_layouts folder and try again', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Can`t create a layout directory. Please check write permission for he_layouts folder and try again', languagevar_default='he_layouts' WHERE languagevar_id='690697024' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697025 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697025', '1', 'Can`t read ZIP-Archive', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Can`t read ZIP-Archive', languagevar_default='he_layouts' WHERE languagevar_id='690697025' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697026 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697026', '1', 'Information file not founded. Set default values for layout Name and Description', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Information file not founded. Set default values for layout Name and Description', languagevar_default='he_layouts' WHERE languagevar_id='690697026' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697027 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697027', '1', 'Can`t found layout styles', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Can`t found layout styles', languagevar_default='he_layouts' WHERE languagevar_id='690697027' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697028 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697028', '1', 'Layout with that name is already existed. Rename or delete existed layout', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Layout with that name is already existed. Rename or delete existed layout', languagevar_default='he_layouts' WHERE languagevar_id='690697028' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697029 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697029', '1', 'Not Valid Folder Name', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Not Valid Folder Name', languagevar_default='he_layouts' WHERE languagevar_id='690697029' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697030 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697030', '1', 'Please, create a dir \"he_layouts\" in your site root folder', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Please, create a dir \"he_layouts\" in your site root folder', languagevar_default='he_layouts' WHERE languagevar_id='690697030' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697031 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697031', '1', 'Can`t create a new layout folder', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Can`t create a new layout folder', languagevar_default='he_layouts' WHERE languagevar_id='690697031' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697032 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697032', '1', 'Error while getting preview icon. Please, try again', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Error while getting preview icon. Please, try again', languagevar_default='he_layouts' WHERE languagevar_id='690697032' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697033 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697033', '1', 'Changes saved', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Changes saved', languagevar_default='he_layouts' WHERE languagevar_id='690697033' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697034 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697034', '1', 'You can`t delete the \"Empty\" layout', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='You can`t delete the \"Empty\" layout', languagevar_default='he_layouts' WHERE languagevar_id='690697034' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697035 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697035', '1', 'Specify right layout for delete', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Specify right layout for delete', languagevar_default='he_layouts' WHERE languagevar_id='690697035' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697036 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697036', '1', 'Layout has already been deleted', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Layout has already been deleted', languagevar_default='he_layouts' WHERE languagevar_id='690697036' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697037 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697037', '1', 'Can`t delete layout directory %1\$s', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Can`t delete layout directory %1\$s', languagevar_default='he_layouts' WHERE languagevar_id='690697037' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697038 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697038', '1', 'You can`t delete default preview image', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='You can`t delete default preview image', languagevar_default='he_layouts' WHERE languagevar_id='690697038' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697039 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697039', '1', 'Preview image deleted', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Preview image deleted', languagevar_default='he_layouts' WHERE languagevar_id='690697039' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697040 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697040', '1', 'Can`t found preview image', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Can`t found preview image', languagevar_default='he_layouts' WHERE languagevar_id='690697040' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697041 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697041', '1', 'Can`t connect to server. Please, try again later', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Can`t connect to server. Please, try again later', languagevar_default='he_layouts' WHERE languagevar_id='690697041' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697042 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697042', '1', 'Couldn`t find ZLib PHP extension', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Couldn`t find ZLib PHP extension', languagevar_default='he_layouts' WHERE languagevar_id='690697042' AND languagevar_language_id='1'");
if( $database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690697043 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690697043', '1', 'Install ZLib PHP Extension to activate this feature', 'he_layouts')"); else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Install ZLib PHP Extension to activate this feature', languagevar_default='he_layouts' WHERE languagevar_id='690697043' AND languagevar_language_id='1'");

}
?>