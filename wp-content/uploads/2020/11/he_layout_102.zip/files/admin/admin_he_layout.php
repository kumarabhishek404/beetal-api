<?php

/**
 * @author Vadim
 * @copyright Hire-Experts LLC
 * @version Layouts 1.01
 */

$page = "admin_he_layout";
include "admin_header.php";
include("../include/pclzip.lib.php");

if (isset($_POST['task']) && $_POST['task']) {
	$task = $_POST['task'];
}

elseif ((isset($_GET['task']) && $_GET['task'])) {
	$task = $_GET['task'];
}

else {
	$task = '';
}


if(isset($_POST['set_layout'])) $task='set_layout';
if(isset($_POST['edit_layout'])) $task='edit_layout';
if(isset($_POST['del_layout'])) $task='del_layout';


if(isset($_POST['layout_id'])) $layout_id=$_POST['layout_id'];
if(isset($_GET['layout_id'])) $layout_id=$_GET['layout_id'];



$layout = new he_layout();


// SET LAYOUT
if($task == "set_layout") {
	$layout->layout_set($layout_id);
}


// DELETE PREVIEW
if($task == "del_preview") {
	$layout->del_preview($layout_id);
}


// DO EDIT
if($task == "layout_update") {
	$layout_id = $_POST['layout_id'];
	$he_name = $_POST['he_name'];
	$he_style = $_POST['he_style'];
	$he_descr = $_POST['he_descr'];

	$layout->layout_update($layout_id, $he_name, $he_style, $he_descr);
}

// EDIT LAYOUT
if($task == "edit_layout" || $task == "del_preview") {
	$layout_info = $layout->layout_view($layout_id);
	$task = 'edit_layout';
	$smarty->assign('layout', $layout_info);
}

// DELETE LAYOUT
if($task == "del_layout") {
	$layout->layout_del($layout_id);
}

// ADD NEW LAYOUT
if($task == "add") {
	$he_name = $_POST['he_name'];
	$he_style = $_POST['he_style'];
	$he_descr = $_POST['he_descr'];
	
	$layout->layout_add($he_name, $he_style, $he_descr);

	$smarty->assign('he_name', $he_name);
	$smarty->assign('he_style', $he_style);
	$smarty->assign('he_descr', $he_descr);
}

// IMPORT LAYOUT
if($task == "import") {
	
	$layout->layout_import($he_name, $he_style, $he_descr);

}


// GET LAYOUTS FROM HE SITE
if($task == "new_layouts") {
	$download_list = $layout->get_new_layouts();
	$smarty->assign('download_list', $download_list);
}

if ( extension_loaded('zlib') ) $smarty->assign('zlib_avaible', true); else $smarty->assign('zlib_avaible', false);


if ($layout->message) $message = $layout->message;

$layouts_list = $layout->layouts_list();





$smarty->assign('layouts', $layouts_list);
$smarty->assign('message', $message);

$smarty->assign('settings', $settings);
$smarty->assign('task', $task);

include "admin_footer.php";
?>