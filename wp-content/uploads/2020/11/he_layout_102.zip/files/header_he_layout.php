<?php

/**
 * @author Vadim
 * @copyright Hire-Experts LLC
 * @version Layouts 1.01
 */

defined('SE_PAGE') or exit();

include_once "./header_he_core.php";
include_once "./include/class_he_layout.php";

$he_layout = new he_layout();
$style = $he_layout->layout_get();
$smarty->assign('he_layout_style', $style);

?>