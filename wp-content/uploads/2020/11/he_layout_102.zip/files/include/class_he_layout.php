<?php

/**
 * @author Vadim
 * @copyright Hire-Experts LLC
 * @version Layouts 1.01
 */

class he_layout {

	var $LAYOUTS_PATH = '../he_layouts/';

	var $NO_PREVIEW_PATH = '../he_layouts/nopreview.png';

	var $is_error;
	var $message;

	var $layouts_list;

	var $layout_style;
	var $layout_preview;


	/*    GET ALL LAYOUTS INFO FROM DB    */
	function he_layout() {
		global $database;

		$sql ="SELECT * FROM se_he_layouts WHERE 1 ORDER BY `id`";

		$resource = $database->database_query($sql);

	    while ($layout = $database->database_fetch_assoc($resource)) {

			if(is_file($this->LAYOUTS_PATH.$layout['name'].'/preview.png')) {
				$preview_img = $this->LAYOUTS_PATH.$layout['name'].'/preview.png';
				$preview_able = true;
			}
			elseif(is_file($this->LAYOUTS_PATH.$layout['name'].'/preview.jpg')) {
				$preview_img = $this->LAYOUTS_PATH.$layout['name'].'/preview.jpg';
				$preview_able = true;
			}
			elseif(is_file($this->LAYOUTS_PATH.$layout['name'].'/preview.jpeg')){
				$preview_img = $this->LAYOUTS_PATH.$layout['name'].'/preview.jpeg';
				$preview_able = true;
			}
			elseif(is_file($this->LAYOUTS_PATH.$layout['name'].'/preview.gif')) {
				$preview_img = $this->LAYOUTS_PATH.$layout['name'].'/preview.gif';
				$preview_able = true;
			}
			else {
				$preview_img = $this->NO_PREVIEW_PATH;
				$preview_able = false;
			}

			$layout['preview_img'] = $preview_img;
			$layout['preview_able'] = $preview_able;

			$layouts_list[$layout['id']] = $layout;

		}

		$this->layouts_list = $layouts_list;
		return true;
	}



	/*    LAYOUT ARRAY OF LAYOUTS    */
	function layouts_list() {
		$this->he_layout();
		return $this->layouts_list;
	}



	/*    SET AN ACTIVE LAYOUT    */
	function layout_set($id) {
		global $database;

		$id = (int)$id;

		if ($id==0) { $this->message['error'] = SE_Language::get(690697022); return(false); }

		if(empty($this->layouts_list[$id]['name'])) { $this->message['error'] = SE_Language::get(690697022); return(false); }

		$sql = 'UPDATE se_he_layouts SET active=0 WHERE 1';
		$resource = $database->database_query($sql);

		$sql = 'UPDATE se_he_layouts SET active=1 WHERE id='.$id.' LIMIT 1';
		$resource = $database->database_query($sql);

		return true;
	}



	/*    VIEW LAYOUT FOR EDITING    */
	function layout_view($id) {
		global $database;

		$id = (int)$id;

		if ($id==0) { $this->message['error'] = SE_Language::get(690697022); return(false); }
		if(empty($this->layouts_list[$id]['name'])) { $this->message['error'] = SE_Language::get(690697022); return(false); }

		return($this->layouts_list[$id]);
	}


	/*    GET LAYOUT STYLE    */
	function layout_get() {
		global $database;

		foreach($this->layouts_list as $layout) {
			if ($layout['active']==1) return $layout['style'];
		}

		return;
	}


	/*    LAYOUT IMPORTER    */
	function layout_import() {
		global $database;
		global $_FILES;

		if ( !is_uploaded_file($_FILES['he_ziparchive']['tmp_name']) ) { $this->message['error'] = SE_Language::get(690697023); return false; }

		$file_name_arr = explode('.', $_FILES['he_ziparchive']['name']);
		$file_extension = array_pop($file_name_arr);
		if ( $file_extension != 'zip' ) { $this->message['error'] = SE_Language::get(690697023); }

		if ( !$this->arch_proc($_FILES['he_ziparchive']['tmp_name']) ) return false;

		$this->he_layout();

		return true;
	}


	function arch_proc($filepath) {
		global $database;

		if ( !extension_loaded('zlib') ) { $this->message['error'] = SE_Language::get(690697042); return false; }

        $zip = new PclZip($filepath);

		$temp_dir = 'temp_'.rand(100,999).'/';					// temp directory name
        
        // Create temp directory
		if( !mkdir($this->LAYOUTS_PATH.$temp_dir) ) { $this->message['error'] = SE_Language::get(690697024); return false; }

        if( $zip->extract(PCLZIP_OPT_PATH, $this->LAYOUTS_PATH.$temp_dir) == 0 ) {
            $this->message['error'] = SE_Language::get(690697025);
            $this->deleteDirectory($this->LAYOUTS_PATH.$temp_dir);
            return false;
        }

		// read file with layout info
		if ( $layout = file($this->LAYOUTS_PATH.$temp_dir.'info.ini') ) {

			// ok, read layout info
			$name = trim($layout['0']);
			$descr = htmlspecialchars(trim($layout['1']));

		} else {
			// sets default values
			$this->message['error'] = SE_Language::get(690697026);
			$name = 'layout_'.rand(1000,9999).'/';
			$descr = 'Without description';
		}

		// read layout styles
		if ( !$style = file_get_contents($this->LAYOUTS_PATH.$temp_dir.'styles.css') ) {
			$this->message['error'] = SE_Language::get(690697027);

			$this->deleteDirectory($this->LAYOUTS_PATH.$temp_dir);
			return false;
		}

		if ( is_dir($this->LAYOUTS_PATH.$name) ) { $this->message['error'] = SE_Language::get(690697028); $this->deleteDirectory($this->LAYOUTS_PATH.$temp_dir); return false; }

		rename($this->LAYOUTS_PATH.$temp_dir, $this->LAYOUTS_PATH.$name.'/');

		$name = $database->database_real_escape_string($name);
		$descr = $database->database_real_escape_string($descr);
		$style = $database->database_real_escape_string($style);

		$sql = "INSERT INTO se_he_layouts (`name`, `style`, `descr`, `active`) VALUES ('$name', '$style', '$descr', 0)";
		$resource = $database->database_query($sql);

	}





	/*    ADD A NEW LAYOUT    */
	function layout_add($name, $style, $descr) {
		global $database;
		global $_FILES;

		// Начальные проверки
		if ( empty($name) ) { $this->message['error'] = SE_Language::get(690697029); return false; }

		if( !is_dir($this->LAYOUTS_PATH) ) { $this->message['error'] = SE_Language::get(690697030); return false; }

		if( !is_dir($this->LAYOUTS_PATH.$name) ) {
			if ( !mkdir($this->LAYOUTS_PATH.$name) ) { $this->message['error'] = SE_Language::get(690697031); return false; }
		}

		// Работа с иконкой

		if ( is_uploaded_file($_FILES['he_icon']['tmp_name']) ) {

			$file_name_arr = explode('.', $_FILES['he_icon']['name']);
			$file_extension = array_pop($file_name_arr);

			$result = move_uploaded_file($_FILES['he_icon']['tmp_name'], $this->LAYOUTS_PATH.$name.'/preview.'.$file_extension);
			
			if ( !$result ) {
				$this->message['error'] = SE_Language::get(690697032); return false;
			}

		}

		$name = $name;
		$descr = $database->database_real_escape_string(htmlspecialchars(trim($descr)));
		$style = $database->database_real_escape_string(htmlspecialchars(trim($style)));

		$sql = "INSERT INTO se_he_layouts (`name`, `style`, `descr`, `active`) VALUES ('$name', '$style', '$descr', 0)";
		$resource = $database->database_query($sql);

	}


	/*    UPDATE LAYOUT PROPERTIES    */
	function layout_update($id, $name, $style, $descr) {
		global $database;
		global $_FILES;

		// Начальные проверки
		$id = (int)$id;
		$id = trim($id);
		if ( $id==1 ) { $this->message['error'] = 'You can`t modify the "Empty" layout'; return(false); }

		if ( empty($name) ) { $this->message['error'] = SE_Language::get(690697029); return false; }

		if( !is_dir($this->LAYOUTS_PATH) ) { $this->message['error'] = SE_Language::get(690697030); return false; }

		if( !is_dir($this->LAYOUTS_PATH.$name) ) {
			if ( !mkdir($this->LAYOUTS_PATH.$name) ) { $this->message['error'] = SE_Language::get(690697031); return false; }
		}


		// upload icon
		if ( is_uploaded_file($_FILES['he_icon']['tmp_name']) ) {

			$file_name_arr = explode('.', $_FILES['he_icon']['name']);
			$file_extension = array_pop($file_name_arr);

			$result = move_uploaded_file($_FILES['he_icon']['tmp_name'], $this->LAYOUTS_PATH.$name.'/preview.'.$file_extension);
			
			if ( !$result ) {
				$this->message['error'] = 'Error while loading icon. Please, try again'; return false;
			}

		}

		$name = $database->database_real_escape_string($name);
		$descr = $database->database_real_escape_string(htmlspecialchars(trim($descr)));
		$style = $database->database_real_escape_string(htmlspecialchars(trim($style)));

		$sql = "UPDATE se_he_layouts SET `name`='$name', `style`='$style', `descr`='$descr' WHERE `id`=$id LIMIT 1";
		$resource = $database->database_query($sql);

		$this->message['info'] = SE_Language::get(690697033);

		$this->he_layout();
	}


	/*    DELETE LAYOUT    */
	function layout_del($id) {
		global $database;

		$id = (int)$id;
		if ($id==1) { $this->message['error'] = SE_Language::get(690697034); return(false); }
		if ( empty($id) ) { $this->message['error'] = SE_Language::get(690697035); return(false); }
		if ( empty($this->layouts_list[$id]['name']) ) { $this->message['error'] = SE_Language::get(690697036); return(false); }


		$sql = "DELETE FROM `se_he_layouts` WHERE `id`=$id";
		$resource = $database->database_query($sql);


		$foldername = $this->LAYOUTS_PATH . $this->layouts_list[$id]['name'];

		if( !$this->deleteDirectory($foldername) ) { $this->message['error'] = SE_Language::get(690697037, array($foldername)); }

		$sql = 'SELECT name FROM se_he_layouts WHERE active=1 LIMIT 1';
		$resource = $database->database_query($sql);

		if ($database->database_num_rows($resource)==0) {
			$sql = 'UPDATE se_he_layouts SET active=1 WHERE 1 LIMIT 1';
			$resource = $database->database_query($sql);
		}
	}


	function del_preview($id) {
		global $database;

		$id = (int)$id;
		if ( $id==1 ) { $this->message['error'] = SE_Language::get(690697034); return(false); }

		if ( $this->layouts_list[$id]['preview_img']==$this->NO_PREVIEW_PATH ) { $this->message['error'] = SE_Language::get(690697038); return(false); }

		if( unlink($this->layouts_list[$id]['preview_img']) ) {

			$this->layouts_list[$id]['preview_img'] = $this->NO_PREVIEW_PATH;
			$this->layouts_list[$id]['preview_able'] = false;

			$this->message['info'] = SE_Language::get(690697039);

		} else { $this->message['error'] = SE_Language::get(690697040); }
	}


	function deleteDirectory($dir) {
		if (!file_exists($dir)) return true;
		if (!is_dir($dir) || is_link($dir)) return unlink($dir);

		if ($res = @opendir($dir)) {
			while (($item = readdir($res)) !== false) {
				if ($item == '.' || $item == '..') continue;
				if (!$this->deleteDirectory($dir . "/" . $item)) {
					chmod($dir . "/" . $item, 0777);
					if (!$this->deleteDirectory($dir . "/" . $item)) return false;
				}
			}
			closedir($res);
		}

		return rmdir($dir);
	}


	function get_new_layouts() {

		if ( !$layouts = @file('http://www.hire-experts.com/he_layouts.list') ) { $this->message['error'] = SE_Language::get(690697041); return false; }

		foreach ($layouts as $element) {
			$layout_info = explode('|', $element);

			$layout['name'] = $layout_info[0];
			$layout['descr'] = $layout_info[1];
			$layout['price'] = $layout_info[2];
			$layout['preview'] = $layout_info[3];
			$layout['link'] = $layout_info[4];
			$layout['download_link'] = $layout_info[5];

			$download_list[] = $layout;
		}

		return $download_list;
	}

}
?>