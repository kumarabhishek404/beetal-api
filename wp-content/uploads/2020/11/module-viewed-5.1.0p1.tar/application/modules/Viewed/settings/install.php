<?php

/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Socialads
 * @author     KALYSKIN
 */
class Viewed_Installer extends Engine_Package_Installer_Module
{
    public function onPreInstall()
    {
        $this->_myViewPage();
        parent::onPreInstall();

        $db = $this->getDb();
        $translate = Zend_Registry::get('Zend_Translate');
}
public function _myViewPage(){
    $db = $this->getDb();

    // profile page
    $pageId = $db->select()
      ->from('engine4_core_pages', 'page_id')
      ->where('name = ?', 'viewed_index_index')
      ->limit(1)
      ->query()
      ->fetchColumn();

        if( empty($pageId) ) {
            $db->insert('engine4_core_pages', array(
        'name' => 'viewed_index_index',
        'displayname' => 'Browse All views profile',
        'title' => 'Browse All views profile',
        'description' => 'This page is the display all viewed profile',
        'custom' => 0,
      ));
            $pageId = $db->lastInsertId('engine4_core_pages');

            // containers
            $db->insert('engine4_core_content', array(
                'page_id' => $pageId,
                'type' => 'container',
                'name' => 'main',
                'parent_content_id' => null,
                'order' => 1,
                'params' => '',
            ));
            $containerId = $db->lastInsertId('engine4_core_content');

            $db->insert('engine4_core_content', array(
                'page_id' => $pageId,
                'type' => 'container',
                'name' => 'right',
                'parent_content_id' => $containerId,
                'order' => 1,
                'params' => '',
            ));
            $rightId = $db->lastInsertId('engine4_core_content');

            $db->insert('engine4_core_content', array(
                'page_id' => $pageId,
                'type' => 'container',
                'name' => 'middle',
                'parent_content_id' => $containerId,
                'order' => 3,
                'params' => '',
            ));
            $middleId = $db->lastInsertId('engine4_core_content');

            // middle column content
            $db->insert('engine4_core_content', array(
                'page_id' => $pageId,
                'type' => 'widget',
                'name' => 'core.content',
                'parent_content_id' => $middleId,
                'order' => 1,
                'params' => '',
            ));

            

            // right column
            $db->insert('engine4_core_content', array(
                'page_id' => $pageId,
                'type' => 'widget',
                'name' => 'core.statistics',
                'parent_content_id' => $rightId,
                'order' => 1,
                'params' => '',
            ));

        } 
}
}

?>