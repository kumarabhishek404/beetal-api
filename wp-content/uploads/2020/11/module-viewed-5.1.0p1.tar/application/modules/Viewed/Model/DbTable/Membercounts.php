<?php
class Viewed_Model_DbTable_Membercounts extends Engine_Db_Table
{
	protected $_rowClass = 'Viewed_Model_Membercount';
}