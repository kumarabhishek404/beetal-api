<?php return array (
  'package' =>
  array (
    'type' => 'module',
    'name' => 'viewed',
    'version' => '5.1.0p1',
    'path' => 'application/modules/Viewed',
    'title' => 'Who Viewed Me',
    'description' => 'This package will show the list of users who viewed your profile.',
    'author' => '<a href="http://ipragmatech.com/">iPragmatech</a>',
    'sku' => 'IPWHOVMP',
    'callback' =>
                array(
                    'path' => 'application/modules/Viewed/settings/install.php',
                    'class' => 'Viewed_Installer',
                ),
    'actions' =>
    array (
      0 => 'install',
      1 => 'upgrade',
      2 => 'refresh',
      3 => 'enable',
      4 => 'disable',
    ),
    'directories' =>
    array (
      0 => 'application/modules/Viewed',
    ),
    'files' =>
    array (
      0 => 'application/languages/en/viewed.csv',
    ),
  ),
	// Items ---------------------------------------------------------------------
		'items' => array(
				'viewed_package',
				'viewed_gateway',
				'viewed_subscription',
				'viewed_order'
		),
); ?>
