<?php
class Viewed_Model_DbTable_Viewmes extends Engine_Db_Table
{
	protected $_rowClass = 'Viewed_Model_Viewme';
	
	public function saveViewMe($user_id,$owner_id)
	{
		
	}
}