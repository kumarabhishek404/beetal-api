INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES  ('hequestion', 'Questions', 'Questions', '4.10.3p2', 1, 'extra') ;
