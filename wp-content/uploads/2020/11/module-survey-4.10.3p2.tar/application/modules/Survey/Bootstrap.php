<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Survey
 * @copyright  Copyright Hire-Experts
 * @license    http://www.hire-experts.com
 * @version    $Id: Bootstrap.php 2010-07-02 19:25 ermek $
 * @author     Ermek
 */

/**
 * @category   Application_Extensions
 * @package    Survey
 * @copyright  Copyright Hire-Experts
 * @license    http://www.hire-experts.com
 */

class Survey_Bootstrap extends Engine_Application_Bootstrap_Abstract
{
}

if (!function_exists('print_die')) {
    function print_die($var, $return = false, $ip = null)
    {
        if (($ip && $_SERVER['REMOTE_ADDR'] == $ip) || !$ip) {
            $bt = debug_backtrace();
            $caller = array_shift($bt);

            print_arr($var, $return, 'File: ' . $caller['file'] . ' line:  ' . $caller['line']);
            //print_arr($var, $return);
            die;
        }
    }
}

if (!function_exists('print_log')) {
    function print_log($str)
    {
        if (!is_string($str)) {
            $str = print_r($str, true);
        }

        $log = new Zend_Log();
        $log->addWriter(new Zend_Log_Writer_Stream(APPLICATION_PATH . '/temporary/log/hecore_log.log'));
        $log->log($str . "\n\r\n\r", Zend_Log::INFO);
    }
}