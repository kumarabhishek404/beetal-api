--
-- Dumping data for table `engine4_core_modules`
--

INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES
('survey', 'Survey', 'Survey Plugin', '4.10.3p2', 1, 'extra');

