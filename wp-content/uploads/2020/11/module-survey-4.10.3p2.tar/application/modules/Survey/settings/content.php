<?php return array(
  array(
    'title' => 'Most Popular Surveys',
    'description' => 'Displays most popular surveys.',
    'category' => 'Surveys',
    'type' => 'widget',
    'name' => 'survey.most-popular',
    'defaultParams' => array(
      'title' => 'Most Popular Surveys',
      'titleCount' => true,
    ),
  ),

  array(
    'title' => 'Most Taken Surveys',
    'description' => 'Displays most taken surveys.',
    'category' => 'Surveys',
    'type' => 'widget',
    'name' => 'survey.most-taken',
    'defaultParams' => array(
      'title' => 'Most Taken Surveys',
      'titleCount' => true,
    ),
  ),

  array(
    'title' => 'Most Recent Surveys',
    'description' => 'Displays most recent surveys.',
    'category' => 'Surveys',
    'type' => 'widget',
    'name' => 'survey.most-recent',
    'defaultParams' => array(
      'title' => 'Most Recent Surveys',
      'titleCount' => true,
    ),
  ),

  array(
    'title' => 'Most Commented Surveys',
    'description' => 'Displays most commented surveys.',
    'category' => 'Surveys',
    'type' => 'widget',
    'name' => 'survey.most-commented',
    'defaultParams' => array(
      'title' => 'Most Commented Surveys',
      'titleCount' => true,
    ),
  ),

  array(
    'title' => 'Last Taken Surveys',
    'description' => 'Displays last taken surveys.',
    'category' => 'Surveys',
    'type' => 'widget',
    'name' => 'survey.recent-taken',
    'defaultParams' => array(
      'title' => 'Last Taken Surveys',
      'titleCount' => true,
    ),
  ),
)
?>