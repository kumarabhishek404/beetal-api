<?php

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version Cooliris 1.01
 */

defined('SE_PAGE') or exit();

include_once "./header_he_core.php";
include_once "./include/class_he_cooliris.php";


if ( $page == 'album' )
{
	$page = 'cooliris_album';
	
	$cooliris_feed_url = 'feed=' . $url->url_base . 'cooliris_rss.php?';
	
	$cooliris_feed = 'cooliris=album';
	$cooliris_feed .= ( $_SERVER['QUERY_STRING'] ) ? '&' . $_SERVER['QUERY_STRING'] : '';
	$cooliris_feed = urlencode($cooliris_feed);

	$cooliris_flash_vars = $cooliris_feed_url . $cooliris_feed . he_cooliris::get_setting_str();
		
	$smarty->assign('cooliris_flash_vars', $cooliris_flash_vars);
}
elseif ( $page == 'browse_videos' )
{
	$page = 'cooliris_browse_videos';
	
	$cooliris_feed_url = 'feed=' . $url->url_base . 'cooliris_rss.php?';
	
	$cooliris_feed = 'cooliris=browse_videos';
	$cooliris_feed .= ( $_SERVER['QUERY_STRING'] ) ? '&' . $_SERVER['QUERY_STRING'] : '';
	$cooliris_feed = urlencode($cooliris_feed);

	$cooliris_flash_vars = $cooliris_feed_url . $cooliris_feed . he_cooliris::get_setting_str();
		
	$smarty->assign('cooliris_flash_vars', $cooliris_flash_vars);
}
elseif ( $page == 'browse_vids' )
{
    $page = 'cooliris_browse_vids';
    
    $cooliris_feed_url = 'feed=' . $url->url_base . 'cooliris_rss.php?';
    
    $cooliris_feed = 'cooliris=browse_vids';
    $cooliris_feed .= ( $_SERVER['QUERY_STRING'] ) ? '&' . $_SERVER['QUERY_STRING'] : '';
    $cooliris_feed = urlencode($cooliris_feed);

    $cooliris_flash_vars = $cooliris_feed_url . $cooliris_feed . he_cooliris::get_setting_str();
    
    $smarty->assign('cooliris_flash_vars', $cooliris_flash_vars);
}

?>