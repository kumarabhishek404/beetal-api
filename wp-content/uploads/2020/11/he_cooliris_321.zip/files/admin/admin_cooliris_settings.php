<?php

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version Cooliris 1.01
 */

$page = "admin_cooliris_settings";
include "admin_header.php";

$task = ( isset($_POST['task']) || $_POST['task'] ) ? $_POST['task'] : '';


if ( $task == 'save_settings' )
{
	$setting['setting_he_cooliris_bg_color'] = $_POST['setting_he_cooliris_bg_color'];
	$setting['setting_he_cooliris_bg_image'] = $_POST['setting_he_cooliris_bg_image'];
	$setting['setting_he_cooliris_num_rows'] = $_POST['setting_he_cooliris_num_rows'];
	$setting['setting_he_cooliris_theme'] = $_POST['setting_he_cooliris_theme'];
	$setting['setting_he_cooliris_logo_image'] = $_POST['setting_he_cooliris_logo_image'];
	$setting['setting_he_cooliris_logo_url'] = $_POST['setting_he_cooliris_logo_url'];
	
	$database->database_query("UPDATE se_settings SET 
		setting_he_cooliris_bg_color='{$setting['setting_he_cooliris_bg_color']}', 
		setting_he_cooliris_bg_image='{$setting['setting_he_cooliris_bg_image']}', 
		setting_he_cooliris_num_rows='{$setting['setting_he_cooliris_num_rows']}', 
		setting_he_cooliris_theme='{$setting['setting_he_cooliris_theme']}',
		setting_he_cooliris_logo_image='{$setting['setting_he_cooliris_logo_image']}',
		setting_he_cooliris_logo_url='{$setting['setting_he_cooliris_logo_url']}'");
		
	$smarty->assign('message', SE_Language::get(191));
}

include "admin_footer.php";

?>