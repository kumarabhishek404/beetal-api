<?php

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version Cooliris 3.2
 */

$plugin_name = "Cooliris Plugin";
$plugin_version = "3.21";
$req_core_version = "3.01";
$plugin_type = "he_cooliris";
$plugin_desc = "It's simply the fastest and most stunning way to browse photos and videos from your site. Effortlessly scroll an infinite \"3D Wall\" of your content without having to click page to page.";
$plugin_icon = "he_cooliris_icon.png";
$plugin_menu_title = "690700000";
$plugin_pages_main = "690700000<!>he_cooliris_icon.png<!>admin_cooliris_settings.php<~!~>";
$plugin_db_charset = 'utf8';
$plugin_db_collation = 'utf8_unicode_ci';
$plugin_reindex_totals = TRUE;




if( $install == "he_cooliris" )
{
	//check core library
	$sql = "SELECT `plugin_version` FROM `se_plugins` WHERE plugin_type='he_core' AND `plugin_disabled`=0 LIMIT 1";
	$resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
	$core_version = $database->database_fetch_array($resource);
	if ( floatval($core_version[0]) < floatval($req_core_version) ) {
		die ('This plugin requires Hire-Experts Core Library. Please install latest version of Hire-Experts Core Library plugin. You can download it from My Plugins section in Hire-Experts.com for FREE.');
	}

    //######### GET CURRENT PLUGIN INFORMATION
    $sql = "SELECT * FROM se_plugins WHERE plugin_type='{$plugin_type}' LIMIT 1";
    $resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");

    $plugin_info = array();
    if( $database->database_num_rows($resource) )
        $plugin_info = $database->database_fetch_assoc($resource);

    //######### INSERT ROW INTO se_plugins
    $sql = "SELECT NULL FROM se_plugins WHERE plugin_type='$plugin_type'";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);

    if( !$database->database_num_rows($resource) )
    {
        $sql = "
            INSERT INTO se_plugins (
              plugin_name,
              plugin_version,
              plugin_type,
              plugin_desc,
              plugin_icon,
              plugin_menu_title,
              plugin_pages_main,
              plugin_pages_level,
              plugin_url_htaccess
            ) VALUES (
            '$plugin_name',
            '$plugin_version',
            '$plugin_type',
            '".str_replace("'", "\'", $plugin_desc)."',
            '$plugin_icon',
            '$plugin_menu_title',
            '$plugin_pages_main',
            '',
            ''
            )
        ";

        $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    }

    //######### UPDATE PLUGIN VERSION IN se_plugins
    else
    {
        $sql = "
            UPDATE
              se_plugins
            SET
              plugin_name='$plugin_name',
              plugin_version='$plugin_version',
              plugin_desc='".str_replace("'", "\'", $plugin_desc)."',
              plugin_icon='$plugin_icon',
              plugin_menu_title='$plugin_menu_title',
              plugin_pages_main='$plugin_pages_main',
              plugin_pages_level='',
              plugin_url_htaccess=''
            WHERE
              plugin_type='$plugin_type'
        ";

        $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    }

    //######### ADD COLUMNS/VALUES TO SETTINGS TABLE
    $sql = "SHOW COLUMNS FROM `$database_name`.`se_settings` LIKE 'setting_he_cooliris_bg_color'";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);

    if( !$database->database_num_rows($resource) )
    {
        $sql = "ALTER TABLE `se_settings` ADD COLUMN `setting_he_cooliris_bg_color` VARCHAR(30) DEFAULT NULL";
        $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    }

    //######### ADD COLUMNS/VALUES TO SETTINGS TABLE
    $sql = "SHOW COLUMNS FROM `$database_name`.`se_settings` LIKE 'setting_he_cooliris_bg_image'";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);

    if( !$database->database_num_rows($resource) )
    {
        $sql = "ALTER TABLE `se_settings` ADD COLUMN `setting_he_cooliris_bg_image` VARCHAR(255) DEFAULT NULL";
        $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    }

    //######### ADD COLUMNS/VALUES TO SETTINGS TABLE
    $sql = "SHOW COLUMNS FROM `$database_name`.`se_settings` LIKE 'setting_he_cooliris_num_rows'";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);

    if( !$database->database_num_rows($resource) )
    {
        $sql = "ALTER TABLE `se_settings` ADD COLUMN `setting_he_cooliris_num_rows` TINYINT(4) NOT NULL DEFAULT 3";
        $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    }

    //######### ADD COLUMNS/VALUES TO SETTINGS TABLE
    $sql = "SHOW COLUMNS FROM `$database_name`.`se_settings` LIKE 'setting_he_cooliris_theme'";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);

    if( !$database->database_num_rows($resource) )
    {
        $sql = "ALTER TABLE `se_settings` ADD COLUMN `setting_he_cooliris_theme` VARCHAR(255) NOT NULL DEFAULT 'black'";
        $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    }

    //######### ADD COLUMNS/VALUES TO SETTINGS TABLE
    $sql = "SHOW COLUMNS FROM `$database_name`.`se_settings` LIKE 'setting_he_cooliris_logo_image'";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);

    if( !$database->database_num_rows($resource) )
    {
        $sql = "ALTER TABLE `se_settings` ADD COLUMN `setting_he_cooliris_logo_image` VARCHAR(255) NOT NULL DEFAULT ''";
        $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    }

    //######### ADD COLUMNS/VALUES TO SETTINGS TABLE
    $sql = "SHOW COLUMNS FROM `$database_name`.`se_settings` LIKE 'setting_he_cooliris_logo_url'";
    $resource = $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);

    if( !$database->database_num_rows($resource) )
    {
        $sql = "ALTER TABLE `se_settings` ADD COLUMN `setting_he_cooliris_logo_url` VARCHAR(255) NOT NULL DEFAULT ''";
        $database->database_query($sql) or die("<b>Error: </b>".$database->database_error()."<br /><b>File: </b>".__FILE__."<br /><b>Line: </b>".__LINE__."<br /><b>Query: </b>".$sql);
    }


    //######### ADD VALUES TO LANGS TABLE
    $he_languagevars = array
    (
        '690700000' => 'Cooliris Plugin',
        '690700001' => 'Cooliris settings',
        '690700002' => 'Customize the look and feel of Cooliris - modify the number of rows, background color and image, theme. If you want to remove the option you need set the field empty.',
        '690700003' => 'Background Color',
        '690700004' => 'Background Image Url',
        '690700005' => 'Number of rows',
        '690700006' => 'Theme',
        '690700007' => 'Logo Image Url',
        '690700008' => 'Logo Target Url'
    );

    foreach ($he_languagevars as $langvar_id => $langvar_value)
    {
        $sql = "SELECT `languagevar_id` FROM `se_languagevars`
           WHERE `languagevar_id`=$langvar_id AND `languagevar_language_id`=1";
        
        if ( $database->database_num_rows($database->database_query($sql)) == 0 )
        {
            $sql = "INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`)
                VALUES('$langvar_id', '1', '$langvar_value', 'cooliris')";
        }
        else
        {
            $sql = "UPDATE `se_languagevars` SET `languagevar_value`='$langvar_value', `languagevar_default`='cooliris'
                WHERE `languagevar_id`=$langvar_id AND `languagevar_language_id`=1";
        }
        
        $resource = $database->database_query($sql) or die("<b>Error: </b>" . $database->database_error() . "<br /><b>File: </b>" . __FILE__ . "<br /><b>Line: </b>" . __LINE__ . "<br /><b>Query: </b>" . $sql);
    }
}

?>