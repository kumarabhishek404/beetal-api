<?php

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version Cooliris 1.01
 */

$page = "cooliris";
include "header.php";

header('Content-Type: application/xml');

$type = trim($_GET['cooliris']);

switch ( $type )
{
	case 'album':
		$content_str = he_cooliris::get_album($_GET);
		break;
		
	case 'browse_videos':
		$content_str = he_cooliris::get_browse_videos($_GET);
		break;
		
	case 'browse_vids':
		$content_str = he_cooliris::get_browse_vids($_GET);
		break;
		
	default:
		break;
}

$output = <<<OUTPUT
<?xml version="1.0" encoding="utf-8" standalone="yes"?>
<rss version="2.0" xmlns:media="http://search.yahoo.com/mrss/" 
    xmlns:atom="http://www.w3.org/2005/Atom">
    <channel>
$content_str
    </channel>
    </rss>
OUTPUT;

echo $output;

exit();