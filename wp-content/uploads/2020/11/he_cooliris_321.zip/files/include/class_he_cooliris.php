<?php

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version Cooliris 1.01
 */

class he_cooliris
{
	function get_album( $params )
	{		
		global $owner;
		global $url;
		
		$album_id = (int)$params['album_id'];
		$album_obj = new se_album($owner->user_info['user_id']);
		
		$where_cond = ' se_media.media_album_id = ' . $album_id;
		$media_list = $album_obj->album_media_list(0, 1000, 'media_id DESC', $where_cond);
		
		$media_dir = $url->url_userdir($owner->user_info['user_id']);
		$media_url = $url->url_base . substr($media_dir, 1);
		$media_str = '';
		
		foreach ($media_list as $media_info)
		{
			$photo_title = strip_tags($media_info['media_title']);
			$photo_desc = strip_tags($media_info['media_desc']);
			
			$photo_link = $url->url_create('album_file', $owner->user_info['user_username'], $media_info['media_album_id'], $media_info['media_id']);
			$photo_link = htmlspecialchars($photo_link);
			$photo_url = $media_url . $media_info['media_id'] . '.' . $media_info['media_ext'];
			$photo_thumb_url = $media_url . $media_info['media_id'] . '_thumb.' . $media_info['media_ext'];
			
			$media_str .= <<<MEDIA
       <item>
           <title>$photo_title</title>
           <media:description>$photo_desc</media:description>
           <link>$photo_link</link>
           <media:thumbnail url="$photo_thumb_url"/>
           <media:content url="$photo_url"/>
       </item>
		
MEDIA;
		}
		
		return $media_str;
	}
	
	function get_browse_videos( $params )
	{
		global $owner, $user, $url;
		
		// PARSE GET/POST
		if ( isset($params['p']) ) { $p = $params['p']; }
		else { $p = 1; }
		
		if ( isset($params['s']) ) { $s = $params['s']; }
		else { $s = "video_datecreated DESC"; }
		
		if ( isset($params['v']) ) { $v = $params['v']; }
		else { $v = 0; }
		
		// ENSURE SORT/VIEW ARE VALID
		if ( $s != "video_datecreated DESC" && $s != "video_views DESC" && $s != "video_cache_rating_weighted DESC" ) { $s = "video_dateupdated DESC"; }
		if ( $v != "0" && $v != "1" ) { $v = 0; }
				
		// SET WHERE CLAUSE
		$where = "video_search='1' AND video_is_converted='1' AND
			(CASE
			    WHEN se_videos.video_user_id='{$user->user_info['user_id']}'
			      THEN TRUE
			    WHEN ((se_videos.video_privacy & @SE_PRIVACY_REGISTERED) AND '{$user->user_exists}'<>0)
			      THEN TRUE
			    WHEN ((se_videos.video_privacy & @SE_PRIVACY_ANONYMOUS) AND '{$user->user_exists}'=0)
			      THEN TRUE
			    WHEN ((se_videos.video_privacy & @SE_PRIVACY_FRIEND) AND (SELECT TRUE FROM se_friends WHERE friend_user_id1=se_videos.video_user_id AND friend_user_id2='{$user->user_info['user_id']}' AND friend_status='1' LIMIT 1))
			      THEN TRUE
			    WHEN ((se_videos.video_privacy & @SE_PRIVACY_SUBNET) AND '{$user->user_exists}'<>0 AND (SELECT TRUE FROM se_users WHERE user_id=se_videos.video_user_id AND user_subnet_id='{$user->user_info['user_subnet_id']}' LIMIT 1))
			      THEN TRUE
			    WHEN ((se_videos.video_privacy & @SE_PRIVACY_FRIEND2) AND (SELECT TRUE FROM se_friends AS friends_primary LEFT JOIN se_users ON friends_primary.friend_user_id1=se_users.user_id LEFT JOIN se_friends AS friends_secondary ON friends_primary.friend_user_id2=friends_secondary.friend_user_id1 WHERE friends_primary.friend_user_id1=se_videos.video_user_id AND friends_secondary.friend_user_id2='{$user->user_info['user_id']}' AND se_users.user_subnet_id='{$user->user_info['user_subnet_id']}' LIMIT 1))
			      THEN TRUE
			    ELSE FALSE
			END)";

		// ONLY MY FRIENDS' VIDEOS
		if ( $v == "1" && $user->user_exists )
		{
			// SET WHERE CLAUSE
			$where .= " AND (SELECT TRUE FROM se_friends WHERE friend_user_id1='{$user->user_info['user_id']}' AND friend_user_id2=se_videos.video_user_id AND friend_status=1)";
		}
		
		// CREATE VIDEO OBJECT
		$video = new se_video();
		
		// GET VIDEO ARRAY
		$media_str = '';
		$video_array = $video->video_list(0, 1000, $s, $where, 1);

		foreach ( $video_array as $video_info )
		{
			$video_title = strip_tags($video_info['video_title']);
			$video_desc = strip_tags($video_info['video_desc']);
			
			$video_link = $url->url_create('video', $video_info['video_author']->user_info['user_username'], $video_info['video_id']);
			$video_link = htmlspecialchars($video_link);
			
			$video_url =  ( $video_info['video_youtube_code'] ) 
					? htmlspecialchars('http://www.youtube.com/v/' . $video_info['video_youtube_code']) 
					: $url->url_base . str_replace('./', '', $video_info['video_dir']) . $video_info['video_id'] . '.flv';

			$video_type = ( $video_info['video_youtube_code'] ) ? 'application/x-shockwave-flash' : 'video/x-flv';

			$video_thumb_url = ( $video_info['video_thumb'] ) 
				? $video_info['video_dir'] . $video_info['video_id'] . '_thumb.jpg'
				: './images/video_placeholder.gif';
			
			$media_str .= <<<MEDIA
        <item>
            <title>$video_title</title>
            <media:description>$video_desc</media:description>
            <link>$video_link</link>
            <media:thumbnail url="$video_thumb_url"/>
            <media:content type="$video_type" url="$video_url"/>
        </item>
        
MEDIA;
		}
		
		return $media_str;		
	}
	
    function get_browse_vids( $params )
    {
        global $video, $user, $url, $database;
        
        if (!$video) $video = new pevid();
        
    	// PARSE GET/POST
        if ( isset($params['q']) ) { $q = trim($params['q']); } 
        else { $q = ""; }

        if ( isset($params['s']) ) { $s = $params['s']; }
        else { $s = "v"; }

        if ( isset($params['c']) ) { $c = (int)$params['c']; }
        else { $c = 1; }

        if ( isset($params['b']) ) { $b = (int)$params['b']; }
        else { $b = 0; }

        if ( isset($params['type']) ) { $type = $params['type']; }
        else { $type = "search"; }

        $vidcats = $database->database_num_rows( $database->database_query("SELECT * FROM se_vidcats WHERE vidcat_id='".$c."'") );
        
        if ( $vidcats == 0 ) { $c = 1; }

        $query = "SELECT * FROM se_vids WHERE vid_search=1 AND vid_is_converted=1";

        if ( $c > 1 )
        {
            $query .= " AND vid_cat='".$c."'";
        }

        if ( $q != '' )
        {
            $q = strip_tags($q);
            $q = mysql_real_escape_string($q);
            
            switch ($type)
            {
                case "search":
                    $query .= " AND ((vid_title like \"%$q%\") OR (vid_desc like \"%$q%\"))";
                break;

                case "tag":
                    $query .= " AND vid_tags like \"%$q%\"";
                break;

                default:
                    $query .= " AND ((vid_title like \"%$q%\") OR (vid_desc like \"%$q%\"))";
                    $type = "search";
                break;
            }
        }

        switch ( $s )
        {
            case "p":
                $query .= " ORDER BY vid_rating_value";
            break;

            case "v":
                $query .= " ORDER BY vid_views";
            break;

            case "c":
                $query .= " ORDER BY vid_datecreated";
            break;

            default:
                $query .= " ORDER BY vid_views";
                $s = "v";
            break;
        }

        switch ( $b )
        {
            case 0:
                $query .= " DESC";
            break;

            case 1:
                $query .= " ASC";
            break;

            default:
                $query .= " DESC";
                $s = 0;
            break;
        }
        
        $query .= " LIMIT 0, 1000 ";
        
        $result = $database->database_query($query);
        
        $media_str = '';
        while ( $videos = $database->database_fetch_assoc($result) )
        {
            $username = $database->database_fetch_assoc($database->database_query("SELECT user_username, user_fname, user_lname, user_photo FROM se_users WHERE user_id='" . $videos['vid_user_id'] . "'"));
            
            $video_dir = $video->video_dir($videos['vid_user_id']);
            
            $vid_locations = explode(',', $videos['vid_location']);
            $vid_current_url = $videos['vid_current_url'];
            
            if ( count($vid_locations) == 2 )
            {
            	$vid_location = he_cooliris::get_vids_embed_code($vid_locations);
                $vid_img_location = $video_dir . $videos['vid_id'] . '.jpg';
            }
            else
            {
                $vid_location = $video_dir . $vid_locations[0] . '.flv';
                $vid_img_location = $video_dir . $vid_locations[0] . '_thumb_0.jpg';
            }

            $vid_author = new se_user();
            $vid_author->user_exists = 1;
            $vid_author->user_info['user_id'] = $videos['vid_user_id'];
            $vid_author->user_info['user_username'] = $username['user_username'];
            $vid_author->user_info['user_fname'] = $username['user_fname'];
            $vid_author->user_info['user_lname'] = $username['user_lname'];
            $vid_author->user_info['user_photo'] = $username['user_photo'];
            $vid_author->user_displayname();

            $vid_privacy_max = $vid_author->user_privacy_max($user);
                       
            if( !($videos['vid_privacy'] & $vid_privacy_max) )
            {
                continue;
            }
     
            $video_title = strip_tags($videos['vid_title']);
            $video_desc = strip_tags($videos['vid_desc']);
            
            $video_link = $url->url_create('vid_file', $vid_author->user_info['user_username'], $videos['vid_id']);
            $video_link = htmlspecialchars($video_link);
            
            if ( count($vid_locations) == 2 )
            {
            	$video_url = htmlspecialchars($vid_location);  
            }
            else 
            {
            	$video_url = $url->url_base . str_replace('./', '', $vid_location);
            }

            $video_type = ( count($vid_locations) == 2  ) ? 'application/x-shockwave-flash' : 'video/x-flv';

            $video_thumb_url = ( $vid_img_location ) 
                ? $vid_img_location
                : './images/video_placeholder.gif';
            
            $media_str .= <<<MEDIA
        <item>
            <title>$video_title</title>
            <media:description>$video_desc</media:description>
            <link>$video_link</link>
            <media:thumbnail url="$video_thumb_url"/>
            <media:content type="$video_type" url="$video_url"/>
        </item>
MEDIA;
        }
        
        return $media_str;
    }
	
	function get_setting_str()
	{
		global $setting;

		$setting_str = '';
		
		if ( $setting['setting_he_cooliris_bg_image'] )
		{
			$setting_str .= '&backgroundImage=' . $setting['setting_he_cooliris_bg_image'];
		}

		if ( $setting['setting_he_cooliris_num_rows'] )
		{
			$setting_str .= '&numRows=' . $setting['setting_he_cooliris_num_rows'];
		}
		
		if ( $setting['setting_he_cooliris_theme'] )
		{
			$setting_str .= '&style=' . $setting['setting_he_cooliris_theme'];
		}

		if ( $setting['setting_he_cooliris_bg_color'] )
		{
			$setting_str .= '&backgroundColor=' . $setting['setting_he_cooliris_bg_color'];
		}
				
		if ( $setting['setting_he_cooliris_logo_image'] )
		{
			$setting_str .= '&customButton=' . $setting['setting_he_cooliris_logo_image'];
			$setting_str .= ( $setting['setting_he_cooliris_logo_url'] ) 
				? ',' . $setting['setting_he_cooliris_logo_url']
				: '';
		}

		return $setting_str;
	}
	
	function get_vids_embed_code( $vid_locations )
	{
		$content = @file_get_contents($vid_locations[0]);
		
		switch ($vid_locations[1]) 
		{
			case "youtube":
			      $vid_embed_id = substr($vid_locations[0], strpos($vid_locations[0], "=")+1);
			      $vid_embed_url = "http://www.youtube.com/v/{$vid_embed_id}";
			      break;
			      
			case "bliptv":
			      preg_match('/link rel="video_src" href="(.*?)"/', $content, $result);
			      $vid_embed_url = $result[1];
			      break;
			      
			case "break":
			      preg_match('/meta name="embed_video_url" content="(.*?)"/', $content, $result);
			      $vid_embed_url = $result[1];
			      break;
			      
			case "metacafe":
			      preg_match('/link rel="video_src" href="(.*?)"/', $content, $result);
			      $vid_embed_url = $result[1];
			      break;
			      
			case "google":
			      $vid_embed_id = substr($vid_locations[0], strpos($vid_locations[0], "=")+1);
			      $vid_embed_url = "http://video.google.com/googleplayer.swf?docid={$vid_embed_id}";
			      break;
			      
			case "vimeo":
			      preg_match('/[0-9]{1,10}/', $vid_locations[0], $match);
			      $vid_embed_id = $match[0];
			      $vid_embed_url = "http://vimeo.com/moogaloop.swf?clip_id={$vid_embed_id}&server=vimeo.com&show_title=1&show_byline=1&show_portrait=0&fullscreen=1";
			      break;
			      
			case "myspace":
			      preg_match('/link rel="video_src" href="(.*?)"/', $content, $result);
			      $vid_embed_url = $result[1];
			      break;
			      
			case "ebaumsworld":
			      preg_match('/link rel="video_src" href="(.*?)"/', $content, $result);
			      $vid_embed_url = 'http://www.ebaumsworld.com/player.swf';
			      $flashvars = explode("?", $result[1]);
			      $flashvars = $flashvars[1];
			      $vid_embed_url = $flashvars;
			      break;
       }
            
		return $vid_embed_url;
	}
	
}

?>