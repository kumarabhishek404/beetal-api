INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`)
VALUES  ('avatarstyler', 'Avatar Styler', 'Avatar Styler plugin', '5.1.0p1', 1, 'extra');
