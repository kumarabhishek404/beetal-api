<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Avatarstyler
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    Id: AdminIndexController.php 08.10.13 14:26 Ulan T $
 * @author     Ulan T
 */

/**
 * @category   Application_Extensions
 * @package    Avatarstyler
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */
class Avatarstyler_AdminIndexController extends Core_Controller_Action_Admin
{
  public function init()
  {
    // if (isset($_GET['ul']) || isset($_FILES['Filedata'])) $this->_forward('download-photo', null, null, array('format' => 'json'));


  }
  public function indexAction()
  {
//      get settings
    $settings = Engine_Api::_()->getDbtable('settings', 'core');
    $this->view->form = $form = new Avatarstyler_Form_Admin_Settings();


      $photoStrIds = $settings->fetchRow($settings->select()->where('name=?','avatarstyler.photo.ids'));

      $photoIDs = explode(",",$photoStrIds->value);

      $this->view->photoIDs = $photoIDs;

      if (!$this->getRequest()->isPost()) {
          return;
      }
      if (!$form->isValid($this->getRequest()->getParams())) {
          return;
      }
      $params = $form->getValues();
      $settings->__set('avatarstyler.usage', $params['usage']);

    echo '<script> window.location.href = window.location.href; </script>'; die;



  }

  public function removePhotoAction()
  {

//      get id of removing photo
      $id = $this->_getParam('id');
    $settings = Engine_Api::_()->getDbtable('images', 'avatarstyler');
    $photoStrIds = $settings->fetchRow($settings->select()->where('photo_id=?', $id));
    $photoStrIds->delete();
//      Delete photo from Storage
      $tableS = Engine_Api::_()->getDbTable('files', 'storage');
      $rowS = $tableS->fetchRow($tableS->select()->where('file_id=?', $id));
      $rowS->delete();

  }

  public function downloadPhotoAction()
  {

    try {
      if (!$this->_helper->requireUser()->checkRequire()) {
        $this->view->status = false;
        $this->view->error = Zend_Registry::get('Zend_Translate')->_('Max file size limit exceeded (probably).');
        return;
      }

      if (!$this->getRequest()->isPost()) {
        $this->view->status = false;
        $this->view->error = Zend_Registry::get('Zend_Translate')->_('Invalid request method');
        return;
      }

      $values = $this->getRequest()->getPost();

      if (empty($_FILES['Filedata'])) {
        $this->view->status = false;
        $this->view->error = Zend_Registry::get('Zend_Translate')->_('No file');
        return;
      }

      if (!isset($_FILES['Filedata']) || !is_uploaded_file($_FILES['Filedata']['tmp_name'])) {
        $this->view->status = false;
        $this->view->error = Zend_Registry::get('Zend_Translate')->_('Invalid Upload');
        return;
      }
    } catch (Exception $e) {
      $e->getMessage();
    }
    try {
      $cover = $this->setUploadPhoto($_FILES['Filedata']);
      $file['id'] = $cover->file_id;
      $file['url'] = $cover->storage_path;
      $photoTable = Engine_Api::_()->getDbTable('images','avatarstyler');
      $row = $photoTable->createRow();
      $row->photo_id = $file['id'];
      $row->photo_url = $file['url'];
      $row->save();
      $this->view->status = true;
      $this->view->photo_id = $file['id'];
      $this->view->url = $file['url'];
      $this->sendJson([
          'id' => $file['id'],
          'photo_id' => $file['id'],
          'status' => true,
          'url' => $file['url'],
          'fileName' => $_FILES['Filedata']['name']

      ]);
    } catch (Exception $e) {
      $this->view->status = false;
      $this->view->error = Zend_Registry::get('Zend_Translate')->_('An error occurred.');

      return;
    }
  }
  public function setUploadPhoto($photo)
  {
    $settings = Engine_Api::_()->getDbtable('settings', 'core');
    $viewer = Engine_Api::_()->user()->getViewer();
    if ($photo instanceof Zend_Form_Element_File) {
      $file = $photo->getFileName();
      $fileName = $file;
    } else if ($photo instanceof Storage_Model_File) {
      $file = $photo->temporary();
      $fileName = $photo->name;
    } else if ($photo instanceof Core_Model_Item_Abstract && !empty($photo->file_id)) {
      $tmpRow = Engine_Api::_()->getItem('storage_file', $photo->file_id);
      $file = $tmpRow->temporary();
      $fileName = $tmpRow->name;
    } else if (is_array($photo) && !empty($photo['tmp_name'])) {
      $file = $photo['tmp_name'];
      $fileName = $photo['name'];
    } else if (is_string($photo) && file_exists($photo)) {
      $file = $photo;
      $fileName = $photo;
    } else {
      throw new User_Model_Exception('invalid argument passed to setPhoto');
    }
    if (!$fileName) {
      $fileName = $file;
    }
    $extension = ltrim(strrchr(basename($fileName), '.'), '.');
    $base = rtrim(substr(basename($fileName), 0, strrpos(basename($fileName), '.')), '.');
    $path = APPLICATION_PATH . DIRECTORY_SEPARATOR . 'temporary';


    $filesTable = Engine_Api::_()->getDbtable('files', 'storage');

    // Resize image (main)
    $mainPath = $path . DIRECTORY_SEPARATOR . $base . '_m.' . $extension;
    $image = Engine_Image::factory();
    $image->open($file)
      ->resize(720, 720)
      ->write($mainPath)
      ->destroy();

    // Resize image (profile)
    $profilePath = $path . DIRECTORY_SEPARATOR . $base . '_p.' . $extension;
    $image = Engine_Image::factory();
    $image->open($file)
      ->resize(200, 400)
      ->write($profilePath)
      ->destroy();

    // Resize image (normal)
    $normalPath = $path . DIRECTORY_SEPARATOR . $base . '_in.' . $extension;
    $image = Engine_Image::factory();
    $image->open($file)
      ->resize(140, 160)
      ->write($normalPath)
      ->destroy();

    // Resize image (icon)
    $squarePath = $path . DIRECTORY_SEPARATOR . $base . '_is.' . $extension;
    $image = Engine_Image::factory();
    $image->open($file);

    $size = min($image->height, $image->width);
    $x = ($image->width - $size) / 2;
    $y = ($image->height - $size) / 2;

    $image->resample($x, $y, $size, $size, 48, 48)
      ->write($squarePath)
      ->destroy();

    $params = array(
      'parent_type' => $viewer->getType(),
      'parent_id' => $viewer->getIdentity(),
      'user_id' => $viewer->getIdentity(),
      'name' => basename($fileName),
    );
    // Store
    $iMain = $filesTable->createFile($mainPath, $params);
    // INSERT the new row to the database
    $iProfile = $filesTable->createFile($profilePath, $params);
    $iIconNormal = $filesTable->createFile($normalPath, $params);
    $iSquare = $filesTable->createFile($squarePath, $params);
    $iMain->bridge($iProfile, 'thumb.profile');
    $iMain->bridge($iIconNormal, 'thumb.normal');
    $iMain->bridge($iSquare, 'thumb.icon');

    // Remove temp files
    @unlink($mainPath);
    @unlink($profilePath);
    @unlink($normalPath);
    @unlink($squarePath);
    return $iMain;
  }


}
