
HE_Phrase = function(lang_id, second_lang_id){
	//vars
	var current_tab = 'browse';
	var current_page = 1;
	var phrases_per_page = 20;
	var language_id = lang_id;
	var highest_id_missing = 0;
	var highest_id_translate = 0;
	var second_language_id = second_lang_id;
	
	//methods
	this.init = function() {
		var bind = this;
		
		$('phrase_result_close_added').addEvent('click', function(){
				$('phrase_result_added').style.display = 'none';
		});
		
		//browse phrases
		$('phrase_button').addEvent('click', function(){ bind.search_phrases(1); });
		$('page_link_last').addEvent('click', function(){ bind.go_last_page(); });
		$('page_link_next').addEvent('click', function(){ bind.go_next_page(); });
		this.search_phrases(1);
		
		//missing values
		$('phrase_tab_missing').addEvent('click', function(){ bind.get_missing_value_phrases(false) });
		$('phrase_more_missing').addEvent('click', function(){ bind.get_missing_value_phrases(true) });
		$('change_second_langauge_missing').addEvent('change', function(){ bind.set_second_language_id($('change_second_langauge_missing').value); bind.get_missing_value_phrases(false) });
		
		//translate values
		$('phrase_tab_translate').addEvent('click', function(){ bind.get_translate_phrases(false) });
		$('phrase_more_translate').addEvent('click', function(){ bind.get_translate_phrases(true) });
		$('change_second_langauge_translate').addEvent('change', function(){ bind.set_second_language_id($('change_second_langauge_translate').value); bind.get_translate_phrases(false) });
	},
	
	this.activate_tab = function(tab){
		$('phrase_body_' + current_tab).style.display = 'none';
		$('phrase_body_' + tab).style.display = '';
		$('phrase_tab_' + current_tab).set('class','phrase_inactive');
		$('phrase_tab_' + tab).set('class', 'phrase_active');
		current_tab = tab;
		
		if( tab == 'add' ) {
			this.generate_new_phrase_id();
		}
	}
	
	this.generate_new_phrase_id = function() {
		var currentDate = new Date();
		$('new_phrase_loading').style.display = '';
		$('new_phrase_id').style.display = 'none';
		new Request({
			method : 'get',
			url : 'admin_language_tools_ajax.php?task=generate_phrase_id&s=' + currentDate.getSeconds(),
			onSuccess : function(response) {
				$('new_phrase_loading').style.display = 'none';
				$('new_phrase_id').style.display = '';
				$('new_phrase_id').value = response;
			}
		}).send();
	}
	
	this.add_phrase = function() {
		var currentDate = new Date();
		var data = new Object();
		var bind = this;
		
		$('phrase_body_add').getElements('textarea').each(function(el){ data[el.name] = el.value; });
		new Request.JSON({
			method : 'get',
			url : 'admin_language_tools_ajax.php?task=add_phrase&s=' + currentDate.getSeconds(),
			data : { 'phrase_id':$('new_phrase_id').value, 'location':$('new_phrase_location').value, 'values' : data },
			onSuccess : function(response) {
				bind.show_result_message(response.status, response.message, 'added');
				bind.reset_add_phrase();
			}
		}).send();
	}
	
	this.cancel_add_phrase = function(){
		this.activate_tab('browse');
	}
	
	this.reset_add_phrase = function() {
		$('new_phrase_location').value = '';
		$('phrase_body_add').getElements('textarea').each(function(el){ el.value = ''; });
		this.generate_new_phrase_id();
	}
	
	this.show_result_message = function(is_success, message, type) {
		$('phrase_result_' + type).style.display = '';
		if( is_success )
			$('phrase_result_inner_' + type).innerHTML = '<div class="phrase_success">' + message + '</div>';
		else
			$('phrase_result_inner_' + type).innerHTML = '<div class="phrase_error">' + message + '</div>';
	}

	
	this.go_last_page = function()
	{
		this.search_phrases(current_page-1);
	}
	
	this.go_next_page = function()
	{
		this.search_phrases(current_page+1);
	}
	
	this.search_phrases = function(page)
	{
		if( !page )
			page = 1;
		current_page = page;
		var bind = this;
		
		this.show_loading('phrases', 'normal');
		var request = new Request.JSON({
			url : 'admin_language_tools_ajax.php',
			method : 'post',
			data : {
				'task'  : 'search',
				'language_id'  : language_id,
				'phrase_id'  : $('phrase_id').value,
				'phrase_value'  : $('phrase_value').value,
				'phrase_location'  : $('phrase_location').value,
				'page' : page,
				'per_page' : phrases_per_page
			},
			'onComplete' : function(responseObject, responseText){
				bind.show_phrases(responseObject);
			}
		});
		request.send();
	}
	
	this.show_phrases = function(response)
	{
		var phrases = $('phrases');
		phrases.empty();
		if( response.count > phrases_per_page )
		{
			$('phrase_pagination').style.display='block';
			
			//page link last set up
			if( current_page!=1 )
			{
				$('page_last').style.display='none';
				$('page_link_last').style.display='inline';
			}
			else
			{
				$('page_last').style.display='inline';
				$('page_link_last').style.display='none';
			}
			
			//page link next set up
			if( current_page * phrases_per_page > response.count )
			{
				$('page_next').style.display='inline';
				$('page_link_next').style.display='none';
			}
			else
			{
				$('page_next').style.display='none';
				$('page_link_next').style.display='inline';
			}
			
			$('items_from').set('text', current_page*phrases_per_page-phrases_per_page+1);
			$('items_to').set('text', current_page*phrases_per_page);
			$('items_total').set('text', response.count);
		}
		else
		{
			$('phrase_pagination').style.display='none';
		}
		
		var index = 0;
		response.rows.each(function(obj, id){
			//insert row
			var row = document.createElement('div');
			row.id = 'tr_' + obj.languagevar_id;
			row.className = 'phrase';
			phrases.appendChild(row);
		
			//insert id
			var cell_id = document.createElement('div');
			cell_id.innerHTML = obj.languagevar_id;
			cell_id.className = 'phrase_id';
			row.appendChild(cell_id);
			
			//insert edit link
			var cell_link = document.createElement('div');
			cell_link.className = 'phrase_link';
			row.appendChild(cell_link);
			var edit_link = document.createElement('a');
			edit_link.href = "javascript:editPhrase(" + obj.languagevar_id + ", " + index +");";
			edit_link.innerHTML = '[edit]';
			cell_link.appendChild(edit_link);
			
			//insert value
			var cell_value = document.createElement('div');
			cell_value.innerHTML = obj.languagevar_value;
			cell_value.className = 'phrase_value';
			cell_value.id = 'value_' + obj.languagevar_id;
			row.appendChild(cell_value);
			
			//insert location
			var cell_location = document.createElement('div');
			cell_location.innerHTML = obj.languagevar_default;
			cell_location.className = 'phrase_location';
			cell_location.id = 'location_' + obj.languagevar_id;
			row.appendChild(cell_location);
			
			var cell_clear = document.createElement('div');
			cell_clear.className = 'phrase_clear';
			row.appendChild(cell_clear);
			
			index++;
		});
	}

	
	this.show_editable_phrases = function(response, cont_id, append, full_edit) {
		var phrases = $(cont_id);
		if( !append )
			phrases.empty();
		var index = 0;
		
		response.rows.each(function(obj, id){
			var uid = cont_id + '_' + obj.languagevar_id;
			//insert row
			var row = document.createElement('div');
			row.className = 'phrase';
			phrases.appendChild(row);
		
			//insert id
			var cell_id = document.createElement('div');
			cell_id.innerHTML = obj.languagevar_id;
			cell_id.className = 'phrase_id';
			row.appendChild(cell_id);
			
			//insert location
			if( !obj.languagevar_default ) obj.languagevar_default = '';
			var cell_location = document.createElement('div');
			cell_location.innerHTML = obj.languagevar_default;
			cell_location.className = 'phrase_location';
			row.appendChild(cell_location);
			
			//insert value
			var cell_value = document.createElement('div');
			cell_value.className = 'phrase_value';
			cell_value.id = 'value_' + uid;
			cell_value.innerHTML = '<textarea class="text" id="input_' + uid + '" onblur="phrase.update_phrase(' + obj.languagevar_id + ', ' + language_id +', this.value, \'' + cell_value.id + '\', \'input_' + uid + '\');">' + obj.languagevar_value + '</textarea>';
			row.appendChild(cell_value);
			
			//insert second value
			if( second_language_id )
			{
				var cell_value2 = document.createElement('div');
				if( !obj.second_value )
					obj.second_value = '';
				
				cell_value2.className = 'phrase_value2';
				cell_value2.id = 'value2_' + uid;
				if( full_edit )
					cell_value2.innerHTML = '<textarea class="text" id="input2_' + uid + '" onblur="phrase.update_phrase(' + obj.languagevar_id + ', ' + second_language_id +', this.value, \'' + cell_value2.id + '\', \'input2_' + uid + '\');">' + obj.second_value + '</textarea>';
				else
					cell_value2.innerHTML = obj.second_value;
				row.appendChild(cell_value2);
			}
			
			//clear floating
			var cell_clear = document.createElement('div');
			cell_clear.className = 'phrase_clear';
			row.appendChild(cell_clear);
			
			index++;
		});
	}
	
	this.get_missing_value_phrases = function(append) {
		var bind = this;
		
		if( !append ) highest_id_missing = 0;
		
		this.show_loading('phrase_more_missing_loader', 'small');
		new Request.JSON({
			method : 'get',
			url : 'admin_language_tools_ajax.php',
			data : {
				'task'  : 'get_missing_value_phrases',
				'language_id'  : language_id,
				'second_language_id'  : second_language_id,
				'highest_phrase_id'  : highest_id_missing
			},
			onSuccess : function(response){
				$('missing_total').set('text', response.count);
				if( !response.highest_phrase_id )
					$('phrase_more_missing').style.display = 'none';
				else
				{
					highest_id_missing = response.highest_phrase_id;
					bind.show_editable_phrases(response, 'missing', append, false);
				}
				bind.hide_loading('phrase_more_missing_loader');
			}
		}).send();
	}
	
	this.get_translate_phrases = function(append) {
		var bind = this;
		
		if( !append ) highest_id_translate = 0;
		
		this.show_loading('phrase_more_translate_loader', 'small');
		new Request.JSON({
			method : 'get',
			url : 'admin_language_tools_ajax.php',
			data : {
				'task'  : 'get_translate_phrases',
				'language_id'  : language_id,
				'second_language_id'  : second_language_id,
				'highest_phrase_id'  : highest_id_translate
			},
			onSuccess : function(response){
				$('translate_total').set('text', response.count);
				if( !response.highest_phrase_id )
					$('phrase_more_translate').style.display = 'none';
				else
				{
					highest_id_translate = response.highest_phrase_id;
					bind.show_editable_phrases(response, 'translate', append, true);
				}
				bind.hide_loading('phrase_more_translate_loader');
			}
		}).send();
	}
	
	this.set_second_language_id = function(lang_id) {
		if( language_id != lang_id ) second_language_id = lang_id;
	}
	
	this.update_phrase = function(phrase_id, lang_id, new_value, cont_id, input_id){
		if( new_value.length < 1 ) return;
		
		var cont_html = $(cont_id).innerHTML;
		$(cont_id).innerHTML = '<img src="../images/icons/language_tool_loading.gif" />';
		
		new Request.JSON({
			method : 'get',
			url : 'admin_language_tools_ajax.php',
			data : {
				'task'  : 'update_phrase',
				'phrase_id'  : phrase_id,
				'language_id'  : lang_id,
				'value'  : new_value
			},
			onSuccess : function(response){
				if( response.status )
					$(cont_id).innerHTML = '<span class="phrase_success">' + response.message + '</span>';
				else
					$(cont_id).innerHTML = '<span class="phrase_error">' + response.message + '</span>';
				
				setTimeout("$('" + cont_id + "').innerHTML=unescape('" + escape(cont_html) + "');  $('" + input_id + "').value=unescape('" + escape(new_value) + "');", 2000);
			}
		}).send();
	}
	
	this.show_loading = function(id, size) {
		$(id).style.display='';
		$(id).empty();
		var loading = document.createElement('div');
		if( size=='small' )
			loading.className = 'phrase_loading_small';
		else
			loading.className = 'phrase_loading';
		$(id).appendChild(loading);
	}
	
	this.hide_loading = function(id) {
		$(id).style.display='none';
	}
}
