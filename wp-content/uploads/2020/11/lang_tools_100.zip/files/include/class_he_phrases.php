<?
define('HE_PHRASE_ID_STARTS', 69630000);
define('HE_PHRASE_ID_ENDS', 69669600);
define('HE_STATUS_ADD_PHRASE_INCORRECT_DATA', 1);
define('HE_STATUS_ADD_PHRASE_ID_EXIST', 2);
define('HE_STATUS_ADD_PHRASE_SUCCESS', 4);

class he_phrases {
	function get_phrases($language_id, $value, $location, $from, $count) {
		global $database;
	
		$language_id = intval($language_id);
		$value = mysql_escape_string(trim($value));
		$location = mysql_escape_string(trim($location));
		$conditions = array();
		$where_q = null;
		
		$conditions[] = "`languagevar_language_id`=$language_id";
		
		if( $value )
			$conditions[] = "`languagevar_value` LIKE '%$value%'";
		if( $location )
			$conditions[] = "`languagevar_default` LIKE '%$location%'";
		
		if( $conditions )
			$where_q = " WHERE ".implode(" AND ", $conditions);
		
		
		$query = "SELECT * FROM `se_languagevars` $where_q ORDER BY languagevar_id LIMIT $from, $count";
		$query_count = "SELECT COUNT(`languagevar_id`) FROM `se_languagevars` $where_q";
		
		$rows = array();
		$res = $database->database_query($query);
		while($row = $database->database_fetch_assoc($res)) {
			$rows[] = $row;
		}
		
		$res_count = $database->database_query($query_count);
		$count = $database->database_fetch_array($res_count);
		
		return array('rows'=>$rows, 'count'=>$count[0]);
	}
	
	function get_missing_value_phrases($language_id, $second_language_id = 0, $highest_phrase_id = 0, $count = 20) {
		global $database;
		
		$language_id = intval($language_id);
		$second_language_id = intval($second_language_id);
		$highest_phrase_id = intval($highest_phrase_id);
		$count = intval($count);
		if( $language_id < 1 )
			return array();
		
		$res = $database->database_query("SELECT l1.languagevar_id,l1.languagevar_default FROM `se_languagevars` as l1 
			LEFT JOIN se_languagevars as l2 ON(l1.languagevar_id=l2.languagevar_id AND l2.`languagevar_language_id`=$language_id)
			WHERE l1.languagevar_id>$highest_phrase_id AND (l2.languagevar_id IS NULL OR l2.languagevar_value='') GROUP BY l1.languagevar_id ORDER BY l1.languagevar_id LIMIT $count");
		
		$rows = array();
		while($row = $database->database_fetch_assoc($res))
		{
			if( $second_language_id )
			{
				$second = $database->database_fetch_assoc($database->database_query("SELECT languagevar_value FROM `se_languagevars` WHERE languagevar_id={$row['languagevar_id']} AND `languagevar_language_id`=$second_language_id"));
				$row['second_value'] = $second['languagevar_value'];
			}
			$row['languagevar_value'] = '';
			$rows[] = $row;
		}
		
		return $rows;
	}
	
	function get_missing_value_phrases_count($language_id) {
		global $database;
		
		$language_id = intval($language_id);
		if( $language_id < 1 )
			return 0;
		
		$res = $database->database_query("SELECT COUNT(DISTINCT l1.languagevar_id) FROM `se_languagevars` as l1 
			LEFT JOIN se_languagevars as l2 ON(l1.languagevar_id=l2.languagevar_id AND l2.`languagevar_language_id`=$language_id)
			WHERE l2.languagevar_id IS NULL OR l2.languagevar_value=''");
		$row = $database->database_fetch_array($res);
		return $row[0];
	}
	
	function get_translation_phrases($language_id, $second_language_id = 0, $highest_phrase_id = 0, $count = 20) {
		global $database;
		
		$language_id = intval($language_id);
		$second_language_id = intval($second_language_id);
		$highest_phrase_id = intval($highest_phrase_id);
		$count = intval($count);
		if( $language_id < 1 )
			return array();
		
		$res = $database->database_query("SELECT languagevar_id,languagevar_default,languagevar_value FROM `se_languagevars` WHERE languagevar_id>$highest_phrase_id AND `languagevar_language_id`=$language_id ORDER BY languagevar_id LIMIT $count");
		
		$rows = array();
		while($row = $database->database_fetch_assoc($res))
		{
			if( $second_language_id )
			{
				$second = $database->database_fetch_assoc($database->database_query("SELECT languagevar_value FROM `se_languagevars` WHERE languagevar_id={$row['languagevar_id']} AND `languagevar_language_id`=$second_language_id"));
				$row['second_value'] = $second['languagevar_value'] ? $second['languagevar_value'] : '';
			}
			$rows[] = $row;
		}
		
		return $rows;
	}

	function get_translation_phrases_count($language_id) {
		global $database;
		
		$language_id = intval($language_id);
		if( $language_id < 1 )
			return 0;
		
		$row = $database->database_fetch_array($database->database_query("SELECT COUNT(languagevar_id) FROM `se_languagevars` WHERE `languagevar_language_id`=$language_id"));
		return $row[0];
	}
		
	function get_phrase($language_id, $phrase_id) {
		global $database;
		
		$language_id = intval($language_id);
		$phrase_id = intval($phrase_id);
		if( $phrase_id < 1 || $language_id < 1 )
			return array();
		
		$res = $database->database_query("SELECT * FROM `se_languagevars` WHERE `languagevar_id`=$phrase_id AND `languagevar_language_id`=$language_id");
		return $database->database_fetch_assoc($res);
	}
	
	function get_locations($language_id, $name, $limit)
	{
		global $database;
		
		$language_id = intval($language_id);
		$name = mysql_escape_string(trim($name));
		$limit = intval($limit) < 3 ? 5 : intval($limit);
		
		$rows = array();
		$res = $database->database_query("SELECT `languagevar_default` FROM `se_languagevars` WHERE `languagevar_language_id`=$language_id AND `languagevar_default` LIKE '%$name%' GROUP BY `languagevar_default` LIMIT $limit");
		while($row = $database->database_fetch_assoc($res)) {
			$rows[] = $row;
//			$rows[] = $row['languagevar_default'];
		}
		
		return $rows;
	}
	
	function is_location_was_added($array, $value)
	{
		//check if items are unique
		$already_added = false;
		foreach ($array as $item)
			if( $item['value']==$value )
			{
				$already_added = true;
				break;
			}
		return $already_added;
	}
	
	function generate_phrase_id() {
		global $database;
		
		srand();
		$id = rand(HE_PHRASE_ID_STARTS, HE_PHRASE_ID_ENDS);
		
		//check if this id exists in database
		return ( he_phrases::is_phrase_id_exists($id) ) ? he_phrases::generate_phrase_id() : $id;
	}
	
	function is_phrase_id_exists($id) {
		global $database;
		
		return ( $database->database_fetch_array($database->database_query("SELECT `languagevar_id` FROM `se_languagevars` WHERE `languagevar_id`=$id LIMIT 1")) );
	}
	
	function add_phrase($phrase_id, $location, $values) {
		global $database;
		
		$phrase_id = intval($phrase_id);
		$location = mysql_escape_string(trim($location));
		if( !is_array($values) || !$values || $phrase_id < 1 )
			return HE_STATUS_ADD_PHRASE_INCORRECT_DATA;

		if( he_phrases::is_phrase_id_exists($phrase_id) )
			return HE_STATUS_ADD_PHRASE_ID_EXIST;
		
		foreach ( $values as $lang_id => $value )
		{
			$lang_id = intval($lang_id);
			$value = mysql_escape_string($value);
			if( $lang_id > 0 )
				$database->database_query("INSERT INTO `se_languagevars` SET `languagevar_id`=$phrase_id,`languagevar_language_id`=$lang_id,`languagevar_value`='$value',`languagevar_default`='$location'");
		}
		
		return HE_STATUS_ADD_PHRASE_SUCCESS;
	}
	
	
	function update_phrase($language_id, $phrase_id, $value) {
		global $database;
		
		$phrase_id = intval($phrase_id);
		$language_id = intval($language_id);
		$value = mysql_escape_string(trim($value));
		if( $phrase_id < 1 || $language_id < 1)
			return false;
		
		if( $database->database_fetch_array($database->database_query("SELECT `languagevar_id` FROM `se_languagevars` WHERE `languagevar_id`=$phrase_id AND languagevar_language_id=$language_id")) )
		{
			$database->database_query("UPDATE `se_languagevars` SET languagevar_value='$value' WHERE `languagevar_id`=$phrase_id AND languagevar_language_id=$language_id");
		}
		else 
		{
			$location = $database->database_fetch_assoc($database->database_query("SELECT `languagevar_default` FROM `se_languagevars` WHERE `languagevar_id`=$phrase_id AND languagevar_language_id!=$language_id AND languagevar_default!='' LIMIT 1"));
			$location = $location['languagevar_default'] ? mysql_escape_string($location['languagevar_default']) : '';
			$database->database_query("INSERT INTO `se_languagevars` SET `languagevar_id`=$phrase_id,languagevar_language_id=$language_id,languagevar_default='$location',languagevar_value='$value'");
		}

		return true;
	}
}
?>