<?

$plugin_name = "Power Language Tools Plugin";
$plugin_version = "1.00";
$plugin_type = "language_tool";
$plugin_desc = "This plugin allows you to easily manage phrases on your site. Now you can: quickly browse phrases in ajax based interface; search phrases by their location; edit not only phrase value but also its location; add new phrases; find all phrases which doesn't have value in the language(missing value feature); easily translate all phrases from choosed existing language to new one. Please go to <a href=\"http://www.hire-experts.com/\">Hire-Experts.com</a> to get this plugin latest version.";
$plugin_icon = "language_tool_i16.png";
$plugin_menu_title = "";
$plugin_pages_main = "696696001<!>language_tool_i16.png<!>admin_language_tools.php<~!~>";
$plugin_pages_level = "";
$plugin_url_htaccess = "";
$plugin_db_charset = 'utf8';
$plugin_db_collation = 'utf8_unicode_ci';


if($install == "language_tool") {
	
	//check if plugin was already installed
	$sql = "SELECT * FROM se_plugins WHERE plugin_type='$plugin_type' LIMIT 1";
	$resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
	
	$plugin_info = array();
	if( $database->database_num_rows($resource) )
		$plugin_info = $database->database_fetch_assoc($resource);
	
	
	//install plugin
	if( !$plugin_info ) {
		$database->database_query("INSERT INTO se_plugins (plugin_name,
			plugin_version,
			plugin_type,
			plugin_desc,
			plugin_icon,
			plugin_menu_title,
			plugin_pages_main,
			plugin_pages_level,
			plugin_url_htaccess
			) VALUES (
			'$plugin_name',
			'$plugin_version',
			'$plugin_type',
			'".str_replace("'", "\'", $plugin_desc)."',
			'$plugin_icon',
			'',
			'$plugin_pages_main',
			'',
			'$plugin_url_htaccess')");
	
	
	//update plugin
	} else {
		$database->database_query("UPDATE se_plugins SET plugin_name='$plugin_name',
			plugin_version='$plugin_version',
			plugin_desc='".str_replace("'", "\'", $plugin_desc)."',
			plugin_icon='$plugin_icon',
			plugin_menu_title='',
			plugin_pages_main='$plugin_pages_main',
			plugin_pages_level='',
			plugin_url_htaccess='$plugin_url_htaccess' WHERE plugin_type='$plugin_type'");
	}
	
	//insert langs
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696001 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696001', '1', 'Power Language Tools', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696002 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696002', '1', 'Languages', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696003 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696003', '1', 'Browse Phrases', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696004 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696004', '1', 'Phrase ID:', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696005 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696005', '1', 'Partial Phrase:', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696006 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696006', '1', 'Phrase Location:', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696007 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696007', '1', 'OR', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696008 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696008', '1', 'Search', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696009 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696009', '1', 'viewing result', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696010 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696010', '1', 'Last Page', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696011 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696011', '1', 'Next Page', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696012 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696012', '1', 'ID', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696013 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696013', '1', 'Phrase', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696014 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696014', '1', 'Location', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696015 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696015', '1', 'There are no language variables in this language matching your search phrase.', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696016 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696016', '1', 'Change your phrases in the languages below:', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696017 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696017', '1', 'Change phrase location:', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696018 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696018', '1', 'Save Changes', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696019 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696019', '1', 'Cancel', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696020 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696020', '1', 'Edit phrase', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696021 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696021', '1', 'Add new phrase', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696022 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696022', '1', 'Phrase Location', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696023 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696023', '1', 'We recommend you to use location field. It helps you to know where this phrase is used. Example: you can use \"event.create\" location for \"Create\" button\'s label on create a new event page', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696024 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696024', '1', 'Enter your phrases in the languages below:', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696025 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696025', '1', 'Create', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696026 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696026', '1', 'Phrase Id', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696027 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696027', '1', 'Use this id in your template. Sample: {lang_print id=HereID}', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696028 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696028', '1', 'This form allows you to add new phrases.', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696029 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696029', '1', 'Incorrect data. Please check fields below and try again.', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696030 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696030', '1', '%1$s exists in database. Please type another phrase id or just click \"generate phrase id\" to get unique id.', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696031 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696031', '1', 'The phrase has been successfully inserted. Phrase ID: <b>%1$s</b>', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696032 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696032', '1', 'Generate Phrase Id', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696033 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696033', '1', 'Missing values', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696034 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696034', '1', 'Here a list of phrases with empty values for %1$s language. Total:', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696035 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696035', '1', 'Saved', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696036 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696036', '1', 'Failed', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696037 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696037', '1', 'more', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696038 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696038', '1', 'Translate Tool', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696039 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696039', '1', 'Here you can easily translate phrases into a new language. First of all, choose base language from the left top then choose a second language in the drop down. Now you can edit base and the second language phrases. Don\'t worry about clicking save button - it automatically saves changes. Total phrases in base language:', 'admin_language_tools')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_language_id=1 AND languagevar_id=696696040 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES('696696040', '1', 'This plugin allows you to easily manage phrases on your site. Now you can: quickly browse phrases in ajax based interface; search phrases by their location; edit not only phrase value but also its location; add new phrases; find all phrases which doesn\'t have value in the language(missing value feature); easily translate all phrases from choosed existing language to new one.', 'admin_language_tools')");	

}  

?>