<?php
$page = "admin_language_tools";
include "admin_header.php";

// GET LANGUAGE PACK LIST
$lang_packlist = SE_Language::list_packs();
ksort($lang_packlist);
$lang_packlist = array_values($lang_packlist);


if(isset($_POST['language_id'])) { $language_id = $_POST['language_id']; } elseif(isset($_GET['language_id'])) { $language_id = $_GET['language_id']; } else { $language_id = 0; }
if( $language_id )
	$language = $database->database_fetch_assoc($database->database_query("SELECT * FROM se_languages WHERE language_id='$language_id'"));

if( !$language ) 
	$language = $database->database_fetch_assoc($database->database_query("SELECT * FROM se_languages WHERE language_default LIMIT 1"));


//choose second language
$is_multilanguage = (count($lang_packlist));
if( $is_multilanguage )
{
	foreach ($lang_packlist as $lang)
		if( $lang['language_id']!=$language['language_id'] )
		{
			$second_language_id = $lang['language_id'];
			break;
		}
}
else 
	$second_language_id = 0;


$smarty->assign('se_version', intval(str_replace('.', '', $version)));
$smarty->assign_by_ref('language', $language);
$smarty->assign('lang_packlist', $lang_packlist);
$smarty->assign('is_multilanguage', $is_multilanguage);
$smarty->assign('second_language_id', intval($second_language_id));
include "admin_footer.php";
?>