<?
define('SE_PAGE_AJAX', TRUE);
$page = "admin_language_tools_ajax";
include "admin_header.php";
include "../include/class_he_phrases.php";

$result = array();
$per_page = intval($_REQUEST['per_page']);
$task = $_POST['task'] ? $_POST['task'] : $_GET['task'];
$language_id = $_POST['language_id'] ? $_POST['language_id'] : $_GET['language_id'];
$phrase_id = $_POST['phrase_id'] ? $_POST['phrase_id'] : $_GET['phrase_id'];
$is_json_response = false;

if( $task=='search' )
{
	$phrase_id = $_POST['phrase_id'];
	$value = $_POST['phrase_value'];
	$location = $_POST['phrase_location'];
	$page = intval($_POST['page']) > 0 ? intval($_POST['page']) : 1;
	$count = $per_page;
	$from = $page * $per_page - $count;
	
	if( $phrase_id )
	{
		$phrase = he_phrases::get_phrase($language_id, $phrase_id);
		$result = array('rows'=>array($phrase), 'count'=>1);
	}
	else
	{
		$result = he_phrases::get_phrases($language_id, $value, $location, $from, $count);
	}
	
	$is_json_response = true;
}


elseif( $task=='get_missing_value_phrases' )
{
	$phrases = he_phrases::get_missing_value_phrases($language_id, $_GET['second_language_id'], $_GET['highest_phrase_id'], 20);
	$result = array('rows'=>$phrases, 'count'=>he_phrases::get_missing_value_phrases_count($language_id), 'highest_phrase_id'=>$phrases[count($phrases)-1]['languagevar_id']);
	$is_json_response = true;
}


elseif( $task=='get_translate_phrases' )
{
	$phrases = he_phrases::get_translation_phrases($language_id, $_GET['second_language_id'], $_GET['highest_phrase_id'], 20);
	$result = array('rows'=>$phrases, 'count'=>he_phrases::get_translation_phrases_count($language_id), 'highest_phrase_id'=>$phrases[count($phrases)-1]['languagevar_id']);
	$is_json_response = true;
}


elseif( $task=='get_locations' )
{
	$input = $_GET['input'];
	$limit = 20;
	$locations = he_phrases::get_locations($language_id, $input, $limit+10);
	
	$handled = array();
	foreach ($locations as $location)
	{
		if( count($handled)>=$limit )
			break;
		
		$val = $location['languagevar_default'];
		if( !strlen($val) )
			continue;
		
		if( strstr($val, ',')!==false )
		{
			$seperated = explode(',', $val);
			foreach ($seperated as $sep)
			{
				if( count($handled)>=$limit )
					break;
				
				$sep = trim($sep);
				if( strstr($sep, $input)!==false )
				{
					if( !he_phrases::is_location_was_added($handled, $sep) )
						$handled[] = array('value'=>$sep, 'info'=>$sep);
				}
			}
		}
		else
		{
			if( !he_phrases::is_location_was_added($handled, $item) )
				$handled[] = array('value'=>$val, 'info'=>$val);
		}
	}
	
//	print_arr($locations);
	$result = array('results' => $handled);
	$is_json_response = true;
}


elseif ( $task == 'generate_phrase_id' ) {
	$result = he_phrases::generate_phrase_id();
}


elseif ( $task == 'add_phrase' ) {
	switch ( he_phrases::add_phrase($_REQUEST['phrase_id'], $_REQUEST['location'], $_REQUEST['values']) )
	{
		case HE_STATUS_ADD_PHRASE_INCORRECT_DATA:
			$result['message'] = SE_Language::_get(696696029);
			$result['status'] = 0;
			break;
		case HE_STATUS_ADD_PHRASE_ID_EXIST:
			$result['message'] = SE_Language::get(696696030, array($_REQUEST['phrase_id']));
			$result['status'] = 0;
			break;
		case HE_STATUS_ADD_PHRASE_SUCCESS:
			$result['message'] = SE_Language::get(696696031, array($_REQUEST['phrase_id']));
			$result['status'] = 1;
			break;
	}
	$is_json_response = true;
}


elseif ( $task == 'update_phrase' ) {
	if( he_phrases::update_phrase($language_id, $phrase_id, $_REQUEST['value']) )
	{
		$result['message'] = SE_Language::_get(696696035);
		$result['status'] = 1;
	}
	else
	{
		$result['message'] = SE_Language::_get(696696036);
		$result['status'] = 0;
	}
	$is_json_response = true;
}


//SHOW RESULTS
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); // Date in the past
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); // always modified
header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
header("Pragma: no-cache"); // HTTP/1.0
if( $is_json_response )
{
	header("Content-Type: application/json");
	echo json_encode($result);
}
else 
{
	header("Content-Type: text/html");
	echo $result;
}
?>