<?
$page = "admin_language_tool_edit_phrase";
include "admin_header.php";

$task = $_POST['task'] ? $_POST['task'] : $_GET['task'];
$language_id = $_POST['language_id'] ? $_POST['language_id'] : $_GET['language_id'];
$phrase_id = $_POST['phrase_id'] ? $_POST['phrase_id'] : $_GET['phrase_id'];


$result  = 0;
if($task == "save") {
	$languagevar_value = $_POST['languagevar_value'];
	
	while(list($lang_id, $value) = each($languagevar_value)) {
		SE_Language::edit($phrase_id, htmlspecialchars_decode($value, ENT_QUOTES), $lang_id);
	}
	$phrase_location = $_POST['phrase_location'];
	$database->database_query("UPDATE se_languagevars SET languagevar_default='".mysql_escape_string($phrase_location)."' WHERE languagevar_id='$phrase_id'");
	
	$result = "window.parent.edit_result('$phrase_id', '".str_replace("'", "\'", str_replace("\n", "", str_replace("\r\n", "", htmlspecialchars_decode($languagevar_value[$language_id], ENT_QUOTES))))."', '".str_replace("'", "\'", str_replace("\n", "", str_replace("\r\n", "", htmlspecialchars_decode($phrase_location, ENT_QUOTES))))."');
	setTimeout('window.parent.TB_remove();', '300');";
}


$res = $database->database_query("SELECT p.*,l.language_id,l.language_name FROM se_languages as l LEFT JOIN se_languagevars as p ON(l.language_id=p.languagevar_language_id AND p.languagevar_id='$phrase_id') WHERE 1");

$i = 0;
$langs = '';
$phrase_location = '';
while($langvar_info = $database->database_fetch_assoc($res)) 
{
	if( !$i ) $phrase_location = $langvar_info['languagevar_default'];
	
	$langs[] = $langvar_info;
	$i++;
}

$smarty->assign('result', $result);
$smarty->assign_by_ref('langs', $langs);
$smarty->assign('phrase_location', $phrase_location);
$smarty->assign('phrase_id', $phrase_id);
$smarty->assign('language_id', $language_id);

include "admin_footer.php";
?>