INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`)
VALUES  ('apptablet', 'Touch-Tablet ', 'Tablet Extension', '4.2.2p7', 1, 'extra') ;
