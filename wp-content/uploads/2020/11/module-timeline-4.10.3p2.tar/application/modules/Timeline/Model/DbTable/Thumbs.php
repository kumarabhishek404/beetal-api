<?php
/**
 * Created by JetBrains PhpStorm.
 * User: adilet
 * Date: 13.10.12
 * Time: 11:15
 * To change this template use File | Settings | File Templates.
 */
class Timeline_Model_DbTable_Thumbs extends Engine_Db_Table
{
  protected $_rowClass = 'Timeline_Model_Thumb';


}
