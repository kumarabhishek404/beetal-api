if (!ImageLayout)
    var ImageLayout = {
        HEIGHTS: [],
        getheight: function (images, width) {
            width -= images.length * 5;
            var h = 0;
            for (var i = 0; i < images.length; ++i) {
                h += images[i].width / images[i].height;
            }
            if (width <= 0) {
                width = 1;
            }
            return (width / h);
        },
        setheight: function (images, height) {
            this.HEIGHTS.push(height);
            var set_i = 0;
            for (var i = 0; i < images.length; ++i) {
                if ((height * images[i].width / images[i].height) <= 0) {
                    return;
                }
                var width = (height * images[i].width / images[i].height);
                if (document.getElementsByClassName('layout_pinfeed_pint_feed').length > 0) {
                    images[i].style.width = (width + 2) + "px";
                } else {
                    images[i].style.width = width + "px";
                }

                images[i].style.height = height + "px";
                images[i].style.maxHeight = "none";
                images[i].style.maxWidth = "none";
                if (images[i].getStyle('width').toInt() == 0) {
                    images[i].setStyle('width', '48%');
                    images[i].style.height = "auto";
                    images[i].style.maxHeight = "none";
                    images[i].style.maxWidth = "none";
                }
            }
        },
        CheckWidth: function (images, height) {
            this.HEIGHTS.push(height);
            for (var i = 0; i < images.length; ++i) {
                if (images[i].getStyle('width').toInt() == 0) {
                    images[i].setStyle('width', '48%');
                    images[i].style.height = "auto";
                    images[i].style.maxHeight = "none";
                    images[i].style.maxWidth = "none";
                }
            }
        },
        collectionToArray: function (collection) {
            var ary = [];
            for (var i = 0, len = collection.length; i < len; i++) {
                ary.push(collection[i]);
            }
            return ary;
        },
        run: function () {

            if (window.layoutRunning) {
                return;
            }
            this.HEIGHTS = [];
            window.layoutRunning = 1;
            var n = 0, max_height = 0;

            var imageCollection = document.querySelectorAll('.feed_item_attachments:not(.laid_out)');


            if (imageCollection.length >= 1) {
                for (var j = 0; j < imageCollection.length; j++) {

                    var images = imageCollection[j].querySelectorAll('[class^=feed_attachment] img');
                    if (images.length > 1) {
                        if (images[images.length - 1].height > 0 && images[images.length - 1].width > 0) {

                            var size = imageCollection[j].offsetWidth;

                            size -= 2 * parseFloat(window.getComputedStyle(imageCollection[j], null).getPropertyValue('padding-left'));
                            if (size > 1) {


                                images = this.collectionToArray(images);
                                max_height = 0;
                                for (var m = 0; m < images.length; m++) {
                                    max_height += images[m].height;
                                }
//                          max_height *= .5;
                                if (max_height > 0) {
                                    var _height = 200;
                                    if (document.getElementsByClassName('layout_pinfeed_pint_feed').length > 0) {
                                        _height = 150;
                                    }
                                    w: while (images.length > 1) {
                                        for (var i = 1; i < images.length + 1; ++i) {
                                            var slice = images.slice(0, i);
                                            var h = this.getheight(slice, size);
                                            if (h < _height) {
                                                this.setheight(slice, h);
                                                n++;
                                                images = images.slice(i);
                                                continue w;
                                            }
                                        }

                                        this.setheight(slice, Math.min(_height, h));
                                        n++;
                                        break;
                                    }

                                    imageCollection[j].className = imageCollection[j].className + " laid_out";
                                }
                            }
                        }
                    }
                    if (images.length == 1 && document.getElementsByClassName('layout_pinfeed_pint_feed').length > 0) {
                        images[0].setStyle('width', '100%');
                        images[0].setStyle('height', 'auto');
                        images[0].style.maxHeight = "none";
                        images[0].style.maxWidth = "none";
                    }

                }
            }
            var self = this;
            if ($$('.comments')[0]) {
                $$('.comments').each(function (item) {
                    if (item.getElements('ul') && window.Wall_smiles) {
                        var ul_elements = item.getElements('ul');
                        ul_elements.each(function (elements) {
                            var elements = elements.getChildren('li:not(.smile_chenge)');
                            if (elements.length) {
                                var elem = elements;
                                var html = '';
                                for (var j = 0; j < elem.length; j++) {
                                    if (elem[j].get('id')) var comment_id = elem[j].get('id').split('-').pop(); else var comment_id = null;

                                    html = elem[j].getChildren('.comments_info').get('html');
                                    if (html[0]) {
                                        for (var i = window.Wall_smiles.length - 1; i >= 0; i--) {
                                            for (var m = 0; m < html[0].toString().length; m++)
                                                html[0] = html[0].toString().replace(window.Wall_smiles[i].index_tag.toString(), window.Wall_smiles[i].html.toString());
                                        }
                                        elem[j].getChildren('.comments_info').set('html', html[0]);
                                        elem[j].className = elem[j].className + ' smile_chenge';
                                    }

                                }
                            }
                        })
                    }

                });
            }
            window.layoutRunning = 0;

        },
        secon_run: function (w) {

            if (window.layoutRunning) {
                return;
            }
            this.HEIGHTS = [];
            window.layoutRunning = 1;
            var n = 0, max_height = 0;

            var imageCollection = document.querySelectorAll('.feed_item_attachments');


            if (imageCollection.length > 1) {
                for (var j = 0; j < imageCollection.length; j++) {

                    var images = imageCollection[j].querySelectorAll('[class^=feed_attachment] img');
                    if (images.length > 1) {
                        if (images[images.length - 1].height > 0 && images[images.length - 1].width > 0) {

                            var size = imageCollection[j].offsetWidth;

                            size -= 2 * parseFloat(window.getComputedStyle(imageCollection[j], null).getPropertyValue('padding-left'));
                            if (size > 1) {


                                images = this.collectionToArray(images);
                                max_height = 0;
                                for (var m = 0; m < images.length; m++) {
                                    max_height += images[m].height;
                                }
//                          max_height *= .5;
                                if (max_height > 0) {
                                    var _height = w;
                                    if (document.getElementsByClassName('layout_pinfeed_pint_feed').length > 0) {
                                        _height = w;
                                    }
                                    w: while (images.length > 1) {
                                        for (var i = 1; i < images.length + 1; ++i) {
                                            var slice = images.slice(0, i);
                                            var h = this.getheight(slice, size);
                                            if ($$('.feed_item_attachments')[0]) {
                                                var h2 = $$('.feed_item_attachments')[0].getSize().y;
                                                if (h2 > h) {
                                                    h = h2;
                                                }
                                            }
                                            if (h < _height) {
                                                this.setheight(slice, h);
                                                n++;
                                                images = images.slice(i);
                                                continue w;
                                            }
                                        }

                                        this.setheight(slice, Math.min(_height, h));
                                        n++;
                                        break;
                                    }

                                    imageCollection[j].className = imageCollection[j].className + " laid_out_three";
                                }
                            }
                        }
                    }
                }
            }


            window.layoutRunning = 0;

        }
    };

function he_show_message(message, type, delay) {
    var text = '';
    var duration = 400;
    var delay = (delay == undefined) ? 3000 : delay;

    text = message;

    if (window.$message_container == undefined) {
        window.$message_container = new Element('div', {'class': 'he_message_container'});
        $(document.body).adopt(window.$message_container);
    }

    var className = 'he_msg_text';
    if (type == 'error') {
        className = 'he_msg_error';
    } else if (type == 'notice') {
        className = 'he_msg_notice';
    } else {
        className = 'he_msg_text';
    }

    var $message = new Element('div', {
        'class': className,
        'styles': {
            'opacity': 0
        }
    });
    var $close_btn = new Element('a', {
        'class': 'he_close',
        'href': 'javascript://',
        'events': {
            'click': function () {
                $message.fade('out');
                $message.removeClass('visible');

                window.setTimeout(function () {
                    $message.dispose();
                    if (window.$message_container.getElements('.visible').length == 0) {
                        window.$message_container.empty();
                    }
                    ;
                }, duration);
            }
        }
    });

    $message.addClass('visible');
    $message.adopt($close_btn);
    $message.adopt('html', new Element('span', {'html': message}));
    window.$message_container.adopt($message);

    $message.set('tween', {duration: duration});
    $message.fade('in');

    window.setTimeout(function () {
        $message.fade('out');
        $message.removeClass('visible');
        window.setTimeout(function () {
            if (window.$message_container.getElements('.visible').length == 0) {
                window.$message_container.empty();
            }
        }, duration);
    }, delay);
}
function he_show_confirm(title, message, callback, options) {
    if (window.$he_confirm_container == undefined) {
        window.$he_confirm_container = new Element('div', {'class': 'he_confirm_container'});
        var $link = window.$he_confirm_container;

        var $title = new Element('div', {'class': 'he_confirm_title'});
        var $description = new Element('div', {'class': 'he_confirm_desc'});

        if (typeof(en4.core.language.translate) == 'undefined') {
            var confirm_label = language.translate('Confirm');
            var or_label = language.translate('or');
            var cancel_label = language.translate('Cancel');
        } else {
            var confirm_label = en4.core.language.translate('Confirm');
            var or_label = en4.core.language.translate('or');
            var cancel_label = en4.core.language.translate('Cancel');
        }

        var $tools = new Element('div', {'class': 'he_confirm_tools'});
        var $confirm_btn = new Element('button', {'class': 'confirm_btn', 'html': confirm_label});
        var $or_text = new Element('span', {'class': 'or_btn', 'html': or_label});
        var $cancel_btn = new Element('a', {'class': 'cancel_btn', 'href': 'javascript://', 'html': cancel_label});

        $tools.adopt($confirm_btn, $or_text, $cancel_btn);
        $link.adopt($title, $description, $tools);

        var $hidden_cont = new Element('div', {'class': 'display_none'});
        $hidden_cont.adopt($link);
        $(document.body).adopt($hidden_cont);
    }

    var $link = window.$he_confirm_container;

    if (title && title.length > 0) {
        $link.getElement('.he_confirm_title').removeClass('display_none').set('html', title);
    } else {
        $link.getElement('.he_confirm_title').addClass('display_none');
    }

    if (message && message.length > 0) {
        $link.getElement('.he_confirm_desc').removeClass('display_none').set('html', message);
    } else {
        $link.getElement('.he_confirm_desc').addClass('display_none');
    }

    if (options && options.confirm_label != undefined)
        $link.getElement('.he_confirm_tools .confirm_btn').set('html', options.confirm_label);
    if (options && options.cancel_label != undefined)
        $link.getElement('.he_confirm_tools .cancel_btn').set('html', options.cancel_label);
    if (options && options.or_label != undefined)
        $link.getElement('.he_confirm_tools .or_btn').set('html', options.or_label);

    var width = (options && options.width) ? options.width : 500;
    var height = (options && options.height) ? options.height : 100;

    Smoothbox.open($link, {mode: 'Inline', width: width, height: height});

    $('TB_ajaxContent').getElement('.he_confirm_tools .cancel_btn').addEvent('click', function () {
        Smoothbox.close();
    });

    if (callback && typeof(callback) == 'function') {
        $('TB_ajaxContent').getElement('.he_confirm_tools .confirm_btn').addEvent('click', function () {
            Smoothbox.close();
            callback();
        });
    }
}

document.addEvent('domready', function () {

    var onResize = (function () {
        var scroller = $('tl-dates');
        var i = 0;
        return function () {
            if (scroller) {
                var left = $('global_content').getSize().x + (window.getSize().x - $('global_content').getSize().x) / 2 + 10;
                var header_y = $('global_header').getSize().y || $$('.layout_page_header')[0].getSize().y;
                var top_ab = header_y + 15;
                scroller.setStyles({
                    'position': 'fixed',
                    'top': top_ab + 'px',
                    'left': left + 'px'
                });
            } else {
                i++;
                scroller = $('tl-dates');
                if (i > 10) {
                    console.warn("$('tl-dates') return null or not found!");
                }
            }
        };
    })();
    onResize();

    setTimeout(function () {
        onResize();
    }, 2000);

    window.addEvent('resize', function () {
        onResize();
    }.bind(this));


    var new_html = $('newfeedtimeline');
    if (new_html) {
        var sethtml = new_html.get('html');
        var tab = $('#tab-timeline');
        if (tab) {
            if (tab.hasClass('page-single-content')) {
                var parent_none = new_html.getParent();
                var tt = parent_none.getParent();
                if (tt) {
                    if (tt.get('id') && $(tt.get('id').replace('#', ''))) $(tt.get('id').replace('#', '')).setStyle('display', 'none');
                }
                tab.setStyle('display', 'block');
                tab.setStyle('position', 'relative');
                //
                if (tab.hasClass('hide-feed-for-widget')) {
                    tab.hide();
                }
                if (1) {
                    parent_none.setStyle('display', 'none');
                    tab.set('html', "");
                    new_html.inject(tab);
                }

            } else {
                var parent_none = new_html.getParent();
                var tt = parent_none.getParent();
                if (tt) {
                    if (tt.get('id') && $(tt.get('id').replace('#', ''))) $(tt.get('id').replace('#', '')).setStyle('display', 'none');
                }
                $$('.active_tabInTimeLine').setStyle('display', 'none');
                tab.setStyle('display', 'block');
                tab.setStyle('position', 'relative');
                $('time_line_widget').getParent('ul').getChildren('li').set('class', '');
                $('time_line_widget').setStyle('display', 'block');
                $('time_line_widget').set('class', 'he-active');
                var ch = $('timeLine-active');
                if (ch) {
                    ch.erase('class');
                    ch.getParent().erase('class');
                }
                if (1) {
                    parent_none.setStyle('display', 'none');
                    tab.set('html', "");
                    new_html.inject(tab);
                }
            }
        }
    }
    if ($('show_popup')) {
        $('show_popup').addEvent('click', function () {
            var modal = $('follow_preference');
            var span = $$(".like_close");
            modal.setStyle('display', 'block');
            span.addEvent('click', function () {
                modal.setStyle('display', 'none');
            });
            window.onclick = function (event) {
                if (event.target == modal) {
                    modal.setStyle('display', 'none');
                }
            }
        });
    }
});

var TimeLineCore = new Class({

    likeUrl: en4.core.baseUrl + 'like/like',
    unlikeUrl: en4.core.baseUrl + 'like/unlike',

    followUrl: en4.core.baseUrl + 'like/follow',
    unfollowUrl: en4.core.baseUrl + 'like/unfollow',

    likeBtn: null,

    followBtn: null,

    likeOnAir: false,

    toggleLike: function () {
        var self = this;
        var span = null;
        if (self.likeBtn.hasClass('he-btn-like')) {
            self.likeBtn.removeClass('he-btn-like');
            self.likeBtn.addClass('he-btn-unlike');
            self.likeBtn.setAttribute('data-like', 0);

            span = self.likeBtn.getElement('span');
            if (span.hasClass('he-glyphicon-thumbs-up')) {
                span.removeClass('he-glyphicon-thumbs-up');
                span.addClass('he-glyphicon-thumbs-down');
            }
            span = self.likeBtn.getElement('span#tl-like-btn-text');
            span.set('text', en4.core.language.translate('like_Unlike'));
            return;
        }
        if (self.likeBtn.hasClass('he-btn-unlike')) {
            self.likeBtn.removeClass('he-btn-unlike');
            self.likeBtn.addClass('he-btn-like');
            self.likeBtn.setAttribute('data-like', 1);

            span = self.likeBtn.getElement('span');
            if (span.hasClass('he-glyphicon-thumbs-down')) {
                span.removeClass('he-glyphicon-thumbs-down');
                span.addClass('he-glyphicon-thumbs-up');
            }
            span = self.likeBtn.getElement('span#tl-like-btn-text');
            span.set('text', en4.core.language.translate('like_Like'));
        }
    },

    toggleFollow: function (followBtn) {
        var span = null;
        if (followBtn.hasClass('he-btn-follow')) {
            followBtn.removeClass('he-btn-follow');
            followBtn.addClass('he-btn-unfollow');
            followBtn.setAttribute('data-like', 0);
            followBtn.getParent().removeClass('timeline_follow');
            followBtn.getParent().addClass('timeline_unfollow');
            span = followBtn.getElement('span#tl-like-btn-text');
            span.set('text', en4.core.language.translate('like_Unfollow'));
            return;
        }
        if (followBtn.hasClass('he-btn-unfollow')) {
            followBtn.removeClass('he-btn-unfollow');
            followBtn.addClass('he-btn-follow');
            followBtn.setAttribute('data-like', 1);
            followBtn.getParent().removeClass('timeline_unfollow');
            followBtn.getParent().addClass('timeline_follow');
            span = followBtn.getElement('span#tl-like-btn-text');
            span.set('text', en4.core.language.translate('like_Follow'));
        }
    },

    likeSubject: function (btn, id, type) {
        var self = this;
        if (self.likeOnAir) {
            return;
        }
        self.likeOnAir = true;
        self.likeBtn = btn;
        var direction = btn.getAttribute('data-like');
        var url = self.likeUrl;
        var followBtn = $$('.he-btn-follow');
        if (direction == 0) {
            url = self.unlikeUrl;
            followBtn = $$('.he-btn-unfollow');
        }

        //this.showLoader();
        new Request.JSON({
            method: 'post',
            url: url + '/object/' + type + '/object_id/' + id,
            data: {
                format: 'json'
            },
            onSuccess: function (response) {
                self.block = false;
                if (response.error) {
                    he_show_message(response.html, 'error', 3000);
                    return;
                }
                self.likeOnAir = false;
                //self.hideLoader();
                self.toggleLike();
                if (typeof followBtn[0] != 'undefined') {
                    self.toggleFollow(followBtn[0]);
                }
                return true;
            }
        }).send();

    },

    followSubject: function (btn, id, type) {
        var self = this;
        if (self.likeOnAir) {
            return;
        }
        self.likeOnAir = true;
        self.followBtn = btn;

        var direction = btn.getAttribute('data-like');
        var url = self.followUrl;
        if (direction == 0) {
            url = self.unfollowUrl;
        }
        //this.showLoader();
        new Request.JSON({
            method: 'post',
            url: url + '/object/' + type + '/object_id/' + id,
            data: {
                format: 'json'
            },
            onSuccess: function (response) {
                self.block = false;
                if (response.error) {
                    he_show_message(response.html, 'error', 3000);
                    return;
                }
                self.likeOnAir = false;
                //self.hideLoader();
                self.toggleFollow(self.followBtn);
                return true;
            }
        }).send();

    },

    isTimeline: function () {
        return 1;
    }

});

document.tl_core = new TimeLineCore();

var TlManager = new Class({
    fireTab: function (id) {
        var tab = $('tab-' + id);
        if (tab) {
            tab.click();
        }
    }
});

document.tl_manager = new TlManager();
var tl_manager = document.tl_manager;