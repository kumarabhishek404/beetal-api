<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Timeline
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: install.php 2012-02-01 16:58:20 mt.uulu $
 * @author     Mirlan
 */

/**
 * @category   Application_Extensions
 * @package    Timeline
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */


class Timeline_Installer extends Engine_Package_Installer_Module
{
    public function onPreInstall()
    {
        parent::onPreInstall();

        $db = $this->getDb();
        
$db = Engine_Db_Table::getDefaultAdapter();


$db->query("INSERT IGNORE INTO `engine4_activity_actiontypes` (`type`, `module`, `body`, `enabled`, `displayable`, `attachable`, `commentable`, `shareable`, `is_generated`) VALUES
('cover_photo_update', 'timeline', '{item:\\\$subject} has added a new cover photo.', 1, 3, 1, 1, 1, 1),
('birth_photo_update', 'timeline', '{item:\\\$subject} has added a new birth photo.', 1, 3, 1, 1, 1, 1);");


$db->query("INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES
('core_admin_main_plugins_timeline', 'timeline', 'HE - Timeline', NULL, '{\"route\":\"admin_default\",\"module\":\"timeline\",\"controller\":\"settings\"}', 'core_admin_main_plugins', NULL, 1, 0, 888),
('timeline_profile_edit', 'timeline', 'Update Info', 'Timeline_Plugin_Menus', '', 'timeline_profile', NULL, 1, 0, 1),
('timeline_profile_friend', 'timeline', 'Friends', 'Timeline_Plugin_Menus', '', 'timeline_profile', NULL, 1, 0, 3),
('timeline_profile_block', 'timeline', 'Block', 'Timeline_Plugin_Menus', '', 'timeline_profile', NULL, 1, 0, 4),
('timeline_profile_report', 'timeline', 'Report User', 'Timeline_Plugin_Menus', '', 'timeline_profile', NULL, 1, 0, 5),
('user_settings_timeline', 'timeline', 'Timeline', 'Timeline_Plugin_Menus', '{\"route\":\"timeline_user_settings\"}', 'user_settings', NULL, 1, 0, 3),
('user_edit_timeline', 'timeline', 'Timeline', 'Timeline_Plugin_Menus', '{\"route\":\"timeline_user_edit\"}', 'user_edit', NULL, 1, 0, 3),
('timeline_admin_main_settings', 'timeline', 'Global Settings', NULL, '{\"route\":\"admin_default\",\"module\":\"timeline\",\"controller\":\"settings\"}', 'timeline_admin_main', NULL, 1, 0, 999);");

$db->query("INSERT IGNORE INTO `engine4_core_settings` (`name`, `value`) VALUES
('timeline.usage', 'choice'),
('timeline.menuitems', '5');");

// \$sql = <<<CONTENT
// SELECT TRUE FROM `engine4_core_modules` WHERE `name` = 'album' LIMIT 1
// CONTENT;
        
// if (\$db->fetchOne(\$sql)){
//   \$db->query("ALTER TABLE `engine4_album_albums` MODIFY COLUMN `type` ENUM('wall','profile','message','blog','cover','born','page_cover');");
// };

// \$sql = <<<CONTENT
// SELECT TRUE FROM `engine4_core_modules` WHERE `name` = 'group' LIMIT 1
// CONTENT;
        
// if (\$db->fetchOne(\$sql)){
// \$res = \$db->query("SHOW COLUMNS FROM `engine4_group_albums` LIKE 'type';");
// if (!\$res->rowCount()){
//   \$db->query("ALTER TABLE `engine4_group_albums` ADD COLUMN `type` ENUM('cover') NULL AFTER `view_count`;");
// }
// };
// \$sql = <<<CONTENT
// SELECT TRUE FROM `engine4_core_modules` WHERE `name` = 'event' LIMIT 1
// CONTENT;
        
// if (\$db->fetchOne(\$sql)){
// \$res = \$db->query("SHOW COLUMNS FROM `engine4_event_albums` LIKE 'type';");
// if (!\$res->rowCount()){
//   \$db->query("ALTER TABLE `engine4_event_albums` ADD COLUMN `type` ENUM('cover') NULL AFTER `view_count`;");
// }
// };

// \$sql = <<<CONTENT
// SELECT TRUE FROM `engine4_core_modules` WHERE `name` = 'pagealbum' LIMIT 1
// CONTENT;
        
// if (\$db->fetchOne(\$sql)){
// \$res = \$db->query("SHOW COLUMNS FROM `engine4_page_albums` LIKE 'type';");
// if (!\$res->rowCount()){
//   \$db->query("ALTER TABLE `engine4_page_albums` ADD COLUMN `type` ENUM('page_cover') NULL AFTER `view_count`;");
// }
// };

$sql ="INSERT IGNORE INTO `engine4_core_pages` (`name`, `displayname`, `title`, `description`, `provides`) VALUES
('timeline_profile_index', 'Timeline', 'Member Profile', 'This is a member\'s  timeline profile', 'subject=user')";

        
$db->query($sql);
$page_id = $db->lastInsertId();



$sql ="INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'container', 'main', NULL, 2)";
        
$db->query($sql);
$main_content_id = $db->lastInsertId();

$sql ="INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'container', 'middle', $main_content_id, 6)";
        
$db->query($sql);
$middle_content_id = $db->lastInsertId();

$sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'widget', 'timeline.new-cover', $middle_content_id, 4)";
$db->query($sql);
$new_cover_id = $db->lastInsertId();

$sql ="INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`) VALUES
($page_id, 'widget', 'album.profile-albums', $new_cover_id, 7, '{\"title\":\"Albums\",\"titleCount\":\"true\"}'),
($page_id, 'widget', 'video.profile-videos', $new_cover_id, 8, '{\"title\":\"Videos\",\"titleCount\":\"true\"}'),
($page_id, 'widget', 'event.profile-events', $new_cover_id, 9, '{\"title\":\"Events\",\"titleCount\":\"true\"}'),
($page_id, 'widget', 'group.profile-groups', $new_cover_id, 10, '{\"title\":\"Groups\",\"titleCount\":\"true\"}'),
($page_id, 'widget', 'blog.profile-blogs'  , $new_cover_id, 11, '{\"title\":\"Blogs\",\"titleCount\":\"true\"}'),

($page_id, 'widget', 'classified.profile-classifieds', $new_cover_id, 12, '{\"title\":\"Classifieds\",\"titleCount\":\"true\"}'),
($page_id, 'widget', 'forum.profile-forum-posts', $new_cover_id, 13, '{\"title\":\"Forum Posts\",\"titleCount\":\"true\"}'),
($page_id, 'widget', 'forum.profile-forum-topics', $new_cover_id, 14, '{\"title\":\"Forum Topics\",\"titleCount\":\"true\"}'),
($page_id, 'widget', 'poll.profile-polls',                $new_cover_id, 16, '{\"title\":\"Polls\",\"titleCount\":\"true\"}')";
$db->query($sql);

$sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`) VALUES
($page_id, 'widget', 'user.profile-friends-followers', $new_cover_id, 17, '{\"title\":\"Followers\",\"titleCount\":\"true\"}'),
($page_id, 'widget', 'user.profile-friends-following', $new_cover_id, 18, '{\"title\":\"Following\",\"titleCount\":\"true\"}'),
($page_id, 'widget', 'user.profile-friends', $new_cover_id, 15, '{\"title\":\"Friends\",\"titleCount\":\"true\"}')";
$db->query($sql);


$sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`) VALUES
($page_id, 'widget', 'timeline.new-feed', $middle_content_id, 5)";
$db->query($sql);

$new_feed_id = $db->lastInsertId();

$sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`) VALUES
($page_id, 'widget', 'user.profile-info', $new_feed_id, 7, '{\"title\":\"Member Info\",\"titleCount\":\"true\"}'),
($page_id, 'widget', 'user.profile-fields', $new_feed_id, 8, '{\"title\":\"Info\",\"titleCount\":\"true\"}'),
($page_id, 'widget', 'timeline.tile-friends', $new_feed_id, 9, '{\"title\":\"Friends\",\"titleCount\":\"true\"}')";
$db->query($sql);
$sql = "INSERT IGNORE INTO `engine4_core_content` (`page_id`, `type`, `name`, `parent_content_id`, `order`, `params`) VALUES
($page_id, 'widget', 'hebadge.profile-badgeicons', $new_feed_id, 6, '{\"title\":\"Badges\",\"titleCount\":\"true\"}')";
$db->query($sql);
        
        
    }
}