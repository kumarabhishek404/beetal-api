<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Timeline
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: Bootstrap.php 2012-02-01 16:58:20 mt.uulu $
 * @author     Mirlan
 */

/**
 * @category   Application_Extensions
 * @package    Timeline
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */
    
class Timeline_Bootstrap extends Engine_Application_Bootstrap_Abstract
{
  public function __construct($application)
  {
    // Add view helper and action helper paths
      parent::__construct($application);
      $this->initViewHelperPath();

      $this->registerScriptsAndCss();
  }

  public function _bootstrap($resource = null)
  {
    $front = Zend_Controller_Front::getInstance();
    $front->registerPlugin(new Timeline_Plugin_Core, 203);
  }

  public function registerScriptsAndCss()
  {
      $view = Zend_Registry::get('Zend_View');

      $view->headScript()
          ->appendFile($view->layout()->staticBaseUrl
              . 'application/libraries/Hireexperts/externals/scripts/imagezoom/core.js')
          ->appendFile($view->layout()->staticBaseUrl
              . 'application/libraries/Hireexperts/externals/scripts/hestrap/Hestrap.js')
          ->appendFile($view->layout()->staticBaseUrl
              . 'application/libraries/Hireexperts/externals/scripts/hestrap/Hestrap.Dropdown.js')
          ->appendFile($view->layout()->staticBaseUrl
              . 'application/libraries/Hireexperts/externals/scripts/hestrap/Hestrap.Tab.js');

      $view->headLink()
          ->appendStylesheet($view->layout()->staticBaseUrls
              . 'application/libraries/Hireexperts/externals/styles/imagezoom/core.css')
          ->appendStylesheet($view->layout()->staticBaseUrl
              . 'application/libraries/Hireexperts/externals/styles/hestrap.css');
  }
}

