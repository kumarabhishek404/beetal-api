<?php return array(
  'package' => array(
    'type' => 'library',
    'name' => 'hireexperts',
    'version' => '4.0.2',
    'revision' => '$Revision: 1568 $',
    'path' => 'application/libraries/Hireexperts',
    'repository' => 'socialengine.com',
    'title' => 'Hire-Experts Lib',
    'author' => 'Hire-Experts Team',
    'directories' => array(
      'application/libraries/Hireexperts'
    )
  )
) ?>
