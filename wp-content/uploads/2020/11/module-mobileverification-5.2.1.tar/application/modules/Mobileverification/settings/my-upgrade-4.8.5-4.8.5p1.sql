CREATE TABLE IF NOT EXISTS `engine4_mobileverification_types` (
  `user_id` int(4) NOT NULL,
  `profile_id` int(10) NOT NULL,
  `mobile_id` int(4) NOT NULL,
  PRIMARY KEY (`profile_id`));  
