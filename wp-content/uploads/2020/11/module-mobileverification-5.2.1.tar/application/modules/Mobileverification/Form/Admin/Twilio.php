<?php
/**
 * iPragmatech Solution Pvt. Ltd.
 *
 * @category   Application_Mobile Verification
 * @package    Mobile Verification
 * @copyright  Copyright 2008-2013 iPragmatech Solution Pvt. Ltd.
 * @license   � 2013 iPragmatech. All Rights Reserved.
 * @version    $Id: Global.php 9747 2013-07-06 02:08:08Z iPrgamtech $
 * @author     iPragmatech
 */

class Mobileverification_Form_Admin_Twilio extends Engine_Form
{
  public function init()
  {

  	$this->setAttrib('id', 'twilio_form');
  	
  	//Account SID
  	$this->addElement('Text', 'sid', array(
  			'label' => 'Account SID',
  			'required' => true,
  	));
  	
  	//Account SID
  	$this->addElement('Text', 'auth', array(
  			'label' => 'Auth Token',
  			'required' => true,
  	));
  	
  	//Twilio Number
  	$this->addElement('Text', 'twilio', array(
  			'label' => 'Twilio Number',
  			'description' => 'Verified Outgoing Caller ID or Twilio number.Example: "+1 423-443-3310" ',
  			'required' => true,
  	));
    
  	// Add submit button
    $this->addElement('Button', 'save', array(
      'label' => 'Save',
      'type' => 'submit',
    ));
  }
}