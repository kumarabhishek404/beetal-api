<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: install.php 16.12.16 05:40 bolot $
 * @author     Bolot
 */

/**
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */
class Mobileverification_Installer extends Engine_Package_Installer_Module
{

  public function onPreInstall()
  {
    parent::onPreInstall();
  }
  function onEnable()
  {
    parent::onEnable();
    $db = $this->getDb();
    $db->query("INSERT IGNORE INTO  `engine4_user_signup` (`signup_id` ,`class` , `order` , `enable`)VALUES (NULL ,  'Mobileverification_Plugin_Signup_Verify',  '99',  '1');
;");

  }

  function onDisable()
  {
    parent::onDisable();
    $db = $this->getDb();
    $db->query("DELETE FROM `engine4_user_signup` WHERE `signup_id`='Mobileverification_Plugin_Signup_Verify';");
  }
  
  
  
}
