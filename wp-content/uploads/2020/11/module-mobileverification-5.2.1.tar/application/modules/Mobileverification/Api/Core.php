<?php
class Mobileverification_Api_Core extends Core_Api_Abstract
{
	public function setvalue($profile_id)
    {
    	$log = Zend_Registry::get ( 'Zend_Log' );
    	$mapTable = Engine_Api::_()->fields()->getTable('user', 'maps');
    	$map_select = $mapTable->select()->where('field_id=1')->where('option_id=?',$profile_id);
    	$map_data = $mapTable->fetchAll($map_select);
    	$field_ids = array();
    	foreach( $map_data as $item) {
    		$field_ids[]= $item->child_id;
    	}
    	//fetch profile label
    	$metaTable = Engine_Api::_()->fields()->getTable('user', 'meta');
    	$meta_select = $metaTable->select()->where('field_id IN(?)',$field_ids);
    	$meta_data = $metaTable->fetchAll($meta_select);
    	
    	return $meta_data;
    }
    
    public function setuserverified($user_id)
    {
    	$log = Zend_Registry::get ( 'Zend_Log' );
    	$log->log('it is coming to widget',Zend_Log::DEBUG);
    	if (!$user_id)
    	{
    		return false;
    	}
    	
    	// get table object
    	$verificationTable = Engine_Api::_ ()->getDbtable ( 'verifications', 'mobileverification' );
    	
    	$log->log('update the values',Zend_Log::DEBUG);
    	// updating table values based on user id    	
    	$verificationTable->update(array('verified' => 1), array('user_id =?' => $user_id));
    	return true;    	    	
    }
   
    public function getverifiedstatus($user_id)
    {
    	//get the details of user 
    	$verificationTable = Engine_Api::_ ()->getDbtable ( 'verifications', 'mobileverification' );
    	$verificationSelect = $verificationTable->select ()->where ( 'user_id=?', $user_id );
    	$verificationData = $verificationTable->fetchRow ( $verificationSelect );
    	//check the status of user is verified or not
    	$verfied=$verificationData['verified'];
    	if($verfied == 1){
    		
    		return true;
    	}
		else{
			
			return false;
		}    
    
    
    
    }
    
}

    
   


