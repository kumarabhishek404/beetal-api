<?php
require 'application/modules/Mobileverification/Api/lib/twilio.php';
class Mobileverification_IndexController extends Core_Controller_Action_Standard {
	public function indexAction() {
		$this->view->someVar = 'someVal';
	}
	public function setvalueAction() {
		$log = Zend_Registry::get ( 'Zend_Log' );
		$this->_helper->content->setNoRender ()->setEnabled ();
		$this->view->form = $form = new Mobileverification_Form_Admin_Type ();
		$profile_id = $this->_getParam ( 'profile_id' );
		
		// Profile Type
		$mapTable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'maps' );
		$map_select = $mapTable->select ()->where ( 'field_id=1' )->where ( 'option_id=?', $profile_id );
		$map_data = $mapTable->fetchAll ( $map_select );
		
		$field_ids = array ();
		foreach ( $map_data as $item ) {
			$field_ids [] = $item->child_id;
		}
		
		// fetch profile label
		$metaTable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'meta' );
		$meta_select = $metaTable->select ()->where ( 'field_id IN(?)', $field_ids );
		$meta_data = $metaTable->fetchAll ( $meta_select );
		$fieldsOptions = array ();
		foreach ( $meta_data as $item ) {
			$fieldsOptions [$item->field_id] = $item->label;
		}
		$form->fields->setMultiOptions ( $fieldsOptions );
		return true;
	}
	public function verificationAction() {
		$log = Zend_Registry::get ( 'Zend_Log' );
		$viewer = Engine_Api::_ ()->user ()->getViewer ();
		
		$this->_helper->content->setNoRender ()->setEnabled ();
		$recipient = $this->_getParam ( 'number' );
		// generate "random" 6-digit verification code
		$code = rand ( 100000, 999999 );
		// fetch twili account info
		$info_table = Engine_Api::_ ()->getDbtable ( 'twilios', 'mobileverification' );
		$select_data = $info_table->select ();
		$twilio_info = $info_table->fetchRow ( $select_data );
		
		// Set our AccountSid and AuthToken
		$AccountSid = $twilio_info ['account_sid'];
		$AuthToken = $twilio_info ['account_token'];
		$twilio_number = $twilio_info ['twilio_number'];
		
		// check mobile number as unique field
		$setting_table = Engine_Api::_ ()->getDbtable ( 'settings', 'mobileverification' );
		$setting_select = $setting_table->select ()->where ( 'user_id=?', 1 );
		$setting_data = $setting_table->fetchRow ( $setting_select );
		
		$recipient = preg_replace ( "/[^0-9+]/", "", $recipient );
		$verification_table = Engine_Api::_ ()->getDbtable ( 'verifications', 'mobileverification' );
		$select_data = $verification_table->select ()->where ( 'number=?', $recipient )->where ( 'user_id=?', $viewer->getIdentity () );
		$number_exist = $verification_table->fetchRow ( $select_data );
		
		if ($setting_data ['unique_field'] == 0 || empty ( $setting_data ) || empty ( $number_exist )) {
			// Instantiate a new Twilio Rest Client
			$client = new TwilioRestClient ( $AccountSid, $AuthToken );
			
			// call data
			$data = array (
					"From" => $twilio_number, // Verified Outgoing Caller ID or Twilio number
					"To" => $recipient, // The phone number you wish to dial
					"Body" => 'Verification code is ' . $code 
			);
			
			// make call
			//$response = $client->request ( "/2008-08-01/Accounts/$AccountSid/SMS/Messages", "POST", $data );
			$response = $client->request ( "/2010-04-01/Accounts/$AccountSid/Messages", "POST", $data );
			
			if ($response->IsError) {
				$params = array (
						'error' => 1,
						'message' => $response->ErrorMessage
						
				);
				
				return $this->_helper->json ( $params );
			} 
			else {
				$_SESSION ['code'] = $code;
					
				$params = array (
						'error' => 0,
						'phone' => $recipient,
						'verify' => $code 
				);
							
				return $this->_helper->json ( $params );
				
			}
		} else {
			$params = array (
					'error' => 1,
					'message' => 'This mobile number is already used by someone' 
			);
			return $this->_helper->json ( $params );
		}
		
	}
	public function mobileverifyAction() {
		$log = Zend_Registry::get ( 'Zend_Log' );
		
		// Set up navigation
		$this->view->navigation = $navigation = Engine_Api::_ ()->getApi ( 'menus', 'core' )->getNavigation ( 'user_edit', array (
				'params' => array (
						'id' => $id
				)
		) );
		
		$viewer = Engine_Api::_ ()->user ()->getViewer ();
		$viewer_id = $viewer->getIdentity ();
		//$level_id=$viewer->level_id;
		
		// chck viewwer is admin or not i admin show the message
		if($viewer_id == 1){
			$this->view->is_admin = true;
			return;
		}
		
		if (! Engine_Api::_ ()->core ()->hasSubject ()) {
			// Can specifiy custom id
			$id = $this->_getParam ( 'id', null );
			$subject = null;
			if (null === $id) {
				$subject = Engine_Api::_ ()->user ()->getViewer ();
				Engine_Api::_ ()->core ()->setSubject ( $subject );
			} else {
				$subject = Engine_Api::_ ()->getItem ( 'user', $id );
				Engine_Api::_ ()->core ()->setSubject ( $subject );
			}
		}
		
		if (! empty ( $id )) {
			$params = array (
					'params' => array (
							'id' => $id 
					) 
			);
		} else {
			$params = array ();
		}
		
		
		// Make form
		$this->view->form = $form = new Mobileverification_Form_User ();
		//$form->getElement ( 'error' )->setValue ( 'error' );
		if (! $this->getRequest ()->isPost ()) {
			return;
		}
		
		if (! $form->isValid ( $this->getRequest ()->getPost () )) {
			return;
		}
		
		// process
		$values = $form->getValues ();
		$values ['confirm_code_widget'] == $_SESSION ['code'];
		$user = Engine_Api::_ ()->user ()->getViewer ();
		$user_id = $user->getIdentity ();
		
		$searchTable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'search' );
		$search_select = $searchTable->select ()->where ( 'item_id=?', $user_id );
		
		$search_data = $searchTable->fetchRow ( $search_select );
		
		// fetch profile label
		if (! empty ( $search_data )) {
			$typeTable = Engine_Api::_ ()->getDbtable ( 'types', 'mobileverification' );
			$type_select = $typeTable->select ()->where ( 'profile_id=?', $search_data->profile_type );
			
			$type_data = $typeTable->fetchRow ( $type_select );
			
			$field_id = $type_data->mobile_id;
			
			$valueTable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'values' );
			$value_select = $valueTable->select ()->where ( 'item_id=?', $user_id )->where ( 'field_id=?', $field_id );
			
			$value_data = $valueTable->fetchRow ( $value_select );
			
		}
		
		$this->view->error = $values ['error'];
		
		//if ($values ['error'] == 'error') {
			
			// check the verification code
			$phone_no = $values ['mobile_hidden'];
			$phone_no = preg_replace ( "/[^0-9+]/", "", $phone_no );
			$verification_table = Engine_Api::_ ()->getDbtable ( 'verifications', 'mobileverification' );
			$select_data = $verification_table->select ()->where ( 'user_id=?', $user_id );
			
			//$values ['confirm_code_widget'] == $_SESSION ['code'];
					
			$select = $verification_table->select ()
			//->where ( 'number=?', $phone_no )
			->where ( 'user_id =?', $user_id );
			$number_exist = $verification_table->fetchRow ( $select );
			
			if ($values ['confirm_code_widget'] == $_SESSION ['code']) {
				if (empty ( $number_exist )) {
					
					$verification_table->insert ( array (
							'user_id' => $user_id,
							'number' => $phone_no,
							'code' => $_SESSION ['code'] 
					) );
				} else {
					$verification_table->update(array(
							'number' => $phone_no,
							'code' => $_SESSION ['code']
							), 
							array('user_id =?' => $user_id)
					);
					
					/* $verification_table->update ( array (
							'user_id' => $user_id,
							'number' => $phone_no,
							'code' => $_SESSION ['code']
					) ); */
					
					/* $verification_table->update ( array (
							'code' => $_SESSION ['code'] 
					), array (
							'user_id=?' => $user_id 
					) ); */
				}
				
				//check the user is verified or not
				//$log->log('updatefor verf',Zend_Log::DEBUG);
				$meta_data = Engine_Api::_()->mobileverification()->setuserverified($user_id); 
				
				if (! empty ( $search_data )) {
					if (! empty ( $value_data )) {
						$where = array ();
						$where ['field_id =?'] = $field_id;
						$where ['item_id = ?'] = $user_id;
						$valueTable->update ( array (
								'value' => $phone_no 
						), $where );
					} else {
						$valueTable->insert ( array (
								'item_id' => $user_id,
								'value' => $phone_no,
								'field_id' => $field_id 
						) );
					}
				}
				$form->addNotice ( 'Mobile number Verified successfully' );
			} else {
				$this->view->code_incorrect = true;
				$form->addError ( 'Code incorrect! Please retry or get a new code' );
			}
		//}
	}
	public function saveprofileAction() {
		$log = Zend_Registry::get ( 'Zend_Log' );
		
		$profparams = $this->_request->getParams ();
		$cmngprams = array_key_exists ( 'profilevalues', $profparams );
		
		if ($cmngprams == false) {
			
			return;
			
		} else {
			
			$type_table = Engine_Api::_ ()->getDbtable ( 'types', 'mobileverification' );
			$type_select = $type_table->select ();
			$type_data = $type_table->fetchRow ( $type_select );
			foreach ( $profparams ['profilevalues'] [0] as $key => $p_value ) {
				
				$typeselect = $type_table->select ()->where ( 'profile_id=?', $key );
				$typesdata = $type_table->fetchRow ( $typeselect );
				
				if (! empty ( $typesdata )) {
					$type_table->update ( array (
							'mobile_id' => $p_value 
					), array (
							'profile_id=?' => $key 
					) );
				} 

				else {
					$type_table->insert ( array (
							'profile_id' => $key,
							'mobile_id' => $p_value,
							'user_id' => 1 
					) );
				}
			}
		}
	}
}
