<?php
/**
 * iPragmatech Solution Pvt. Ltd.
 *
 * @category   Application_User Importer
 * @package    User Importer
 * @copyright  Copyright 2008-2013 iPragmatech Solution Pvt. Ltd.
 * @license   � 2013 iPragmatech. All Rights Reserved.
 * @version    $Id: Global.php 9747 2013-07-06 02:08:08Z iPrgamtech $
 * @author     iPragmatech
 */

class Mobileverification_Form_User extends Engine_Form
{
  public function init()
  {
  	$log = Zend_Registry::get('Zend_Log');
  	$this->setAttrib('id', 'mobileverification_widget');

  	//$this->setAction()
  	//Mobile Numberr

    $accountSession = new Zend_Session_Namespace('User_Plugin_Signup_Fields');
  	$profileTypeValue = @$accountSession->data;

  	$prof=$profileTypeValue[1];


  	$user = Engine_Api::_()->user()->getViewer();
  	$user_id = $user->getIdentity();

  	$searchTable = Engine_Api::_()->fields()->getTable('user', 'search');
  	$search_select = $searchTable->select()->where('item_id=?',$user_id);
  	$search_data = $searchTable->fetchRow($search_select);

  	$userprofile=$search_data['profile_type'];


  	if($user_id == 1) {
  		$userprofile = 1;

  	}
   	$metaTable = Engine_Api::_()->fields()->getTable('user', 'meta');
  	$typeTable = Engine_Api::_()->getDbtable('types', 'mobileverification');

  	$typeSelect = $typeTable->select()
  	->setIntegrityCheck(false)
  	->from(array('typ' => $typeTable->info('name')))
  	->join(array('met' => $metaTable->info('name')),'typ.mobile_id = met.field_id',array("label"))
  	->where('typ.profile_id = ?',$userprofile);


  	$profiledata = $typeTable->fetchAll($typeSelect);

  	$label=$profiledata['profiledata']['label'];

  //	$description = Zend_Registry::get('Zend_Translate')->_('111111111111111111111111');
  	$this->addElement('Text', 'mobile_number', array(
  			'description'=> 'An SMS will be sent to the number below Example: "+91-8130-389-373" or "+91 8130 389 373"',
  			'label' => $label,
  	));

  	//Verification Code
  	$this->addElement('Text', 'confirm_code_widget', array(
  			'label' => 'Verification Code',
  	));

  	//hidden Input which take mobile number
  	$this->addElement('hidden', 'mobile_hidden');

  	//hidden Input which take mobile number
  	$this->addElement('Text', 'error', array(
  			'attribs' => array ('style' => 'visibility: hidden'),
  	));

   // Add submit button
    $this->addElement('Button', 'send_code_button', array(
    		'label' => 'Send',
    		'type' => 'button',
    		'onClick' => 'sendcode()'
    ));

    // Add submit button
    $this->addElement('Button', 'confirm_code_button', array(
    		'label' => 'Verify',
    		'type' => 'submit',


    ));
  }

}
