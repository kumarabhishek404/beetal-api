<?php
/**
 * iPragmatech Solution Pvt. Ltd.
 *
 * @category   Application_Mobile Verification
 * @package    Mobile Verification
 * @copyright  Copyright 2008-2013 iPragmatech Solution Pvt. Ltd.
 * @license   � 2013 iPragmatech. All Rights Reserved.
 * @version    $Id: Global.php 9747 2013-07-06 02:08:08Z iPrgamtech $
 * @author     iPragmatech
 */
class Mobileverification_Form_Admin_Type extends Engine_Form {
	public function init() {
		$log = Zend_Registry::get ( 'Zend_Log' );
		$actionName = Zend_Controller_Front::getInstance ()->getRequest ()->getActionName ();
		$this->setAttrib ( 'id', 'type_setting' );
		// Profile Type
		$optionTable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'options' );
		$option_select = $optionTable->select ()->where ( 'field_id=1' );
		$option_data = $optionTable->fetchAll ( $option_select );
		
		$profileOptions = array ();
		$profileOptions [99] = 'Select Profile Type';
		
		$id = 0;
		foreach ( $option_data as $item ) {
			$profileOptions [$item->option_id] = $item->label;
			
			$id = $item->option_id;
		}
		
				
		$count = 1;
		foreach ( $profileOptions as $key => $value ) {
			$value = preg_replace ( '/\s+/', '', $value );
			if ($key == 99) {
				continue;
				$this->_helper->redirector->gotoRoute ( array (
						'action' => 'typesetting',
						'controller' => 'settings',
						'module' => 'mobileverification' 
				), 'admin_default', true );
			}
			
			$mapTable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'maps' );
			$map_select = $mapTable->select ()->where ( 'field_id=1' )->where ( 'option_id=?', $key );
			$map_data = $mapTable->fetchAll ( $map_select );
			$field_ids = array ();
			
			foreach ( $map_data as $item ) {
				
				$field_ids [] = $item->child_id;
			}
			
			if ($field_ids == NULL) {
				
				$fields_ids = array ();
			} else {
				
				// fetch profile label
				$metaTable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'meta' );
				$meta_select = $metaTable->select ()->where ( 'field_id IN(?)', $field_ids );
				$meta_data = $metaTable->fetchAll ( $meta_select );
				
				$fieldsOptions = array (
						"Select Field" 
				);
				
				foreach ( $meta_data as $item ) {
					$fieldsOptions [$item->field_id] = $item->label;
					$field_id = $item->field_id;
				}
				
				$fieldsData = array ();
				$fieldsData [] = $value;
				
				$type_table = Engine_Api::_ ()->getDbtable ( 'types', 'mobileverification' );
				$type_select = $type_table->select ();
				$type_data = $type_table->fetchRow ( $type_select );
				
				$this->addElement ( 'Text', $value, array (
						'label' => 'Profile Type',
						'id' => "profile_type_" . $key,
						'registerInArrayValidator' => false,
						'value' => $value,
						'readonly' => true 
				) );
				
				$this->addElement ( 'Select', $value . 'fields', array (
						'label' => 'Select Fields',
						'registerInArrayValidator' => false,
						'multiOptions' => $fieldsOptions,
						'onChange' => "javascript:fetchSettingsnew(this.value,$key);" 
				)
				 );
				
				$this->addElement ( 'Hidden', $value . '_profile_type', array (
						'id' => $key,
						'class' => profile_type_value,
						'order' => $count,
						'value' => 0 
				)
				 );
				
				$this->addElement ( 'text', $value . '_error', array (
						'required' => false,
						'decorators' => array (
								array (
										'HtmlTag',
										array (
												'tag' => 'div',
												'class' => 'validate',
												'id' => "error_" . $key 
										) 
								) 
						) 
				) );
				
				$this->addElement ( 'text', $value . 'line', array (
						'required' => false,
						'decorators' => array (
								array (
										'HtmlTag',
										array (
												'tag' => 'div',
												'class' => 'line' 
										)
										 
								) 
						) 
				) );
				$count ++;
			}
		}
		
		$this->addElement ( 'Button', 'save', array (
				'label' => 'Save Setting',
				'type' => 'submit' 
		) );
	}
}