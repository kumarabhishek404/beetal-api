<?php
/**
 * iPragmatech Solution Pvt. Ltd.
 *
 * @category   Application_Mobile Verification
 * @package    Mobile Verification
 * @copyright  Copyright 2008-2013 iPragmatech Solution Pvt. Ltd.
 * @license   � 2013 iPragmatech. All Rights Reserved.
 * @version    $Id: Global.php 9747 2013-07-06 02:08:08Z iPrgamtech $
 * @author     iPragmatech
 */

class Mobileverification_Form_Admin_Setting extends Engine_Form
{
  public function init()
  {
 
  	$actionName = Zend_Controller_Front::getInstance()->getRequest()->getActionName();
  	$this->setAttrib('id', 'mobile_setting');
  	
  	
  	// Element: enable
  		$signup_table = Engine_Api::_()->getDbtable('signup', 'user');
  		$enable_data = $signup_table->select()->where('class=?','Mobileverification_Plugin_Signup_Verify');
  		$enabled = $signup_table->fetchRow($enable_data);
  		
  		$menu_table = Engine_Api::_()->getDbtable('menuitems', 'core');
  		$menu_data = $menu_table->select()->where('name=?','user_edit_mobileveify');
  		$enabled_menu = $signup_table->fetchRow($menu_data);
  	
  if($actionName == "global")
  {
  	$this->addElement('Radio', 'enable', array(
  			'description' => 'Do you really want to Activate/Deactivate Mobile Verification Plugin?',
  			'multiOptions' => array(
  					'1' => 'Activate this Plugin',
  					'0' => 'Deactivate this plugin',
  			),
  			'value' => $enabled['enable']
  	));
  }
  else 
  {
  	$this->addElement('Radio', 'enable', array(
  			'description' => 'Do you really want to Enable/Disable Mobile Verification in Edit Profile?',
  			'multiOptions' => array(
  					'1' => 'Enable in Edit Profile',
  					'0' => 'Disable in Edit Profile',
  			),
  			'value' => $enabled_menu['enabled']
  	));
  }
 
  	
  	// Add submit button
  	$this->addElement('Button', 'save', array(
  			'label' => 'Save Changes',
  			'type' => 'submit',
  	));
  }
}