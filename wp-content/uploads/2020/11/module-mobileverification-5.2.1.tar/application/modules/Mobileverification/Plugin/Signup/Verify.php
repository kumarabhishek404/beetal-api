<?php
class Mobileverification_Plugin_Signup_Verify extends Core_Plugin_FormSequence_Abstract {
	protected $_name = 'account';
	protected $_formClass = 'Mobileverification_Form_Signup_Verify';
	protected $_script = array (
			'_signupVerify.tpl',
			'mobileverification' 
	);
	protected $_adminFormClass = 'Mobileverification_Form_Admin_Signup_Verify';
	protected $_adminScript = array (
			'_signupVerifyAdmin.tpl',
			'mobileverification' 
	);
	public function init() {
		$request = Zend_Controller_Front::getInstance ()->getRequest ();
		$session = $this->getSession ();
	}
	public function onSubmit(Zend_Controller_Request_Abstract $request) {
		$log = Zend_Registry::get ( 'Zend_Log' );
		if ($this->getForm ()->isValid ( $request->getPost () )) {
			
			$request1 = Zend_Controller_Front::getInstance ()->getRequest ();
			$form = $this->getForm ();
			$form->getElement ( 'error' )->setValue ( 'error' );
			$this->getSession ()->data = $values = $this->getForm ()->getValues ();
			$user = Engine_Api::_ ()->user ()->getViewer ();
			$user_id = $user->getIdentity ();
			if ($values ['confirm_code_widget'] != $_SESSION['code']) {
					return $form->addError ( 'Code incorrect! Please retry or get a new code' );
			}
			else {
				   
					$this->setActive ( false );
					$this->onSubmitIsValid ();
					return true;
			}
			
			
		} 		

		// Form was not valid
		else {
			$this->getSession ()->active = true;
			$this->onSubmitNotIsValid ();
			return false;
		}
	}
	public function getForm() {
		if (null === $this->_form) {
			$form = parent::getForm ();
			$this->_form = $form;
		}
		return $this->_form;
	}
	public function onProcess() {
		$log = Zend_Registry::get ( 'Zend_Log' );
		
		// Register a hook to this method for onUserCreateAfter
		if (! $this->_registry->user) {
			// Register temporary hook
			Engine_Hooks_Dispatcher::getInstance ()->addEvent ( 'onUserCreateAfter', array (
					'callback' => array (
							$this,
							'onProcess' 
					) 
			) );
			return;
		}
		
		$form = $this->getForm ();
		$user = $this->_registry->user;
		$values = $form->getValues ();
		$phone = $values ['mobile_hidden'] ;
		$code = $_SESSION['code'] ;
		$user_id = $user->getIdentity ();

		//save mobile number and code in table
		$verification_table = Engine_Api::_()->getDbtable('verifications', 'mobileverification');
		  		$verification_table->insert ( array (
		  		'user_id' => $user_id,		
		    	'number' => $phone,
				'code' => $code,
				) );
		  		unset($_SESSION['code']);
		  		/*** makeing user verified ***/
		  		$meta_data = Engine_Api::_()->mobileverification()->setuserverified($user_id);
		  		/*** fetchig user information ***/
		  		$searchTable = Engine_Api::_()->fields()->getTable('user', 'search');
		  		$search_select = $searchTable->select()->where('item_id=?',$user_id);
		  		$search_data = $searchTable->fetchRow($search_select);
		  		 
		  		//fetch profile label
		  		if(!empty($search_data))
		  		{
		  			$typeTable = Engine_Api::_()->getDbtable('types', 'mobileverification');
		  			$type_select = $typeTable->select()->where('profile_id=?',$search_data->profile_type);
		  			$type_data = $typeTable->fetchRow($type_select);
		  			$field_id = $type_data->mobile_id;
		  		
		  			$valueTable = Engine_Api::_()->fields()->getTable('user', 'values');
		  			$value_select = $valueTable->select()->where('item_id=?',$user_id)->where('field_id=?',$field_id);
		  			$value_data = $valueTable->fetchRow($value_select);
		  		}
		  		if(!empty($value_data))
		  		{
		  			$where = array();
		  			$where['field_id =?'] = $field_id;
		  			$where['item_id = ?'] = $user_id;
		  			$valueTable->update(array(
		  					'value' =>$phone,
		  			), $where);
		  		}
		  		else
		  		{
		  			$valueTable->insert ( array (
		  					'item_id'=> $user_id,
		  					'value' => $phone,
		  					'field_id' => $field_id,
		  			) );
		  		}
	
	}
	public function onAdminProcess($form) {
		$step_table = Engine_Api::_ ()->getDbtable ( 'signup', 'user' );
		$step_row = $step_table->fetchRow ( $step_table->select ()->where ( 'class = ?', 'Mobileverification_Plugin_Signup_Verify' ) );
		$step_row->enable = $form->getValue ( 'enable' );
		$step_row->save ();
		$form->addNotice ( 'Successfully save your changes' );
	}
}