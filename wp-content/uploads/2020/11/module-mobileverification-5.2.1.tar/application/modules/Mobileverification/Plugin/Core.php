<?php

/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Sitestore
 * @copyright  Copyright 2012-2013 BigStep Technologies Pvt. Ltd.
 * @license    http://www.socialengineaddons.com/license/
 * @version    $Id: Core.php 2013-09-02 00:00:00Z SocialEngineAddOns $
 * @author     SocialEngineAddOns
 */
// class Mobileverification_Plugin_Core extends Zend_Controller_Plugin_Abstract 
// {
//     public function onUserCreateAfter($event) 
//     {
//     	$payload = $event->getPayload();
// 		if ($payload instanceof User_Model_User) {
// 			$user_id = $payload->getIdentity();
// 			Engine_Api::_()->mobileverification()->updatefieldValue($user_id);
// 		}
//   	}
// }
