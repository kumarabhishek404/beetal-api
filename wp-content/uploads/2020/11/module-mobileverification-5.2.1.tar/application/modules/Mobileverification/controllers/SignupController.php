<?php
/**
 * SocialEngine
 *
 * @category   Application_Core
 * @package    Mobile Verification
 * @copyright  Copyright 2006-2010 iPragmatech
 * @license    http://www.socialengine.com/license/
 * @author     iPragmatech
 */

/**
 * @category   Application_Core
 * @package    Mobile Verification
 * @copyright  Copyright 2006-2010 iPragmatech
 * @license    http://www.socialengine.com/license/
 */
require 'application/modules/Mobileverification/Api/lib/twilio.php';
//require 'application/modules/Mobileverification/Api/twilio/Services/Twilio.php';
//require 'application/modules/Mobileverification/Api/twilio/Services';

class Mobileverification_SignupController extends Core_Controller_Action_Standard
{
    
  public function init()
  {
  }
  public function indexAction()
  {
		  	
  }

}