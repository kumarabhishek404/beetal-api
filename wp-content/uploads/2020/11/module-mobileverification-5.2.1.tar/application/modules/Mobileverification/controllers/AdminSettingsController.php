<?php

class Mobileverification_AdminSettingsController extends Core_Controller_Action_Admin
{
  public function indexAction()
  {
  	$log = Zend_Registry::get('Zend_Log');
  	$this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
  	->getNavigation('mobileverification_admin_main', array(), 'mobileverification_admin_main_settings');
  	
  	$this->view->form = $form = new Mobileverification_Form_Admin_Twilio();
  	
  	$info_table = Engine_Api::_()->getDbtable('twilios', 'mobileverification');
  	$select_data = $info_table->select();
  	$exist_info = $info_table->fetchRow($select_data);
  	
  	$form->getElement('sid')->setValue($exist_info['account_sid']);
  	$form->getElement('auth')->setValue($exist_info['account_token']);
  	$form->getElement('twilio')->setValue($exist_info['twilio_number']); 
  	
  	if( !$this->getRequest()->isPost() ) {
  		return;
  	}
  	
  	if( !$form->isValid($this->getRequest()->getPost()) ) {
  		return;
  	}
  	
  	// Process
  	$values = $form->getValues();
  	
  	
  	
  	if (empty($exist_info)) {
  		$new_user_id = $info_table->insert ( array (
  				'account_sid' => $values['sid'],
  				'account_token' => $values['auth'],
  				'twilio_number' => $values['twilio'],
  					
  		) );
  	}
  	else 
  	{
  		$new_user_id = $info_table->update ( array (
  				'account_sid' => $values['sid'],
  				'account_token' => $values['auth'],
  				'twilio_number' => $values['twilio'],
  		),array('twilio_id = ? '=> $exist_info['twilio_id']) );
  	}
  	$form->addNotice("Information saved successfully");
  }
  
  public function globalAction()
  {
  	$log = Zend_Registry::get('Zend_Log');
  	$check=$this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
  	->getNavigation('mobileverification_admin_main', array(), 'mobileverification_admin_main_global');
  	 
  	$this->view->form = $form = new Mobileverification_Form_Admin_Setting();
  	
  	if( !$this->getRequest()->isPost() ) {
  		return;
  	}
  	 
  	if( !$form->isValid($this->getRequest()->getPost()) ) {
  		return;
  	}
  	
  	// Process
  	$values = $form->getValues();
  	$module_table = Engine_Api::_()->getDbtable('modules', 'core');
  	$signup_table = Engine_Api::_()->getDbtable('signup', 'user');
  	$module_table->update ( array (
  				'enabled' => $values['enable'],
  				),array('name=?'=> 'mobileverification') );
  	$signup_table->update ( array (
  			'enable' => $values['enable'],
  			),array('class=?'=> 'Mobileverification_Plugin_Signup_Verify') );
  if($values['enable'] == 1){
  $setting_select = $signup_table->select()->where('class=?','Mobileverification_Plugin_Signup_Verify');
  $setting_data = $signup_table->fetchRow($setting_select);
  if($setting_data){
    $signup_table->update ( array (
        'enable' => $values['enable'],
        ),array('class=?'=> 'Mobileverification_Plugin_Signup_Verify') );
  }else{
      $signup_table->insert ( array (
        'class' => 'Mobileverification_Plugin_Signup_Verify',
        'enable' => 1));
  }

  }else{
    $signup_table->delete(array(
                'class = ?' => 'Mobileverification_Plugin_Signup_Verify',
            ));
  }
  	$form->addNotice('Successfully save your changes');
  	//return $this->_helper->redirector->gotoRoute(array( 'action' => 'index'), 'admin_default', true);
 }
 
 public function profileAction()
 {
 	$log = Zend_Registry::get('Zend_Log');
 	$check=$this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
 	->getNavigation('mobileverification_admin_main', array(), 'mobileverification_admin_main_profile');
  	$this->view->form = $form = new Mobileverification_Form_Admin_Setting();
 	 
 	if( !$this->getRequest()->isPost() ) {
 		return;
 	}
 
 	if( !$form->isValid($this->getRequest()->getPost()) ) {
 		return;
 	}
 	 
 	// Process
 	$values = $form->getValues();
 	$menu_table = Engine_Api::_()->getDbtable('menuitems', 'core');
 	$menu_table->update ( array (
 			'enabled' => $values['enable'],
 	),array('name=?'=> 'user_edit_mobileveify') );

 	$form->addNotice('Successfully save your changes');
 	//return $this->_helper->redirector->gotoRoute(array( 'action' => 'index'), 'admin_default', true);
 }
 
 public function mobilesettingAction()
 {
 	$log = Zend_Registry::get('Zend_Log');
 	$this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
 	->getNavigation('mobileverification_admin_main', array(), 'mobileverification_admin_main_mobilesetting');
 
 	$this->view->form = $form = new Mobileverification_Form_Admin_Mobilesetting();
 		
 	if( !$this->getRequest()->isPost() ) {
 		return;
 	}
 
 	if( !$form->isValid($this->getRequest()->getPost()) ) {
 		return;
 	}
 		
 	// Process
 	$values = $form->getValues();
 	$setting_table = Engine_Api::_()->getDbtable('settings', 'mobileverification');
 	$setting_select = $setting_table->select()->where('user_id=?',1);
 	$setting_data = $setting_table->fetchRow($setting_select);
 	if(empty($setting_data))
 	{
 		$setting_table->insert ( array (
 				'unique_field' => $values['enable'],
 				'user_id' => 1));
 	}
 	else 
 	{
 		$setting_table->update ( array (
 				'unique_field' => $values['enable'],
 		),array('user_id=?'=> 1));
 	}
 	$form->addNotice('Successfully save your changes');
 	//return $this->_helper->redirector->gotoRoute(array( 'action' => 'index'), 'admin_default', true);
  }
  
  public function typesettingAction()
  {
  	$log = Zend_Registry::get('Zend_Log');
  	
  	$this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
  	->getNavigation('mobileverification_admin_main', array(), 'mobileverification_admin_main_typesetting');
  
  	$this->view->form = $form = new Mobileverification_Form_Admin_Type();
  	
  	$profile_id= $this->_getParam('profile_id');
  	
  	
  	 	// fetch profile label.  	
  		$metaTable = Engine_Api::_()->fields()->getTable('user', 'options');
  		$type_table = Engine_Api::_()->getDbtable('types', 'mobileverification');
  		 
  		$typeSelect = $type_table->select()
  		->setIntegrityCheck(false)
  		->from(array('typ' => $type_table->info('name')))
  		->join(array('met' => $metaTable->info('name')),'typ.profile_id = met.option_id',array("label"));
  		$meta_data = $type_table->fetchAll($typeSelect);
  		
  		foreach($meta_data as $item)
  		{
  			$name = preg_replace('/\s+/', '', $item->label)."fields";
  			$namehidden = preg_replace('/\s+/', '', $item->label)."_profile_type";
  			$form->getElement($name)->setValue($item->mobile_id);
  			$form->getElement($namehidden)->setValue($item->mobile_id);
  		} 
  	
  	if($profile_id==99)
  	{
  		return $this->_helper->redirector->gotoRoute(array( 'action' => 'typesetting','controller'=>'settings','module'=>'mobileverification'), 'admin_default', true);
  	}
  	$type_table = Engine_Api::_()->getDbtable('types', 'mobileverification');
  	$type_select = $type_table->select();
  	$type_data = $type_table->fetchRow($type_select);
  	
  	  
  	//Profile Type
  	//if($profile_id!="")
  	if(false)
  	{
  		   $getelement=$form->getElement('type')->setValue($profile_id);
  		     		    
  		    $meta_data = Engine_Api::_()->mobileverification()->setvalue($profile_id);
  		    $fieldsOptions = array();
  		    foreach( $meta_data as $item) {
  		    	$fieldsOptions[$item->field_id] = $item->label;
  		    	$field_id= $item->field_id;
  		    }
  		    
  		   //	$form->fields->setMultiOptions($fieldsOptions);
		  	//$form->getElement('fields')->setValue($field_id);
  	}

  	else
  	{
  		if(false)
  		//if(!empty($type_data) && ($profile_id==""))
  		{
  			$form->getElement('type')->setValue($type_data->profile_id);
  			$profile_id = $type_data->profile_id;
  			$form->getElement('type')->setValue($profile_id);
  			
  			$meta_data = Engine_Api::_()->mobileverification()->setvalue($profile_id);
  			
  			$fieldsOptions = array();
  			foreach( $meta_data as $item) {
  			$fieldsOptions[$item->field_id] = $item->label;
  				}
  			$form->fields->setMultiOptions($fieldsOptions);
  			$form->getElement('fields')->setValue($type_data->mobile_id);
  				
  			  			
  		}
  	}
  	  	  	
  	if( !$this->getRequest()->isPost() ) {
  		return;
  	}
  
  	if( !$form->isValid($this->getRequest()->getPost()) ) {
  		return;
  	}
  		
  	// Process
  
  	$values = $form->getValues();
  	
  	
  	if($profile_id!="")
  	{
	  	if(empty($type_data))
	  	{
	  		$type_table->insert ( array (
	  				'profile_id' => $profile_id ,
	  				'mobile_id' => $values['fields'],
	  				'user_id' => 1,
	  				));
	  	}
	  	else 
	  	{
	  		$typeselect = $type_table->select()->where('profile_id=?',$profile_id);
	  		$typesdata = $type_table->fetchRow($typeselect);
	  		
	  		if(!empty($typesdata))
	  		{
		  		$type_table->update ( array (
		  		  		'mobile_id' => $values['fields'],
		  		),array('profile_id=?'=> $profile_id));
	  		}
	  		else 
	  		{
	  			$type_table->insert ( array (
	  					'profile_id' => $profile_id ,
	  					'mobile_id' => $values['fields'],
	  					'user_id' => 1,
	  			));
	  		}
	  	}
  	}
  	
  	
  	
    	$form->addNotice('Successfully save your changes');
  }

  public function userverfiedAction()
{
	$log = Zend_Registry::get('Zend_Log');
	$this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
	->getNavigation('mobileverification_admin_main', array(), 'mobileverification_admin_main_userverfied');
    $this->view->formFilter = $formFilter = new User_Form_Admin_Manage_Filter();
    $page = $this->_getParam('page', 1);
	//get the details of users for status
    $metaTable= Engine_Api::_()->getDbtable('users', 'user');
    $verificationTable = Engine_Api::_ ()->getDbtable ( 'verifications', 'mobileverification' );
    
      $select = $metaTable->select()
    ->setIntegrityCheck(false)
    ->from(array('met' => $metaTable->info('name')))
    ->joinLeft(array('ver' => $verificationTable->info('name')),'ver.user_id = met.user_id', array('verified'));
    
    $profiledata = $verificationTable->fetchAll($select);
     // Process form
    $values = array();
    if( $formFilter->isValid($this->_getAllParams()) ) {
      $values = $formFilter->getValues();
    }

    foreach( $values as $key => $value ) {
      if( null === $value ) {
        unset($values[$key]);
      }
    }

    $values = array_merge(array(
      'order' => 'user_id',
      'order_direction' => 'DESC',
    ), $values);
    
    $this->view->assign($values);

    // Set up select info
    $select->order(( !empty($values['order']) ? $values['order'] : 'user_id' ) . ' ' . ( !empty($values['order_direction']) ? $values['order_direction'] : 'DESC' ));

    if( !empty($values['displayname']) ) {
      $select->where('displayname LIKE ?', '%' . $values['displayname'] . '%');
    }
    if( !empty($values['username']) ) {
      $select->where('username LIKE ?', '%' . $values['username'] . '%');
    }
    if( !empty($values['email']) ) {
      $select->where('email LIKE ?', '%' . $values['email'] . '%');
    }
    if( !empty($values['level_id']) ) {
      $select->where('level_id = ?', $values['level_id'] );
    }
    if( isset($values['enabled']) && $values['enabled'] != -1 ) {
      $select->where('enabled = ?', $values['enabled'] );
    }
    if( !empty($values['user_id']) ) {
      $select->where('user_id = ?', (int) $values['user_id']);
    }
    
    // Filter out junk
    $valuesCopy = array_filter($values);
    // Reset enabled bit
    if( isset($values['enabled']) && $values['enabled'] == 0 ) {
      $valuesCopy['enabled'] = 0;
    }
    
    // Make paginator
    $this->view->paginator = $paginator = Zend_Paginator::factory($select);
    $this->view->paginator = $paginator->setCurrentPageNumber( $page );
    $this->view->formValues = $valuesCopy;

    $this->view->superAdminCount = count(Engine_Api::_()->user()->getSuperAdmins());
    $this->view->hideEmails = _ENGINE_ADMIN_NEUTER;
    //$this->view->formDelete = new User_Form_Admin_Manage_Delete();
    
    $this->view->openUser = (bool) ( $this->_getParam('open') && $paginator->getTotalItemCount() == 1 );
  }
  
  
  
  
  }