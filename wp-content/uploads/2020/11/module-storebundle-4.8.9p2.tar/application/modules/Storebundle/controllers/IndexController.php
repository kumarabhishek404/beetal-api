<?php

class Storebundle_IndexController extends Core_Controller_Action_Standard
{
  public function indexAction()
  {
  }
}
