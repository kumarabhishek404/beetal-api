<?php return array(
  'package' =>
    array(
      'type' => 'module',
      'name' => 'storebundle',
      'version' => '4.8.9p2',
      'path' => 'application/modules/Storebundle',
      'title' => 'Store Bundle Products',
      'description' => 'Store Bundle Products Plugin from Hire-Express LLC',
      'author' => '<a href="http://www.hire-experts.com" title="Hire-Experts LLC" target="_blank">Hire-Experts LLC</a>',
      'meta' => array(
        'title' => 'Store Bundle Products',
        'description' => 'Store Bundle Products Plugin from Hire-Express LLC',
        'author' => '<a href="http://www.hire-experts.com" title="Hire-Experts LLC" target="_blank">Hire-Experts LLC</a>',
      ),
      'dependencies' => array(
        array(
          'type' => 'module',
          'name' => 'core',
          'minVersion' => '4.1.8',
        ),
        array(
          'type' => 'module',
          'name' => 'store',
          'minVersion' => '4.3.2',
        ),
      ),
      'callback' => array(
        'path' => 'application/modules/Storebundle/settings/install.php',
        'class' => 'Storebundle_Installer',
      ),
      'actions' =>
        array(
          0 => 'install',
          1 => 'upgrade',
          2 => 'refresh',
          3 => 'enable',
          4 => 'disable',
        ),
      'directories' =>
        array(
          0 => 'application/modules/Storebundle',
          1 => 'application/libraries/Hireexperts',
        ),
      'files' =>
        array(
          0 => 'application/languages/en/storebundle.csv',
          1 => 'application/languages/en/hecore.csv',
        ),
    ),
  // Items ---------------------------------------------------------------------
  'items' => array(
    'storebundle'
  ),
  'hooks' => array(
    array(
      'event' => 'onItemDeleteAfter',
      'resource' => 'Storebundle_Plugin_Core',
    ),
  ),
); ?>