INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES  ('headvancedmembers', 'Advanced Members', 'Advanced Members', '5.2.0', 1, 'extra') ;
