<?php return array (
  'package' =>
  array (
    'type' => 'module',
    'name' => 'headvancedmembers',
    'version' => '5.2.0',
    'path' => 'application/modules/Headvancedmembers',
    'title' => 'Advanced Members',
    'description' => 'Advanced Members',
    'author' => '<a href="http://www.hire-experts.com" title="Hire-Experts LLC" target="_blank">Hire-Experts LLC</a>',
    'sku' => 'HEAMMP2',
    'callback' => array(
      'path' => 'application/modules/Headvancedmembers/settings/install.php',
      'class' => 'Headvancedmembers_Installer',
    ),
    'actions' =>
    array (
      0 => 'install',
      1 => 'upgrade',
      2 => 'refresh',
      3 => 'enable',
      4 => 'disable',
    ),
    'directories' =>
    array (
      0 => 'application/modules/Headvancedmembers',
    ),
    'files' =>
    array (
      0 => 'application/languages/en/headvancedmembers.csv',
    ),
  ),
); ?>
