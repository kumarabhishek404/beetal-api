<?php

class Headvancedmembers_Api_Core extends Core_Api_Abstract
{

  public function isActive($subject)
  {
    $table = Engine_Api::_()->getDbTable('status', 'headvancedmembers');
    $select  = $table->select()->where('user_id = ?',$subject->getIdentity())->where('status = 1');
    $row = $table->fetchRow($select);
    if($row){
      return true;
    }
    return false;
  }
  public function usersSupported($subject)
  {
    $table = Engine_Api::_()->getDbTable('verification', 'headvancedmembers');
    $select  = $table->select()->where('user_id = ?',$subject->getIdentity());
    $row = $table->fetchAll($select);
    return count($row);
  }

  public function getMemberType($user){
    $subject = $user;
    $fieldsByAlias = Engine_Api::_()->fields()->getFieldsObjectsByAlias($subject);

    if (!empty($fieldsByAlias['profile_type'])) {
      $optionId = $fieldsByAlias['profile_type']->getValue($subject);
      if ($optionId) {
        $optionObj = Engine_Api::_()->fields()
          ->getFieldsOptions($subject)
          ->getRowMatching('option_id', $optionId->value);
        if ($optionObj) {
          $ProfileType =  $optionObj->label;
        }else{
          $ProfileType =  '';
        }
      }
    }
    return $ProfileType;
  }
  public function getFaceBookUrl($user){
    $profileTypeId = $this->getProfileType($user);
    if (!$profileTypeId)
      return false;
    $fieldsMapsTable = new Fields_Model_DbTable_Meta("user", "maps");
    $fieldsMetaTable = new Fields_Model_DbTable_Meta("user", "meta");

    $select = $fieldsMetaTable->select()
      ->setIntegrityCheck(false)
      ->from(array("meta" => $fieldsMetaTable->info('name')), array("meta.field_id"))
      ->where("type = ?", "facebook")
      ->joinLeft(array("maps" => $fieldsMapsTable->info('name')), "meta.field_id = maps.child_id", array())
      ->where("option_id = ?", $profileTypeId);

      $result = $fieldsMetaTable->fetchAll($select)->toArray();

    if (!empty($result)) {
      $birthdayFieldId=  $result[0]['field_id'];
    }
    $fieldsValuesTable = new Fields_Model_DbTable_Values("user", "values");
    $myBirthdaySql = $fieldsValuesTable->select()->where("field_id = ?", $birthdayFieldId)->where("item_id = ?", $user->getIdentity());
    $myBirthdayRow = $fieldsValuesTable->fetchAll($myBirthdaySql)->toArray();
    if($myBirthdayRow && !empty($myBirthdayRow[0]['value'])) {

      return $myBirthdayRow[0]['value'];
    }
    return false;
  }
  public function getTwitterUrl($user){
    $profileTypeId = $this->getProfileType($user);
    if (!$profileTypeId)
      return false;
    $fieldsMapsTable = new Fields_Model_DbTable_Meta("user", "maps");
    $fieldsMetaTable = new Fields_Model_DbTable_Meta("user", "meta");

    $select = $fieldsMetaTable->select()
      ->setIntegrityCheck(false)
      ->from(array("meta" => $fieldsMetaTable->info('name')), array("meta.field_id"))
      ->where("type = ?", "twitter")
      ->joinLeft(array("maps" => $fieldsMapsTable->info('name')), "meta.field_id = maps.child_id", array())
      ->where("option_id = ?", $profileTypeId);

      $result = $fieldsMetaTable->fetchAll($select)->toArray();

    if (!empty($result)) {
      $birthdayFieldId=  $result[0]['field_id'];
    }
    $fieldsValuesTable = new Fields_Model_DbTable_Values("user", "values");
    $myBirthdaySql = $fieldsValuesTable->select()->where("field_id = ?", $birthdayFieldId)->where("item_id = ?", $user->getIdentity());
    $myBirthdayRow = $fieldsValuesTable->fetchAll($myBirthdaySql)->toArray();
    if($myBirthdayRow && !empty($myBirthdayRow[0]['value'])) {

      return $myBirthdayRow[0]['value'];
    }
    return false;
    
  }
  public function getWebsiteUrl($user){
    $profileTypeId = $this->getProfileType($user);
    if (!$profileTypeId)
      return false;
    $fieldsMapsTable = new Fields_Model_DbTable_Meta("user", "maps");
    $fieldsMetaTable = new Fields_Model_DbTable_Meta("user", "meta");

    $select = $fieldsMetaTable->select()
      ->setIntegrityCheck(false)
      ->from(array("meta" => $fieldsMetaTable->info('name')), array("meta.field_id"))
      ->where("type = ?", "website")
      ->joinLeft(array("maps" => $fieldsMapsTable->info('name')), "meta.field_id = maps.child_id", array())
      ->where("option_id = ?", $profileTypeId);

      $result = $fieldsMetaTable->fetchAll($select)->toArray();

    if (!empty($result)) {
      $birthdayFieldId=  $result[0]['field_id'];
    }
    $fieldsValuesTable = new Fields_Model_DbTable_Values("user", "values");
    $myBirthdaySql = $fieldsValuesTable->select()->where("field_id = ?", $birthdayFieldId)->where("item_id = ?", $user->getIdentity());
    $myBirthdayRow = $fieldsValuesTable->fetchAll($myBirthdaySql)->toArray();
    if($myBirthdayRow && !empty($myBirthdayRow[0]['value'])) {

      return $myBirthdayRow[0]['value'];
    }
    return false;
    
  }
    public function getAboutMe($user){
    $profileTypeId = $this->getProfileType($user);
    if (!$profileTypeId)
      return false;
    $fieldsMapsTable = new Fields_Model_DbTable_Meta("user", "maps");
    $fieldsMetaTable = new Fields_Model_DbTable_Meta("user", "meta");

    $select = $fieldsMetaTable->select()
      ->setIntegrityCheck(false)
      ->from(array("meta" => $fieldsMetaTable->info('name')), array("meta.field_id"))
      ->where("type = ?", "about_me")
      ->joinLeft(array("maps" => $fieldsMapsTable->info('name')), "meta.field_id = maps.child_id", array())
      ->where("option_id = ?", $profileTypeId);

      $result = $fieldsMetaTable->fetchAll($select)->toArray();

    if (!empty($result)) {
      $birthdayFieldId=  $result[0]['field_id'];
    }
    $fieldsValuesTable = new Fields_Model_DbTable_Values("user", "values");
    $myBirthdaySql = $fieldsValuesTable->select()->where("field_id = ?", $birthdayFieldId)->where("item_id = ?", $user->getIdentity());
    $myBirthdayRow = $fieldsValuesTable->fetchAll($myBirthdaySql)->toArray();
    if($myBirthdayRow && !empty($myBirthdayRow[0]['value'])) {

      return $myBirthdayRow[0]['value'];
    }
    return false;
    
  }
    public function getProfileType($user)
  {
    $fieldsSearchTable = new Fields_Model_DbTable_Search("user", "search");
    $profileTypeSql = $fieldsSearchTable->select()->where("item_id = ?", $user->user_id);
    $profileTypeRow = $fieldsSearchTable->fetchRow($profileTypeSql);

    if(!$profileTypeRow || !is_object($profileTypeRow))
      return "";
    $profileType = $profileTypeRow->toArray();
    return $profileType['profile_type'];
  }

}