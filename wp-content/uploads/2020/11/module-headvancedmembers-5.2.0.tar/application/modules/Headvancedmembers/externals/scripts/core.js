/**
  $Id: core.js 2015-10-13 01:44 bolot $
 */
var HeadvancedMembers = {};
HeadvancedMembers.init  = function(){
  var body_element = $$('body')[0];
  this.bg.inject(body_element);
  this.contaner.inject(body_element);
  this.rebiltButtons();
};
HeadvancedMembers.bg = new Element('div',{
  'class':'bg_form_headvuser',
  'id': 'bg_form_headvuser',
  'style':'position:fixed; top:0px; left:0px; width: 100%; height: 100%; background-color:rgba(0,0,0,0.4);display:none;z-index:999;'
});
HeadvancedMembers.contaner = new Element('div',{
  'class':'container_form_headvuser',
  'id': 'container_form_headvuser',
  'style':'position:absolute; top:100px; left:40%; width: 400px; min-height: 200px; background-color:#fff;display:none;z-index:1000;'
});

HeadvancedMembers.request  = function (url, data, callback) {
  if (typeof(data) == 'object') {
    data.format = 'json';
  } else if (typeof(data) == 'string') {
    data += '&format=json';
  }
  HeadvancedMembers.is_request = true;

  (new Request.JSON({
    secure: false,
    url: url,
    method: 'post',
    data: data,
    onSuccess: function (obj) {
      // callback
      if ($type(callback) == 'function') {
        callback(obj);
      }
    }
  })).send();

};
HeadvancedMembers.html  = function (url, data, callback) {
  if (typeof(data) == 'object') {

  } else if (typeof(data) == 'string') {
    data += '&format=json';
  }
  HeadvancedMembers.is_request = true;

  (new Request.HTML({
    secure: false,
    url: url,
    method: 'post',
    data: data,
    onSuccess: function (responseTree, responseElements, responseHTML, responseJavaScript) {

      // callback
      if ($type(callback) == 'function') {
        callback(responseHTML);
      }
    }
  })).send();

};
HeadvancedMembers.search = function(element){
  var self = this;
  var data  = element.value;
  var url = en4.core.baseUrl + 'headvancedmembers/index/search';
  if(data.length>2){
    $('hememberslist1').setStyle('display','block');
    $('hememberslist1').set('html','loading...');
    var post = {'search':data, 'format':'html'};
    self.html(url,post,function(ebg){
      var error = 0;
      var type = '';
      $('hememberslist').setStyle('display','none');
      $('hememberslist1').setStyle('display','block');
      $('hememberslist1').set('html',ebg);
    });
  }else{
    $('hememberslist').setStyle('display','block');
    $('hememberslist1').setStyle('display','none');
    $('hememberslist1').set('html','');
  }
};
HeadvancedMembers.rebiltButtons = function(){
    var self = this;
  $('search_headvanced_members').addEvent('keyup',function(){
    HeadvancedMembers.search(this);
  });
    $$('.headvuser_button').each(function(button){
      var element =  $(button);
      var href =  element.get('href');
      var url = href.replace('/members/','/headvancedmembers/');
      element.removeEvent('click');
      var loader = new HeadvancedMembers.loader();
      element.addEvent('click', function (e) {
        e.stopPropagation();
        e.preventDefault();
        var parent = this.getParent();
        if(parent) {
          parent.set('html', '<img class="irc_mi" style="width:16px;height:16px;" src="' + en4.core.baseUrl + 'application/modules/Headvancedmembers/externals/images/loading.gif" width="16" height="16" title="loading ">');
        }
        self.request(url,'',function(ebg){
          var error = 0;
          var type = '';
          if(ebg.message){
            var message = ebg.message;
          }else{
            error = 1;
            var message = en4.core.language.translate('An error has occurred.');
          }
          if(error>0){
            he_show_message(message,type);
            type = 'error';
          }else{
          if(parent){
            parent.set('html',ebg.body);
            he_show_message(message,type);
            HeadvancedMembers.rebiltButton(parent);
          }
            if($('hememberslist') && (370*3) >=$('hememberslist').getSize().x){
              $$('#browsemembers_ul_normal_advhe li').each(function(element){
                element.setStyle('width','44%')
              })
            }
          }
        });
      })
      });

};
HeadvancedMembers.rebiltButton = function(parent_b){
    var self = this;
      var element =  parent_b.getChildren('a')[0];
      var href =  element.get('href');
      var url = href.replace('/members/','/headvancedmembers/');
      element.removeEvent('click');
      var loader = new HeadvancedMembers.loader();
      element.addEvent('click', function (e) {
        self.contaner.set('html','loading');
        e.stopPropagation();
        e.preventDefault();
        var parent = this.getParent();
        if(parent) {
          parent.set('html', '<img class="irc_mi" style="width:16px;height:16px;" src="' + en4.core.baseUrl + 'application/modules/Headvancedmembers/externals/images/loading.gif" width="16" height="16" title="loading ">');
        }
        self.request(url,'',function(ebg){
          var error = 0;
          var type = '';
          if(ebg.message){
            var message = ebg.message;
          }else{
            type = 'error'
            error = 1;
            var message = 'An error has occurred.';
          }
          if(error>0){
            he_show_message(message,type);
          }else{
          if(parent){
            parent.set('html',ebg.body);
            he_show_message(message,type);
            HeadvancedMembers.rebiltButton(parent);
          }

          }
        });
      })
      ;

};
HeadvancedMembers.loader =  new Class({

  bg: HeadvancedMembers.bg,
  element: HeadvancedMembers.contaner,


  hide: function () {
    if (this.element) {
      $(this.element).setStyle('display', 'none');
    }
    if (this.bg) {
      $(this.bg).setStyle('display', 'none');
    }
  },

  show: function () {
    var self = this;
    this.bg.addEvent('click',function(){
      self.bg.setStyle('display','none');
      self.element.setStyle('display','none');
      self.element.set('html','');
    });
    if (this.element) {
      $(this.element).setStyle('display', 'block');
    }
    if (this.bg) {
      $(this.bg).setStyle('display', 'block');
    }
  }

});/* function(){
  var body_element = $$('body')[0];

    console.log(this.bg);

};*/