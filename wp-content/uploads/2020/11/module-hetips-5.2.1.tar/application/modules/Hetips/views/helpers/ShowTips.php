<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Hetips
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: ShowTips.php 2012-03-31 13:34 alexander $
 * @author     Alexander
 */

/**
 * @category   Application_Extensions
 * @package    Hetips
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Hetips_View_Helper_ShowTips  extends Zend_View_Helper_Abstract
{

  public function showTips($tips, $type, $settings)
  {
    $content = '';
      if ($settings[$type.'_show_labels']) {
        foreach($tips as $label => $tip){
          if ($tip != null) {
            $tip = substr($tip,0, 100);
            if($label == 'First Name'){
              $icon = 'fa fa-user';
            }
            if($label == 'Last Name'){
              $icon = 'fa fa-user';
            }
            if($label == 'About Me'){
              $icon = 'fa fa-info-circle';
            }
            if($label == 'Gender'){
              $icon = 'fa fa-venus-mars';
            }
            if($label == 'Birthday'){
              $icon = 'fa fa-calendar-alt';
            }
            if($label == 'Twitter'){
              $icon = 'fab fa-twitter';
            }
            if($label == 'Facebook'){
              $icon = 'fab fa-facebook-f';
            }
            if($label == 'Website'){
              $icon = 'fa fa-globe';
            }
            if($label == 'Facebook' || $label == 'Twitter'){
              $content .= <<<EOL
              <li class="custom-tips"><span style="font-weight:bold;"><i class="{$icon}"></i>{$this->view->translate($label)}: </span> <a href="{$this->view->translate($tip)}">{$this->view->translate($label)} Profile</a></li>
EOL;
            }else{

            
            $content .= <<<EOL
              <li class="custom-tips"><span style="font-weight:bold;"><i class="{$icon}"></i>{$this->view->translate($label)}:</span> {$this->view->translate($tip)}</li>
EOL;
}
          }
        }
      } else {
        foreach($tips as $tip){
          if ($tip != null) {
            $tip = substr($tip,0, 100);
            $content .= <<<EOL
              <li>{$this->view->translate($tip)}</li>
EOL;
          }
        }
      }
    return $content;
  }
}