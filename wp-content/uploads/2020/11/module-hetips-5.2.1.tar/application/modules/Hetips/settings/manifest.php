<?php return array (
  'package' => 
  array (
    'type' => 'module',
    'name' => 'hetips',
    'version' => '5.2.1',
    'path' => 'application/modules/Hetips',
    'title' => 'Hire-Experts Tips',
    'description' => '',
    'author' => '<a href="http://www.hire-experts.com" title="Hire-Experts LLC" target="_blank">Hire-Experts LLC</a>',
    'sku' => 'HEAMTTP',
    'callback' =>
    array (
        'class' => 'Hetips_Installer',
        'path' => 'application/modules/Hetips/settings/install.php',
      
    ),
    'actions' => 
    array (
      0 => 'install',
      1 => 'upgrade',
      2 => 'refresh',
      3 => 'enable',
      4 => 'disable',
    ),
    'directories' => 
    array (
      0 => 'application/modules/Hetips',
    ),
    'files' => 
    array (
      0 => 'application/languages/en/hetips.csv',
    ),
  ),
  /*Hooks -----------------------------------------> */
  'hooks' => array(
    array(
      'event' => 'onRenderLayoutDefault',
      'resource' => 'Hetips_Plugin_Core'
    )
  ),
); ?>