INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`)
VALUES  ('hetips', 'Hire-Experts Tips', '', '5.2.1', 1, 'extra') ;

CREATE TABLE IF NOT EXISTS `engine4_hetips_maps` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tip_id` int(10) unsigned DEFAULT '0',
  `tip_type` varchar(100) NOT NULL,
  `option_id` int(10) unsigned DEFAULT '0',
  `order` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=0;

CREATE TABLE IF NOT EXISTS `engine4_hetips_types` (
  `type_id` int(10) unsigned NOT NULL ,
  `type` varchar(50) DEFAULT NULL,
  `label` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB;

INSERT IGNORE INTO `engine4_hetips_types` (`type_id`, `type`, `label`) VALUES
  (1, 'user', 'USER_PROFILE_TIPS'),
  (2, 'page', 'PAGE_PROFILE_TIPS'),
  (3, 'group', 'GROUP_PROFILE_TIPS');

CREATE TABLE IF NOT EXISTS `engine4_hetips_meta` (
  `tip_id` int(5) unsigned NOT NULL ,
  `tip_type` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `label` varchar(150) DEFAULT NULL,
  `order` int(10) unsigned DEFAULT '999',
  PRIMARY KEY (`tip_id`)
) ENGINE=InnoDB;

INSERT IGNORE INTO `engine4_hetips_meta` (`tip_id`, `tip_type`, `type`, `label`, `order`) VALUES
  (1, 'page', 'url', 'Url', 999),
  (2, 'page', 'displayname', 'Display Name', 999),
  (3, 'page', 'title', 'Title', 999),
  (4, 'page', 'country', 'Country', 999),
  (5, 'page', 'street', 'Street', 999),
  (6, 'page', 'phone', 'Phone', 999),
  (7, 'page', 'website', 'Web Site', 999),
  (8, 'group', 'title', 'Title', 999),
(9, 'group', 'member_count', 'Member count', 999);

CREATE TABLE IF NOT EXISTS `engine4_hetips_settings` (
  `type_id` int(5) DEFAULT NULL,
  `name` varchar(100) NOT NULL DEFAULT '',
  `value` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB;

INSERT IGNORE INTO `engine4_hetips_settings` (`type_id`, `name`, `value`) VALUES
(1, 'user_display_friends', '1'),
(1, 'user_how_display', 'hetips_own_row'),
(1, 'user_likes_count', '1'),
(1, 'user_show_labels', '1'),
(2, 'page_how_display', 'hetips_own_row'),
(2, 'page_likes_count', '1'),
(2, 'page_members_like', '1'),
(2, 'page_show_labels', '1'),
(3, 'group_display_friends', '1'),
(3, 'group_how_display', 'hetips_own_row'),
(3, 'group_likes_count', '1'),
(3, 'group_members_count', '1'),
(3, 'group_show_labels', '1');

INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `params`, `menu`, `order`) VALUES 
('hetips_admin_main_settings', 'hetips', 'HETIPS_Hetips', '{\"route\":\"admin_default\",\"module\":\"hetips\"}', 'core_admin_main_plugins', 888);
