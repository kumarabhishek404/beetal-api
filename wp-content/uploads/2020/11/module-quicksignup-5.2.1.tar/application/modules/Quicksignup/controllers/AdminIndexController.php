<?php
class Quicksignup_AdminIndexController extends Core_Controller_Action_Admin
{
	public function indexAction()
	{
		$log=Zend_Registry::get('Zend_Log');
			
		$this->view->form = $form = new Quicksignup_Form_Admin_Settings();
		$setting_table = Engine_Api::_()->getDbTable('settings','quicksignup');
		$select = $setting_table->select()
		//->where('password_type = ?', $password_type);
		;
		$passwordtype_exits = $setting_table->fetchRow($select);
		$pass = $passwordtype_exits->password;
		if($pass)
		{
			$form->getElement('password_type')->setValue('1');
			$form->getElement('password')->setValue($pass);
			$this->view->pass=true;
		}
		else {
			$form->getElement('password_type')->setValue('0');
			$this->view->pass=false;
		}
		// Not post/invalid
		if (!$this->getRequest()->isPost()) {
			return;
		}
		
		if (!$form->isValid($this->getRequest()->getPost())) {
			$this->view->formErrors = $form->getMessages(null, true);
			return;
		}
				// Process
				$values = $form->getValues();
				$password = $values['password'];
				$password_type = $values['password_type'];
				if ($this->getRequest()->isPost()) {
					if($password == null && $password_type == 1)
					{
						$form->addErrors(array('please fill password'));
						return;
					}	
				}
				  	
				$db = $setting_table->getAdapter();
					$db->beginTransaction();
					try {
						if (!$passwordtype_exits['setting_id']) {
							$passwordtype_exits = $setting_table->createRow();
						}
						
						$passwordtype_exits->setFromArray($values);
						if($values['password_type']==0)
						{
							$passwordtype_exits['password'] = '';
						}
						$passwordtype_exits->save();
						$db->commit();
						$form->addNotice(array('Your values has been saved'));
					}
					catch (Exception $e)
					{
						$db->rollBack();
						throw $e;
					}
	}
}