<?php
/**
 * iPragmatech Solution Pvt. Ltd.
 *
 * @category   Application_User Importer
 * @package    User Importer
 * @copyright  Copyright 2008-2013 iPragmatech Solution Pvt. Ltd.
 * @license   � 2013 iPragmatech. All Rights Reserved.
 * @version    $Id: Global.php 9747 2013-07-06 02:08:08Z iPrgamtech $
 * @author     iPragmatech
 */

class Quicksignup_Form_User extends Engine_Form
{
  public function init()
  {
  	$tabindex = 1;
  	

  	$this->setAttrib('id', 'quick_signup_widget');
  	//$this->setTitle('Quick Signup');

  	//Email Address
  	$this->addElement('Text', 'email', array(
  			'label' => 'Email',
  			'validators' => array(
  					array('EmailAddress', true),
  			),
  			'filters' => array(
  					'StringTrim'
  			),
  			'class'=>'text'
  	));
  	
  	//Name
  	$this->addElement('Text', 'username', array(
  			'label' => 'Name',
  	));
    
  	// Add submit button
    $this->addElement('Button', 'user_signup', array(
      'label' => 'Sign Up',
      'type' => 'submit',
    ));
  }
}