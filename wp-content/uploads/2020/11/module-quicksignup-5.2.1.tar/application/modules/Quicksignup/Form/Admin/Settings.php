<?php
class Quicksignup_Form_Admin_Settings extends Engine_Form
{
	public function init()
	{

		$this->setAttrib('id', 'admin-settings');
		$this->setTitle('Quick Signup');
		$this->setDescription('Select the type of password You want to send when user signup');
		 
		
		$this->addElement('Radio', 'password_type', array(
				'label' => 'Select Type of Password',
				'required'=>true,
				'multiOptions' => array(
						'0' => 'Random Password',
						'1' => 'Enter Your Password',
				),
				'value' => 0
			));
		 
		//Name
		$this->addElement('Text', 'password', array(
				'label' => 'Enter Your Password',
				
		));

		// Add submit button
		$this->addElement('Button', 'submit', array(
				'label' => 'Save Changes',
				'type' => 'submit',
		));
	}
}