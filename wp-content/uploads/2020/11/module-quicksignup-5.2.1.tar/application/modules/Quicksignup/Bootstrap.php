<?php

class Quicksignup_Bootstrap extends Engine_Application_Bootstrap_Abstract
{

}