UPDATE `engine4_core_modules` SET `version` = '4.8.11'  WHERE `name` = 'quicksignup';

