INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES  ('quicksignup', 'Quicksignup', 'Quick and easy signup for user.', '5.2.1', 1, 'extra') ;
INSERT INTO `engine4_core_menuitems` (`id`, `name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES (NULL, 'core_admin_main_quicksignup_manage', 'quicksignup', 'Quick Signup', '', '{"route":"admin_default","module":"quicksignup","controller":"index"}', 'core_admin_main_plugins', '', '1', '0', '1');
CREATE TABLE IF NOT EXISTS `engine4_quicksignup_settings` (
  `setting_id` int(10) NOT NULL AUTO_INCREMENT,
  `password_type` tinyint(4) NOT NULL,
  `password` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`setting_id`)
);