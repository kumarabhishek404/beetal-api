<?php return array (
  'package' =>
  array (
    'type' => 'module',
    'name' => 'quicksignup',
    'version' => '5.2.1',
    'path' => 'application/modules/Quicksignup',
    'title' => 'Quicksignup',
    'description' => 'Quick and easy signup for user.',
    'author' => '<a href="http://ipragmatech.com/">iPragmatech</a>',
    'sku' => 'se-quicksignup',
    'callback' =>
    array (
      'class' => 'Engine_Package_Installer_Module',
    ),
    'actions' =>
    array (
      0 => 'install',
      1 => 'upgrade',
      2 => 'refresh',
      3 => 'enable',
      4 => 'disable',
    ),
    'directories' =>
    array (
      0 => 'application/modules/Quicksignup',
    ),
    'files' =>
    array (
      0 => 'application/languages/en/quicksignup.csv',
    ),
  ),
); ?>