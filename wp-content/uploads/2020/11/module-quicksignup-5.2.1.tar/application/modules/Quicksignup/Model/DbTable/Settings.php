<?php
class Quicksignup_Model_DbTable_Settings extends Engine_Db_Table
{
	protected $_rowClass = 'Quicksignup_Model_Setting';
	
}