<?php

class Quicksignup_Api_Core extends Core_Api_Abstract
{    
    public function quickSignup(array $userdata = array(),$type,$level_id) {
    	$log = Zend_Registry::get('Zend_Log');
    	$setting_table = Engine_Api::_()->getDbTable('settings','quicksignup');
    	$setting_select = $setting_table->select()
    	                               ->where('password_type = 1');
    	$log->log('query coming>>>'.$setting_select,Zend_Log::DEBUG);
    	$password_exits = $setting_table->fetchRow($setting_select);
    	foreach ($userdata as $key=>$value)
    	{
    		if(!empty($key) && !empty($value))
    		{
    				$email = $key;
    				if(isset($password_exits) && count($password_exits)>0)
    				{
    					$admin_password = $password_exits->password;
    					$log->log('inside admin password>>>'.$admin_password,Zend_Log::DEBUG);
    					$password = $admin_password;
    				}
    				else {
    					$password = Engine_Api::_()->user()->randomPass(10);
    					$log->log('inside other password>>>'.$password,Zend_Log::DEBUG);
    				}
		    		$user_name = $value;
		    		$last_name= '';
		    		$userarry = explode ( " ", $user_name );
		    		$user_table = Engine_Api::_ ()->getDbtable ( 'users', 'user' );
		    		$user_select = $user_table->select ()->where ( 'email = ?', $email );
		    		
		    		// If post exists
		    		$existing_user = $user_table->fetchRow ( $user_select );
		    		
		    		if(empty($existing_user))
		    		{
		    			$first_name = $userarry [0];
			    		if (count ( $userarry ) > 1 && $userarry [1]) {
			    			$last_name = $userarry [1];
			    		}
			    			
			    		try {
			    
			    			$salt = (string) rand(1000000, 9999999);
			    			$salt1 = Engine_Api::_ ()->getApi ( 'settings', 'core' )->getSetting ( 'core.secret', 'staticSalt' );
			    			$incrypt_password = md5 ( $salt1.$password.$salt);
			    			$new_user_id = $user_table->insert ( array (
			    					'user_id' => null,
			    					'email' => $email,
			    					'level_id' => $level_id,
			    					'password' => $incrypt_password,
			    					'salt' => $salt,
			    					'modified_date' => new Zend_Db_Expr ( 'NOW()' ),
			    					'creation_date' => new Zend_Db_Expr ( 'NOW()' )
			    			) );
			    
			    			$userfieldsearchtable = Engine_Api::_ ()->fields ()->getTable ( 'user', 'search' );
			    			$userfieldsearchtable->insert ( array (
			    					'item_id' => $new_user_id,
			    					'profile_type' => $type,
			    					'first_name' => $first_name,
			    					'last_name' => $last_name
			    			) );
							
			    			/*** code start for send welcome email on each email address***/
								$mail_Params = array(
										'host' => $_SERVER['HTTP_HOST'],
										'email' => $email,
										'recipient_title' => $first_name,
										'password' => $password,
										'object_link'=> '/login',
				
								);

								Engine_Api::_()->getApi('mail', 'core')->sendSystem($email, 'core_welcome_password', $mail_Params);
							/*** code end for send welcome email on each email address***/

			    		} 
			    		catch ( Exception $e ) {
			    			$status = false;
			    			$message = 'User creation failed' . $e;
			    		}
				}
		    
    		}
    	}
    }
    
}
