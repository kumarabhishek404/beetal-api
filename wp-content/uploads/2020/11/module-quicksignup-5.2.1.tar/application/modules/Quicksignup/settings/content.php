<?php
/**
 * SocialEngine
 *
 * @category   Application_UserImporter
 * @package    Userimport
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.ipragmatech.com/license/
 * @version    $Id: content.php 9747 2012-07-26 02:08:08Z ipragmatech $
 * @author     iPragmatech
 */
return array(
  		array(
				'title' => 'Quick User SignUp',
				'description' => 'Quick user SignUp on socialengine',
				'category' => 'Quick SignUp',
				'type' => 'widget',
				'name' => 'quicksignup.quick-signup',
		),
		
) ?>