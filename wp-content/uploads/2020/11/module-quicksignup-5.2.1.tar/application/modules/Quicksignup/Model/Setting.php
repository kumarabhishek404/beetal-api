<?php
class Quicksignup_Model_Setting extends Core_Model_Item_Abstract
{
	
}