UPDATE `engine4_core_modules` SET `version` = '4.8.12p2'  WHERE `name` = 'advbilling';
