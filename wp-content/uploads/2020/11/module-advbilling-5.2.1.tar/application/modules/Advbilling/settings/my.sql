INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`)
VALUES  ('advbilling', 'Advanced Billing system', 'Advanced Billing system', '5.2.1', 1, 'extra') ;
