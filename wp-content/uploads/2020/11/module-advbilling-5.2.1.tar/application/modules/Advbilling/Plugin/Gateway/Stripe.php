<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: Stripe.php 16.12.16 05:40 bolot $
 * @author     Bolot
 */

/**
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */
class Advbilling_Plugin_Gateway_Stripe extends Experts_Payment_Plugin_Abstract
{
  protected $_gatewayInfo;
  protected $_gateway;
  // General
  /**
   * Constructor
   */
  public function __construct(Zend_Db_Table_Row_Abstract $gatewayInfo)
  {
    $this->_gatewayInfo = $gatewayInfo;
    // @todo
  }

  /**
   * Get the service API
   *
   * @return Engine_Service_PayPal
   */
  public function createRequestTransaction(Store_Model_Order $order, array $params = array())
  {

  }

  public function getService()
  {
    return $this->getGateway()->getService();
  }

  /**
   * Get the gateway object
   *
   * @return Engine_Payment_Gateway
   */
  public function getGateway()
  {

    if (null === $this->_gateway) {
      $class = 'Engine_Payment_Gateway_PayPal';
      Engine_Loader::loadClass($class);

      try {
        $gateway = new $class(array('config' => (array)$this->_gatewayInfo->config, 'testMode' => $this->_gatewayInfo->test_mode, 'currency' => Engine_Api::_()->getApi('settings', 'core')->getSetting('payment.currency', 'USD'),));
      } catch (Exception $e) {
        throw new Engine_Exception('Plugin class not instance of Engine_Payment_Gateway');
      }

      if (!($gateway instanceof Engine_Payment_Gateway)) {
        throw new Engine_Exception('Plugin class not instance of Engine_Payment_Gateway');
      }
      $this->_gateway = $gateway;
    }

    return $this->_gateway;
  }

  public function cancelOrder($transactionId)
  {
    // TODO: Implement cancelOrder() method.
  }

  public function onRequestTransactionIpn(
    Store_Model_Order $order,
    Experts_Payment_Ipn $ipn)
  {

  }

  /**
   * Generate href to a page detailing the order
   *
   * @param $orderId
   *
   * @return string
   */
  public function getOrderDetailLink($orderId)
  {
    // TODO: Implement getOrderDetailLink() method.
  }

  public function onCartTransactionReturn(Store_Model_Order $order, array $params = array())
  {

    // Check that gateways match
    if ($order->gateway_id != $this->_gatewayInfo->gateway_id) {
      throw new Experts_Payment_Plugin_Exception('Gateways do not match');
    }

    // Check that item_type match
    if ($order->item_type != 'store_cart') {
      throw new Experts_Payment_Plugin_Exception("Wrong item_type has been provided. Method requires 'store_cart'");
    }

    // Check if the cart has any items
    if (!$order->hasItems()) {
      throw new Experts_Payment_Plugin_Exception("Provided store_cart doesn't have any order items");
    }


    // Check for cancel state - the user cancelled the transaction
    if ($params['state'] == 'cancel') {
      $order->onPaymentFailure();
      // Error
      throw new Store_Model_Exception('Your payment has been cancelled and ' .
        'not been purchased. If this is not correct, please try again later.');
    }

    if ($order->ukey != $params['ukey']) {
      $order->onPaymentFailure();
      // This is a sanity error and cannot produce information a user could use
      // to correct the problem.
      throw new Store_Model_Exception('There was an error processing your ' .
        'transaction. Please try again later.');
    }


    $order->save();

    // Get payment status
    $paymentStatus = null;
    $orderStatus = null;

    switch (strtolower($params['status'])) {
      case 'created':
      case 'pending':
        $paymentStatus = 'pending';
        break;

      case 'completed':
      case 'processed':
      case 'succeeded':
      case 'canceled_reversal': // Probably doesn't apply
        $paymentStatus = 'okay';
        break;

      case 'denied':
      case 'failed':
      case 'voided': // Probably doesn't apply
      case 'reversed': // Probably doesn't apply
      case 'refunded': // Probably doesn't apply
      case 'expired': // Probably doesn't apply
      default: // No idea what's going on here
        $paymentStatus = 'failed';
        break;
    }

    /**
     * Insert transaction
     *
     * @var $transactionsTable Store_Model_DbTable_Transactions
     * */
    $transactionsTable = Engine_Api::_()->getDbtable('transactions', 'store');
    $db = $transactionsTable->getAdapter();
    $db->beginTransaction();

    try {
      $transactionsTable->insert(array(
        'item_id' => $order->item_id,
        'item_type' => $order->item_type,
        'order_id' => $order->order_id,
        'user_id' => $order->user_id,
        'timestamp' => new Zend_Db_Expr('NOW()'),
        'state' => $paymentStatus,
        'gateway_id' => $this->_gatewayInfo->gateway_id,
        'gateway_transaction_id' => $params['transaction_id'],
        'gateway_fee' => 0.00,
        'amt' => $order->total_amt,
        'currency' => $order->currency,
        'token' => $order->token
      ));

      $db->commit();
    } catch (Exception $e) {
      $db->rollBack();
      print_log($e);
      throw $e;
    }
    try {
      // Insert transaction
      $transactionsTable = Engine_Api::_()->getDbtable('transactions', 'payment');
      $transactionsTable->insert(array(
        'user_id' => $order->user_id,
        'gateway_id' => $this->_gatewayInfo->gateway_id,
        'timestamp' => new Zend_Db_Expr('NOW()'),
        'order_id' => $order->order_id,
        'type' => 'payment',
        'state' => 'okay',
        'gateway_transaction_id' => $params['transaction_id'],
        'amount' => $order->total_amt, // @todo use this or gross (-fee)?
        'currency' => $order->currency
      ));
    } catch (Exception $e) {
      print_log($e);
      throw $e;
    }

    $user = $order->getUser();

    // Check payment status
    if ($paymentStatus == 'okay') {
      try {
        // Payment success
        $order->onPaymentSuccess();

        // send notification
        if ($order->didStatusChange()) {
          try {
            Engine_Api::_()->getApi('mail', 'core')->sendSystem($user, 'store_cart_complete', array(
              'order_details' => $order->getDetails(),
              'order_link' => 'http://' . $_SERVER['HTTP_HOST'] .
                Zend_Controller_Front::getInstance()->getRouter()->assemble(array(), 'user_login', true),
            ));
          } catch (Exception $e) {
            print_log($e, 'mail');
          }
        }
        $order->gateway_transaction_id = $params['transaction_id'];
        $order->save();
      } catch (Exception $e) {
        print_die('filed ' . $e);
      }

      return $order->status;
    } else if ($paymentStatus == 'pending') {

      // Payment pending
      $order->onPaymentPending();

      // send notification
      if ($order->didStatusChange()) {
        try {
          Engine_Api::_()->getApi('mail', 'core')->sendSystem($user, 'store_cart_pending', array(
            'order_details' => $order->getDetails(),
            'order_link' => 'http://' . $_SERVER['HTTP_HOST'] .
              Zend_Controller_Front::getInstance()->getRouter()->assemble(array(), 'user_login', true),
          ));
        } catch (Exception $e) {
          print_log($e, 'mail');
        }
      }

      return $order->status;
    } else if ($paymentStatus == 'failed') {

      // Payment failed
      $order->onPaymentFailure();

      throw new Store_Model_Exception('Your payment could not be ' .
        'completed. Please ensure there are sufficient available funds ' .
        'in your account.');
    } else {
      // This is a sanity error and cannot produce information a user could use
      // to correct the problem.
      throw new Store_Model_Exception('There was an error processing your ' .
        'transaction. Please try again later.');
    }
  }

  public function onRequestTransactionReturn(Store_Model_Order $order, array $params = array())
  {

  }

  public function onCartTransactionIpn(Store_Model_Order $order, Experts_Payment_Ipn $ipn)
  {

    return $this;
  }

  public function getGatewayForm()
  {
    return new Advbilling_Form_Admin_Stripe();
  }
  // Actions

  /**
   * Create a transaction object from specified parameters
   *
   * @return Engine_Payment_Transaction
   */
  public function createTransaction(array $params)
  {
    $transaction = new Engine_Payment_Transaction($params);
    $transaction->process($this->getGateway());
    return $transaction;
  }

  // SEv4 Specific

  /**
   * Process return of subscription transaction
   *
   * @param Payment_Model_Order $order
   * @param array $params
   */
  public function onSubscriptionTransactionReturn(Payment_Model_Order $order, array $params = array())
  {
    // Check that gateways match
    if ($order->gateway_id != $this->_gatewayInfo->gateway_id) {
      throw new Engine_Payment_Plugin_Exception('Gateways do not match');
    }

    // Get related info
    $user = $order->getUser();
    $subscription = $order->getSource();
    $package = $subscription->getPackage();

    // Check subscription state
    if ($subscription->status == 'active' || $subscription->status == 'trial') {
      return 'active';
    } else if ($subscription->status == 'pending') {
      return 'pending';
    }
    // Update order with profile info and complete status?
    $order->state = 'complete';
    $order->gateway_transaction_id = $params['transaction_id'];
    $order->save();

    // Insert transaction
    $transactionsTable = Engine_Api::_()->getDbtable('transactions', 'payment');
    $transactionsTable->insert(array(
      'user_id' => $order->user_id,
      'gateway_id' => $this->_gatewayInfo->gateway_id,
      'timestamp' => new Zend_Db_Expr('NOW()'),
      'order_id' => $order->order_id,
      'type' => 'payment',
      'state' => 'okay',
      'gateway_transaction_id' => $params['transaction_id'],
      'amount' => $params['amount'], // @todo use this or gross (-fee)?
      'currency' => $params['currency']));

    // Get benefit setting
    $giveBenefit = Engine_Api::_()->getDbtable('transactions', 'payment')->getBenefitStatus($user);

    //YN - Random a code
    $sid = 'abcdefghiklmnopqstvxuyz0123456789ABCDEFGHIKLMNOPQSTVXUYZ';
    $max = strlen($sid) - 1;
    $rCode = "";
    for ($i = 0; $i < 16; ++$i) {
      $rCode .= $sid[mt_rand(0, $max)];
    }

    // Update subscription info
    $subscription->gateway_id = $this->_gatewayInfo->gateway_id;
    $subscription->gateway_profile_id = ($params['transaction_id']) ? $params['transaction_id'] : $rCode;

    $subscription->payment_date = date('Y-m-d H:i:s');
    // Payment success
    $subscription->onPaymentSuccess();

    // send notification
    if ($subscription->didStatusChange()) {
      Engine_Api::_()->getApi('mail', 'core')->sendSystem($user, 'payment_subscription_active', array('subscription_title' => $package->title, 'subscription_description' => $package->description, 'subscription_terms' => $package->getPackageDescription(), 'object_link' => 'http://' . $_SERVER['HTTP_HOST'] . Zend_Controller_Front::getInstance()->getRouter()->assemble(array(), 'user_login', true),));
    }
    return 'active';
  }


  /**
   * Cancel a subscription (i.e. disable the recurring payment profile)
   *
   * @params $transactionId
   * @return Engine_Payment_Plugin_Abstract
   */
  public function cancelSubscription($transactionId, $note = null)
  {
    $profileId = null;

    if ($transactionId instanceof Payment_Model_Subscription) {
      $package = $transactionId->getPackage();
      if ($package->isOneTime()) {
        return $this;
      }
      $profileId = $transactionId->gateway_profile_id;
    } else if (is_string($transactionId)) {
      $profileId = $transactionId;
    } else {
      // Should we throw?
      return $this;
    }

    try {
      $r = $this->getService()->cancelRecurringPaymentsProfile($profileId, $note);
    } catch (Exception $e) {
      // throw?
    }

    return $this;
  }


  /**
   * Generate href to a page detailing the transaction
   *
   * @param string $transactionId
   * @return string
   */
  public function getTransactionDetailLink($transactionId)
  {
    // @todo make sure this is correct
    if ($this->getGateway()->getTestMode()) {
      // Note: it doesn't work in test mode
      return 'https://dashboard.stripe.com/test/payments/' . $transactionId;
    } else {
      return 'https://dashboard.stripe.com/payments/' . $transactionId;
    }
  }

  /**
   * Get raw data about an order or recurring payment profile
   *
   * @param string $orderId
   * @return array
   */
  public function getOrderDetails($orderId)
  {

    try {
      return $this->getTransactionDetails($orderId);
    } catch (Exception $e) {
      echo $e;
    }

    return false;
  }

  /**
   * Get raw data about a transaction
   *
   * @param $transactionId
   * @return array
   */
  public function getTransactionDetails($transactionId)
  {
    return $this->getService()->detailTransaction($transactionId);
  }
  // Forms

  /**
   * Get the admin form for editing the gateway info
   *
   * @return Engine_Form
   */
  public function getAdminGatewayForm()
  {
    return new Advbilling_Form_Admin_Stripe();
  }

  public function processAdminGatewayForm(array $values)
  {
    return $values;
  }

  public function createSubscriptionTransaction(User_Model_User $user,
                                                Zend_Db_Table_Row_Abstract $subscription,
                                                Payment_Model_Package $package,
                                                array $params = array())
  {
  }

  public function onSubscriptionTransactionIpn(
    Payment_Model_Order $order,
    Engine_Payment_Ipn $ipn)
  {
  }

  public function createIpn(array $params)
  {
  }

  public function onIpn(Experts_Payment_Ipn $ipn)
  {
  }

  public function createCartTransaction(Store_Model_Order $order, array $params = array())
  {
    // Check that gateways match
    if ($order->gateway_id != $this->_gatewayInfo->gateway_id) {
      throw new Experts_Payment_Plugin_Exception('Gateways do not match');
    }

    // Check that item_type match
    if ($order->item_type != 'store_cart') {
      throw new Experts_Payment_Plugin_Exception("Wrong item_type has been provided. Method requires 'store_cart'");
    }

    // Check if the cart has any items
    if (!$order->hasItems()) {
      throw new Experts_Payment_Plugin_Exception("Provided store_cart doesn't have any order items");
    }

    $transaction = $this->createTransaction($params);

    return $transaction;
  }

}
