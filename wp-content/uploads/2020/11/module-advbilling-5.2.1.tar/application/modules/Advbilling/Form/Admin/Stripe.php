<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: Stripe.php 16.12.16 05:40 bolot $
 * @author     Bolot
 */

/**
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */
class Advbilling_Form_Admin_Stripe extends Payment_Form_Admin_Gateway_Abstract
{
  public function init()
  {
    parent::init();

    $this->setTitle('Stripe Api details');
    $description = $this->getTranslator()->translate('FORM_STRIPE_DESCRIPTION');
    $description = vsprintf($description, array(
      'https://stripe.com',
      'http://' . $_SERVER['HTTP_HOST'] . Zend_Controller_Front::getInstance()->getRouter()->assemble(array(
        'action' => 'stripe-callback',
      ), 'advbilling_payment', true),
    ));
    $this->setDescription($description);

    // Decorators
    $this->loadDefaultDecorators();
    $this->getDecorator('Description')->setOption('escape', false);

    // Elements
    $this->addElement('Text', 'secret_key', array(
      'label' => 'Secret Key',
      'filters' => array(
        new Zend_Filter_StringTrim(),
      ),
    ));

    $this->addElement('Text', 'public_key', array(
      'label' => 'Public Key',
      'filters' => array(
        new Zend_Filter_StringTrim(),
      ),
    ));
    $this->addElement('Checkbox', 'enabled', array(
      'label' => 'Enabled?',
      'multiOptions' => array(
        '1' => 'Yes'
      ),
      'order' => 10001,
    ));
  }
}