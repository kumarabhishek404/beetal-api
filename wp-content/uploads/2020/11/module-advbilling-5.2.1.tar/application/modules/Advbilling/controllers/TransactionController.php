<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: TransactionController.php 16.12.16 05:40 bolot $
 * @author     Bolot
 */

/**
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */
class Advbilling_TransactionController extends Core_Controller_Action_Standard
{
  /**
   * @var User_Model_User
   */
  protected $_user;
  /**
   * @var Zend_Session_Namespace
   */
  protected $_session;
  /**
   * @var Store_Model_Gateway | Store_Model_Api
   */
  protected $_gateway;

  /**
   * @var Store_Model_Order
   */
  protected $_order;

  protected $_subscription;

  /**
   * @var Payment_Model_Package
   */
  protected $_package;

  public function init()
  {
    // Get user and session
    $this->_user = Engine_Api::_()->user()->getViewer();
    if($this->_getParam('subscrition', 0) != 1) {
      $this->_session = new Zend_Session_Namespace('Store_Transaction');

      // Check viewer and user
      if (!$this->_user || !$this->_user->getIdentity()) {
        if ($this->_session->__isset('user_id')) {
          $this->_user = Engine_Api::_()->getItem('user', $this->_session->__get('user_id'));
        }

        $token = Engine_Api::_()->store()->getToken(true);
        // If no user && no token, redirect to home?
        if (!$token && (!$this->_user || !$this->_user->getIdentity())) {
          return $this->_redirector();
        }
      }

      $this->_session->__set('user_id', $this->_user->getIdentity());

      // Get Store order
      $order_ukey = $this->_getParam('order_id', $this->_session->__get('order_id'));
      if (!$order_ukey || null == ($this->_order = Engine_Api::_()->getDbTable('orders', 'store')->getOrderByUkey($order_ukey))) {

        return $this->_redirector();
      }

      $this->_session->__set('order_id', $this->_order->ukey);

      $mode = Engine_Api::_()->store()->getPaymentMode();

      if ($mode == 'client_store') {
        $gateway = Engine_Api::_()->getItem('store_gateway', $this->_order->gateway_id);
        if ($gateway->getTitle() != 'PayPal' && $gateway->getTitle() != 'Stripe') {
          return $this->_redirector();
        }

        $apisTbl = Engine_Api::_()->getDbTable('apis', 'store');
        $stores = $this->_order->getStores();
        foreach ($stores as $page_id => $store) {
          $api = $apisTbl->getApi($page_id, $this->_order->gateway_id);
          if ($api && $api->enabled) {
            $this->_gateway = $gateway;
            break;
          }
        }
      } else {
        // Get Store gateway
        if (!Engine_Api::_()->getDbtable('gateways', 'store')->isGatewayEnabled($this->_order->gateway_id)) {
          return $this->_redirector();
        }
        $this->_gateway = Engine_Api::_()->getItem('store_gateway', $this->_order->gateway_id);
      }
      if (!$this->_gateway && isset($this->_order->gateway_id)) {
        $this->_gateway = Engine_Api::_()->getItem('store_gateway', $this->_order->gateway_id);
      }
    }else{
      // Get user and session
      $this->_user = Engine_Api::_()->user()->getViewer();
      switch ($this->_getParam('type', 0)) {
        case 'subscrition':
          $this->_session = new Zend_Session_Namespace('Payment_Subscription');
          break;
        case 'page':
          $this->_session = new Zend_Session_Namespace('Page_Subscription');
          break;
        case 'credit':
          $this->_session = new Zend_Session_Namespace('Credit_Transaction');
          break;
        case 'offer':
          $this->_session = new Zend_Session_Namespace('Offer_Subscription');
          break;
        case 'ads':
          $this->_session = new Zend_Session_Namespace('Socialads_Transaction');
          break;
        case 'gifts':
          $this->_session = new Zend_Session_Namespace('Hegift_Transaction');
          break;
        case 'events':
          $this->_session = new Zend_Session_Namespace('Event_Subscription');
          break;
      }

      // Check viewer and user
      if( !$this->_user || !$this->_user->getIdentity() ) {
        if( !empty($this->_session->user_id) ) {
          $this->_user = Engine_Api::_()->getItem('user', $this->_session->user_id);
        }
        // If no user, redirect to home?
        if( !$this->_user || !$this->_user->getIdentity() ) {
          $this->_session->unsetAll();
          return $this->_helper->redirector->gotoRoute(array(), 'default', true);
        }
      }
    }
  }

  protected function _redirector()
  {
    $this->_session->unsetAll();
    return $this->_helper->redirector->gotoRoute(array('controller' => 'cart'), 'store_extended', true);
  }

  public function indexAction()
  {
    return $this->_helper->redirector->gotoRoute(array('action' => 'stripe'), 'advbilling_transaction', true);

  }

  public function stripeAction()
  {
    $log = Zend_Registry::get('Zend_Log');
    $item = $this->_order->getItem();

    if (!($item instanceof Store_Model_Item_Abstract) || $item->getPrice() <= 0) {
      return $this->_redirector();
    }

    // Unset unnecessary values
    $this->_session->__unset('order_id');
    $this->_session->__unset('errorMessage');
    $this->_session->__unset('token');

    /**
     * Make the order unique
     */
    $this->_order->updateUkey();
    $this->_session->__set('order_id', $this->_order->ukey);

    // Get gateway plugin

    // Prepare host info
    $schema = 'http://';
    if (!empty($_ENV["HTTPS"]) && 'on' == strtolower($_ENV["HTTPS"])) {
      $schema = 'https://';
    }
    $host = $_SERVER['HTTP_HOST'];
    /**
     * Get gateway plugin
     *
     * @var $plugin Experts_Payment_Plugin_Abstract
     */
    $settings = (array)$this->_gateway->config;
    $public_key = "";
    $secret_key = "";
    $gateways = Engine_Api::_()->getDbTable('gateways', 'payment')->fetchRow(array('title = ?' => 'Stripe'));
    if (!empty($settings) && !empty($settings['public_key']) && !empty($settings['public_key'])) {
        $log->log("-----Install log if----------------: ",Zend_Log::DEBUG);
      $public_key = $settings['public_key'];
      $secret_key = $settings['secret_key'];
    }else{
        $log->log("-----Install log else----------------: ",Zend_Log::DEBUG);
        $public_key =  $gateways->config['public_key'];
        $secret_key =  $gateways->config['secret_key'];
    }
    $this->view->public_key = $public_key;
    $this->view->form = $form = new Advbilling_Form_Stripe();
    $this->view->gatewayPlugin = $gatewayPlugin = $this->_gateway->getGateway();
    $plugin = $this->_gateway->getPlugin();
    $this->view->ammount = $amount = $this->_order->total_amt;

    if (!$this->getRequest()->isPost()) {
      return;
    }

    $errors = array();
    $t = $this->_getParam('stripeToken', 0);
    if (isset($t)) {
      $token = $t;

      if (isset($this->_session->token) && ($this->_session->token == $token)) {
        $errors['token'] = 'Resubmit form, please try again';
        $form->addError($errors['token']);
        return;
      } else {
        $this->_session->__set('token', $token);
      }
    } else {
      $errors['token'] = 'The order cannot be processed. Please make sure you have JavaScript enabled and try again.';
      $form->addError($errors['token']);
      return;
    }

    $amount = ($this->_order->total_amt) * 100;
    // If no errors, process the order:
    if (empty($errors)) {
      try {
        $Stripe = new Advbilling_Api_Core();
        $Stripe->include_files();
        Stripe\Stripe::setApiKey($secret_key);
        $viewer = Engine_Api::_()->user()->getViewer();
        $params_array = array(
          "amount" => $amount, // amount in cents, again
          "currency" => Engine_Api::_()->getApi('settings', 'core')->getSetting('payment.currency'),
          "card" => $token,
          "metadata" => array('order_id' => $this->_session->order_id),
        );

        $charge = Stripe\Charge::create($params_array);
        // Check that it was paid:
        $request = array();
        if ($charge->paid == true) {
          $request['authorized'] = TRUE;
          $request['transaction_id'] = $charge->id;
          $request['amount'] = $charge->amount / 100;
          $request['currency'] = strtoupper($charge->currency);
          $request['status'] = $charge->status;
          $request['ukey'] = $this->_order->ukey;
          $request['state'] = $charge->status;

          return $this->_helper->redirector->gotoRoute(array_merge(array(
            'action' => 'return',
            'order_id' => $charge->metadata['order_id']
          ), $request), 'advbilling_transaction', true);

        } else {
          // Charge was not paid!
          return $this->_helper->redirector->gotoRoute(array(
            'action' => 'finish',
            'state' => 'failed'
          ), 'advbilling_transaction', true);
        }

      } catch (Stripe_CardError $e) {
        // Card was declined.
        $e_json = $e->getJsonBody();
        $err = $e_json['error'];
        $errors['stripe'] = $err['message'];
        $form->addError($errors['stripe']);
        return;
      } catch (Stripe_ApiConnectionError $e) {
        // Network problem, perhaps try again.
        $form->addError('Network problem, perhaps try again');
        return;
      } catch (Stripe_InvalidRequestError $e) {
        // You screwed up in your programming. Shouldn't happen!
        $form->addError('You screwed up in your programming. Shouldn\'t happen!');
        return;
      } catch (Stripe_ApiError $e) {
        // Stripe's servers are down!
        $form->addError('Stripe\'s servers are down!');
        return;
      } catch (Stripe_CardError $e) {
        // Something else that's not the customer's fault.
        $form->addError('Something else that\'s not the customer\'s fault.');
        return;
      }
    }
  }
  public function subscriptionAction()
  {
    // Get gateway

    $gatewayId = $this->_getParam('gateway_id', $this->_session->gateway_id);
    if( !$gatewayId ||
      !($gateway = Engine_Api::_()->getItem('payment_gateway', $gatewayId)) ||
      !($gateway->enabled) ) {
      return $this->_helper->redirector->gotoRoute(array('action' => 'gateway'));
    }
    $this->view->gateway = $gateway;

    // Get subscription
    $subscriptionId = $this->_getParam('subscription_id', $this->_session->subscription_id);
    if( !$subscriptionId ||
      !($subscription = Engine_Api::_()->getItem('payment_subscription', $subscriptionId))  ) {
      return $this->_helper->redirector->gotoRoute(array('action' => 'choose'));
    }
    $this->view->subscription = $subscription;

    // Get package
    $package = $subscription->getPackage();
    if( !$package || $package->isFree() ) {
      return $this->_helper->redirector->gotoRoute(array('action' => 'choose'));
    }
    $this->view->package = $package;

    // Prepare host info
    $schema = 'http://';
    if (!empty($_ENV["HTTPS"]) && 'on' == strtolower($_ENV["HTTPS"])) {
      $schema = 'https://';
    }
    $host = $_SERVER['HTTP_HOST'];
    /**
     * Get gateway plugin
     *
     * @var $plugin Experts_Payment_Plugin_Abstract
     */
    $settings = (array)$gateway->config;
    $public_key = "";
    $secret_key = "";
    if ($settings) {
      $public_key = $settings['public_key'];
      $secret_key = $settings['secret_key'];
    }

    $this->view->public_key = $public_key;
    $this->view->form = $form = new Advbilling_Form_Stripe();
    $this->view->gatewayPlugin = $gatewayPlugin = $gateway->getGateway();
    $plugin = $gateway->getPlugin();
    $this->view->ammount = $amount = $package->price;

    if (!$this->getRequest()->isPost()) {
      return;
    }

    $errors = array();
    $t = $this->_getParam('stripeToken', 0);

    if (isset($t)) {
      $token = $t;

      if (isset($this->_session->token) && ($this->_session->token == $token)) {
        $errors['token'] = 'Resubmit form, please try again';
        $form->addError($errors['token']);
        return;
      } else {
        $this->_session->__set('token', $token);
      }
    } else {
      $errors['token'] = 'The order cannot be processed. Please make sure you have JavaScript enabled and try again.';
      $form->addError($errors['token']);
      return;
    }

    $amount = ( $package->price) * 100;
    // If no errors, process the order:

    if (empty($errors)) {
      try {
        $Stripe = new Advbilling_Api_Core();
        $Stripe->include_files();
        Stripe\Stripe::setApiKey($secret_key);
        $viewer = Engine_Api::_()->user()->getViewer();
        $params_array = array(
          "amount" => $amount, // amount in cents, again
          "currency" => Engine_Api::_()->getApi('settings', 'core')->getSetting('payment.currency'),
          "card" => $token,
          "metadata" => array('order_id' => $this->getParam('order_id',$this->_session->order_id)),
        );

        $charge = Stripe\Charge::create($params_array);
        // Check that it was paid:
        $request = array();

        if ($charge->paid == true) {
          $request['authorized'] = TRUE;
          $request['transaction_id'] = $charge->id;
          $request['amount'] = $charge->amount / 100;
          $request['currency'] = strtoupper($charge->currency);
          $request['status'] = $charge->status;
          $request['ukey'] = $this->_order->ukey;
          $request['state'] = $charge->status;

          return $this->_helper->redirector->gotoUrl($this->_session->return_url. '&' . http_build_query($request));

        } else {
          // Charge was not paid!
          return $this->_helper->redirector->gotoUrl($this->_session->cancel_url);

        }

      } catch (Stripe_CardError $e) {
        // Card was declined.
        $e_json = $e->getJsonBody();
        $err = $e_json['error'];
        $errors['stripe'] = $err['message'];
        $form->addError($errors['stripe']);
        return;
      } catch (Stripe_ApiConnectionError $e) {
        // Network problem, perhaps try again.
        $form->addError('Network problem, perhaps try again');
        return;
      } catch (Stripe_InvalidRequestError $e) {
        // You screwed up in your programming. Shouldn't happen!
        $form->addError('You screwed up in your programming. Shouldn\'t happen!');
        return;
      } catch (Stripe_ApiError $e) {
        // Stripe's servers are down!
        $form->addError('Stripe\'s servers are down!');
        return;
      } catch (Stripe_CardError $e) {
        // Something else that's not the customer's fault.
        $form->addError('Something else that\'s not the customer\'s fault.');
        return;
      }
    }
  }

  public function subscriptionpageAction()
  {
    // Get gateway

    $gatewayId = $this->_getParam('gateway_id', $this->_session->gateway_id);
    if( !$gatewayId ||
      !($gateway = Engine_Api::_()->getItem('payment_gateway', $gatewayId)) ||
      !($gateway->enabled) ) {
      return $this->_helper->redirector->gotoRoute(array('action' => 'gateway'));
    }
    $this->view->gateway = $gateway;

    // Get subscription
    $subscriptionId = $this->_getParam('subscription_id', $this->_session->subscription_id);
    if( !$subscriptionId ||
      !($subscription = Engine_Api::_()->getItem('page_subscription', $subscriptionId))  ) {
      return $this->_helper->redirector->gotoRoute(array('action' => 'choose'));
    }
    $this->view->subscription = $subscription;

    // Get package
    $package = $subscription->getPackage();
    if( !$package || $package->isFree() ) {
      return $this->_helper->redirector->gotoRoute(array('action' => 'choose'));
    }
    $this->view->package = $package;

    // Prepare host info
    $schema = 'http://';
    if (!empty($_ENV["HTTPS"]) && 'on' == strtolower($_ENV["HTTPS"])) {
      $schema = 'https://';
    }
    $host = $_SERVER['HTTP_HOST'];
    /**
     * Get gateway plugin
     *
     * @var $plugin Experts_Payment_Plugin_Abstract
     */
    $settings = (array)$gateway->config;
    $public_key = "";
    $secret_key = "";
    if ($settings) {
      $public_key = $settings['public_key'];
      $secret_key = $settings['secret_key'];
    }

    $this->view->public_key = $public_key;
    $this->view->form = $form = new Advbilling_Form_Stripe();
    $this->view->gatewayPlugin = $gatewayPlugin = $gateway->getGateway();
    $plugin = $gateway->getPlugin();
    $this->view->ammount = $amount = $package->price;

    if (!$this->getRequest()->isPost()) {
      return;
    }

    $errors = array();
    $t = $this->_getParam('stripeToken', 0);

    if (isset($t)) {
      $token = $t;

      if (isset($this->_session->token) && ($this->_session->token == $token)) {
        $errors['token'] = 'Resubmit form, please try again';
        $form->addError($errors['token']);
        return;
      } else {
        $this->_session->__set('token', $token);
      }
    } else {
      $errors['token'] = 'The order cannot be processed. Please make sure you have JavaScript enabled and try again.';
      $form->addError($errors['token']);
      return;
    }

    $amount = ( $package->price) * 100;
    // If no errors, process the order:

    if (empty($errors)) {
      try {
        $Stripe = new Advbilling_Api_Core();
        $Stripe->include_files();
        Stripe\Stripe::setApiKey($secret_key);
        $viewer = Engine_Api::_()->user()->getViewer();
        $params_array = array(
          "amount" => $amount, // amount in cents, again
          "currency" => Engine_Api::_()->getApi('settings', 'core')->getSetting('payment.currency'),
          "card" => $token,
          "metadata" => array('order_id' => $this->getParam('order_id',$this->_session->order_id)),
        );

        $charge = Stripe\Charge::create($params_array);
        // Check that it was paid:
        $request = array();

        if ($charge->paid == true) {
          $request['authorized'] = TRUE;
          $request['transaction_id'] = $charge->id;
          $request['amount'] = $charge->amount / 100;
          $request['currency'] = strtoupper($charge->currency);
          $request['status'] = $charge->status;
          $request['ukey'] = $this->_order->ukey;
          $request['state'] = $charge->status;

          return $this->_helper->redirector->gotoUrl($this->_session->return_url. '&' . http_build_query($request));

        } else {
          // Charge was not paid!
          return $this->_helper->redirector->gotoUrl($this->_session->cancel_url);

        }

      } catch (Stripe_CardError $e) {
        // Card was declined.
        $e_json = $e->getJsonBody();
        $err = $e_json['error'];
        $errors['stripe'] = $err['message'];
        $form->addError($errors['stripe']);
        return;
      } catch (Stripe_ApiConnectionError $e) {
        // Network problem, perhaps try again.
        $form->addError('Network problem, perhaps try again');
        return;
      } catch (Stripe_InvalidRequestError $e) {
        // You screwed up in your programming. Shouldn't happen!
        $form->addError('You screwed up in your programming. Shouldn\'t happen!');
        return;
      } catch (Stripe_ApiError $e) {
        // Stripe's servers are down!
        $form->addError('Stripe\'s servers are down!');
        return;
      } catch (Stripe_CardError $e) {
        // Something else that's not the customer's fault.
        $form->addError('Something else that\'s not the customer\'s fault.');
        return;
      }
    }

  }
  public function creditbuyAction()
  {
    // Get gateway

    $gatewayId = $this->_getParam('gateway_id', $this->_session->gateway_id);
    if( !$gatewayId ||
      !($gateway = Engine_Api::_()->getItem('payment_gateway', $gatewayId)) ||
      !($gateway->enabled) ) {
      return $this->_helper->redirector->gotoRoute(array('action' => 'gateway'));
    }
    $this->view->gateway = $gateway;

    // Get subscription
    $order_id = $this->_getParam('order_id', $this->_session->order_id);
    if($order_id) {
      $order = Engine_Api::_()->getItem('credit_order', $order_id);
    }



    // Prepare host info
    $schema = 'http://';
    if (!empty($_ENV["HTTPS"]) && 'on' == strtolower($_ENV["HTTPS"])) {
      $schema = 'https://';
    }
    $host = $_SERVER['HTTP_HOST'];
    /**
     * Get gateway plugin
     *
     * @var $plugin Experts_Payment_Plugin_Abstract
     */
    $settings = (array)$gateway->config;
    $public_key = "";
    $secret_key = "";
    if ($settings) {
      $public_key = $settings['public_key'];
      $secret_key = $settings['secret_key'];
    }

    $this->view->public_key = $public_key;
    $this->view->form = $form = new Advbilling_Form_Stripe();
    $this->view->gatewayPlugin = $gatewayPlugin = $gateway->getGateway();
    $plugin = $gateway->getPlugin();
    $this->view->ammount = $amount = $order->price;

    if (!$this->getRequest()->isPost()) {
      return;
    }

    $errors = array();
    $t = $this->_getParam('stripeToken', 0);

    if (isset($t)) {
      $token = $t;

      if (isset($this->_session->token) && ($this->_session->token == $token)) {
        $errors['token'] = 'Resubmit form, please try again';
        $form->addError($errors['token']);
        return;
      } else {
        $this->_session->__set('token', $token);
      }
    } else {
      $errors['token'] = 'The order cannot be processed. Please make sure you have JavaScript enabled and try again.';
      $form->addError($errors['token']);
      return;
    }

    $amount = ( $order->price) * 100;
    // If no errors, process the order:

    if (empty($errors)) {
      try {
        $Stripe = new Advbilling_Api_Core();
        $Stripe->include_files();
        Stripe\Stripe::setApiKey($secret_key);
        $viewer = Engine_Api::_()->user()->getViewer();
        $params_array = array(
          "amount" => $amount, // amount in cents, again
          "currency" => Engine_Api::_()->getApi('settings', 'core')->getSetting('payment.currency'),
          "card" => $token,
          "metadata" => array('order_id' => $this->getParam('order_id',$this->_session->order_id)),
        );

        $charge = Stripe\Charge::create($params_array);
        // Check that it was paid:
        $request = array();

        if ($charge->paid == true) {
          $request['authorized'] = TRUE;
          $request['transaction_id'] = $charge->id;
          $request['amount'] = $charge->amount / 100;
          $request['currency'] = strtoupper($charge->currency);
          $request['status'] = $charge->status;
          $request['ukey'] = $this->_order->ukey;
          $request['state'] = $charge->status;

          return $this->_helper->redirector->gotoUrl($this->_session->return_url. '&' . http_build_query($request));

        } else {
          // Charge was not paid!
          return $this->_helper->redirector->gotoUrl($this->_session->cancel_url);

        }

      } catch (Stripe_CardError $e) {
        // Card was declined.
        $e_json = $e->getJsonBody();
        $err = $e_json['error'];
        $errors['stripe'] = $err['message'];
        $form->addError($errors['stripe']);
        return;
      } catch (Stripe_ApiConnectionError $e) {
        // Network problem, perhaps try again.
        $form->addError('Network problem, perhaps try again');
        return;
      } catch (Stripe_InvalidRequestError $e) {
        // You screwed up in your programming. Shouldn't happen!
        $form->addError('You screwed up in your programming. Shouldn\'t happen!');
        return;
      } catch (Stripe_ApiError $e) {
        // Stripe's servers are down!
        $form->addError('Stripe\'s servers are down!');
        return;
      } catch (Stripe_CardError $e) {
        // Something else that's not the customer's fault.
        $form->addError('Something else that\'s not the customer\'s fault.');
        return;
      }
    }

  }
  public function offersAction()
  {
    // Get gateway


    $gatewayId = $this->_getParam('gateway_id',555);
    if( !$gatewayId ||
      !($gateway = Engine_Api::_()->getItem('payment_gateway', $gatewayId)) ||
      !($gateway->enabled) ) {
      return $this->_helper->redirector->gotoRoute(array('action' => 'gateway'));
    }
    $this->view->gateway = $gateway;

    // Get subscription
    $order_id = $this->_getParam('order_id', $this->_session->order_id);
    if($order_id) {
      $order = Engine_Api::_()->getItem('offers_order', $order_id);
    }
    $offer_id = $this->_getParam('offer_id', $this->_session->order_id);
    if($offer_id) {
      $offer = Engine_Api::_()->getItem('offer', $offer_id);
    }



    // Prepare host info
    $schema = 'http://';
    if (!empty($_ENV["HTTPS"]) && 'on' == strtolower($_ENV["HTTPS"])) {
      $schema = 'https://';
    }
    $host = $_SERVER['HTTP_HOST'];
    /**
     * Get gateway plugin
     *
     * @var $plugin Experts_Payment_Plugin_Abstract
     */
    $settings = (array)$gateway->config;
    $public_key = "";
    $secret_key = "";
    if ($settings) {
      $public_key = $settings['public_key'];
      $secret_key = $settings['secret_key'];
    }

    $this->view->public_key = $public_key;
    $this->view->form = $form = new Advbilling_Form_Stripe();
    $this->view->gatewayPlugin = $gatewayPlugin = $gateway->getGateway();
    $plugin = $gateway->getPlugin();
    $this->view->ammount = $amount = $offer->getPrice();

    if (!$this->getRequest()->isPost()) {
      return;
    }

    $errors = array();
    $t = $this->_getParam('stripeToken', 0);

    if (isset($t)) {
      $token = $t;

      if (isset($this->_session->token) && ($this->_session->token == $token)) {
        $errors['token'] = 'Resubmit form, please try again';
        $form->addError($errors['token']);
        return;
      } else {
        $this->_session->__set('token', $token);
      }
    } else {
      $errors['token'] = 'The order cannot be processed. Please make sure you have JavaScript enabled and try again.';
      $form->addError($errors['token']);
      return;
    }

    $amount = ( $offer->getPrice()) * 100;
    // If no errors, process the order:

    if (empty($errors)) {
      try {
        $Stripe = new Advbilling_Api_Core();
        $Stripe->include_files();
        Stripe\Stripe::setApiKey($secret_key);
        $viewer = Engine_Api::_()->user()->getViewer();
        $params_array = array(
          "amount" => $amount, // amount in cents, again
          "currency" => Engine_Api::_()->getApi('settings', 'core')->getSetting('payment.currency'),
          "card" => $token,
          "metadata" => array('order_id' => $this->getParam('order_id',$this->_session->order_id)),
        );

        $charge = Stripe\Charge::create($params_array);
        // Check that it was paid:
        $request = array();

        if ($charge->paid == true) {
          $request['authorized'] = TRUE;
          $request['transaction_id'] = $charge->id;
          $request['amount'] = $charge->amount / 100;
          $request['currency'] = strtoupper($charge->currency);
          $request['status'] = $charge->status;
          $request['ukey'] = $this->_order->ukey;
          $request['state'] = $charge->status;
          return $this->_helper->redirector->gotoUrl($this->_session->return_url. '&' . http_build_query($request));

        } else {
          // Charge was not paid!
          return $this->_helper->redirector->gotoUrl($this->_session->cancel_url);

        }

      } catch (Stripe_CardError $e) {
        // Card was declined.
        $e_json = $e->getJsonBody();
        $err = $e_json['error'];
        $errors['stripe'] = $err['message'];
        $form->addError($errors['stripe']);
        return;
      } catch (Stripe_ApiConnectionError $e) {
        // Network problem, perhaps try again.
        $form->addError('Network problem, perhaps try again');
        return;
      } catch (Stripe_InvalidRequestError $e) {
        // You screwed up in your programming. Shouldn't happen!
        $form->addError('You screwed up in your programming. Shouldn\'t happen!');
        return;
      } catch (Stripe_ApiError $e) {
        // Stripe's servers are down!
        $form->addError('Stripe\'s servers are down!');
        return;
      } catch (Stripe_CardError $e) {
        // Something else that's not the customer's fault.
        $form->addError('Something else that\'s not the customer\'s fault.');
        return;
      }
    }

  }
  public function eventsAction()
  {
    // Get gateway


    $gatewayId = $this->_getParam('gateway_id',555);
    if( !$gatewayId ||
      !($gateway = Engine_Api::_()->getItem('payment_gateway', $gatewayId)) ||
      !($gateway->enabled) ) {
      return $this->_helper->redirector->gotoRoute(array('action' => 'gateway'));
    }
    $this->view->gateway = $gateway;

    // Get subscription
    $order_id = $this->_getParam('order_id', $this->_session->order_id);
    if($order_id) {
       $table_order =  $ordersTable = Engine_Api::_()->getDbtable('orders', 'heevent');
      $select  = $table_order->select()->where('order_id = ?',$order_id);
      $order = $table_order->fetchRow($select);

    }
    $event_id = $this->_getParam('event_id', $this->_session->event_id);
    if($event_id) {
      $event = Engine_Api::_()->getItem('event', $event_id);
    }

      $subscription_id = $this->_getParam('subscription_id', 0);
    $subscriptionsTable = Engine_Api::_()->getDbtable('subscriptions', 'heevent');
    if($subscription_id){
    $subscription = $subscriptionsTable->fetchRow(array(
      'subscription_id = ?' => $subscription_id));
    }

    // Prepare host info
    $schema = 'http://';
    if (!empty($_ENV["HTTPS"]) && 'on' == strtolower($_ENV["HTTPS"])) {
      $schema = 'https://';
    }
    $host = $_SERVER['HTTP_HOST'];
    /**
     * Get gateway plugin
     *
     * @var $plugin Experts_Payment_Plugin_Abstract
     */
    $settings = (array)$gateway->config;
    $strip_settings = Engine_Api::_()->getDbtable('eventssettings', 'advbilling');
    $select_setting  = $strip_settings->select()->where('event_id = ?',$event_id);
    $user_setting = $strip_settings->fetchRow($select_setting);
    $public_key = "";
    $secret_key = "";
    if($user_setting){
      $public_key = $user_setting['publish_key'];
      $secret_key = $user_setting['secret_key'];
    }else{
      if ($settings) {
        $public_key = $settings['public_key'];
        $secret_key = $settings['secret_key'];
      }
    }



    $this->view->public_key = $public_key;
    $this->view->form = $form = new Advbilling_Form_Stripe();
    $this->view->gatewayPlugin = $gatewayPlugin = $gateway->getGateway();
    $plugin = $gateway->getPlugin();
    $this->view->ammount = $amount = $event->getPrice() * $subscription->quantity;

    if (!$this->getRequest()->isPost()) {
      return;
    }

    $errors = array();
    $t = $this->_getParam('stripeToken', 0);

    if (isset($t)) {
      $token = $t;

      if (isset($this->_session->token) && ($this->_session->token == $token)) {
        $errors['token'] = 'Resubmit form, please try again';
        $form->addError($errors['token']);
        return;
      } else {
        $this->_session->__set('token', $token);
      }
    } else {
      $errors['token'] = 'The order cannot be processed. Please make sure you have JavaScript enabled and try again.';
      $form->addError($errors['token']);
      return;
    }

    $amount = ( $event->getPrice() * $subscription->quantity) * 100;
    // If no errors, process the order:

    if (empty($errors)) {
      try {
        $Stripe = new Advbilling_Api_Core();
        $Stripe->include_files();
        Stripe\Stripe::setApiKey($secret_key);
        $viewer = Engine_Api::_()->user()->getViewer();
        $params_array = array(
          "amount" => $amount, // amount in cents, again
          "currency" => Engine_Api::_()->getApi('settings', 'core')->getSetting('payment.currency'),
          "card" => $token,
          "metadata" => array('order_id' => $this->getParam('order_id',$this->_session->order_id)),
        );

        $charge = Stripe\Charge::create($params_array);
        // Check that it was paid:
        $request = array();

        if ($charge->paid == true) {
          $request['authorized'] = TRUE;
          $request['transaction_id'] = $charge->id;
          $request['amount'] = $charge->amount / 100;
          $request['currency'] = strtoupper($charge->currency);
          $request['status'] = $charge->status;
          $request['ukey'] = $this->_order->ukey;
          $request['state'] = $charge->status;
          return $this->_helper->redirector->gotoUrl($this->_session->return_url. '&' . http_build_query($request));

        } else {
          // Charge was not paid!
          return $this->_helper->redirector->gotoUrl($this->_session->cancel_url);

        }

      } catch (Stripe_CardError $e) {
        // Card was declined.
        $e_json = $e->getJsonBody();
        $err = $e_json['error'];
        $errors['stripe'] = $err['message'];
        $form->addError($errors['stripe']);
        return;
      } catch (Stripe_ApiConnectionError $e) {
        // Network problem, perhaps try again.
        $form->addError('Network problem, perhaps try again');
        return;
      } catch (Stripe_InvalidRequestError $e) {
        // You screwed up in your programming. Shouldn't happen!
        $form->addError('You screwed up in your programming. Shouldn\'t happen!');
        return;
      } catch (Stripe_ApiError $e) {
        // Stripe's servers are down!
        $form->addError('Stripe\'s servers are down!');
        return;
      } catch (Stripe_CardError $e) {
        // Something else that's not the customer's fault.
        $form->addError('Something else that\'s not the customer\'s fault.');
        return;
      }
    }

  }
  public function adsAction()
  {
    // Get gateway
    $gatewayId = $this->_getParam('gateway_id',555);
    if( !$gatewayId ||
      !($gateway = Engine_Api::_()->getItem('payment_gateway', $gatewayId)) ||
      !($gateway->enabled) ) {
      return $this->_helper->redirector->gotoRoute(array('action' => 'gateway'));
    }
    $this->view->gateway = $gateway;

    // Get subscription
   /* $order_id = $this->_getParam('order_id', $this->_session->order_id);
    if($order_id) {
      $order = Engine_Api::_()->getItem('offers_order', $order_id);
    }*/
    $ad_id = $this->_getParam('ad_id', $this->_session->ad_id);
    if($ad_id) {
      $ad = Engine_Api::_()->getItem('ad', $ad_id);
    }



    // Prepare host info
    $schema = 'http://';
    if (!empty($_ENV["HTTPS"]) && 'on' == strtolower($_ENV["HTTPS"])) {
      $schema = 'https://';
    }
    $host = $_SERVER['HTTP_HOST'];
    /**
     * Get gateway plugin
     *
     * @var $plugin Experts_Payment_Plugin_Abstract
     */
    $settings = (array)$gateway->config;
    $public_key = "";
    $secret_key = "";
    if ($settings) {
      $public_key = $settings['public_key'];
      $secret_key = $settings['secret_key'];
    }

    $this->view->public_key = $public_key;
    $this->view->form = $form = new Advbilling_Form_Stripe();
    $this->view->gatewayPlugin = $gatewayPlugin = $gateway->getGateway();
    $plugin = $gateway->getPlugin();
    $this->view->ammount = $amount = $ad->price;

    if (!$this->getRequest()->isPost()) {
      return;
    }

    $errors = array();
    $t = $this->_getParam('stripeToken', 0);

    if (isset($t)) {
      $token = $t;

      if (isset($this->_session->token) && ($this->_session->token == $token)) {
        $errors['token'] = 'Resubmit form, please try again';
        $form->addError($errors['token']);
        return;
      } else {
        $this->_session->__set('token', $token);
      }
    } else {
      $errors['token'] = 'The order cannot be processed. Please make sure you have JavaScript enabled and try again.';
      $form->addError($errors['token']);
      return;
    }

    $amount = ($ad->price) * 100;
    // If no errors, process the order:

    if (empty($errors)) {
      try {
        $Stripe = new Advbilling_Api_Core();
        $Stripe->include_files();
        Stripe\Stripe::setApiKey($secret_key);
        $viewer = Engine_Api::_()->user()->getViewer();
        $params_array = array(
          "amount" => $amount, // amount in cents, again
          "currency" => Engine_Api::_()->getApi('settings', 'core')->getSetting('payment.currency'),
          "card" => $token,
          "metadata" => array('order_id' => $this->getParam('order_id',$this->_session->order_id)),
        );

        $charge = Stripe\Charge::create($params_array);
        // Check that it was paid:
        $request = array();

        if ($charge->paid == true) {
          $request['authorized'] = TRUE;
          $request['transaction_id'] = $charge->id;
          $request['amount'] = $charge->amount / 100;
          $request['currency'] = strtoupper($charge->currency);
          $request['status'] = $charge->status;
          $request['ukey'] = $this->_order->ukey;
          $request['state'] = $charge->status;
          return $this->_helper->redirector->gotoUrl($this->_session->return_url. '&' . http_build_query($request));

        } else {
          // Charge was not paid!
          return $this->_helper->redirector->gotoUrl($this->_session->cancel_url);

        }

      } catch (Stripe_CardError $e) {
        // Card was declined.
        $e_json = $e->getJsonBody();
        $err = $e_json['error'];
        $errors['stripe'] = $err['message'];
        $form->addError($errors['stripe']);
        return;
      } catch (Stripe_ApiConnectionError $e) {
        // Network problem, perhaps try again.
        $form->addError('Network problem, perhaps try again');
        return;
      } catch (Stripe_InvalidRequestError $e) {
        // You screwed up in your programming. Shouldn't happen!
        $form->addError('You screwed up in your programming. Shouldn\'t happen!');
        return;
      } catch (Stripe_ApiError $e) {
        // Stripe's servers are down!
        $form->addError('Stripe\'s servers are down!');
        return;
      } catch (Stripe_CardError $e) {
        // Something else that's not the customer's fault.
        $form->addError('Something else that\'s not the customer\'s fault.');
        return;
      }
    }

  }
  public function giftsAction()
  {
    $recipients = $this->_session->__get('gifts_info')['recipients'];
    // Get gateway
    $gatewayId = $this->_getParam('gateway_id',555);
    if( !$gatewayId ||
      !($gateway = Engine_Api::_()->getItem('payment_gateway', $gatewayId)) ||
      !($gateway->enabled) ) {
      return $this->_helper->redirector->gotoRoute(array('action' => 'gateway'));
    }
    $this->view->gateway = $gateway;

    // Get subscription
    $gift_id = $this->_getParam('gift_id', $this->_session->ad_id);
    if($gift_id) {
      $gift = Engine_Api::_()->getItem('gift', $gift_id);
    }
    /**
     * Get gateway plugin
     *
     * @var $plugin Experts_Payment_Plugin_Abstract
     */
    $settings = (array)$gateway->config;
    $public_key = "";
    $secret_key = "";
    if ($settings) {
      $public_key = $settings['public_key'];
      $secret_key = $settings['secret_key'];
    }

    $this->view->public_key = $public_key;
    $this->view->form = $form = new Advbilling_Form_Stripe();
    $this->view->gatewayPlugin = $gatewayPlugin = $gateway->getGateway();
    $this->view->ammount = $amount = $gift->gift_price * count($recipients);

    if (!$this->getRequest()->isPost()) {
      return;
    }

    $errors = array();
    $t = $this->_getParam('stripeToken', 0);

    if (isset($t)) {
      $token = $t;

      if (isset($this->_session->token) && ($this->_session->token == $token)) {
        $errors['token'] = 'Resubmit form, please try again';
        $form->addError($errors['token']);
        return;
      } else {
        $this->_session->__set('token', $token);
      }
    } else {
      $errors['token'] = 'The order cannot be processed. Please make sure you have JavaScript enabled and try again.';
      $form->addError($errors['token']);
      return;
    }
    $amount = ($gift->gift_price) * 100 * count($recipients);
    // If no errors, process the order:

    if (empty($errors)) {
      try {
        $Stripe = new Advbilling_Api_Core();
        $Stripe->include_files();
        Stripe\Stripe::setApiKey($secret_key);
        $viewer = Engine_Api::_()->user()->getViewer();
        $params_array = array(
          "amount" => $amount, // amount in cents, again
          "currency" => Engine_Api::_()->getApi('settings', 'core')->getSetting('payment.currency'),
          "card" => $token,
          "metadata" => array('order_id' => $this->getParam('order_id',$this->_session->order_id)),
        );

        $charge = Stripe\Charge::create($params_array);
        // Check that it was paid:
        $request = array();

        if ($charge->paid == true) {
          $request['authorized'] = TRUE;
          $request['transaction_id'] = $charge->id;
          $request['amount'] = $charge->amount / 100;
          $request['currency'] = strtoupper($charge->currency);
          $request['status'] = $charge->status;
          $request['ukey'] = $this->_order->ukey;
          $request['state'] = $charge->status;
          return $this->_helper->redirector->gotoUrl($this->_session->return_url. '&' . http_build_query($request));

        } else {
          // Charge was not paid!
          return $this->_helper->redirector->gotoUrl($this->_session->cancel_url);

        }

      } catch (Stripe_CardError $e) {
        // Card was declined.
        $e_json = $e->getJsonBody();
        $err = $e_json['error'];
        $errors['stripe'] = $err['message'];
        $form->addError($errors['stripe']);
        return;
      } catch (Stripe_ApiConnectionError $e) {
        // Network problem, perhaps try again.
        $form->addError('Network problem, perhaps try again');
        return;
      } catch (Stripe_InvalidRequestError $e) {
        // You screwed up in your programming. Shouldn't happen!
        $form->addError('You screwed up in your programming. Shouldn\'t happen!');
        return;
      } catch (Stripe_ApiError $e) {
        // Stripe's servers are down!
        $form->addError('Stripe\'s servers are down!');
        return;
      } catch (Stripe_CardError $e) {
        // Something else that's not the customer's fault.
        $form->addError('Something else that\'s not the customer\'s fault.');
        return;
      }
    }

  }
  public function returnAction()
  {

    /**
     * Get gateway plugin
     *
     * @var $plugin Experts_Payment_Plugin_Abstract
     */
    try {
      $plugin = $this->_gateway->getPlugin();

      try {
        $status = $plugin->onCartTransactionReturn($this->_order, $this->getAllParams());
      } catch (Store_Model_Exception $e) {
        $this->_session->__set('errorMessage', $e->getMessage());
        $status = 'failed';
      }

    } catch (Exception $e) {
      if ('development' == APPLICATION_ENV) {
        throw $e;
      }

      $status = 'failed';
    }

    return $this->_finishPayment($status);
  }

  protected function _finishPayment($status = 'completed')
  {
    $viewer = Engine_Api::_()->user()->getViewer();

    // Log the user in, if they aren't already


    if (($status == 'completed') && $this->_user && !$this->_user->isSelf($viewer) && !$viewer->getIdentity()) {
      Zend_Auth::getInstance()->getStorage()->write($this->_user->getIdentity());
      Engine_Api::_()->user()->setViewer();
      $viewer = $this->_user;
    }


    // Handle email verification or pending approval
    if ($viewer->getIdentity() && !$viewer->enabled) {
      Engine_Api::_()->user()->setViewer(null);
      Engine_Api::_()->user()->getAuth()->getStorage()->clear();
      return $this->_helper->_redirector->gotoRoute(array('action' => 'confirm'), 'user_signup', true);
    }


    // Clear session
    $errorMessage = $this->_session->__get('errorMessage');
    $errorName = $this->_session->__get('errorName');
    $this->_session->unsetAll();
    $this->_session->__set('order_id', $this->_order->ukey);
    $this->_session->__set('user_id', $viewer->getIdentity());
    $this->_session->__set('errorMessage', $errorMessage);
    $this->_session->__set('errorName', $errorName);

    // Redirect
    return $this->_helper->redirector->gotoRoute(array('action' => 'finish',
      'status' => $status));
  }

  public function finishAction()
  {
    $this->view->status = $status = $this->_getParam('status');


    if (in_array($status, array('completed', 'shipping', 'processing'))) {
      $url = $this->view->escape($this->view->url(array('order_id' => $this->_order->ukey), 'store_purchase', true));
      Engine_Api::_()->store()->sendPublicPurchaseEmail($url);
    } else {
      $url = $this->view->escape($this->view->url(array('controller' => 'cart'), 'store_extended', true));

      if (!$this->_session->__isset('errorMessage')) {
        $this->view->error = 'There was an error processing your transaction. Please try again later.';
      } else {
        $this->view->error = $this->_session->__get('errorMessage');
        $this->view->errorName = $this->_session->__get('errorName');
      }
    }


    $this->view->continue_url = $url;

    $this->_session->unsetAll();
  }
}