<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: install.php 16.12.16 05:40 bolot $
 * @author     Bolot
 */

/**
 * @category   Application_Extensions
 * @package    Advbilling
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */
class Advbilling_Installer extends Engine_Package_Installer_Module
{

  public function onPreInstall()
  {
    parent::onPreInstall();

    $db = $this->getDb();
    $db = Engine_Db_Table::getDefaultAdapter();
 $db->query("CREATE TABLE IF NOT EXISTS `engine4_advbilling_donatesettings` (
`donatesettings_id` int(11) NOT NULL AUTO_INCREMENT,
`donate_id` int(11) DEFAULT NULL,
`secret_key` varchar(250) DEFAULT NULL,
`status` int(1) DEFAULT NULL,
`publish_key` varchar(250) DEFAULT NULL,
PRIMARY KEY (`donatesettings_id`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=latin1");
    
    $db->query("CREATE TABLE IF NOT EXISTS  `engine4_advbilling_eventssettings` (
`eventssetting_id` INT(11) NOT NULL AUTO_INCREMENT,
`event_id` INT(11) NULL DEFAULT '0',
`secret_key` VARCHAR(250) NULL DEFAULT '0',
`publish_key` VARCHAR(250) NULL DEFAULT '0',
`status` INT(1) NULL DEFAULT '0',
`paypal_email` VARCHAR(250) NULL DEFAULT '0',
PRIMARY KEY (`eventssetting_id`)
) COLLATE='latin1_swedish_ci' ENGINE=InnoDB AUTO_INCREMENT=0;");
    
    $db->query("INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES
('core_admin_main_plugins_advbilling', 'advbilling', 'HE Advanced Billing', '', '{\"route\":\"advbilling_admin_index\"}', 'core_admin_main_plugins', '', '1', '0', '888'),
('advbilling_admin_main_transactions', 'advbilling', 'Transactions', '', '{\"route\":\"advbilling_admin_index\", \"action\":\"transaction\"}', 'advbilling_admin_main', '', '1', '0', '1'),
('advbilling_admin_main_settings', 'advbilling', 'Settings', '', '{\"route\":\"advbilling_admin_index\"}', 'advbilling_admin_main', '', '1', '0', '2')");
    
    
    $sql = <<<CONTENT
SELECT TRUE FROM `engine4_core_modules` WHERE `name` = 'store' LIMIT 1
CONTENT;
    
    if (null != $db->fetchRow($sql)) {
        $db->query("INSERT IGNORE INTO`engine4_store_gateways` (`gateway_id`, `title`, `description`, `button_url`, `enabled`, `plugin`, `email`, `config`, `test_mode`)
VALUES (555, 'Stripe', 'Advanced Billing ', NULL, 1, 'Advbilling_Plugin_Gateway_Stripe', '', '', 0);");
    }
    
    
    
    $db->query("INSERT IGNORE INTO `engine4_payment_gateways` (`gateway_id`, `title`, `description`, `enabled`, `plugin`, `config`, `test_mode`)
VALUES (555, 'Stripe', NULL, 1, 'Advbilling_Plugin_Gateway_Stripemain', '', 0);");
  }
  function onEnable()
  {
    parent::onEnable();
    $db = $this->getDb();
    $db->query("INSERT IGNORE INTO `engine4_payment_gateways` (`gateway_id`, `title`, `description`, `enabled`, `plugin`, `config`, `test_mode`)
VALUES (555, 'Stripe', NULL, '0', 'Advbilling_Plugin_Gateway_Stripemain',NULL, '0');");

  }

  function onDisable()
  {
    parent::onDisable();
    $db = $this->getDb();
    $db->query("DELETE FROM `engine4_payment_gateways` WHERE `gateway_id`=555;");
  }
  
  
  
}
