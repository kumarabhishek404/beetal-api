$(document).ready(function () {
    $('#calendar').eCalendar();
});

 function getEvents_byDate(day, mouth, year) {
    var data = {
      'day': day,
      'mouth': mouth,
      'year': year
    };
    $('#content_event_calendar').show();
    $('.background_page_calendar_event').show();
    $('#content_event_calendar').html('<div class="loader_ecevent"></div>');
    var left = (window.getSize().x - 600) / 2;
    $('#content_event_calendar').css('left', left + 'px');
    var arg = {
      url: en4.core.baseUrl + 'ecalendar/index/geteventst?format=html',
      method: 'post',
      data: data,
      evalScripts: true,
      onSuccess: function (a, b, html) {
        $('#content_event_calendar').html(html);
        var left = (window.getSize().x - 600) / 2;
        var height = (window.getSize().y - 130);
        $('#content_event_calendar').show();
        $('#content_event_calendar').css('left', left + 'px');
        $('#content_event_calendar').css('height', height + 'px');
        $('.background_page_calendar_event').css('display', 'block');
      }
    };

    new Request.HTML(arg).send();
  }
  function close_calendar_heevent() {
    $('#content_event_calendar').html('');
    $('#content_event_calendar').css('display', 'none');
    $('.background_page_calendar_event').css('display', 'none');
  }
  function closeEvents(){
  	close_calendar_heevent();
  }