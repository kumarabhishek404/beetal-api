<?php return array (
  'package' =>
  array (
    'type' => 'module',
    'name' => 'ecalendar',
    'version' => '5.1.0p1',
    'path' => 'application/modules/Ecalendar',
    'title' => 'Event Calendar',
    'description' => 'This module allows to display events in the monthly,weekly calendar format',
    'author' => '<a href="ipragmatech.com"> iPragmatech</a>',
    'sku' => 'IPSEECAL',
    'callback' => array(
      'path' => 'application/modules/Ecalendar/settings/install.php',
      'class' => 'Ecalendar_Installer',
    ),
    'actions' =>
    array (
      0 => 'install',
      1 => 'upgrade',
      2 => 'refresh',
      3 => 'enable',
      4 => 'disable',
    ),
    'directories' =>
    array (
      0 => 'application/modules/Ecalendar',
    ),
    'files' =>
    array (
      0 => 'application/languages/en/ecalendar.csv',
    ),
  ),
		'routes' => array(
				'ecalendar_general' => array(
						'route' => 'ecalendar/:controller/:action',
						'defaults' => array(
								'module' => 'ecalendar',
								'controller' => 'index',
								'action' => 'index',
						),
						'reqs' => array(
								'action' => '(index|allevents)',
						)
				),



		)
		); ?>
