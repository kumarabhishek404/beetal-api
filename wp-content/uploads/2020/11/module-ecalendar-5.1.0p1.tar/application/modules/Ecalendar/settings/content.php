<?php
return array(
  array(
                'title' => 'Profile Calendar',
                'description' => 'Displays a member\'s activies entries in calendar view on their profile.',
                'category' => 'Ecalendar',
                'type' => 'widget',
                'name' => 'ecalendar.profile-calendar',
                'defaultParams' => array(
                        'title' => 'Calendar',
                        'titleCount' => true,
                ),
                'requirements' => array(
                        'subject' => 'user',
                ),
     )

        ) ?>
