update engine4_core_modules SET version = '4.10.3p1' where name = "ecalender";
DELETE FROM `engine4_core_menuitems` WHERE `name` = 'all_calendar_events';