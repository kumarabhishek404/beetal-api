<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Donation
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @author     adik
 * @date       06.09.12
 * @time       10:26
 */
class Ecalendar_Installer extends Engine_Package_Installer_Module
{
  public function onPreInstall()
  {
    $this->_myEventPage();
    parent::onPreInstall();

    $db = $this->getDb();
    $db = Engine_Db_Table::getDefaultAdapter();
}
  public function onDisable() {

    $db = $this->getDb();

    $db->query('DELETE FROM `engine4_core_menuitems` WHERE `name` = "mycalendar";');
    parent::onDisable();
  }

  function onEnable() {

    $db = $this->getDb();

    //Plugin Enabled and disabled
    $select = new Zend_Db_Select($db);
    $select
            ->from('engine4_core_menuitems')
            ->where('name = ?', 'mycalendar')
            ->limit(1);
        ;
        $info = $select->query()->fetch();
    if( empty($info) ) {
      $sql = "INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES
( 'mycalendar', 'core', 'My Calendar', '', '{\"route\":\"ecalendar_general\",\"module\":\"ecalendar\",\"controller\":\"index\"}', 'event_main', '', 1, 1, 999)";
    $db->query($sql);
    }
    parent::onEnable();
  }
public function _myEventPage(){
    $db     = $this->getDb();
        $select = new Zend_Db_Select($db);

        // Check if it's already been placed
        $select = new Zend_Db_Select($db);
        $select
            ->from('engine4_core_pages')
            ->where('name = ?', 'ecalendar_index_index')
            ->limit(1);
        ;
        $info = $select->query()->fetch();

        if( empty($info) ) {
            $db->insert('engine4_core_pages', array(
                'name' => 'ecalendar_index_index',
                'displayname' => 'Ecalendar Browse page',
                'title' => 'Ecalendar Browse page',
                'description' => 'This is the Ecalendar Browse page.',
                'custom' => 0,
            ));
            $pageId = $db->lastInsertId('engine4_core_pages');

            // Insert top
            $db->insert('engine4_core_content', array(
                'type' => 'container',
                'name' => 'top',
                'page_id' => $pageId,
                'order' => 1,
            ));
            $topId = $db->lastInsertId();

            // Insert main
            $db->insert('engine4_core_content', array(
                'type' => 'container',
                'name' => 'main',
                'page_id' => $pageId,
                'order' => 2,
            ));
            $mainId = $db->lastInsertId();

            // Insert top-middle
            $db->insert('engine4_core_content', array(
                'type' => 'container',
                'name' => 'middle',
                'page_id' => $pageId,
                'parent_content_id' => $topId,
            ));
            $topMiddleId = $db->lastInsertId();

            // Insert main-middle
            $db->insert('engine4_core_content', array(
                'type' => 'container',
                'name' => 'middle',
                'page_id' => $pageId,
                'parent_content_id' => $mainId,
                'order' => 2,
            ));
            $mainMiddleId = $db->lastInsertId();

            // Insert main-right
            $db->insert('engine4_core_content', array(
                'type' => 'container',
                'name' => 'right',
                'page_id' => $pageId,
                'parent_content_id' => $mainId,
                'order' => 1,
            ));
            $mainRightId = $db->lastInsertId();


            // Insert menu
            $db->insert('engine4_core_content', array(
                'type' => 'widget',
                'name' => 'event.browse-menu',
                'page_id' => $pageId,
                'parent_content_id' => $topMiddleId,
                'order' => 1,
            ));

            // Insert content
            $db->insert('engine4_core_content', array(
                'type' => 'widget',
                'name' => 'core.content',
                'page_id' => $pageId,
                'parent_content_id' => $mainMiddleId,
                'order' => 1,
            ));

            // Insert search
            $db->insert('engine4_core_content', array(
                'type' => 'widget',
                'name' => 'event.browse-menu-quick',
                'page_id' => $pageId,
                'parent_content_id' => $mainRightId,
                'order' => 1,
            ));
        }
}
}
