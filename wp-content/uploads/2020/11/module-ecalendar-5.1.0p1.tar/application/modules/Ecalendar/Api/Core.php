<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Ravshanbek
 * Date: 20.07.12
 * Time: 12:08
 * To change this template use File | Settings | File Templates.
 */
class Ecalendar_Api_Core extends Core_Api_Abstract
{
  public function getEvents($date)
  {
    $log = Zend_Registry::get('Zend_Log');
    $eventTable = Engine_Api::_()->getDbTable('events', 'event');
    $select = $eventTable->select()
      ->where("starttime like '$date%'")
    ->order('starttime DESC');
    $log->log("getEvents :::".$select,Zend_Log::DEBUG);
    $events = $eventTable->fetchAll($select);
    return array(
     'event' => $events,
    );
  
  }

}
