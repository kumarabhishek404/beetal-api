<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Blog
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: Controller.php 9747 2012-07-26 02:08:08Z john $
 * @author     John
 */

/**
 * @category   Application_Extensions
 * @package    Blog
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
class Ecalendar_Widget_ProfileCalendarController extends Engine_Content_Widget_Abstract
{
  

  public function indexAction()
  {

    $log = Zend_Registry::get('Zend_Log');
        $viewer = Engine_Api::_()->user()->getViewer();
        $membership = Engine_Api::_()->getDbtable('membership', 'event');
        $events = Engine_Api::_()->getDbtable('events', 'event');
        $select = $membership->getMembershipsOfSelect($viewer);
        //$select = $events->select();
        //$select->where('starttime >= ?', $this->_getParam("startDate"));
        ///$select->where('starttime <= ?', $this->_getParam("endDate"));
        //$select->where('endtime >= ?', $this->_getParam("startDate"));
        $select->order('starttime ASC');

        $events = $membership->fetchAll($select);
        $data = array();


        foreach ($events as $event) {
            $not = 0;
            $waiting = 0;
            $maybe = 0;
            $attend = 0;

            $select = $membership->select()->from($membership, array('rsvp', 'count(*) as cnt'))->where('resource_id = ?', $event->event_id)->group('rsvp');
            $attendings = $membership->fetchAll($select);

            foreach ($attendings as $attending) {
                if ($attending->rsvp == "2") {
                    $attend = $attending->cnt;

                } elseif ($attending->rsvp == "1") {
                    $maybe = $attending->cnt;
                } elseif ($attending->rsvp == "3") {
                    $waiting = $attending->cnt;
                } else {
                    $not = $attending->cnt;
                }
            }

            $params = array(
                'route' => 'event_profile',
                'reset' => true,
                'id' => $event->event_id,
            );

            $categoryTable = Engine_Api::_()->getDbtable('categories', 'event');
            $category = $categoryTable->find($event->category_id)->current();
            $catName = "";
            if (isset($category)) {
                $catName = $category->title;
            }
            $route = $params['route'];
            $reset = $params['reset'];
            unset($params['route']);
            unset($params['reset']);
            $href = Zend_Controller_Front::getInstance()->getRouter()
                ->assemble($params, $route, $reset);
            $tmpBody = strip_tags($event->description);
            $desc = (Engine_String::strlen($tmpBody) > 255 ? Engine_String::substr($tmpBody, 0, 255) . '...' : $tmpBody);


            $tmpTitle = strip_tags($event->title);
            $title = $tmpTitle;

            $startd = DateTime::createFromFormat('Y-m-d H:i:s', $event->starttime);
            $endd = DateTime::createFromFormat('Y-m-d H:i:s', $event->endtime);
            $items = Engine_Api::_()->getItem('event', $event->event_id);
            $data[] = array(
                'title' => $title,
                'start' => $this->view->locale()->toDateTime($event->starttime),
                'end' => $this->view->locale()->toDateTime($event->endtime),
                'startString' => $startd->getTimestamp() * 1000,
                'endString' => $endd->getTimestamp() * 1000,
                'location' => $event->location,
                'description' => $desc,
                'host' => $event->host,
                'href' => $href,
                'datetime' => date('m/d/Y',strtotime($event->starttime)),
                'category' => $catName == null ? '' : $catName,
                'attending' => $attend == null ? '0' : $attend,
                'maybe' => $maybe == null ? '0' : $maybe,
                'notattend' => $not == null ? '0' : $not,
                'waiting' => $waiting == null ? '0' : $waiting,
                'image' => $this->itemPhoto($items, 'thumb.profile') ? $this->itemPhoto($items, 'thumb.icon') : '/application/modules/Event/externals/images/nophoto_event_thumb_icon.png'


            );

        }

        $this->view->jsonData = $data;
  }

  public function itemPhoto($item, $type = 'thumb.profile')
  {
    // Whoops
    if (!($item instanceof Core_Model_Item_Abstract)) {
      throw new Zend_View_Exception("Item must be a valid item");
    }

    // Get url
    $src = $item->getPhotoUrl($type);
    $safeName = ($type ? str_replace('.', '_', $type) : 'main ');

    return $src;
  }
}
