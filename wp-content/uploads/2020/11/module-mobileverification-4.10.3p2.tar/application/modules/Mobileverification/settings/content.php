<?php
/**
 * SocialEngine
 *
 * @category   Application_UserImporter
 * @package    Userimport
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.ipragmatech.com/license/
 * @version    $Id: content.php 9747 2012-07-26 02:08:08Z ipragmatech $
 * @author     iPragmatech
 */
return array(
		array(
				'title' => 'Mobile Verfication verified',
				'description' => 'Mobile Verification',
				'category' => 'Mobile Verification',
				'type' => 'widget',
				'name' => 'mobileverification.verified-user',
		),
		array(
				'title' => 'Mobile Verfication annoucement',
				'description' => 'Mobile Verification',
				'category' => 'Mobile Verification',
				'type' => 'widget',
				'name' => 'mobileverification.user-verified',
		),

)
  		?>
