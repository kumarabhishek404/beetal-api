<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Group
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: Controller.php 9747 2012-07-26 02:08:08Z john $
 * @author     John
 */

/**
 * @category   Application_Extensions
 * @package    Group
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
class Mobileverification_Widget_VerifiedUserController extends Engine_Content_Widget_Abstract
{
  public function indexAction()
  {
  	$log = Zend_Registry::get ( 'Zend_Log' );
  	
  	$menu_table = Engine_Api::_()->getDbtable('modules', 'core');
  	$menu_data = $menu_table->select()->where('name=?','mobileverification');
  	$enabled_menu = $menu_table->fetchRow($menu_data);
   //	$log->log('module_table'.json_encode($enabled_menu['enabled']),Zend_Log::DEBUG);
  	
  	if($enabled_menu['enabled']==0){
  		return $this->setNoRender();
  	}
  	else{
  	 	
  	$subject = Engine_Api::_()->core()->getSubject();
  	//if subject is not there
  	if(!$subject){
  		return $this->setNoRender();
  	}
  	// get viewer
  	$viewer = Engine_Api::_ ()->user ()->getViewer ();
  	$viewer_id = $viewer->getIdentity ();
  	$level_id=$viewer->level_id;
  	// check viewer is login or not, if not set no render
  	if($viewer_id==1){
  		return $this->setNoRender();
  	}
  	
  	
   	$verification_table = Engine_Api::_ ()->getDbtable ( 'verifications', 'mobileverification' );
  	$verification_select = $verification_table->select ()->where ( 'user_id=?', $subject->user_id );
  	$verificationdata = $verification_table->fetchRow ( $verification_select );
  	$verfied=$verificationdata['verified'];
  	  	
  	if($verfied == 1){
  		$this->view->status = true;
  	}else {
  		$this->view->status = false;
  	}  	
  }
}
}

