<?php
/**
 * iPragmatech Solution Pvt. Ltd.
 *
 * @category   Application_Mobile Verification
 * @package    Mobile Verification
 * @copyright  Copyright 2008-2013 iPragmatech Solution Pvt. Ltd.
 * @license   � 2013 iPragmatech. All Rights Reserved.
 * @version    $Id: Global.php 9747 2013-07-06 02:08:08Z iPrgamtech $
 * @author     iPragmatech
 */

class Mobileverification_Form_Admin_Mobilesetting extends Engine_Form
{
  public function init()
  {
 
  	$actionName = Zend_Controller_Front::getInstance()->getRequest()->getActionName();
  	$this->setAttrib('id', 'mobile_setting');
  	
  	
  	// Element: enable
    $setting_table = Engine_Api::_()->getDbtable('settings', 'mobileverification');
 	$setting_select = $setting_table->select()->where('user_id=?',1);
 	$setting_data = $setting_table->fetchRow($setting_select);
  		
  	$this->addElement('Radio', 'enable', array(
  			'description' => 'Do you really want to make mobile number as unique field?',
  			'multiOptions' => array(
  					'1' => 'Yes, make as unique field',
  					'0' => 'No,do not make as unique field',
  			),
  			'value' => $setting_data['unique_field']
  	));
 
  	// Add submit button
  	$this->addElement('Button', 'save', array(
  			'label' => 'Save Changes',
  			'type' => 'submit',
  	));
  }
}