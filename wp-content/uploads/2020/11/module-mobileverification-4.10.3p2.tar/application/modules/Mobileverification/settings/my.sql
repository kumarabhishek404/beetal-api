INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES  ('mobileverification', 'Mobile Verification', 'This plugin verify the code from the Users mobile.', '4.8.13', 1, 'extra') ;

INSERT INTO  `engine4_user_signup` (`signup_id` ,`class` , `order` , `enable`)VALUES (NULL ,  'Mobileverification_Plugin_Signup_Verify',  '99',  '1');

INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES ('core_admin_main_plugins_twilioinfo', 'mobileverification', 'Mobile Verification', '', '{"route":"admin_default","module":"mobileverification", "controller":"settings"}', 'core_admin_main_plugins', NULL, 1, 0, 999);

INSERT IGNORE INTO `engine4_core_menus` (`name`, `type`, `title`, `order`) VALUES ('mobileverification_admin_main', 'standard', 'Twilio Info Main Navigation Menu', 999);

INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES ('mobileverification_admin_main_settings', 'mobileverification', 'Twilio Info', '', '{"route":"admin_default","module":"mobileverification","controller":"settings"}', 'mobileverification_admin_main', '', 1, 0, 1);

INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES ('mobileverification_admin_main_global', 'mobileverification', 'Global Setting', '', '{"route":"admin_default","module":"mobileverification","controller":"settings","action":"global"}', 'mobileverification_admin_main', '', 1, 0, 2);

CREATE TABLE IF NOT EXISTS `engine4_mobileverification_twilios` (
  `twilio_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_sid` varchar(100) NOT NULL,
  `account_token` varchar(100) NOT NULL,
  `twilio_number` varchar(100) NOT NULL,
  PRIMARY KEY (`twilio_id`));

CREATE TABLE IF NOT EXISTS `engine4_mobileverification_verifications` (
  `user_id` int(11) NOT NULL,
  `number` varchar(100) NOT NULL,
  `code` int(15) NOT NULL,
  `verified` int(15) NOT NULL,
  PRIMARY KEY (`user_id`));

CREATE TABLE IF NOT EXISTS `engine4_mobileverification_settings` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `unique_field` int(4) NOT NULL,
  PRIMARY KEY (`id`));  

INSERT INTO `engine4_core_menuitems` (`id`, `name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES (NULL, 'user_edit_mobileveify', 'mobileverification', 'Mobile Verify', '', '{"route":"mobile_extended"}', 'user_edit', '', '1', '0', '99');

INSERT INTO `engine4_core_menuitems` (`id`, `name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES (NULL, 'mobileverification_admin_main_profile', 'mobileverification', 'Profile Setting', '', '{"route":"admin_default","module":"mobileverification","controller":"settings","action":"profile"}', 'mobileverification_admin_main', '', '1', '0', '3');

INSERT INTO `engine4_core_menuitems` (`id`, `name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES (NULL, 'mobileverification_admin_main_mobilesetting', 'mobileverification', 'Mobile Setting', '', '{"route":"admin_default","module":"mobileverification","controller":"settings","action":"mobilesetting"}', 'mobileverification_admin_main', '', '1', '0', '4');

INSERT INTO `engine4_core_menuitems` (`id`, `name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES (NULL, 'mobileverification_admin_main_typesetting', 'mobileverification', 'Profile Type Setting', '', '{"route":"admin_default","module":"mobileverification","controller":"settings","action":"typesetting"}', 'mobileverification_admin_main', '', '1', '0', '5');

INSERT INTO `engine4_core_menuitems` (`id`, `name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES (NULL, 'mobileverification_admin_main_userverfied', 'mobileverification', 'User Status', '', '{"route":"admin_default","module":"mobileverification","controller":"settings","action":"userverfied"}', 'mobileverification_admin_main', '', '1', '0', '6');


CREATE TABLE IF NOT EXISTS `engine4_mobileverification_types` (
  `user_id` int(4) NOT NULL,
  `profile_id` int(10) NOT NULL,
  `mobile_id` int(4) NOT NULL,
  PRIMARY KEY (`profile_id`));  
