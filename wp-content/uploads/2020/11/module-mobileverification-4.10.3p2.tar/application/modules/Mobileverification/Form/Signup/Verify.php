<?php
/**
 * iPragmatech Solution Pvt. Ltd.
 *
 * @category   Application_User Importer
 * @package    User Importer
 * @copyright  Copyright 2008-2013 iPragmatech Solution Pvt. Ltd.
 * @license   � 2013 iPragmatech. All Rights Reserved.
 * @version    $Id: Global.php 9747 2013-07-06 02:08:08Z iPrgamtech $
 * @author     iPragmatech
 */

class Mobileverification_Form_Signup_Verify extends Engine_Form
{
  public function init()
  {
  	$log = Zend_Registry::get('Zend_Log');
  	$this->setAttrib('id', 'mobileverification_widget');
  	
  	$accountSession = new Zend_Session_Namespace('User_Plugin_Signup_Fields');
  	$profileTypeValue = @$accountSession->data;
  	$prof=$profileTypeValue[1];
  	
  	  	
   $metaTable = Engine_Api::_()->fields()->getTable('user', 'meta');
  	$typeTable = Engine_Api::_()->getDbtable('types', 'mobileverification');
  	
  	
  	$typeSelect = $typeTable->select()
  	->setIntegrityCheck(false)
  	->from(array('typ' => $typeTable->info('name')))
  	->join(array('met' => $metaTable->info('name')),'typ.mobile_id = met.field_id',array("label"))
  	->where('typ.profile_id = ?',$prof);
  	$profiledata = $typeTable->fetchAll($typeSelect);
  	
  	$label=$profiledata['profiledata']['label'];
  	$type_table = Engine_Api::_()->getDbtable('types', 'mobileverification');
  	
  	$type_select = $type_table->select();
  	$type_data = $type_table->fetchAll($type_select);
  	
  foreach( $profiledata as $item) {
  		if($profileTypeValue[$item->mobile_id]!= '')
  		{
  			$html = $profileTypeValue[$item->mobile_id];
  			
  		}
  	}
  	
  	//Mobile Number
  	 
  	 	$this->addElement('Text', 'mobile_number', array(
	  			'description'=> 'Please re-enter your mobile number below to receive a verification code by sms enter here. Example: "+91 9630389373"',
	  			'label' => $label,
	  			'value' => $html
	  	));
  	
  	//Verification Code
  	  	$this->addElement('Text', 'confirm_code_widget', array(
	  			'label' => 'Verification Code',
	  	));
  	
  	//hidden Input which take mobile number
  	  	$this->addElement('hidden', 'mobile_hidden');
  	  	
  	
  	$this->addElement('Text', 'error', array(
  				'attribs' => array ('style' => 'visibility: hidden')
	));

   // Add submit button
    $this->addElement('Button', 'send_code_button', array(
    		'label' => 'Send',
    		'type' => 'button',
    		'onClick' => 'sendcode();'
    ));
    
    // Add submit button
    $this->addElement('Button', 'confirm_code_button', array(
    		'label' => 'Verify',
    		'type' => 'submit',
    ));
  }
  
}

