<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Mobileverification
 * @license    http://www.socialengine.com/license/
 * @author     iPragmatech
 */

/**
 * @category   Application_Extensions
 * @package    Mobileverification
 * @copyright  Copyright 2014 iPragmatech
 * @license    http://www.socialengine.com/license/
 */
class Mobileverification_Model_DbTable_Settings extends Engine_Db_Table
{
}