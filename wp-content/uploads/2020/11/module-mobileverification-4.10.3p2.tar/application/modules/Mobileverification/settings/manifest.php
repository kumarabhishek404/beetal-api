<?php return array (
  'package' =>
  array (
    'type' => 'module',
    'name' => 'mobileverification',
    'version' => '4.10.3p2',
    'path' => 'application/modules/Mobileverification',
    'title' => 'Mobile Verification',
    'description' => 'This plugin verify the code from the Users mobile.',
    'author' => 'iPragmatech',
  	'sku'  => 'IPSEMVEC',
  	'callback' =>
  	array (
      'class' => 'Engine_Package_Installer_Module',
    ),
    'actions' =>
    array (
      0 => 'install',
      1 => 'upgrade',
      2 => 'refresh',
      3 => 'enable',
    ),
    'directories' =>
    array (
      0 => 'application/modules/Mobileverification',
    ),
    'files' =>
    array (
      0 => 'application/languages/en/mobileverification.csv',
    ),
  ),

		// Hooks ---------------------------------------------------------------------
// 		'hooks' => array(
// 				array(
// 						'event' => 'onUserCreateAfter',
// 						'resource' => 'Mobileverification_Plugin_Core',
// 				),

// 		),
		//routes--------------------------------------------------------
		'routes' => array(
				'mobile_extended' => array(
						'route' => 'mobileverification/mobileverify',
						'defaults' => array(
								'module' => 'mobileverification',
								'controller' => 'index',
								'action' => 'mobileverify',
						),
				),
				'mobile_extended_widget' => array(
						'route' => 'mobileverification/confirmcode',
						'defaults' => array(
								'module' => 'mobileverification',
								'controller' => 'index',
								'action' => 'confirmcode',
						),
				),
		),
); ?>
