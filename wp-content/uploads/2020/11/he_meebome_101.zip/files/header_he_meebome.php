<?php

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version MeeboMe 1.01
 */

defined('SE_PAGE') or exit();

include_once "./header_he_core.php";
include_once "./include/class_he_meebome.php";

// PRELOAD LANGUAGE
SE_Language::_preload(690690038);

$plugin_vars['menu_user'] = array( 
	'file' => 'user_meebome.php', 
	'icon' => 'he_meebome_icon.png', 
	'title' => 690690038 );


// SET PROFILE MENU VARS
if ( $owner->user_exists && $page=="profile" )
{
	$meebome_info = he_meebome::get_info($owner->user_info['user_id']);
	$privacy_max = $owner->user_privacy_max($user);
	
	if ( $meebome_info['code'] && $meebome_info['privacy_level'] & $privacy_max )
	{
		$meebome_code = htmlspecialchars_decode($meebome_info['code']);
		
		$smarty->assign('he_meebome_code', $meebome_code);
		
		$plugin_vars['menu_profile_side'] = array( 
			'file' => 'profile_he_meebome.tpl', 
			'title' => 690690038, 
			'name' => 'he_meebome');
	}
}

// Use new template hooks
if ( is_a($smarty, 'SESmarty') )
{
	$plugin_vars['uses_tpl_hooks'] = TRUE;
	
	$smarty->assign_hook('menu_user_apps', $plugin_vars['menu_user']);

	if( !empty($plugin_vars['menu_profile_side']) )
	{
		$smarty->assign_hook('profile_side', $plugin_vars['menu_profile_side']);
	}
	
	if( $page=="user_meebome" || $page == "profile" )
	{
 		$smarty->assign_hook('styles', './templates/he_meebome_styles.css');	
	}
}


?>