<?php

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version MeeboMe 1.01
 */

class he_meebome
{
	function get_info( $user_id )
	{
		$query = he_database::placeholder( "SELECT * FROM `se_he_meebome` 
			WHERE `user_id`=?", $user_id );
		
		return he_database::fetch_row($query);
	}
	
	function save_or_update( $user_id, $code, $privacy_level )
	{			
		$meebome_src = he_meebome::get_meebome_src($code);
		
		if ( !$user_id || !$meebome_src )
		{
			return false;	
		}
		
		$default_meebome_code = '<embed src="{$replace_src}" type="application/x-shockwave-flash" width="190" height="275"></embed>';
		$meebome_code = str_replace('{$replace_src}', $meebome_src, $default_meebome_code);	
		
		$query = he_database::placeholder( "INSERT INTO `se_he_meebome` (`user_id`, `code`, `privacy_level`) VALUES(?, '?', ?) 
			ON DUPLICATE KEY UPDATE `code`='?', `privacy_level`=?", $user_id, $meebome_code, $privacy_level, $meebome_code, $privacy_level );

		he_database::query($query);
		
		return true;
	}
	
	function get_meebome_src( $code )
	{
		$code_arr = explode("http://widget.meebo.com/mm.swf?", $code);

		if ( !$code_arr[1] )
		{
			return false;
		}

		$code_arr = explode('"', $code_arr[1]);
		$meebome_src = $code_arr[0];
		
		if ( !$meebome_src )
		{
			return false;
		}

		return "http://widget.meebo.com/mm.swf?$meebome_src";
	}
}

?>