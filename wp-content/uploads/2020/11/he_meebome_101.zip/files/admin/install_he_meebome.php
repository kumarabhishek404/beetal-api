<?

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version MeeboMe 1.01
 */

$plugin_name = "MeeboMe Widget";
$plugin_version = "1.01";
$req_core_version = "3.01";
$plugin_type = "he_meebome";
$plugin_desc = "This plugin is intended to increase activity on your site. It allows users to put MeeboMe widget on their profile page. Using this widget visitors can chat(IM) with user on profile page. Please go to <a href=\"http://www.hire-experts.com/\">Hire-Experts.com</a> to get this plugin latest version.";
$plugin_icon = "he_meebome_icon.png";
$plugin_menu_title = "";
$plugin_pages_main = "";
$plugin_pages_level = "";
$plugin_url_htaccess = "";
$plugin_db_charset = 'utf8';
$plugin_db_collation = 'utf8_unicode_ci';


if($install == "he_meebome") {

	//check core library
	$sql = "SELECT `plugin_version` FROM `se_plugins` WHERE plugin_type='he_core' AND `plugin_disabled`=0 LIMIT 1";
	$resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
	$core_version = $database->database_fetch_array($resource);
	if ( floatval($core_version[0]) < floatval($req_core_version) ) {
		die ('This plugin requires Hire-Experts Core Library. Please install latest version of Hire-Experts Core Library plugin. You can download it from My Plugins section in Hire-Experts.com for FREE.');
	}

	//check if plugin was already installed
	$sql = "SELECT * FROM se_plugins WHERE plugin_type='$plugin_type' LIMIT 1";
	$resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
	
	$plugin_info = array();
	if( $database->database_num_rows($resource) )
		$plugin_info = $database->database_fetch_assoc($resource);
	
	
	//install plugin
	if( !$plugin_info ) {
		$database->database_query("INSERT INTO se_plugins (plugin_name,
			plugin_version,
			plugin_type,
			plugin_desc,
			plugin_icon,
			plugin_menu_title,
			plugin_pages_main,
			plugin_pages_level,
			plugin_url_htaccess
			) VALUES (
			'$plugin_name',
			'$plugin_version',
			'$plugin_type',
			'".str_replace("'", "\'", $plugin_desc)."',
			'$plugin_icon',
			'',
			'$plugin_pages_main',
			'',
			'$plugin_url_htaccess')");
	
	
	//update plugin
	} else {
		$database->database_query("UPDATE se_plugins SET plugin_name='$plugin_name',
			plugin_version='$plugin_version',
			plugin_desc='".str_replace("'", "\'", $plugin_desc)."',
			plugin_icon='$plugin_icon',
			plugin_menu_title='',
			plugin_pages_main='$plugin_pages_main',
			plugin_pages_level='',
			plugin_url_htaccess='$plugin_url_htaccess' WHERE plugin_type='$plugin_type'");
	}


	$database->database_query("CREATE TABLE IF NOT EXISTS `se_he_meebome` (
		`user_id` INT NOT NULL ,
		`code` TEXT NOT NULL ,
		`privacy_level` INT NOT NULL DEFAULT '0',
		UNIQUE (`user_id`)
		) ENGINE = MYISAM ");

	//insert langs
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690038 LIMIT 1")) == 0)
		$database->database_query("INSERT INTO `se_languagevars` VALUES('690690038', '1', 'MeeboMe Widget', 'meebome')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='MeeboMe Widget', languagevar_default='meebome' WHERE languagevar_id='690690038' AND languagevar_language_id='1'");
	
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690039 LIMIT 1")) == 0)
		$database->database_query("INSERT INTO `se_languagevars` VALUES('690690039', '1', 'Show/Hide tips', 'meebome')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Show/Hide tips', languagevar_default='meebome' WHERE languagevar_id='690690039' AND languagevar_language_id='1'");
	
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690040 LIMIT 1")) == 0)
		$database->database_query("INSERT INTO `se_languagevars` VALUES('690690040', '1', 'It allows you to chat with members who visit your profile. Please go to <a href=\"http://www.meebome.com/\">MeeboMe</a> and generate widget code. Then put this code into textbox.', 'meebome')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='It allows you to chat with members who visit your profile. Please go to <a href=\"http://www.meebome.com/\">MeeboMe</a> and generate widget code. Then put this code into textbox.', languagevar_default='meebome' WHERE languagevar_id='690690040' AND languagevar_language_id='1'");
	
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690041 LIMIT 1")) == 0)
		$database->database_query("INSERT INTO `se_languagevars` VALUES('690690041', '1', 'MeeboMe widget code', 'meebome')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='MeeboMe widget code', languagevar_default='meebome' WHERE languagevar_id='690690041' AND languagevar_language_id='1'");
	
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690042 LIMIT 1")) == 0)
		$database->database_query("INSERT INTO `se_languagevars` VALUES('690690042', '1', 'Who can chat with you', 'meebome')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Who can chat with you', languagevar_default='meebome' WHERE languagevar_id='690690042' AND languagevar_language_id='1'");
	
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690043 LIMIT 1")) == 0)
		$database->database_query("INSERT INTO `se_languagevars` VALUES('690690043', '1', 'Save changes', 'meebome')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Save changes', languagevar_default='meebome' WHERE languagevar_id='690690043' AND languagevar_language_id='1'");
	
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690044 LIMIT 1")) == 0)
		$database->database_query("INSERT INTO `se_languagevars` VALUES('690690044', '1', 'Changes has been successfully saved.', 'meebome')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Changes has been successfully saved.', languagevar_default='meebome' WHERE languagevar_id='690690044' AND languagevar_language_id='1'");
	
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690045 LIMIT 1")) == 0)
		$database->database_query("INSERT INTO `se_languagevars` VALUES('690690045', '1', 'Please type valid MeeboMe widget code.', 'meebome')");
	else $database->database_query("UPDATE `se_languagevars` SET languagevar_value='Please type valid MeeboMe widget code.', languagevar_default='meebome' WHERE languagevar_id='690690045' AND languagevar_language_id='1'");

}
?>