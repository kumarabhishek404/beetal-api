<?php

/**
 * @author Ermek
 * @copyright Hire-Experts LLC
 * @version MeeboMe 1.01
 */

$page = "user_meebome";
include "header.php";

// DISPLAY ERROR PAGE IF NO OWNER
if($user->user_exists == 0)
{
  $page = "error";
  $smarty->assign('error_header', 639);
  $smarty->assign('error_message', 828);
  $smarty->assign('error_submit', 641);
  include "footer.php";
}

$user_id = $user->user_info['user_id']; 

$message = array();

if ( isset($_POST['save_code']) && $_POST['save_code'] )
{
	$meebome_code = trim($_REQUEST['meebome_code']);
	$meebome_code = ( get_magic_quotes_gpc() ) ? stripcslashes($meebome_code) : $meebome_code;

	$privacy_level = (int)$_POST['privacy_level'];
	
	$result = he_meebome::save_or_update($user_id, $meebome_code, $privacy_level);
	
	$message = ( $result ) ? array('type'=>'success', 'text'=>SE_Language::get(690690044))
						   : array('type'=>'error', 'text'=>SE_Language::get(690690045));
}

$meebome_info = he_meebome::get_info($user_id);

$level_meebome = array( 63, 31, 15, 7, 3, 0 );
$meebome_options = array();

for ($c=0; $c<count($level_meebome); $c++)
{
	if( user_privacy_levels($level_meebome[$c] ) != "" )
	{
		SE_Language::_preload(user_privacy_levels($level_meebome[$c]));
		$meebome_options[$level_meebome[$c]] = user_privacy_levels($level_meebome[$c]);
	}
}

$smarty->assign('message', $message);
$smarty->assign('meebome_info', $meebome_info);
$smarty->assign('meebome_options', $meebome_options);

include "footer.php";
?>