<?php

class Advnotifications_IndexController extends Core_Controller_Action_Standard
{
  public function indexAction()
  {
    /**
     * @var $table Activity_Model_DbTable_Notifications
     * @var $item Activity_Model_Notification
     */
    /*$viewer = Engine_Api::_()->user()->getViewer();
    $table = Engine_Api::_()->getDbTable('notifications', 'activity');
    $select = $table->select()
      //->where('notification_id=3073')
      ->where('user_id = ?', $viewer->getIdentity())
      ->where('`read` = 0')
      ->where('is_shown = 0')
      ->order('date desc')
      ->limit(1);
    $item = $table->fetchRow($select);

    if (!$item) {
      return;
    }
    $this->view->html = $this->getNotification($item);*/
  }

  public function updateAction()
  {
    /**
     * @var $table Advnotifications_Model_DbTable_Advnotifications
     * @var $item Advnotifications_Model_Advnotification
     * @var $object Activity_Model_Action
     */
    $viewer = Engine_Api::_()->user()->getViewer();
    $table = Engine_Api::_()->getDbTable('advnotifications', 'advnotifications');
    $select = $table->select()
      ->where('user_id = ?', $viewer->getIdentity())
      ->where('`read` = 0')
      ->where('is_shown = 0')
      ->order('date desc')
      ->limit(1);

    $item = $table->fetchRow($select);

    if (!$item) {
      $this->view->status = true;
      return;
    }

    $item->is_shown = 1;
    $item->read = 1;
    $item->save();

    $this->getNotification($item);
  }

  private function getNotification($item = null)
  {
    /**
     * @var $item Advnotifications_Model_Advnotification
     * @var $object Activity_Model_Action
     */
    if (!$item) {
      return '';
    }

    $object = $item->getObject();
    $name = $item->getSubject();
    //$log = Zend_Registry::get('Zend_Log');

    if ($object->getType() == 'activity_action') {
      $content = $object->body;
    } else {
      $content = false;
    }

    $this->view->action_id = $item->getIdentity();
    $this->view->href = $object->getHref();
    $this->view->subjectHref = $name->getHref();
    $this->view->status = true;
    
    $nContent = $item->getContent();
    
    $params = json_decode($item->params);
    
    if ($content) {
      $nContent = substr($nContent, 0, strlen($nContent) - 1) . ' :"' . $content . '"';
    }

    $nContent = str_replace(array('<a', '</a'), array('<span', '</span'), $nContent);
    $nContent = $item->getContent();
    
    if($params->label){
       // $nContent = substr($nContent, 0, strlen($nContent) - 1) . ' : ' . $params->label . '';
	$nContent = substr($nContent, 0, strlen($nContent) - 1) . '  ' . '<a href="'.$name->getHref().'"><span id="feed-item">'.$params->label .'</span></a>'. '';    
}
    
    $time = $this->view->timestamp(strtotime($item->date));





    switch ($item->type) {
      case 'liked':
        $icon = 'thumbs-up';
        break;
      case 'commented':
        $icon = 'comment';
        break;
      default:
        $icon = false;
    }

    $isHeAdvMessages = Engine_Api::_()->getDbTable('modules', 'core')->isModuleEnabled('headvmessages');

    if ($isHeAdvMessages && $item->type == 'message_new' && $item->object_type == 'messages_conversation' &&
      $item->subject_type == 'user'
    ) {
      $this->view->id = $item->object_id;
      $this->view->advMessages = true;
    }

      if($item->type!='friend_request'){

        $this->view->html = $html = $this->view->partial('_notification.tpl', array(
          'user' => $item->getSubject(),
          'time' => $time,
          'icon' => $icon,
          'nContent' => $nContent,
          'type' => $item->type,
            'name' =>  $name,
        ));

      }else{
        $arr = $item->toArray();
          $nContentlink = "<div class='rowsemembers_results_links' style='margin-top: 20px; margin-right: 20px;' >

    <span  class='btn_heuser_list btn-headdfriend headvuser_button wp_init link_ok'>
    <i style='background: #02c852; color: #fff; padding: 5px 15px; border-radius: 6px; cursor: pointer; font-size: 11pt; font-style: normal;' data-id='".$arr['subject_id']."' data-notif='".$arr['notification_id']."' id='link_ok'>Accept</i>
    </span>

    <span  class='btn_heuser_list btn-headdfriend headvuser_button wp_init link_not_ok'>
    <i style='background: #f44f4f; color: #fff; padding: 5px 15px; border-radius: 6px; cursor: pointer; font-size: 11pt; font-style: normal;' data-id='".$arr['subject_id']."' data-notif='".$arr['notification_id']."' id='link_not_ok'>Decline</i>
    </span><br/>
    <br/>

</div>";


          $this->view->html = $html = $this->view->partial('_notification.tpl', array(
              'user' => $item->getSubject(),
              'time' => $time,
              'icon' => $icon,
              'nContent' => $nContent,
              'nContentlink'=>$nContentlink,
              'type' => $item->type,
              'name' =>  $name,
          ));
      }
    $this->view->imgUrl = $this->getImageUrlByType($item->type,$item->getSubject());
    $this->view->type = $item->type;
    $this->view->body = trim(strip_tags($nContent));
    $this->view->siteUrl = str_replace('advnotifications/index/update',"",$this->siteUrl());
    return $html;
  }

  public function getImageUrlByType($type,$item)
  {
    switch ($type) {
      case 'friend_accepted':
      case 'post_user':
      case 'shared':
      case 'friend_request': return str_replace('advnotifications/index/update',"",$this->siteUrl()).ltrim($item->getPhotoUrl('thumb.profile'), '/');
      case 'hebadge_new':
      case 'hebadgecredit_new':
      case 'hebadgepage_new':
        return str_replace('advnotifications/index/update',"",$this->siteUrl()).'application/modules/Advnotifications/externals/images/new_badge_recieved.png';
      case 'commented':
        return str_replace('advnotifications/index/update',"",$this->siteUrl()).'application/modules/Advnotifications/externals/images/new_comment.png';
      case 'page_like':
      case 'liked':
        return str_replace('advnotifications/index/update',"",$this->siteUrl()).'application/modules/Advnotifications/externals/images/page_like.png';
      case 'message_new':
        return str_replace('advnotifications/index/update',"",$this->siteUrl()).'application/modules/Advnotifications/externals/images/new_message.png';
      case 'post_pagereview':
        return str_replace('advnotifications/index/update',"",$this->siteUrl()).'application/modules/Advnotifications/externals/images/page_review_icon.png';
      case 'send_gift':
        return str_replace('advnotifications/index/update',"",$this->siteUrl()).'application/modules/Advnotifications/externals/images/new_gift.png';
      case 'post_productreview':
        return str_replace('advnotifications/index/update',"",$this->siteUrl()).'application/modules/Advnotifications/externals/images/store_review.png';
    }
  }
  public function siteUrl(){
    return sprintf(
        "%s://%s%s",
        isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http',
        $_SERVER['SERVER_NAME'],
        $_SERVER['REQUEST_URI']
    );
  }
  public function siteUrlDn(){
    return sprintf(
        "%s://%s%s",
        isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http',
        $_SERVER['SERVER_NAME'],
        '/'
    );
  }


}
