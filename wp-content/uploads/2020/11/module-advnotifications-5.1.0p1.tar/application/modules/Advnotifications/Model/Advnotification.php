<?php
/**
 * SocialEngine
 *
 * @category   Application_Core
 * @package    Activity
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: Notification.php 9747 2012-07-26 02:08:08Z john $
 * @author     John
 */

/**
 * @category   Application_Core
 * @package    Activity
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
class Advnotifications_Model_Advnotification extends Activity_Model_Notification //Core_Model_Item_Abstract //extends Activity_Model_Notification
{

  protected $_user;
    
  protected $_object;
    
  protected $_subject;

  public function getContent()
  {
    $model = Engine_Api::_()->getApi('core', 'activity');
    $params = array_merge(
      $this->toArray(),
      (array) $this->params,
      array(
        'user' => $this->getUser(),
        'object' => $this->getObject(),
        'subject' => $this->getSubject(),
      )
    );
    $content = $model->assemble($this->getTypeInfo()->body, $params);
    return $content;
  }

  public function getContentAsArray()
  {
    $model = Engine_Api::_()->getApi('core', 'advnotifications');
    $params = array_merge(
        $this->toArray(),
        (array) $this->params,
        array(
            'user' => $this->getUser(),
            'object' => $this->getObject(),
            'subject' => $this->getSubject(),
        )
    );
    $content = $model->assemble($this->getTypeInfo()->body, $params);
    return $content;
  }
  
  public function getUser()
  {
      if( null === $this->_user ) {
          $this->_user = Engine_Api::_()->getItem('user', $this->user_id);
      }
      
      return $this->_user;
  }
  
  


}