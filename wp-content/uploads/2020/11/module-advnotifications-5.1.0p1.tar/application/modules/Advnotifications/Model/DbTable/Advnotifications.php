<?php
/**
 * SocialEngine
 *
 * @category   Application_Core
 * @package    Activity
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: Notifications.php 10148 2014-03-26 19:11:58Z lucas $
 * @author     John
 */

/**
 * @category   Application_Core
 * @package    Activity
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
class Advnotifications_Model_DbTable_Advnotifications extends Engine_Db_Table  //extends Activity_Model_DbTable_Notifications
{
    protected $_rowClass = 'Advnotifications_Model_Advnotification';
    //protected $_name = 'activity_advnotifications';
}
