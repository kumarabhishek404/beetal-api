<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Avatarstyler
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    Id: install.php 18.10.13 14:26 Ulan T $
 * @author     Ulan T
 */

/**
 * @category   Application_Extensions
 * @package    Avatarstyler
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Advnotifications_Installer extends Engine_Package_Installer_Module
{
  public function onPreInstall()
  {
     parent::onPreInstall();
     $db = $this->getDb();
     $db->query("CREATE TABLE IF NOT EXISTS `engine4_advnotifications_advnotifications` (
  `notification_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `subject_type` varchar(24) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `subject_id` int(11) unsigned NOT NULL,
  `object_type` varchar(24) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `object_id` int(11) unsigned NOT NULL,
  `type` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `params` text COLLATE utf8_unicode_ci,
  `read` tinyint(1) NOT NULL DEFAULT '0',
  `mitigated` tinyint(1) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL,
  `is_shown` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
");

 $db->query("ALTER TABLE `engine4_advnotifications_advnotifications`
  ADD PRIMARY KEY (`notification_id`),
  ADD KEY `LOOKUP` (`user_id`,`date`),
  ADD KEY `subject` (`subject_type`,`subject_id`),
  ADD KEY `object` (`object_type`,`object_id`)");

 $db->query("ALTER TABLE `engine4_advnotifications_advnotifications` MODIFY `notification_id` int(11) unsigned NOT NULL AUTO_INCREMENT;");

 $db->getConnection()->query("DROP TRIGGER IF EXISTS activity_notification_after");

 $db->getConnection()->query("CREATE TRIGGER activity_notification_after AFTER INSERT ON engine4_activity_notifications FOR EACH ROW INSERT INTO engine4_advnotifications_advnotifications(notification_id,user_id,subject_type,subject_id,object_type,object_id,type,params,mitigated,date) VALUES(NEW.notification_id,NEW.user_id,NEW.subject_type,NEW.subject_id,NEW.object_type,NEW.object_id,NEW.type,NEW.params,NEW.mitigated,NEW.date)");
  }
}
