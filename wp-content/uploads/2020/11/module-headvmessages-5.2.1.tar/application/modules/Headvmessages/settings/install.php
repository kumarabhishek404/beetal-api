<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Avatarstyler
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    Id: install.php 18.10.13 14:26 Ulan T $
 * @author     Ulan T
 */

/**
 * @category   Application_Extensions
 * @package    Avatarstyler
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */

class Headvmessages_Installer extends Engine_Package_Installer_Module
{

    public function onPreInstall()
    {
        parent::onPreInstall();

        $db = $this->getDb();
        $db->query("INSERT IGNORE INTO `engine4_core_menuitems` ( `name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES
('core_admin_main_plugins_headvmessages', 'headvmessages', 'HE - Advanced Messages', NULL, '{\"route\":\"admin_default\",\"module\":\"headvmessages\",\"controller\":\"index\"}', 'core_admin_main_plugins', NULL, 1, 0, 888),
('headvmessages_admin_main_index', 'headvmessages', 'Global Settings', NULL, '{\"route\":\"admin_default\",\"module\":\"headvmessages\",\"controller\":\"index\",\"action\":\"index\"}', 'headvmessages_admin_main', NULL, 1, 0, 1),
('headvmessages_admin_main_levels', 'headvmessages', 'Levels Settings', NULL, '{\"route\":\"admin_default\",\"module\":\"headvmessages\",\"controller\":\"index\",\"action\":\"levels\"}', 'headvmessages_admin_main', NULL, 1, 0, 2);
");
        
        $db->query("INSERT IGNORE INTO `engine4_authorization_permissions` (`level_id`, `type`, `name`, `value`, `params`) VALUES
(1, 'headvmessages', 'use', 1, NULL),
(2, 'headvmessages', 'use', 1, NULL),
(3, 'headvmessages', 'use', 1, NULL),
(4, 'headvmessages', 'use', 1, NULL),
(5, 'headvmessages', 'use', 0, NULL);");
        
        $db->query("INSERT IGNORE INTO `engine4_core_settings` (`name`, `value`) VALUES
('headvmessages.enabled', '1'),
('headvmessages.enter.send.enabled', '1');");
        
    }
}
