<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Wall
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 * @version    $Id: Smiles.php 18.06.12 10:52 michael $
 * @author     Michael
 */

/**
 * @category   Application_Extensions
 * @package    Headvmessages
 * @copyright  Copyright Hire-Experts LLC
 * @license    http://www.hire-experts.com
 */


class Headvmessages_View_Helper_Smiles extends Zend_View_Helper_Abstract
{
  protected $Smiles;
  protected $version;
  public $wall = false;
  public $heemoticon = false;
  public function __construct()
  {
    $modules =  Engine_Api::_()->getDbTable('modules', 'core');
    //$this->version = $modules->version;
    $select = $modules->select()
        ->where('name = ?', 'wall')
        ->where('enabled = ?', 1);
    $select2 = $modules->select()
        ->where('name = ?', 'heemoticon')
        ->where('enabled = ?', 1);

    $wall = $modules->fetchRow($select);
    $heemoticon = $modules->fetchRow($select2);
    if($wall){
      $this->wall = true;
      $this->Smiles = Engine_Api::_()->getDbTable('smiles', 'wall')->getPaginator()->getCurrentItems();
    }
    if($heemoticon) $this->heemoticon = true;


  }
  public function _baseUrl()
  {
    $base_url = '';
    if (version_compare($this->version, '4.1.8', '>=')){
      $base_url = $this->view->layout()->staticBaseUrl;
    } else {
      $base_url = $this->view->baseUrl() . '/';
    }
    return $base_url;

  }

  public function Smiles()
  {
    return $this;
  }

  public function replaceHeemoticon($content)
  {

    if($this->heemoticon) {
      $base_url = $this->_baseUrl();
      preg_match_all('/\(H\)(.*?)\(\/H\)/s', $content, $text);
      for ($i = 0; $i < count($text[1]); $i++) {

        if (intval($text[1][$i])) {
          $sticker_id = $text[1][$i];
          $viewer = Engine_Api::_()->user()->getViewer();
          $useds = Engine_Api::_()->getDbTable('useds', 'heemoticon');
          $used_select = $useds->select()
              ->where('sticker_id = ?', $sticker_id);
          $used = $useds->fetchRow($used_select);

          if ($used) {
            $used = $used->toArray();
            $user_id = $viewer->getIdentity();
            $img_url = $used['url'] . '?row=' . $user_id;
          }
          $stickers = Engine_Api::_()->getDbTable('stickers', 'heemoticon');
          $select = $stickers->select()
              ->where('sticker_id = ?', $sticker_id);
          $sticker = $stickers->fetchRow($select);
          if ($sticker) {

            $sticker = $sticker->toArray();
            $origin = explode('?', APPLICATION_PATH . DIRECTORY_SEPARATOR . $sticker['url']);
            $dest = explode(basename($origin[0]), $origin[0]);
            $nu = explode(basename($origin[0]), $sticker['url']);
            $newurluse = $nu[0] . 'work_' . basename($origin[0]);
            $new_url = $dest[0] . 'work_' . basename($origin[0]);
            $st = $this->smileCopy($origin[0], $new_url);
            $user_id = $viewer->getIdentity();
            $img_url = $newurluse . '?row=' . $user_id;

          }
          if ($nu) {
            $img = '<img class="heemoticon" src="' . $img_url . '"/>';
            $content = str_replace('(H)' . $text[1][$i] . '(/H)', $img, $content);
          }

        }
      }
    }
    if($this->wall){
      return $this->replaceWallSmiles($content);
    }else{
      return $content;
    }



  }
  public function smileCopy($source, $dest, $options = array('folderPermission' => 0755, 'filePermission' => 0755))
  {
    $result = false;

    if (is_file($source)) {
      if ($dest[strlen($dest) - 1] == DIRECTORY_SEPARATOR) {
        if (!file_exists($dest)) {
          cmfcDirectory::makeAll($dest, $options['folderPermission'], true);
        }
        $__dest = $dest . DIRECTORY_SEPARATOR . basename($source);
      } else {
        $__dest = $dest;
      }
      $result = copy($source, $__dest);
      chmod($__dest, $options['filePermission']);

    } elseif (is_dir($source)) {
      if ($dest[strlen($dest) - 1] == DIRECTORY_SEPARATOR) {
        if ($source[strlen($source) - 1] == DIRECTORY_SEPARATOR) {
          //Copy only contents
        } else {
          //Change parent itself and its contents
          $dest = $dest . basename($source);
          @mkdir($dest);
          chmod($dest, $options['filePermission']);
        }
      } else {
        if ($source[strlen($source) - 1] == DIRECTORY_SEPARATOR) {
          //Copy parent directory with new name and all its content
          @mkdir($dest, $options['folderPermission']);
          chmod($dest, $options['filePermission']);
        } else {
          //Copy parent directory with new name and all its content
          @mkdir($dest, $options['folderPermission']);
          chmod($dest, $options['filePermission']);
        }
      }

      $dirHandle = opendir($source);
      while ($file = readdir($dirHandle)) {
        if ($file != "." && $file != "..") {
          if (!is_dir($source . DIRECTORY_SEPARATOR . $file)) {
            $__dest = $dest . DIRECTORY_SEPARATOR . $file;
          } else {
            $__dest = $dest . DIRECTORY_SEPARATOR . $file;
          }

          $result = smileCopy($source . DIRECTORY_SEPARATOR . $file, $__dest, $options);
        }
      }
      closedir($dirHandle);

    } else {
      $result = false;
    }
    return $result;
  }

  public function replaceWallSmiles($content)
  {
    $base_url = $this->_baseUrl();

    $smiles = array();

    foreach ($this->Smiles as $item){
      $smiles[] = $item;
    }
    usort($smiles, array($this, "sortSmiles"));


    foreach ($smiles as $item){

      $src = '';
      if ($item->file_id){

      } else {
        $src = $base_url . $item->file_src;
      }
      $html = '<img src="'.$src.'" class="wall_smile" alt="'.$item->title.'" />';
      $list_tag = array();
      foreach (explode(',', $item->tag) as $tag){
        $list_tag[] = trim($tag);
      }
      $content = str_ireplace($list_tag, $html, $content);
    }

    return $content;

  }

  protected  function sortSmiles($a, $b)
  {
    return strlen( (string) $a->tag ) < strlen( (string) $b->tag );
  }

  public function getJson()
  {
    $base_url = $this->_baseUrl();
    $data = array();


    foreach ($this->Smiles as $item){
      $src = '';
      if ($item->file_id){

      } else {
        $src = $base_url . $item->file_src;
      }
      $html = '<img src="'.$src.'" class="wall_smile" alt="'.$item->title.'" />';
      $json_item = $item->toArray();
      $json_item['html'] = $html;
      $json_item['title'] = $this->view->translate('WALL_' . strtoupper(str_replace(" ", "_", $json_item['title'])));

      $list_tag = array();
      foreach (explode(',', $item->tag) as $tag){
        $list_tag[] = trim($tag);
      }
      $index_tag = (empty($list_tag[0])) ? '': $list_tag[0];
      $json_item['index_tag'] = trim($index_tag);
      $data[] = $json_item;
    }

    return Zend_Json::encode($data);
  }



}
