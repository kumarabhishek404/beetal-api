
UPDATE `engine4_core_modules` SET `version` = '4.2.0'  WHERE `name` = 'pagevideo';