INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES  
('pagevideo', 'Page Video', 'Page Video Plugin', '4.2.2', 1, 'extra');