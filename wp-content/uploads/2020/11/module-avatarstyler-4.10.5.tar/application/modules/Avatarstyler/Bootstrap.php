<?php

class Avatarstyler_Bootstrap extends Engine_Application_Bootstrap_Abstract
{
    public function __construct($application)
    {
        // Add view helper and action helper paths
        parent::__construct($application);
        $this->initViewHelperPath();
        $view = Zend_Registry::get('Zend_View');
        $view->headLink() ->appendStylesheet($view->layout()->staticBaseUrl
            . 'application/libraries/Hireexperts/externals/styles/main.css');
    }
}