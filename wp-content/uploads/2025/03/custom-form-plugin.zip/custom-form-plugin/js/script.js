var uploadedFiles = [];

document.addEventListener("DOMContentLoaded", function () {
    const radioButtons = document.querySelectorAll(
        'input[name="form2_radio_option"]'
    );
    const radioButtonsForm3 = document.querySelectorAll(
        'input[name="ipo-allotment-radio-option"]'
    );
    const radioButtonsLoginForm = document.querySelectorAll(
        'input[name="login_radio_option"]'
    );
    const dynamicField = document.getElementById("form2-dynamic-field");
    const dynamicFieldForm3 = document.getElementById(
        "ipo-allotment-dynamic-field"
    );
    const dynamicFieldFormLogin = document.getElementById("dynamic-field-login");
    // console.log('dynamicField', dynamicField);
    radioButtons.forEach((radio) => {
        radio.addEventListener("change", function () {
            this.checked = true;
            // if (this.checked) {
            dynamicField.placeholder = this.value;
            // }
        });
    });
    radioButtonsForm3.forEach((radio) => {
        radio.addEventListener("change", function () {
            this.checked = true;
            // if (this.checked) {
            dynamicFieldForm3.value = '';
            dynamicFieldForm3.placeholder = this.value;
            // }
        });
    });
    radioButtonsLoginForm.forEach((radio) => {
        radio.addEventListener("change", function () {
            this.checked = true;
            // if (this.checked) {
            dynamicFieldFormLogin.placeholder = this.value;
            dynamicFieldFormLogin.value = '';
            // }
        });
    });

    const tabs = document.querySelectorAll(".tab");
    const contents = document.querySelectorAll(".tab-content");

    tabs.forEach((tab) => {
        tab.addEventListener("click", function () {
            tabs.forEach((t) => t.classList.remove("active"));
            contents.forEach((c) => c.classList.remove("active"));

            tab.classList.add("active");
            document
                .getElementById(tab.getAttribute("data-tab"))
                .classList.add("active");
        });
    });
    showDataOnURLChange();

    const menuToggleIcon = document.getElementById("menuToggleIcon");
    const menuCollapse = document.getElementById("menuCollapse");

    if (menuToggleIcon && menuCollapse) {
        // Add event listener for when the menu is shown
        menuCollapse.addEventListener("shown.bs.collapse", function () {
            menuToggleIcon.classList.add("rotate-icon");
        });

        // Add event listener for when the menu is hidden
        menuCollapse.addEventListener("hidden.bs.collapse", function () {
            menuToggleIcon.classList.remove("rotate-icon");
        });
    }

    let header = document.querySelector(".ast-below-header-wrap");
    let logo = document.querySelector(".ast-header-html-2");
    let originalPosition = header.offsetTop;
    let timeout;

    if (header) {
        window.addEventListener("scroll", function () {
            if (window.scrollY > originalPosition) {
                header.classList.add("sticky-header");
                header.classList.add("visible");
                if (logo) {
                    logo.style.display = "block";
                }
            } else {
                header.classList.remove("visible");
                header.classList.remove("sticky-header");
                if (logo) {
                    logo.style.display = "none";
                }
            }
        });
    }
});

window.addEventListener("hashchange", function () {
    showDataOnURLChange();
});

function showLoadingScreen() {
    const loadingScreen = document.createElement("div");
    loadingScreen.id = "loading-screen";
    loadingScreen.classList.add("loading");
    loadingScreen.innerHTML = '<div class="loader"></div>';

    document.body.appendChild(loadingScreen);
}

// Function to hide the loading screen
function hideLoadingScreen() {
    const loadingScreen = document.getElementById("loading-screen");
    if (loadingScreen) {
        loadingScreen.remove();
    }
}

// Show the loading screen before reload

// Hide the loading screen after the page has loaded

function showDataOnURLChange() {
    const fragment = window.location.hash.substring(1); // Get the string after #
    if (fragment) {
        if (fragment === "IPO_Allotment_Status") {
            openForm("form1", "tab1");
        } else if (fragment === "Open_Buyback_right_issue") {
            openForm("form2", "tab2");
        } else if (fragment === "KYC_Compliance") {
            openForm("form3", "tab3");
        } else if (fragment === "TDS_Exemption") {
            openForm("form4", "tab4");
        } else if (fragment === "Investor_Service_Request") {
            openForm("form5", "tab5");
        }
    }
}

function replaceTabParameter(newCompanyName, tabName) {
    // Get the current URL
    const currentURL = window.location.href;

    // Extract the URL parameters
    // const currentURL_split_hash = currentURL.split("#")[0];
    const removeHash = currentURL.split("#")[0];
    let urlParams = removeHash.split("?")[0];
    // Construct the new URL
    const newURL = `${urlParams.toString()}?company=${newCompanyName}#${tabName}`;
    // Redirect to the new URL
    window.history.pushState({}, "", newURL);
}

function openForm(formId, tabId) {

        document
            .querySelectorAll(".form-container")
            .forEach((form) => (form.style.display = "none"));
        document.querySelectorAll(".menu-items").forEach((form) => {
            form.classList.remove("menu-active");
            form.classList.add("text-white");
        });
        document
            .querySelectorAll(".tabs")
            .forEach((form) => (form.style.display = "none"));
    if (document.getElementById(formId)) {
        document.getElementById(formId).style.display = "block";
    }
    if (document.getElementById(tabId)) {
        document.getElementById(tabId).style.display = "block";
         document
           .getElementById(`${formId}${tabId}`)
           .classList.add("menu-active");
         document
           .getElementById(`${formId}${tabId}`)
           .classList.remove("text-white");
    } else {
         document
           .getElementById(`${formId}tab5`)
           .classList.add("menu-active");
         document
           .getElementById(`${formId}tab5`)
           .classList.remove("text-white");
    }
    
       
}

function changeTab(url, tab) {
    if (tab === "Investor_Service_Request") {
        window.location.href = `${url}/#${tab}`;
        // window.addEventListener("beforeunload", showLoadingScreen);
        // window.location.reload();
        // window.addEventListener("load", hideLoadingScreen);

    } else {
        window.location.href = `${url}/#${tab}`;
    }
}

function fetchLoginDataFromURL(params) {
    // console.log("Fetching login data for ", params);
    return new Promise(resolve => {
        jQuery.ajax({
            url: ajaxurl,
            method: "POST",
            data: { ...params },
            success: function (response) {
                console.log(response);
                if (response.success) {
                    resolve({ status: true });
                } else {
                    resolve({ status: false, message: response?.data?.message });
                }
            },
            error: function () {
                resolve({ status: false, message: "Something went wrong, try again later..." });
            },
        });
    });
}

function cfpShowSuccessMessage(
    message
) {
    jQuery(document).ready(function ($) {
        // Create a temporary error message div
        var errorDiv = $('<div class="success-message">' + message + "</div>");
        $("body").append(errorDiv);

        // Show the error message for 1 second
        setTimeout(function () {
            errorDiv.fadeOut("fast", function () {
                errorDiv.remove();
            });
        }, 8000);
    });
}

function cfpShowErrorMessage(
    message = "Oops! The server is currently unavailable. Please try again later. If the issue persists, please contact the administrator."
) {
    jQuery(document).ready(function ($) {
        // Create a temporary error message div
        var errorDiv = $('<div class="error-message">' + message + "</div>");
        $("body").append(errorDiv);

        // Show the error message for 1 second
        setTimeout(function () {
            errorDiv.fadeOut("fast", function () {
                errorDiv.remove();
            });
        }, 8000);
    });
}

function redirectUser(url) {
    const fragment = window.location.hash.substring(1);
    if (fragment === "Investor_Service_Request") {
        window.location.href = url;
    }
}

function offer_html(data) {
    return `
      <div id="show_allotment_result">
        <h3 class="mb-0">Offer Status</h3>
        <hr class="">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between flex-wrap">
                    <div class="d-flex h5 gap-2"><i class="bi bi-person-fill text-blue"></i>${data.name
        }</div>
                    <div class="h5 d-flex gap-2">
                        <i class="bi bi-check-circle-fill ${+data.alloted_shares < +data.applied_shares
            ? "text-danger"
            : "text-success"
        }"></i>
                        ${+data.alloted_shares} out of ${+data.applied_shares}
                    </div>
                </div>
                <div class="d-flex justify-content-between gap-5">
                    <div class="d-flex col-6 flex-fill justify-content-between justify-content-md-start gap-3">
                        <div class="d-flex flex-column gap-1">
                            <div class="d-flex gap-2"><i class="bi bi-person-vcard-fill text-blue me-1"></i>PAN</div>
                             <div class="d-flex gap-2"><i class="bi bi-person-lines-fill text-blue me-1"></i>DPID/Client </div>
                             <div class="d-flex gap-2 d-md-none"><i class="bi bi-file-earmark-text-fill text-blue me-1"></i>Application No. </div>
                        </div>
                        <div class="d-flex flex-column align-items-end align-items-md-start gap-1">
                           <div> ${data.pan_number}</div>
                            <div>${data.client_id}</div>
                            <div class="d-md-none">${data.application_number
        }</div>
                        </div>
                    </div>
                    <div class="col-6 flex-fill d-none d-md-flex gap-3 justify-content-end">
                        <div class="d-flex gap-2"><i class="bi bi-file-earmark-text-fill text-blue"></i>Application No. </div>
                        <div>${data.application_number}</div>
                    </div>
                </div>
            </div>
        </div>
    </div>`;
}

function ipo_allotment_html(data) {
    return `
      <div id="show_allotment_result" class="mx-4 mx-md-5 my-5">
        <h3 class="mb-0">Allotment Status</h3>
        <hr class="">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between flex-wrap">
                    <div class="d-flex h5 gap-2"><i class="bi bi-person-fill text-blue"></i>${data.name
        }</div>
                    <div class="h5 d-flex gap-2">
                        <i class="bi bi-check-circle-fill ${+data.alloted_shares < +data.applied_shares
            ? "text-danger"
            : "text-success"
        }"></i>
                        ${+data.alloted_shares} out of ${+data.applied_shares}
                    </div>
                </div>
                <div class="d-flex justify-content-between gap-5">
                    <div class="d-flex col-6 flex-fill justify-content-between justify-content-md-start gap-3">
                        <div class="d-flex flex-column gap-1">
                            <div class="d-flex gap-2"><i class="bi bi-person-vcard-fill text-blue me-1"></i>PAN</div>
                             <div class="d-flex gap-2"><i class="bi bi-person-lines-fill text-blue me-1"></i>DPID/Client </div>
                             <div class="d-flex gap-2 d-md-none"><i class="bi bi-file-earmark-text-fill text-blue me-1"></i>Application No. </div>
                        </div>
                        <div class="d-flex flex-column align-items-end align-items-md-start gap-1">
                           <div> ${data.pan_number}</div>
                            <div>${data.client_id}</div>
                            <div class="d-md-none">${data.application_number
        }</div>
                        </div>
                    </div>
                    <div class="col-6 flex-fill d-none d-md-flex gap-3 justify-content-end">
                        <div class="d-flex gap-2"><i class="bi bi-file-earmark-text-fill text-blue"></i>Application No. </div>
                        <div>${data.application_number}</div>
                    </div>
                </div>
            </div>
        </div>
    </div>`;
}

function sendAjaxRequestToDisplayResources(company, $) {
    // console.log(company);
    if (!company || !$) {
        if ($(".show-tab2-resources")) $(".show-tab2-resources").remove();
        return;
    }
    if ($(".show-tab2-resources")) $(".show-tab2-resources").remove();
    $("#company-data").remove();

    $('.loading-tab2-resources').removeClass('d-none');
    $.ajax({
        url: ajaxurl, // WordPress AJAX URL provided by default
        type: "POST",
        data: {
            action: "tab2_download_resources", // Action name defined in PHP
            company_name: company,
        },
        success: function (response) {
            if (response.success) {
                console.log(response.data);
                $("#tab2").append(response.data.download);
                $("#form2-company-name").text('');
                $("#form2-company-name").append(response.data.company);

            }
            $(".loading-tab2-resources").addClass("d-none");

        },
        error: function () {
            $(".loading-tab2-resources").addClass("d-none");

        },
    });
}

jQuery(document).ready(async function ($) {

    jQuery("#login-form").validate({
        rules: {
            email_phone: {
                required: true,
                email: true,
            },
            folio_number: {
                required: true,
            },
            company_login: {
                required: true,
            }
        },
        messages: {
            email_phone: {
                required: "Please enter your email address",
                email: "Please enter a valid email address or phone number",
            },
            folio_number: "Please fill the folio number",
            company_login: "Select company name",
        },
    });

    jQuery("#login-form").on("submit", async function (e) {
        e.preventDefault();
        jQuery("#form-message").remove();

        let formData = jQuery(this).serialize();
        let params = new URLSearchParams(formData);
        let email_phone = params.get("dynamic-value-field");
        let radio_selected = params.get("login_radio_option");
        let company_login = params.get("company_login");
        let folio_number = params.get("folio_number_login");

        if (!company_login && !email_phone && !folio_number) {
            jQuery("#login-form").append(`
                    <div id="form-message" style="color: red; margin-top: 10px;">
                        Please fill in the following fields: Company, Email/Phone number & Folio number.
                    </div>
                `);
            return;
        }
        if (!company_login) {
            jQuery("#login-form").append(`
                    <div id="form-message" style="color: red; margin-top: 10px;">
                        Please select a company
                    </div>
                `);
            return;
        }
        if (params.has("dynamic-value-field")) {
            if (!email_phone) {
                jQuery("#login-form").append(`
                    <div id="form-message" style="color: red; margin-top: 10px;">
                        Please enter a valid email address or phone number
                    </div>
                `);
                return;
            }
            if (radio_selected === "Enter your email") {
                let parts = email_phone.split("@");
                if (parts.length !== 2) {
                    jQuery("#login-form").append(`
                    <div id="form-message" style="color: red; margin-top: 10px;">
                        Please enter a valid email
                    </div>
                `);
                    return false;
                }

                let localPart = parts[0];
                let domainPart = parts[1];

                if (!localPart || /\s/.test(localPart)) {
                    jQuery("#login-form").append(`
                    <div id="form-message" style="color: red; margin-top: 10px;">
                        Please enter a valid email
                    </div>
                `);
                    return false;
                }
                if (!domainPart || domainPart.indexOf(".") === -1) {
                    jQuery("#login-form").append(`
                    <div id="form-message" style="color: red; margin-top: 10px;">
                        Please enter a valid email
                    </div>
                `);
                    return false;
                }
                let domainParts = domainPart.split(".");

                for (let i = 0; i < domainParts.length; i++) {
                    if (!domainParts[i]) {
                        jQuery("#login-form").append(`
                    <div id="form-message" style="color: red; margin-top: 10px;">
                        Please enter a valid email
                    </div>
                `);
                        return false;
                    }
                }
            } else if (radio_selected === "Enter your phone number") {
                if (email_phone.length !== 10) {
                    jQuery("#login-form").append(`
                    <div id="form-message" style="color: red; margin-top: 10px;">
                        Please enter a valid phone number
                    </div>
                `);
                    return false;
                }
            }
        } else {
            jQuery("#login-form").append(`
                    <div id="form-message" style="color: red; margin-top: 10px;">
                        Please enter a valid email address or phone number
                    </div>
                `);
            return;
        }

        if (!folio_number) {
            // alert('Please fill in all required fields.');
            jQuery("#login-form").append(`
                    <div id="form-message" style="color: red; margin-top: 10px;">
                        Please enter a valid folio number
                    </div>
                `);
            return;
        }
        // console.log("processing...");

        jQuery(".login_loader").show();
        jQuery(".login_none_loader").hide();
        jQuery(".login_resend_loader").hide();
        jQuery(".sending_otp_login_loader").hide();
        // console.log(ajaxurl);
        const data = {
            action: "verify_folio_info",
            folio_number,
            company_login,
            email: radio_selected === "Enter your email" ? email_phone : null,
            phone: radio_selected === "Enter your email" ? null : email_phone,
        };
        await fetchLoginDataFromURL(data).then(async fetchResult => {
            if (fetchResult?.status) {
                //send OTP notification
                jQuery(".login_loader").hide();
                jQuery(".login_none_loader").hide();
                jQuery(".login_resend_loader").hide();
                jQuery(".sending_otp_login_loader").show();
                jQuery.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'send_otp',
                        type: radio_selected === 'Enter your email' ? 'email' : 'phone',
                        recipient: email_phone,
                    },
                    success: function (response) {
                        // cfpShowSuccessMessage(response.data);
                        jQuery("#login-form").append(`
                    <div id="form-message" style="color: #218838; margin-top: 10px; margin-bottom: 10px;">
                        ${response.data}
                    </div>
                `);
                        jQuery("#show-login-form-otp").show();
                        jQuery(".login_loader").hide();
                        jQuery(".login_none_loader").hide();
                        jQuery(".login_resend_loader").show();
                        jQuery(".sending_otp_login_loader").hide();
                    },
                    error: function () {
                        // cfpShowErrorMessage();
                        jQuery("#login-form").append(`
                    <div id="form-message" style="color: red; margin-top: 10px;">
                       Oops! The server is currently unavailable. Please try again later. If the issue persists, please contact the administrator.
                    </div>
                `);
                        jQuery("#show-login-form-otp").hide();
                        jQuery(".login_loader").hide();
                        jQuery(".login_none_loader").show();
                        jQuery(".login_resend_loader").hide();
                        jQuery(".sending_otp_login_loader").hide();
                    }
                });
            } else {
                // cfpShowErrorMessage(fetchResult?.message);
                jQuery("#login-form").append(`
                    <div id="form-message" style="color: red; margin-top: 10px;">
                        ${fetchResult?.message ||
                    "Oops! The server is currently unavailable. Please try again later. If the issue persists, please contact the administrator."
                    }
                    </div>
                `);
                jQuery(".login_loader").hide();
                jQuery(".login_none_loader").show();
                jQuery(".login_resend_loader").hide();
                jQuery(".sending_otp_login_loader").hide();
            }
        });
    });

    jQuery("#show-login-form-otp").validate({
        rules: {
            verify_otp: {
                required: true,
            }
        },
        messages: {
            verify_otp: "Please fill the OTP",
        },
    });

    jQuery("#show-login-form-otp").on("submit", async function (e) {
        e.preventDefault();
        jQuery("#form-message").remove();

        let formData = jQuery(this).serialize();
        let params = new URLSearchParams(formData);
        let otp = params.get("verify-otp-login");
        let email_phone = jQuery("#dynamic-field-login").val();
        let radio_selected = jQuery("input[name='login_radio_option']:checked").val();
        let company_login = jQuery("#company_login").val();
        let folio_number = jQuery("#folio_number_login").val();
        // console.log({ email_phone, radio_selected, company_login, folio_number });

        if (!otp) {
            jQuery("#show-login-form-otp").append(`
                        <div id="form-message" style="color: red; margin-top: 10px;">
                            Please enter the OTP.
                        </div>
                    `);
            return;
        } else if (otp.length != 6) {
            jQuery("#show-login-form-otp").append(`
                        <div id="form-message" style="color: red; margin-top: 10px;">
                            Please enter a valid OTP.
                        </div>
                    `);
            return;
        } else {
            jQuery(".verify_otp_none_loader").hide();
            jQuery(".redirect_verify_otp_loader").hide();
            jQuery(".verify_otp_loader").show();

            jQuery.ajax({
                url: ajaxurl,
                type: "POST",
                data: {
                    action: "custom_user_login", // Action name defined in PHP
                    email: radio_selected === 'Enter your email' ? email_phone : null,
                    phone: radio_selected === 'Enter your email' ? null : email_phone,
                    company_login: company_login,
                    folio_number: folio_number,
                    otp
                },
                success: function (response) {
                    // console.log(response);
                    if (response.success) {
                        jQuery(".redirect_verify_otp_loader").show();
                        jQuery(".verify_otp_loader").hide();
                        // cfpShowSuccessMessage(response.data.message);
                        jQuery("#show-login-form-otp").append(`
                        <div id="form-message" style="color: #218838; margin-top: 10px;">
                            ${response.data.message}
                        </div>
                    `);
                        window.location.href =
                            response?.data?.redirect_url ||
                            "https://pragmaappscstg.wpengine.com/investor-service-request";
                        // new Promise(resolve => {
                        //     setTimeout(() => {
                        //         resolve(
                        //             window.location.href = response?.data?.redirect_url || "https://pragmaappscstg.wpengine.com/investor-service-request"
                        //             //response.data.redirect_url
                        //         );
                        //     }, 1000);
                        // });
                    } else {
                        // cfpShowErrorMessage();
                        jQuery("#show-login-form-otp").append(`
                        <div id="form-message" style="color: red; margin-top: 10px;">
                            ${response.data.message}
                        </div>
                    `);
                        jQuery(".login_loader").hide();
                        jQuery(".login_none_loader").hide();
                        jQuery(".login_resend_loader").show();
                        jQuery(".sending_otp_login_loader").hide();
                        jQuery(".verify_otp_none_loader").show();
                        jQuery(".verify_otp_loader").hide();
                    }
                },
                error: function () {
                    // cfpShowErrorMessage();
                    jQuery("#show-login-form-otp").append(`
                        <div id="form-message" style="color:red; margin-top: 10px;">
                            Oops! The server is currently unavailable. Please try again in a little while.
                        </div>
                    `);
                    jQuery(".login_none_loader").hide();
                    jQuery(".login_loader").hide();
                    jQuery(".login_resend_loader").hide();
                    jQuery(".sending_otp_login_loader").show();
                    jQuery(".verify_otp_none_loader").show();
                    jQuery(".verify_otp_loader").hide();
                    jQuery('#show-login-form-otp').text('An error occurred while processing your request.').css('color', 'red');
                },
            });
        }
    });

    jQuery("#signup-form").validate({
        rules: {
            signup_email: {
                required: true,
                email: true,
            },
            signup_phone: {
                required: true,
                minlength: 10,
                maxlength: 10,
            },
            signup_username: {
                required: true,
            },
            pan: {
                required: true,
            },
            signup_password: {
                required: true,
            },
        },
        messages: {
            signup_email: {
                required: "Please enter your email address",
                email: "Please enter a valid email address",
            },
            signup_phone: {
                required: "Please enter your phone number",
                minlength: "Phone number must be at least 10 digits",
                maxlength: "Phone number cannot exceed 10 digits",
            },
            signup_username: "This field is required",
            pan: "This field is required",
            signup_password: "Please fill the password",
        },
    });

    jQuery("#signup-form").on("submit", function (e) {
        e.preventDefault();
        // console.log("Form submiitteddd");
        let formData = jQuery(this).serialize();
        let params = new URLSearchParams(formData);
        let phone = params.get("signup_phone");
        let email = params.get("signup_email");
        let pan = params.get("pan");
        let password = params.get("signup_password");
        let username = params.get("signup_username");

        if (params.has("signup_email")) {
            if (!email) {
                return;
            }
            let parts = email.split("@");
            if (parts.length !== 2) {
                return false;
            }

            let localPart = parts[0];
            let domainPart = parts[1];

            if (!localPart || /\s/.test(localPart)) {
                return false;
            }
            if (!domainPart || domainPart.indexOf(".") === -1) {
                return false;
            }
            let domainParts = domainPart.split(".");

            for (let i = 0; i < domainParts.length; i++) {
                if (!domainParts[i]) {
                    return false;
                }
            }
        }
        if (params.has("signup_phone")) {
            if (!phone || phone.length != 10) {
                return false;
            }
        }

        if (!password || !username || !phone || !pan) {
            // alert('Please fill in all required fields.');
            return;
        }
        jQuery(".signup_loader").show();
        jQuery(".signup_none_loader").hide();
        jQuery.ajax({
            url: ajaxurl, // WordPress AJAX URL provided by default
            type: "POST",
            data: {
                action: "register_new_user", // Action name defined in PHP
                email: email,
                password: password,
                phone: phone,
                pan: pan,
                username: username,
            },
            success: function (response) {
                if (response.success) {
                    // console.log("In if condition user register");
                    jQuery.ajax({
                        url: ajaxurl,
                        type: "POST",
                        data: {
                            action: "custom_user_login", // Action name defined in PHP
                            email: email,
                            password: password,
                        },
                        success: function (response) {
                            console.log(response);
                            if (response.success) {
                                // jQuery('.signup_loader').hide()
                                jQuery(".signup_loader").hide();
                                jQuery(".signup_none_loader").show();
                                window.location.href =
                                    "https://pragmaappscstg.wpengine.com/investor-service-request"; // Replace with your desired page
                            } else {
                                jQuery("#signup-form").append(`
                                    <div id="form-message" style="color: red; margin-top: 10px;">
                                        ${response.data.message}
                                    </div>
                                `);
                                jQuery(".signup_loader").hide();
                                jQuery(".signup_none_loader").show();
                            }
                        },
                        error: function () {
                            jQuery(".signup_loader").hide();
                            jQuery(".signup_none_loader").show();
                            // jQuery('#login-message').text('An error occurred while processing your request.').css('color', 'red');
                        },
                    });
                } else {
                    jQuery("#signup-form").append(`
                        <div id="form-message" style="color: red; margin-top: 10px;">
                            ${response.data.message}
                        </div>
                    `);
                    jQuery(".signup_loader").hide();
                    jQuery(".signup_none_loader").show();
                }
            },
            error: function () {
                jQuery(".signup_loader").hide();
                jQuery(".signup_none_loader").show();
                // jQuery('#login-message').text('An error occurred while processing your request.').css('color', 'red');
            },
        });
    });

    $("#tab2_company_select_tab").on("change", function () {
        // Get the selected tab value
        var selectedTab = $(this).val();
        sendAjaxRequestToDisplayResources(selectedTab, $);
        replaceTabParameter(selectedTab, "Open_Buyback_right_issue");
    });

    $("#copy_of_form_10f_submitted_at").on("change", function (e) {
        $(".download-files-list").remove();
        let files = e.target.files;
        let outputHTML = `<div class="d-flex align-items-center gap-3 flex-wrap download-files-list">
    <div class="flex-nowrap d-none d-md-flex"> Uploaded files: </div>
    <div class="d-md-none d-flex col-12 flex-nowrap"> Uploaded files: </div>`;

        // Append selected files to the list
        $.each(files, function (index, file) {
            uploadedFiles.push(file);
        });
        outputHTML += `<div class="d-flex flex-row flex-wrap">`;
        uploadedFiles.forEach(function (file, fileId) {
            outputHTML += `
                <span class="badge badge-primary m-1 p-2 border-blue file-badge bg-white text-blue d-flex justify-content-between align-items-center text-wrap" style="font-size:12px;" data-id="${fileId}">
                    ${file.name} 
                    <i class="bi bi-x-circle text-danger remove-upload-file ms-2 fs-6" data-id="${fileId}"></i>
                </span>
            `;
        });

        outputHTML += `</div>`;
        outputHTML += `</div>`;
        $(".show-uploaded-form2-list").append(outputHTML);

        // Clear input to allow selecting the same file again
        $("#copy_of_form_10f_submitted_at").val("");
    });

    $(document).on("click", ".remove-upload-file", function () {
        if (uploadedFiles.length == 1) {
            uploadedFiles = [];
            $(".download-files-list").remove();
        }
        let fileId = $(this).data("id");
        uploadedFiles = uploadedFiles.filter((_, index) => index !== fileId);
        $(this).closest(".file-badge").remove();
        console.log("Uploading files...", uploadedFiles);
    });

    $("#tds-exemption-form").on("submit", async function (e) {
        e.preventDefault();
        showLoadingScreen();
        $(".alert").remove();

        let receivedFormData = jQuery(this).serialize();
        let params = new URLSearchParams(receivedFormData);

        let formData = new FormData();
        // Append files
        uploadedFiles.forEach((file) => {
            formData.append("files[]", file);
        });

        formData.append("action", "cfp_submit_tds_form");
        formData.append("tds_company_name", params.get("tds_company_name"));
        formData.append("financial_year", params.get("financial_year"));
        formData.append(
            "select_exemption_form_type",
            params.get("select_exemption_form_type")
        );
        formData.append("folio_number", params.get("folio_number"));
        formData.append("pan_number", params.get("pan_number"));
        formData.append("mobile_number", params.get("mobile_number"));
        formData.append("email_id", params.get("email_id"));
        formData.append("isin", params.get("isin"));

        jQuery.ajax({
            url: ajaxurl,
            type: "POST",
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {
                if (response.success && response?.data?.redirect_url) {
                    window.location.href = response.data.redirect_url;
                    showToastSuccessMessage(
                        `Request submitted!`
                    );
                } else {
                    showToastErrorMessage(response?.data);
                }
                hideLoadingScreen();
            },
            error: function () {
                hideLoadingScreen();
                showToastErrorMessage(
                    "An error occurred while submitting your ticket. If the issue persists, contact support."
                );
            },
        });
    });
});
